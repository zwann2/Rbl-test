# Redacted BannerLab v1.1.1-test.106

- Inventaire : remplacement systématique des anciens SVG de secours par les assets Ingress embarqués au build.
- Palette de rareté alignée sur le Scanner : Common `#3EF5C3`, Rare `#B78EFF`, Very Rare `#FF81FF`.
- Palette des niveaux L1 à L8 corrigée pour suivre les couleurs Prime.
- Les mods et objets non nivelés conservent désormais leurs couleurs propres : aucune recoloration artificielle par CSS.
- Le script d’intégration supprime les anciens placeholders avant de récupérer les assets, afin qu’un faux asset ne puisse plus se glisser dans l’APK.
