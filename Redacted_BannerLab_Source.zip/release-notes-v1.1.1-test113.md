# v1.1.1-test.113

- REDACTED RUN : descente accélérée, saut mis en mémoire juste avant l’atterrissage.
- Nouveaux obstacles aériens : certains punissent un saut inutile, d’autres passent au-dessus de Redacted.
- Ambiance du ciel cyclique : nuit, bleu Résistance, nuit, vert Enlightened, avec transitions progressives.
- RITA News : source unique de découverte = https://ingress.com/news ; les High Priority Updates et les dernières news sont extraites de cette page, puis chaque article est enrichi avec son contenu officiel.
- Actions distinctes : traduction Google de l’article et source originale.
