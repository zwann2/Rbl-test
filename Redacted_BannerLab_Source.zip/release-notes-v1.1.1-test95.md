# Redacted BannerLab v1.1.1-test.95

## MILO · installation Chrome revue

- Le tutoriel Chrome est reconstruit en 5 étapes qui suivent le vrai fonctionnement de MILO.
- Le test d'installation ne dépend plus d'une fresque complète et ne demande plus `MILO_CurrentBanner.json`. Il vérifie uniquement le favori Chrome et `MILO.user.js`.
- La confirmation de test revient automatiquement dans RBL via un jeton temporaire signé.
- Lors d'une vraie publication, RBL ouvre Mission Authoring avec un marqueur de session. Le favori MILO charge alors `MILO_CurrentBanner.json`.
- Au premier chargement seulement, Chrome demande de choisir `MILO_CurrentBanner.json`; le handle est ensuite mémorisé et réutilisé tant que Chrome conserve l'autorisation.
- MILO passe en 0.5.5 et le SHA-256 embarqué est resynchronisé.

Version Android : `1.1.1-test.95` · build `2100011095`.
