# Redacted BannerLab 1.1.1 TEST-77 CLEAN

- Navigation du Lab uniformisée : un seul bouton Ascenseur en haut des pages d’étage.
- Suppression des boutons Ascenseur dupliqués en bas.
- Sous-pages IGOR : retour Salle IGOR + bouton Ascenseur dans le même en-tête.
- Calcul AP exact et Timers rapprochés visuellement du palier LEON, avec accès Ascenseur cohérent.
- Tous les tutoriels guidés proposent « Ne plus afficher ». Ce choix coupe les tutoriels automatiques, tout en les laissant accessibles manuellement.
- Le tutoriel LEON se termine désormais sur le palier LEON, et non dans Calcul AP exact.
- MILO : texte de présentation traduit explicitement dans les 7 langues prioritaires.
- Sous-sol : suppression de la page intermédiaire ; animation d’accès restreint puis arrivée directe dans l’Arcade.
- Glyph Lab : intégré à l’Arcade sous forme de console expérimentale du sous-sol.
- Android versionCode 2100011077.
