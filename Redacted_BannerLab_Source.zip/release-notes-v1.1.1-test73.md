# Redacted BannerLab 1.1.1 TEST-73 CLEAN

Reconstruction depuis la base propre 1.1.0, sans reprendre en bloc les rustines TEST55-72.

- Ascenseur thématique réintégré proprement : cabine par étage, dernier bouton allumé, descriptions compactes, Redacted au premier lancement, personnages contextuels au retour.
- IGOR 0.6.35 réintégré depuis la branche récente.
- Inventaire : interface de base conservée, sans recoloration agressive.
- Inventaire : Beacon / Battle Beacon + correction ITO (+/-).
- Total inventaire : matériel + Portal Keys, avec détail clés dans le sac / rangées dans les conteneurs.
- Glyph Lab : base stable conservée ; tracé utilisateur refait sur le chemin réel du doigt avec courbe lissée, tête lumineuse, coordonnées SVG exactes et détection immédiate des nœuds.
- Arcade Glyph : progression 1/2/3/4/5 ralentie par paliers de trois séries, countdown raccourci, score/timer dans le HUD, vibrations optionnelles.
- Outils locaux ajoutés pour compiler hors GitHub et copier automatiquement l'APK vers un dossier Google Drive / OneDrive configurable.
- Android TEST : versionCode 2100011073.
