# Redacted BannerLab 1.1.1 TEST-88

- HUD REDACTED : **un seul clic** sur `SCANNER // REDACTED //` ouvre Redacted et ses anecdotes.
- Les **7 clics restent uniquement sur le logo de l’étage Fresque**, avec les interactions historiques du Lab.
- Ascenseur / sous-sol : l’étage Fresque est isolé et ne doit plus apparaître derrière l’ascenseur.
- HUD : `COMM` reste retiré. En bas à gauche, l’ancien libellé `SCANNER` est remplacé par **Redacted BannerLab + version**.
- Arcade : suppression du bouton permanent **LAB** en haut de la salle. La croix quitte l’Arcade depuis le menu et revient au menu depuis un jeu.
- **MILO · Glyph Lab** devient une vraie neuvième borne de l’Arcade, au même niveau que les autres jeux.
- Glyph Lab reçoit un briefing MILO, un tutoriel avant lancement et une présentation dédiée.
- Glyph Lab et son briefing MILO sont traduits dans les **20 langues** de Redacted BannerLab.
- Cohérence de version corrigée dans les sources : `1.1.1-test.88`, build `2100011088`.
