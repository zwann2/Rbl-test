# Redacted BannerLab 1.1.1 TEST-88

- HUD REDACTED : **un seul clic** sur `SCANNER // REDACTED //` ouvre Redacted et ses anecdotes.
- Les **7 clics restent uniquement sur le logo de l’étage Fresque**, avec les interactions historiques du Lab.
- Ascenseur : il devient un niveau visuellement isolé ; le contenu de l’étage Fresque est masqué tant que l’ascenseur est ouvert.
- Sous-sol : suppression renforcée du flash / de l’apparition de la Fresque pendant l’entrée et le retour vers l’ascenseur.
- COMM reste retiré du HUD ; signature Redacted BannerLab + version conservée en bas.
