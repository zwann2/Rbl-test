🧪 REDACTED BANNERLAB 1.1.0

Les portes du Lab viennent de se rouvrir après quelques travaux. « Quelques travaux », dans le langage du Lab, signifie apparemment déplacer des étages entiers, recâbler IGOR, installer LEON dans une vraie salle et laisser MILO toucher au Publisher sans déclencher l'alarme.

Redacted BannerLab 1.1.0 est disponible.

🏢 LE LAB ÉVOLUE

Le Lab dispose désormais d'une organisation beaucoup plus complète autour de son ascenseur et de ses différents étages.

Navigation, transitions, retours et tutoriels ont été revus pour accompagner cette nouvelle organisation.

🧪 IGOR — IITC Gateway for Operations & Routing

IGOR continue de grandir.

Son intégration IITC a été largement revue : panneau minimisable, modules mieux organisés, retour permanent vers son espace principal et synchronisations Missions, Clés, Inventaire et Captures uniques renforcées.

🧮 LEON — Level Expert and Operation Navigator

LEON prend officiellement en charge les calculs et le temps.

Son étage accueille désormais :
• Calcul AP exact
• AP Pile / Tout Pile
• Timer Drone ENL ou RES
• Timers personnalisés
• Timers de hack et de portail
• Heat Sinks et Multi-Hacks avec gestion de leur rareté
• Calcul automatique du cooldown
• Calcul du nombre de hacks avant burnout
• Vérification des événements Ingress pouvant temporairement modifier le cooldown Drone, le cooldown de hack ou le nombre de hacks

Les timers peuvent fonctionner en overlay Android, être déplacés, réduits et continuer leur travail en arrière-plan jusqu'à leur notification de fin.

🛠 MILO — Mission Interface and Logistics Operator

MILO a lui aussi reçu sa part de câblage.

Le Publisher et les échanges Android ont été consolidés, la gestion du stockage améliorée et les contrôles d'intégrité renforcés.

📡 RITA — Redacted Information & Telegram Assistant

Et maintenant, je surveille aussi les mises à jour.

Redacted BannerLab peut vérifier automatiquement au lancement si une nouvelle version stable est disponible.

Si j'en trouve une, je viendrai vous prévenir directement dans le Lab avec les informations de la nouvelle version.

L'APK téléchargé est contrôlé avant installation : SHA-256, package Android, signature et version. Android conserve naturellement la confirmation finale. Il fallait bien lui laisser une responsabilité.

✨ PRIME RESTE PROPRE

La version stable conserve uniquement le cadre néon optionnel autour d'Ingress Prime :
• vert ENL
• bleu RES
• totalement traversant

Les expérimentations de HUD interactif restent pour le moment au laboratoire.

Les timers flottants de LEON, eux, sont bien présents dans cette version.

🌍 ET SOUS LE CAPOT

Les traductions ont été harmonisées, de nombreux écrans mobiles ont été repris, la navigation a été consolidée et une jolie collection de petits bugs a été envoyée rejoindre le bac des expériences ratées.

Version : 1.1.0

Bienvenue dans le nouveau Lab.

— RITA
Redacted Information & Telegram Assistant
