# Redacted BannerLab — dépôt local + builds Android Studio

## 1. Dépôt source maison

Garde le projet source dans un dossier local simple, par exemple :

`C:\RedactedBannerLab`

Initialise Git localement :

```bat
git init
git add .
git commit -m "Base propre TEST73"
```

Pour chaque nouvelle version :

```bat
git add .
git commit -m "TEST74 - description"
```

Évite de synchroniser directement le dossier `.git` avec Google Drive pendant qu'Android Studio travaille. Pour la sauvegarde, fais plutôt une copie ZIP ponctuelle du source ou sauvegarde le dossier quand Android Studio est fermé.

## 2. Compiler avec Android Studio

La chaîne reste :

1. `npm install` (une seule fois tant que les dépendances ne changent pas)
2. `npm run build`
3. `RBL_TEST_BUILD=1`
4. `npx cap add android`
5. `npx cap sync android`
6. copie de `android-res` vers `android/app/src/main/res`
7. `py android-patch\patch_manifest.py`
8. ouvrir le dossier `android` dans Android Studio
9. compiler l'APK.

Le script `local-tools\build-debug-local.cmd` automatise toute cette chaîne pour un APK debug local.

## 3. Où est l'APK ?

APK debug :

`android\app\build\outputs\apk\debug\app-debug.apk`

APK release non signé :

`android\app\build\outputs\apk\release\app-release-unsigned.apk`

## 4. Retrouver l'APK directement sur le téléphone

Installe Google Drive Desktop sur le PC et crée un dossier, par exemple :

`G:\Mon Drive\Redacted BannerLab Builds`

Copie `local-tools\local-config.example.cmd` vers :

`local-tools\local-config.cmd`

Puis mets dedans :

```bat
set "RBL_OUTPUT_DIR=G:\Mon Drive\Redacted BannerLab Builds"
```

Après compilation, lance `local-tools\copy-apk-to-drive.cmd`. Le fichier `Redacted-BannerLab-LOCAL-TEST.apk` sera recopié dans Drive et visible depuis l'application Drive du téléphone.

## 5. Signature

Le debug Android Studio utilise la clé debug de ce PC. Pour une chaîne TEST durable, crée ensuite une clé locale dédiée et garde-la hors du dépôt. Une fois cette clé choisie, ne la change plus. La PROD conserve évidemment sa clé PROD historique séparée.
