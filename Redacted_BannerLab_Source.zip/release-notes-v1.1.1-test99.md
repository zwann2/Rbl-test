# Redacted BannerLab — v1.1.1-test.99

## Inventaire local et visuel

- Les icônes de l’inventaire sont désormais embarquées directement dans `public/inventory/`.
- Plus aucun chargement d’icône d’objet depuis GitHub au runtime : l’inventaire fonctionne hors ligne et ne dépend plus d’URLs externes.
- Ajout d’assets dédiés pour les familles d’objets : XMP, Ultra Strike, résonateurs, Power Cubes, Hyper Cube, shields, Aegis, Heat Sinks, Multi Hacks, Link Amps, SoftBank Ultra Link, Turret, Force Amp, ITO EN, ADA, JARVIS, Apex, Fracker, Beacons, Capsules, Key Locker et Media.
- Les couleurs par niveau et par rareté restent portées directement par les cartes façon Prime.
- Le fallback graphique n’apparaît plus que si un asset local manque réellement.

## Clés IGOR

- Ajout d'un sélecteur de tri dans la vue des clés : nom A → Z, nom Z → A, quantité décroissante ou quantité croissante.
- Les filtres Favoris et À farmer restent indépendants du tri.
