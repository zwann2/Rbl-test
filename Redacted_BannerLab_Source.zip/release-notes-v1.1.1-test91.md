# Redacted BannerLab 1.1.1 TEST-91

- Fresque : suppression du gros panneau flottant/sticky qui recouvrait le canvas pendant l’édition.
- Les commandes rapides restent au-dessus de la fresque dans le flux normal de la page, sans cadre opaque ni superposition.
- Conservation du verrouillage d’étage TEST-90 : la Fresque est masquée hors RDC, notamment pendant l’accès au sous-sol et dans l’Arcade.
- Version : 1.1.1-test.91 · build 2100011091.
