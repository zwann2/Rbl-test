# Redacted BannerLab v1.1.1-test.100

- Key Sync corrigé : « Synchroniser les clés via IGOR » lit maintenant directement le stockage IITC Keys et ne lance plus une synchronisation C.O.R.E. par erreur.
- Une absence réelle du plugin/stockage IITC Keys est signalée sans effacer les clés déjà présentes dans BannerLab.
- Résolution des clés ajoutées par lien renforcée : plus de conversion `null -> 0,0`, récupération du GUID/PLL depuis le lien source et attente IITC plus longue.
- Barre de navigation des grandes fresques remontée sur le bord droit et conservée au-dessus de la navigation basse.
- IGOR 0.6.40.
