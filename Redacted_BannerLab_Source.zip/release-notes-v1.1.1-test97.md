# Redacted BannerLab v1.1.1-test.97

- MILO Chrome : le callback du diagnostic est désormais conservé dans une file native durable avant le retour vers RBL. Le résultat ne peut plus se perdre lors d’une reprise Android/Chrome.
- MILO Chrome : l’écran de succès est affiché immédiatement après validation et retenté au retour au premier plan si Android reprend l’app dans un ordre différent.
- Fresque : barre de navigation affichée strictement à partir de 4 rangées, jamais pour 1 à 3.
- Fresque : barre fixée à droite, remontée près du haut de l’écran et agrandie pour les fresques longues.
