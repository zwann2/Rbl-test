# Redacted BannerLab v1.1.1-test.109

- Corrige la localisation italienne du retour d’ascenseur de Redacted au sous-sol.
- Ajoute les libellés italiens manquants du bouton d’activation du timer Drone.
- Le bouton Activer/Désactiver du timer Drone suit désormais la faction : bleu RES, vert ENL.
- Supprime la recoloration CSS monochrome des XMP, Ultra Strike et Résonateurs : les vrais SVG Prime conservent leurs couleurs natives.
- Les mods conservent le rendu validé de TEST-108.
