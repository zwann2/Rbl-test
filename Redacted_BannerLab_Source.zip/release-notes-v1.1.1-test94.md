# Redacted BannerLab — v1.1.1-test.94

- Corrige l'enrichissement des clés ajoutées manuellement par lien Intel : IGOR renvoie désormais le nom, l'adresse, l'image et le GUID résolus même lorsque C.O.R.E. n'est pas disponible.
- Rend la résolution des liens `pll/ll` plus fiable : IGOR attend réellement le chargement du portail après recentrage de la carte.
- Trie la liste des clés par ordre alphabétique du nom de portail, avec adresse puis GUID comme départage. Les quantités n'influencent plus l'ordre.
- IGOR passe en 0.6.36.
