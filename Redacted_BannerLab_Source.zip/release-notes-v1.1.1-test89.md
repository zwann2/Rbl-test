# Redacted BannerLab 1.1.1 TEST-89

- Prime HUD : ajout en haut à droite d’un libellé de faction au-dessus de la zone du pseudo.
- Le libellé suit immédiatement la faction choisie dans BannerLab : **AGENT ENLIGHTENED** en ENL, **AGENT RÉSISTANT** en RES.
- Le texte reprend la couleur du HUD : vert Enlightened ou bleu Resistance.
- Le bas gauche conserve **Redacted BannerLab + version** et `COMM` reste retiré.
- Version : `1.1.1-test.89`, build `2100011089`.
