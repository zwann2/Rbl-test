# Redacted BannerLab 1.1.1 TEST-87

- Ascenseur : suppression du flash de l’étage Fresque au retour du sous-sol.
- Overlay : faux COMM retiré.
- Bas du HUD : Redacted BannerLab + version.
- Easter egg : 7 clics sur SCANNER // REDACTED //.
- Popup recentré, plus assumé et interactif.
- Archive #BackInMyDays enrichie avec 24 souvenirs/anecdotes de l’ancien Scanner.
