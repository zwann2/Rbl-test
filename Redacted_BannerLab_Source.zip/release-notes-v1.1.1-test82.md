# Redacted BannerLab 1.1.1 TEST-82 CLEAN

- Prime HUD : COMM agrandi fortement pour recouvrir visuellement le contrôle inférieur droit de Prime.
- COMM reste 100 % touch-through : le HUD passif ne consomme aucun toucher.
- Prime HUD : suppression du rectangle autour de SCANNER REDACTED.
- Nouveau libellé discret : `SCANNER // REDACTED //`, placé sous le contour néon supérieur.
- Le déclencheur Redacted n'est désormais visible et actif que lorsque Ingress Prime est réellement au premier plan.
- Le popup Redacted est fermé automatiquement dès que Prime quitte le premier plan.
- Protection supplémentaire : le popup ne peut pas s'ouvrir si Prime n'est pas confirmé au premier plan.
- Android versionCode : 2100011082.
