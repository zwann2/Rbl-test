# Redacted BannerLab 1.1.1 TEST-80 CLEAN

- 7 clics sur Redacted : listener remplacé par une délégation globale, robuste aux re-renders du header.
- Prime HUD : refonte visuelle inspirée du Scanner [REDACTED] historique.
- Coins carrés / coupés à 45°, rails cyan/vert, fin des gros arrondis.
- Ajout du libellé cliquable « SCANNER REDACTED » en haut à gauche.
- Un clic sur SCANNER REDACTED ouvre Redacted avec une blague nostalgique sur l’ancien Scanner.
- Ajout d’un vrai cadre COMM en bas à droite.
- COMM reste 100 % touch-through : le HUD ne bloque pas le bouton Prime situé derrière.
- Ajout d’une petite barre d’état type ancien Scanner en bas.
- Android versionCode : 2100011080.
