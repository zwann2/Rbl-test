# Redacted BannerLab 1.1.1 TEST-90

## Correctif étage / sous-sol

- La Fresque est désormais physiquement masquée dès que le Lab quitte le RDC.
- Le changement d’état d’étage se fait avant la fermeture de l’ascenseur et avant la séquence d’accès au sous-sol, supprimant le flash d’une frame où la Fresque pouvait réapparaître.
- Le retour au RDC réactive explicitement l’application Fresque.
- Le correctif ne dépend plus du seul état visuel `labElevatorOpen` : l’invariant est lié à l’étage courant (`labNonGroundFloor`).

Version : `1.1.1-test.90` · build `2100011090`.
