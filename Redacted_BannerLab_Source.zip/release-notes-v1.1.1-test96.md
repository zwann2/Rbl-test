# Redacted BannerLab v1.1.1-test.96

- Refonte complète du tutoriel d’installation MILO dans Chrome.
- Séparation nette entre installation de MILO, connexion Mission Authoring et première publication.
- Suppression des grandes captures qui encombraient le tutoriel.
- Diagnostic final réel : MILO affiche `MILO // DIAGNOSTIC` puis renvoie une confirmation signée à RBL.
- Impossible de valider l’installation avec un simple bouton « C’est fait ».
- Le test d’installation ne demande que `MILO.user.js`; `MILO_CurrentBanner.json` reste réservé aux vraies publications.
- MILO 0.5.6.
