# Redacted BannerLab 1.1.1 TEST-74 CLEAN

- Base CLEAN TEST73 conservée.
- Inventaire : vrais assets Ingress Prime spécifiques Common / Rare / Very Rare pour les mods.
- Les cartes restent sombres et sobres ; seule la rareté reçoit un accent discret.
- Couleurs de rareté volontairement adoucies pour éviter l'effet néon/fluo.
- IGOR 0.6.36 : suppression complète du mode Explorateur C.O.R.E.
- La synchro C.O.R.E. normale, les clés, missions et captures uniques restent présentes.
- MILO : ajout de son vrai visuel au chapeau dans la salle d'IGOR.
- RITA · Signal Storm : correction du toucher mobile sur les signaux en mouvement.
- Les signaux réagissent maintenant dès l'appui (pointerdown), sans attendre le click final.
- Zone tactile des signaux légèrement agrandie.
- Android versionCode : 2100011074.
