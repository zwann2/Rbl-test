# Redacted BannerLab 1.1.1 TEST-86 CLEAN

- IGOR passe en 0.6.39.
- Key Sync : les clés ajoutées manuellement dans RBL sont maintenant envoyées à IGOR avec GUID/coordonnées.
- IGOR tente d’abord `getPortalDetails` quand le lien contient déjà un GUID.
- Pour les liens Intel ne contenant que `pll=lat,lng`, IGOR cherche le portail chargé le plus proche ; si nécessaire il centre temporairement IITC sur les coordonnées, attend le chargement de la carte puis résout le portail.
- Une fois résolu, IGOR renvoie à RBL le GUID réel, le nom du portail, l’adresse, l’image et les coordonnées.
- RBL remplace automatiquement les entrées `manual:lat,lng` par le vrai GUID sans perdre le nombre de clés ni les favoris/objectifs de farm.
- Les clés manuelles restent utilisables si Intel ne parvient pas à résoudre un lien : aucune entrée n’est supprimée.
- Android versionCode : 2100011086.
