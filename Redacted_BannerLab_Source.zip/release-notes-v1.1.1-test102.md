# Redacted BannerLab — v1.1.1-test.102

- Corrige la synchronisation des clés saisies manuellement dans IITC Keys.
- IGOR enrichit maintenant les GUID du plugin Keys avec les métadonnées Intel (nom, image, adresse, coordonnées) avant retour vers RBL.
- Cache local des métadonnées pour éviter de recharger inutilement les mêmes portails à chaque synchro.
- Les clés ajoutées par lien dans RBL continuent d’être résolues séparément via `resolvedManual`.
- IGOR 0.6.42.
