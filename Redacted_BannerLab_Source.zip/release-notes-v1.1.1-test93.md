# Redacted BannerLab v1.1.1-test.93

- Corrige le refus « MILO : Publisher refusé : SHA-256 invalide » dans Mission Authoring Tool.
- Le favori Chrome MILO n’est plus verrouillé sur l’empreinte exacte d’une seule version de `MILO.user.js`, ce qui cassait dès que MILO était mis à jour.
- Le lanceur vérifie désormais des marqueurs d’identité stables de MILO ; l’application Android conserve, elle, la vérification SHA-256 stricte du fichier embarqué avant export.
- Une mise à jour unique du favori Chrome MILO est nécessaire pour remplacer l’ancien mini-code qui contient encore l’ancienne empreinte.
