# Redacted BannerLab v1.1.1-test.107

- Inventaire : le build télécharge désormais les vrais SVG Ingress avant Vite. Les anciens placeholders ne peuvent plus être embarqués silencieusement.
- Inventaire : variantes Common / Rare / Very Rare conservées avec leurs couleurs Prime et niveaux L1-L8.
- LEON : le timer Drone est désormais explicitement activable/désactivable et désactivé par défaut. Ouvrir LEON ou la salle Timers ne le démarre jamais.
- LEON : désactiver le timer Drone arrête son compte à rebours et retire son overlay natif. Le choix est mémorisé.
