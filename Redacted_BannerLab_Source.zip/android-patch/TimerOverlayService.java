package com.bannerforge.mobile;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class TimerOverlayService extends Service {
    public static final String ACTION_SYNC = "com.bannerforge.mobile.timeroverlay.SYNC";
    public static final String ACTION_STOP = "com.bannerforge.mobile.timeroverlay.STOP";
    public static final String EXTRA_TIMERS = "timersJson";
    public static final String PREFS = "rbl_leon_timer_overlay";

    private static final String CHANNEL_SERVICE = "rbl_leon_timers_service";
    private static final String CHANNEL_DONE = "rbl_leon_timers_done";
    private static final int SERVICE_NOTIFICATION_ID = 7633;
    private static final String INGRESS_PACKAGE = "com.nianticproject.ingress";

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, TimerView> views = new LinkedHashMap<>();
    private String timersJson = "[]";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            tick();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("active", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent != null && intent.hasExtra(EXTRA_TIMERS)) {
            String incoming = intent.getStringExtra(EXTRA_TIMERS);
            if (incoming != null) timersJson = incoming;
            prefs.edit().putString("timersJson", timersJson).apply();
        } else {
            timersJson = prefs.getString("timersJson", "[]");
        }

        if (!hasAnyNativeTimer(timersJson)) {
            prefs.edit().putBoolean("active", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(SERVICE_NOTIFICATION_ID, buildServiceNotification());
        rebuild(timersJson);
        prefs.edit().putBoolean("active", true).apply();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        return START_STICKY;
    }

    private boolean hasAnyNativeTimer(String json) {
        try {
            JSONArray a = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                boolean overlay = o.optBoolean("overlay", true);
                boolean runningNotify = o.optBoolean("running", false) && o.optBoolean("notify", true);
                if (overlay || runningNotify) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void rebuild(String json) {
        removeAllViews();
        try {
            JSONArray a = new JSONArray(json == null ? "[]" : json);
            int slot = 0;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                boolean wantsOverlay = o.optBoolean("overlay", true);
                boolean runningNotify = o.optBoolean("running", false) && o.optBoolean("notify", true);
                if (!wantsOverlay && !runningNotify) continue;
                boolean drawOverlay = wantsOverlay && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this));
                TimerView tv = createTimerView(o, slot++, drawOverlay);
                views.put(tv.id, tv);
            }
        } catch (Exception ignored) {}
        tick();
    }

    private TimerView createTimerView(JSONObject o, int slot, boolean drawOverlay) {
        TimerView tv = new TimerView();
        tv.id = o.optString("id", "timer-" + slot);
        tv.name = o.optString("name", "Timer");
        tv.kind = o.optString("kind", "custom");
        tv.faction = o.optString("faction", "enl");
        tv.color = parseColor(o.optString("color", "#75eda9"), 0xFF75EDA9);
        tv.durationSec = Math.max(1L, o.optLong("durationSec", 60L));
        tv.startedAt = Math.max(0L, o.optLong("startedAt", 0L));
        tv.endAt = Math.max(0L, o.optLong("endAt", 0L));
        tv.nativeChangedAt = Math.max(0L, o.optLong("nativeChangedAt", 0L));
        tv.running = o.optBoolean("running", false);
        tv.visibility = o.optString("visibility", "always");
        tv.notify = o.optBoolean("notify", true);
        tv.readyText = o.optString("ready", "READY");
        tv.remainingText = o.optString("remaining", "Remaining");
        tv.openIngressText = o.optString("openIngress", "Ingress");
        tv.openLabText = o.optString("openLab", "Lab");
        tv.closeOverlayText = o.optString("closeOverlay", "Close");
        tv.expiredTitle = o.optString("expiredTitle", "Timer finished");
        tv.expiredText = o.optString("expiredText", tv.name + " is ready.");

        long hiddenEnd = prefs.getLong("hiddenEnd_" + tv.id, -1L);
        if (hiddenEnd == tv.endAt) drawOverlay = false;
        if (!drawOverlay) return tv;

        FrameLayout root = new FrameLayout(this);
        root.setPadding(dp(3), dp(3), dp(3), dp(3));
        tv.root = root;

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(11), dp(9), dp(9), dp(9));
        GradientDrawable panelBg = rounded(0xF20A100D, tv.color, 16, 2);
        panel.setBackground(panelBg);
        tv.panel = panel;

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        View glyph;
        if ("drone".equals(tv.kind)) {
            ImageView drone = new ImageView(this);
            drone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            drone.setImageResource("res".equals(tv.faction) ? R.drawable.drone_mk_ii_res : R.drawable.drone_mk_ii_enl);
            drone.setPadding(dp(1), dp(1), dp(1), dp(1));
            glyph = drone;
        } else {
            TextView g = text("hack".equals(tv.kind) ? "⌁" : "⌛", 18f, tv.color, true);
            g.setGravity(Gravity.CENTER);
            GradientDrawable glyphBg = new GradientDrawable();
            glyphBg.setShape(GradientDrawable.OVAL);
            glyphBg.setColor(0xFF07100B);
            glyphBg.setStroke(dp(2), tv.color);
            g.setBackground(glyphBg);
            glyph = g;
        }
        top.addView(glyph, new LinearLayout.LayoutParams(dp(43), dp(43)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(9), 0, dp(6), 0);
        TextView title = text(tv.name, 13f, Color.WHITE, true);
        title.setSingleLine(true);
        TextView label = text(tv.remainingText, 8f, 0xFF789083, false);
        titleBox.addView(title, new LinearLayout.LayoutParams(-1, -2));
        titleBox.addView(label, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        top.addView(titleBox, titleLp);

        TextView clock = text("--:--", 18f, tv.color, true);
        clock.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clock.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        tv.clock = clock;
        top.addView(clock, new LinearLayout.LayoutParams(dp(72), dp(40)));
        panel.addView(top, new LinearLayout.LayoutParams(-1, -2));
        tv.dragTarget = top;

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(6), 0, 0);

        Button lab = button(tv.openLabText, 0xFF17231C, Color.WHITE);
        lab.setOnClickListener(v -> openLab());
        actions.addView(lab, new LinearLayout.LayoutParams(0, dp(36), 1f));

        Button ingress = button(tv.openIngressText, tv.color, 0xFF06100A);
        ingress.setOnClickListener(v -> openIngress());
        LinearLayout.LayoutParams ingLp = new LinearLayout.LayoutParams(0, dp(36), 1.35f);
        ingLp.leftMargin = dp(5);
        actions.addView(ingress, ingLp);

        Button minimize = button("−", 0xFF17231C, Color.WHITE);
        LinearLayout.LayoutParams minLp = new LinearLayout.LayoutParams(dp(38), dp(36));
        minLp.leftMargin = dp(5);
        actions.addView(minimize, minLp);

        Button close = button("×", 0xFF3A1717, 0xFFFFB7B7);
        close.setContentDescription(tv.closeOverlayText);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(38), dp(36));
        closeLp.leftMargin = dp(5);
        actions.addView(close, closeLp);
        close.setOnClickListener(v -> hideOverlay(tv));
        panel.addView(actions, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout compact = new FrameLayout(this);
        compact.setVisibility(View.GONE);
        tv.compact = compact;

        TimerRingView ring = new TimerRingView(this, tv.color);
        tv.ring = ring;
        compact.addView(ring, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        View compactGlyph;
        if ("drone".equals(tv.kind)) {
            ImageView drone = new ImageView(this);
            drone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            drone.setImageResource("res".equals(tv.faction) ? R.drawable.drone_mk_ii_res : R.drawable.drone_mk_ii_enl);
            drone.setPadding(dp(8), dp(7), dp(8), dp(13));
            compactGlyph = drone;
        } else {
            TextView cg = text("hack".equals(tv.kind) ? "⌁" : "⌛", 15f, tv.color, true);
            cg.setGravity(Gravity.CENTER); compactGlyph = cg;
        }
        compact.addView(compactGlyph, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        TextView compactClock = text("", 8f, Color.WHITE, true);
        compactClock.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        compactClock.setGravity(Gravity.CENTER);
        compactClock.setShadowLayer(5f, 0f, 0f, Color.BLACK);
        FrameLayout.LayoutParams ccLp = new FrameLayout.LayoutParams(dp(56), dp(20), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        ccLp.bottomMargin = dp(4);
        compact.addView(compactClock, ccLp);
        tv.compactClock = compactClock;

        root.addView(panel, new FrameLayout.LayoutParams(dp(274), -2));
        root.addView(compact, new FrameLayout.LayoutParams(dp(66), dp(66)));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(dp(280), -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        int stableSlot = Math.abs(tv.id.hashCode() % 7);
        lp.x = prefs.getInt("x_" + tv.id, dp(10 + (stableSlot % 3) * 18));
        lp.y = prefs.getInt("y_" + tv.id, dp(125 + stableSlot * 78));
        tv.params = lp;
        tv.collapsed = prefs.contains("collapsed_" + tv.id)
            ? prefs.getBoolean("collapsed_" + tv.id, false)
            : !tv.running;
        applyCollapsed(tv, tv.collapsed, false);

        top.setOnTouchListener(dragListener(tv));
        compact.setOnTouchListener(compactGestureListener(tv));
        minimize.setOnClickListener(v -> applyCollapsed(tv, true, true));

        try { windowManager.addView(root, lp); } catch (Exception ignored) {}
        root.post(() -> { clamp(tv); savePosition(tv); });
        return tv;
    }

    private View.OnTouchListener dragListener(TimerView tv) {
        return new View.OnTouchListener() {
            float downRawX, downRawY;
            int downX, downY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (tv.params == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX(); downRawY = e.getRawY(); downX = tv.params.x; downY = tv.params.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(e.getRawX() - downRawX), dy = Math.round(e.getRawY() - downRawY);
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        tv.params.x = downX + dx; tv.params.y = downY + dy; clamp(tv);
                        try { windowManager.updateViewLayout(tv.root, tv.params); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        clamp(tv); savePosition(tv);
                        try { windowManager.updateViewLayout(tv.root, tv.params); } catch (Exception ignored) {}
                        if (!moved && e.getActionMasked() == MotionEvent.ACTION_UP) {
                            if (tv.collapsed) applyCollapsed(tv, false, true);
                            else openIngress();
                        }
                        return true;
                    default: return false;
                }
            }
        };
    }

    private void applyCollapsed(TimerView tv, boolean collapsed, boolean persist) {
        tv.collapsed = collapsed;
        if (tv.panel != null) tv.panel.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        if (tv.compact != null) tv.compact.setVisibility(collapsed ? View.VISIBLE : View.GONE);
        if (tv.params != null) {
            tv.params.width = dp(collapsed ? 72 : 280);
            tv.params.height = collapsed ? dp(72) : WindowManager.LayoutParams.WRAP_CONTENT;
            try { if (tv.root != null && tv.root.isAttachedToWindow()) windowManager.updateViewLayout(tv.root, tv.params); } catch (Exception ignored) {}
        }
        if (persist) prefs.edit().putBoolean("collapsed_" + tv.id, collapsed).apply();
    }

    private void tick() {
        long now = System.currentTimeMillis();
        boolean ingressForeground = isIngressForeground();
        for (TimerView tv : views.values()) {
            long left = tv.running ? Math.max(0L, tv.endAt - now) : 0L;
            String time = formatTime(left);
            boolean ready = tv.running && left <= 0L;
            if (tv.clock != null) tv.clock.setText(!tv.running ? "--:--" : (ready ? tv.readyText : time));
            if (tv.compactClock != null) tv.compactClock.setText(!tv.running ? "▶" : (ready ? "00:00" : compactTime(left)));
            if (tv.ring != null) {
                float progress = tv.running && tv.durationSec > 0 ? Math.max(0f, Math.min(1f, left / (tv.durationSec * 1000f))) : 0f;
                tv.ring.setProgress(progress, ready, !tv.running);
            }
            boolean show = !"ingress".equals(tv.visibility) || !hasUsageAccess() || ingressForeground;
            if (tv.root != null) tv.root.setVisibility(show ? View.VISIBLE : View.GONE);
            if (ready) {
                if (tv.notify) notifyFinishedOnce(tv);
                tv.running = false; tv.startedAt = 0L; tv.endAt = 0L;
                persistNativeMutation(tv);
            }
        }
        if (views.isEmpty()) {
            prefs.edit().putBoolean("active", false).apply();
            stopSelf();
        }
    }

    private void notifyFinishedOnce(TimerView tv) {
        String key = "notified_" + tv.id + "_" + tv.endAt;
        if (prefs.getBoolean(key, false)) return;
        prefs.edit().putBoolean(key, true).apply();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent ingressIntent = getPackageManager().getLaunchIntentForPackage(INGRESS_PACKAGE);
        PendingIntent pi = null;
        if (ingressIntent != null) {
            ingressIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) f |= PendingIntent.FLAG_IMMUTABLE;
            pi = PendingIntent.getActivity(this, 9000 + Math.abs(tv.id.hashCode() % 3000), ingressIntent, f);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_DONE)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(tv.expiredTitle)
            .setContentText(tv.expiredText)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL);
        if (pi != null) b.setContentIntent(pi);
        nm.notify(8000 + Math.abs(tv.id.hashCode() % 5000), b.build());
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    private boolean isIngressForeground() {
        if (!hasUsageAccess()) return false;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            if (usm == null) return false;
            long end = System.currentTimeMillis(), start = end - 5000L;
            UsageEvents events = usm.queryEvents(start, end);
            UsageEvents.Event ev = new UsageEvents.Event();
            String foreground = "";
            while (events.hasNextEvent()) {
                events.getNextEvent(ev);
                int type = ev.getEventType();
                if (type == UsageEvents.Event.MOVE_TO_FOREGROUND || (Build.VERSION.SDK_INT >= 29 && type == UsageEvents.Event.ACTIVITY_RESUMED)) foreground = ev.getPackageName();
            }
            return INGRESS_PACKAGE.equals(foreground);
        } catch (Exception e) { return false; }
    }


    private void hideOverlay(TimerView tv) {
        if (tv == null) return;
        prefs.edit().putLong("hiddenEnd_" + tv.id, tv.endAt).apply();
        if (tv.root != null) {
            try { windowManager.removeView(tv.root); } catch (Exception ignored) {}
            tv.root = null; tv.panel = null; tv.compact = null; tv.clock = null; tv.compactClock = null;
        }
    }

    private void openLab() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launch == null) return;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(launch);
        } catch (Exception ignored) {}
    }

    private void openIngress() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(INGRESS_PACKAGE);
            if (launch == null) return;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(launch);
        } catch (Exception ignored) {}
    }

    private Notification buildServiceNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi = null;
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) f |= PendingIntent.FLAG_IMMUTABLE;
            pi = PendingIntent.getActivity(this, SERVICE_NOTIFICATION_ID, launch, f);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("LEON · Timers")
            .setContentText(localizedActiveText())
            .setOngoing(true).setSilent(true).setPriority(NotificationCompat.PRIORITY_LOW);
        if (pi != null) b.setContentIntent(pi);
        return b.build();
    }

    private String localizedActiveText() {
        String l = java.util.Locale.getDefault().getLanguage();
        if ("fr".equals(l)) return "Timers flottants actifs";
        if ("es".equals(l)) return "Temporizadores flotantes activos";
        if ("pt".equals(l)) return "Temporizadores flutuantes ativos";
        if ("de".equals(l)) return "Schwebende Timer aktiv";
        if ("it".equals(l)) return "Timer flottanti attivi";
        if ("nl".equals(l)) return "Zwevende timers actief";
        return "Floating timers active";
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel service = new NotificationChannel(CHANNEL_SERVICE, "LEON timers", NotificationManager.IMPORTANCE_LOW);
        service.setDescription("LEON floating timer service"); service.setShowBadge(false); nm.createNotificationChannel(service);
        NotificationChannel done = new NotificationChannel(CHANNEL_DONE, "LEON timer alerts", NotificationManager.IMPORTANCE_HIGH);
        done.setDescription("Timer completion alerts from LEON"); nm.createNotificationChannel(done);
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(null, Typeface.BOLD); return v;
    }

    private Button button(String value, int bg, int fg) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(value); b.setTextSize(9f); b.setTextColor(fg); b.setTypeface(null, Typeface.BOLD); b.setPadding(dp(7), 0, dp(7), 0); b.setMinHeight(0); b.setMinWidth(0); b.setBackground(rounded(bg, bg, 10, 0)); return b;
    }

    private GradientDrawable rounded(int fill, int stroke, int radiusDp, int strokeDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke); return g;
    }

    private int parseColor(String s, int fallback) { try { return Color.parseColor(s); } catch (Exception e) { return fallback; } }
    private String formatTime(long ms) { long sec = Math.max(0L, (ms + 999L) / 1000L), h = sec / 3600L, m = (sec % 3600L) / 60L, s = sec % 60L; return h > 0 ? String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, s) : String.format(java.util.Locale.US, "%02d:%02d", m, s); }
    private String shortTime(long ms) { long min = Math.max(0L, (ms + 59999L) / 60000L); if (min >= 60) return (min / 60) + "h"; return min + "m"; }
    private String compactTime(long ms) { long sec = Math.max(0L, (ms + 999L) / 1000L); if (sec >= 3600L) return String.format(java.util.Locale.US, "%d:%02d", sec/3600L, (sec%3600L)/60L); return String.format(java.util.Locale.US, "%02d:%02d", sec/60L, sec%60L); }

    private void clamp(TimerView tv) {
        if (tv == null || tv.params == null) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = tv.collapsed ? dp(72) : dp(220), h = tv.collapsed ? dp(72) : dp(132);
        tv.params.x = Math.max(0, Math.min(tv.params.x, Math.max(0, dm.widthPixels - w)));
        tv.params.y = Math.max(0, Math.min(tv.params.y, Math.max(0, dm.heightPixels - h - dp(35))));
    }

    private void savePosition(TimerView tv) { prefs.edit().putInt("x_" + tv.id, tv.params.x).putInt("y_" + tv.id, tv.params.y).apply(); }

    private void removeAllViews() {
        for (TimerView tv : views.values()) { try { if (tv.root != null) windowManager.removeView(tv.root); } catch (Exception ignored) {} }
        views.clear();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(ticker); removeAllViews(); prefs.edit().putBoolean("active", false).apply(); super.onDestroy();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    private View.OnTouchListener compactGestureListener(TimerView tv) {
        return new View.OnTouchListener() {
            float downRawX, downRawY; int downX, downY; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (tv.params == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX=e.getRawX(); downRawY=e.getRawY(); downX=tv.params.x; downY=tv.params.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=Math.round(e.getRawX()-downRawX), dy=Math.round(e.getRawY()-downRawY);
                        if (Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)) moved=true;
                        if (moved) { tv.params.x=downX+dx; tv.params.y=downY+dy; clamp(tv); try { windowManager.updateViewLayout(tv.root,tv.params); } catch(Exception ignored){} }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        clamp(tv); savePosition(tv); try { windowManager.updateViewLayout(tv.root,tv.params); } catch(Exception ignored){}
                        if (!moved && e.getActionMasked()==MotionEvent.ACTION_UP) queueCompactTap(tv);
                        return true;
                    default:return false;
                }
            }
        };
    }

    private void queueCompactTap(TimerView tv) {
        tv.tapCount++;
        if (tv.tapRunnable != null) handler.removeCallbacks(tv.tapRunnable);
        tv.tapRunnable = () -> {
            int count = tv.tapCount; tv.tapCount = 0; tv.tapRunnable = null;
            if (count >= 3) { applyCollapsed(tv, false, true); return; }
            if (count == 2) { restartTimerNative(tv); return; }
            if (count == 1 && (!tv.running || tv.endAt <= System.currentTimeMillis())) startTimerNative(tv);
        };
        handler.postDelayed(tv.tapRunnable, 340L);
    }

    private void startTimerNative(TimerView tv) {
        if (tv == null || (tv.running && tv.endAt > System.currentTimeMillis())) return;
        long now=System.currentTimeMillis(); tv.running=true; tv.startedAt=now; tv.endAt=now+Math.max(1L,tv.durationSec)*1000L; persistNativeMutation(tv);
    }
    private void restartTimerNative(TimerView tv) {
        if (tv == null) return; long now=System.currentTimeMillis(); tv.running=true; tv.startedAt=now; tv.endAt=now+Math.max(1L,tv.durationSec)*1000L; persistNativeMutation(tv);
    }
    private void persistNativeMutation(TimerView tv) {
        if (tv == null) return;
        tv.nativeChangedAt=System.currentTimeMillis();
        try {
            JSONArray a=new JSONArray(timersJson==null?"[]":timersJson);
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!tv.id.equals(o.optString("id")))continue;o.put("running",tv.running);o.put("startedAt",tv.startedAt);o.put("endAt",tv.endAt);o.put("nativeChangedAt",tv.nativeChangedAt);break;}
            timersJson=a.toString(); prefs.edit().putString("timersJson",timersJson).apply();
        } catch(Exception ignored){}
    }

    private static class TimerRingView extends View {
        private final Paint track=new Paint(Paint.ANTI_ALIAS_FLAG), progressPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int baseColor; private float progress=0f; private boolean ready=false,idle=true;
        TimerRingView(Context c,int color){super(c);baseColor=color;setLayerType(View.LAYER_TYPE_SOFTWARE,null);track.setStyle(Paint.Style.STROKE);progressPaint.setStyle(Paint.Style.STROKE);track.setStrokeCap(Paint.Cap.ROUND);progressPaint.setStrokeCap(Paint.Cap.ROUND);}
        void setProgress(float p,boolean isReady,boolean isIdle){progress=Math.max(0f,Math.min(1f,p));ready=isReady;idle=isIdle;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),pad=Math.max(4f,w*.07f),sw=Math.max(4f,w*.065f);track.setStrokeWidth(sw);track.setColor(0x552A4033);progressPaint.setStrokeWidth(sw);int col=baseColor;if(!idle&&progress<=.10f)col=0xFFFF5F66;else if(!idle&&progress<=.25f)col=0xFFFFB347;if(ready)col=0xFFFF5F66;progressPaint.setColor(col);progressPaint.setShadowLayer(ready?12f:8f,0f,0f,col);android.graphics.RectF r=new android.graphics.RectF(pad,pad,w-pad,h-pad);c.drawArc(r,-90f,360f,false,track);if(idle)c.drawArc(r,-90f,360f,false,progressPaint);else c.drawArc(r,-90f,Math.max(8f,360f*progress),false,progressPaint);}
    }

    private static class TimerView {
        String id, name, kind, faction, visibility, readyText, remainingText, openIngressText, openLabText, closeOverlayText, expiredTitle, expiredText;
        int color, tapCount; long durationSec, startedAt, endAt, nativeChangedAt; boolean notify, collapsed, running; Runnable tapRunnable;
        FrameLayout root, compact; LinearLayout panel; View dragTarget; TextView clock, compactClock; TimerRingView ring; WindowManager.LayoutParams params;
    }
}
