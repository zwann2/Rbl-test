from pathlib import Path
import shutil
import os
import json
import xml.etree.ElementTree as ET

if os.environ.get("RBL_TEST_BUILD") != "1":
    raise SystemExit("Source TEST-73 CLEAN : utilise le workflow TEST avec RBL_TEST_BUILD=1.")


manifest = Path("android/app/src/main/AndroidManifest.xml")
tree = ET.parse(manifest)
root = tree.getroot()
ns = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ns)
A = f"{{{ns}}}"

app = root.find("application")
if app is None:
    raise SystemExit("application absente du manifest")

# Edition TEST-55 : package et icône isolés de la PROD.
app.set(A+"icon", "@mipmap/ic_launcher_test")
app.set(A+"roundIcon", "@mipmap/ic_launcher_test_round")
app.set(A+"label", "Redacted BannerLab TEST")
# System backups are disabled. RBL keeps its own explicit user-controlled backup/export flow.
app.set(A+"allowBackup", "false")
app.set(A+"fullBackupContent", "false")
app.set(A+"dataExtractionRules", "@xml/data_extraction_rules")
app.set(A+"usesCleartextTraffic", "false")

# Overlay/foreground-service permissions.
existing_permissions = {p.get(A+"name") for p in root.findall("uses-permission")}
for permission in [
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.REQUEST_INSTALL_PACKAGES",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.PACKAGE_USAGE_STATS",
    "android.permission.VIBRATE",
]:
    if permission not in existing_permissions:
        root.insert(0, ET.Element("uses-permission", {A+"name": permission}))

activity = None
for a in app.findall("activity"):
    name = a.get(A + "name", "")
    if name.endswith(".MainActivity") or name == "com.bannerforge.mobile.MainActivity":
        activity = a
        break
if activity is None:
    activity = app.find("activity")
if activity is None:
    raise SystemExit("MainActivity introuvable")

# Deep links IITC / Browser Publisher -> BannerLab.
# TEST-32: a single native trampoline receives every redactedbannerlabtest:// link.
# Sync callbacks are queued before MainActivity is resumed, so a Capacitor/WebView lifecycle
# race can no longer make an apparently successful IITC round-trip disappear.
for f in list(activity.findall("intent-filter")):
    if any(data.get(A+"scheme") in ["redactedbannerlab", "redactedbannerlabtest"] for data in f.findall("data")):
        activity.remove(f)

autosync_name = ".IitcAutoSyncActivity"
autosync = next((a for a in app.findall("activity") if a.get(A+"name") in [autosync_name, "com.bannerforge.mobile.IitcAutoSyncActivity"]), None)
if autosync is None:
    autosync = ET.SubElement(app, "activity", {
        A+"name": autosync_name,
        A+"exported": "true",
        A+"excludeFromRecents": "true",
        A+"noHistory": "true",
        A+"launchMode": "singleTop",
        A+"taskAffinity": "",
        A+"theme": "@android:style/Theme.NoDisplay",
    })
else:
    autosync.set(A+"exported", "true")
    autosync.set(A+"excludeFromRecents", "true")
    autosync.set(A+"noHistory", "true")
    autosync.set(A+"launchMode", "singleTop")
    autosync.set(A+"taskAffinity", "")
    autosync.set(A+"theme", "@android:style/Theme.NoDisplay")
for f in list(autosync.findall("intent-filter")):
    autosync.remove(f)
bridge_filter = ET.SubElement(autosync, "intent-filter")
ET.SubElement(bridge_filter, "action", {A+"name":"android.intent.action.VIEW"})
ET.SubElement(bridge_filter, "category", {A+"name":"android.intent.category.DEFAULT"})
ET.SubElement(bridge_filter, "category", {A+"name":"android.intent.category.BROWSABLE"})
ET.SubElement(bridge_filter, "data", {A+"scheme":"redactedbannerlabtest"})

# Dedicated read-only provider for the real IITC external-plugin installer.
# It removes the existing canonical Companion lazily only when IITC opens the
# package after the user accepted IITC's own confirmation dialog.
install_provider_authority = "${applicationId}.rblinstallprovider"
if not any((pr.get(A+"authorities") == install_provider_authority) for pr in app.findall("provider")):
    ET.SubElement(app, "provider", {
        A+"name": ".IitcInstallProvider",
        A+"authorities": install_provider_authority,
        A+"exported": "false",
        A+"grantUriPermissions": "true",
    })

# FileProvider used to hand the bundled .user.js directly to IITC Mobile.
provider_authority = "${applicationId}.rblfileprovider"
if not any((pr.get(A+"authorities") == provider_authority) for pr in app.findall("provider")):
    provider = ET.SubElement(app, "provider", {
        A+"name": "androidx.core.content.FileProvider",
        A+"authorities": provider_authority,
        A+"exported": "false",
        A+"grantUriPermissions": "true",
    })
    ET.SubElement(provider, "meta-data", {
        A+"name": "android.support.FILE_PROVIDER_PATHS",
        A+"resource": "@xml/rbl_file_paths",
    })

# Foreground callback Activity used by PackageInstaller for self-updates.
# PackageInstaller may require user confirmation even when USER_ACTION_NOT_REQUIRED
# is requested. Using an Activity directly avoids a BroadcastReceiver -> Activity
# trampoline, which modern Android can block in the background.
update_activity_name = ".UpdateInstallActivity"
update_activity = next(
    (a for a in app.findall("activity")
     if a.get(A+"name") in [update_activity_name, "com.bannerforge.mobile.UpdateInstallActivity"]),
    None
)
if update_activity is None:
    update_activity = ET.SubElement(app, "activity", {
        A+"name": update_activity_name,
        A+"enabled": "true",
        A+"exported": "false",
        A+"excludeFromRecents": "true",
        A+"launchMode": "singleTop",
        A+"taskAffinity": "",
        A+"theme": "@android:style/Theme.Translucent.NoTitleBar",
    })
else:
    update_activity.set(A+"enabled", "true")
    update_activity.set(A+"exported", "false")
    update_activity.set(A+"excludeFromRecents", "true")
    update_activity.set(A+"launchMode", "singleTop")
    update_activity.set(A+"taskAffinity", "")
    update_activity.set(A+"theme", "@android:style/Theme.Translucent.NoTitleBar")

# Native Redacted companion overlay service.
if not any((s.get(A+"name", "").endswith("RedactedOverlayService")) for s in app.findall("service")):
    redacted_service = ET.SubElement(app, "service", {
        A+"name": ".RedactedOverlayService",
        A+"enabled": "true",
        A+"exported": "false",
        A+"foregroundServiceType": "specialUse",
    })
    ET.SubElement(redacted_service, "property", {
        A+"name": "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
        A+"value": "User-enabled Scanner REDACTED-style companion overlay with touch-through HUD and COMM rail."
    })

# PROD 1.1.0: interactive Prime accessibility HUD intentionally not registered.

# Native LEON timer overlay service.
if not any((s.get(A+"name", "").endswith("TimerOverlayService")) for s in app.findall("service")):
    timer_service = ET.SubElement(app, "service", {
        A+"name": ".TimerOverlayService",
        A+"enabled": "true",
        A+"exported": "false",
        A+"foregroundServiceType": "specialUse",
    })
    ET.SubElement(timer_service, "property", {
        A+"name": "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
        A+"value": "User-created floating countdown timers managed by LEON; timers remain visible and notify at expiry."
    })

# Native mission overlay service.
if not any((s.get(A+"name", "").endswith("MissionOverlayService")) for s in app.findall("service")):
    service = ET.SubElement(app, "service", {
        A+"name": ".MissionOverlayService",
        A+"enabled": "true",
        A+"exported": "false",
        A+"foregroundServiceType": "specialUse",
    })
    ET.SubElement(service, "property", {
        A+"name": "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE",
        A+"value": "Visible floating banner mission navigator controlled by the user; opens Ingress missions only through deep links."
    })

# Android 11+ package visibility
queries = root.find("queries")
if queries is None:
    queries = ET.Element("queries")
    children = list(root)
    root.insert(children.index(app), queries)
existing = {p.get(A+"name") for p in queries.findall("package")}
for package_name in [
    "org.exarhteam.iitc_mobile",
    "org.exarhteam.iitcprime",
    "org.mozilla.firefox",
    "org.mozilla.firefox_beta",
    "com.android.chrome",
    "com.chrome.beta",
    "com.nianticproject.ingress",
    "com.google.android.apps.maps",
]:
    if package_name not in existing:
        ET.SubElement(queries, "package", {A+"name": package_name})

# Security invariants: fail the build if a later patch re-opens these surfaces.
# Legacy Android <= 9 only: direct public Downloads fallback needs write permission.
# maxSdkVersion=28 makes this permission irrelevant on modern Android/scoped storage.
perm_names = {p.get(A+"name") for p in root.findall("uses-permission")}
if "android.permission.WRITE_EXTERNAL_STORAGE" not in perm_names:
    legacy_write = ET.Element("uses-permission", {
        A+"name": "android.permission.WRITE_EXTERNAL_STORAGE",
        A+"maxSdkVersion": "28",
    })
    root.insert(0, legacy_write)

if "android.permission.UPDATE_PACKAGES_WITHOUT_USER_ACTION" in {p.get(A+"name") for p in root.findall("uses-permission")}:
    raise SystemExit("Permission de mise à jour silencieuse interdite")
if app.get(A+"allowBackup") != "false":
    raise SystemExit("android:allowBackup doit rester false")

tree.write(manifest, encoding="utf-8", xml_declaration=True)

# Force a higher Android package version code while keeping the visible version name.
# Redacted BannerLab v1.1.1 TEST-76 CLEAN / IGOR 0.6.39 / MILO 0.5.5 / RITA / LEON.
# IMPORTANT: older public APKs used Unix-timestamp versionCodes (~1.7B).
# Keep Android versionCode above that historical family. Do NOT return to 11xxx values.
ANDROID_VERSION_CODE = 2100011099
ANDROID_VERSION_NAME = "1.1.1-test.99"

build_gradle = Path("android/app/build.gradle")
if not build_gradle.exists():
    raise SystemExit("android/app/build.gradle absent")
gradle_text = build_gradle.read_text(encoding="utf-8")
import re
new_gradle, code_count = re.subn(r"(?m)^(\s*)versionCode\s+\d+\s*$", rf"\1versionCode {ANDROID_VERSION_CODE}", gradle_text, count=1)
new_gradle, name_count = re.subn(r'(?m)^(\s*)versionName\s+["\'][^"\']*["\']\s*$', rf'\1versionName "{ANDROID_VERSION_NAME}"', new_gradle, count=1)
if code_count != 1 or name_count != 1:
    raise SystemExit(f"Impossible de forcer versionCode/versionName (code={code_count}, name={name_count})")
# Production package id must stay stable for in-place updates.
new_gradle, appid_count = re.subn(
    r'(?m)^(\s*)applicationId\s+["\'][^"\']+["\']\s*$',
    r'\1applicationId "com.bannerforge.mobile.test"',
    new_gradle,
    count=1,
)
if appid_count != 1:
    raise SystemExit(f"Impossible de forcer applicationId TEST (count={appid_count})")
build_gradle.write_text(new_gradle, encoding="utf-8")

# The Android platform is regenerated by the workflow on every build.
# Reinstall the custom launcher resources every time so the APK metadata and
# installed launcher both use the same icon.
src_res = Path("android-res")
dst_res = Path("android/app/src/main/res")
if not src_res.exists():
    raise SystemExit("android-res absent")
for source in src_res.rglob("*"):
    if source.is_file():
        rel = source.relative_to(src_res)
        target = dst_res / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

# MILO integrity: MILO.user.js itself is the source of truth.
# The sidecar is GENERATED from the current file during every build. This avoids
# stale hashes when MILO changes (and also works with *.sha256 ignored by git).
# Keep the Android Java exporter and Chrome bookmarklet synchronized automatically.
import hashlib
publisher_source = Path("public/MILO.user.js")
publisher_sha_source = Path("public/MILO.user.js.sha256")
bookmarklet_source = Path("public/MILO_Launch.txt")
publisher_plugin_source = Path("android-patch/PublisherFilePlugin.java")
if not publisher_source.exists() or not bookmarklet_source.exists() or not publisher_plugin_source.exists():
    raise SystemExit("MILO/MILO_Launch/plugin Android absent")

publisher_sha = hashlib.sha256(publisher_source.read_bytes()).hexdigest()
expected_publisher_sha = publisher_sha
publisher_sha_source.write_text(expected_publisher_sha + "\n", encoding="utf-8")

# TEST-93: the Chrome bookmarklet is intentionally NOT pinned to one MILO SHA-256.
# Chrome keeps the bookmark across app updates; an exact digest here made every MILO
# update invalidate an already-installed bookmark. The launcher now validates MILO's
# stable identity markers, while Android still verifies the bundled asset byte-for-byte
# against the hash generated from the bundled MILO file before exporting it.
bookmarklet_text = bookmarklet_source.read_text(encoding="utf-8")
if "@name         MILO · Redacted BannerLab" not in bookmarklet_text or "SHA-256 invalide" in bookmarklet_text:
    raise SystemExit("MILO_Launch.txt n'utilise pas le validateur durable attendu")

# cap sync has normally already copied public/ into Android assets: update that copy too.
android_bookmarklet = Path("android/app/src/main/assets/public/MILO_Launch.txt")
if android_bookmarklet.exists():
    android_bookmarklet.write_text(bookmarklet_text, encoding="utf-8")

# Synchronize the Java runtime integrity check before copying the plugin to the app.
publisher_plugin_text = publisher_plugin_source.read_text(encoding="utf-8")
publisher_plugin_text, plugin_count = re.subn(
    r'(EXPECTED_PUBLISHER_SHA256\s*=\s*")[0-9a-fA-F]{64}(";)',
    rf'\g<1>{expected_publisher_sha}\2',
    publisher_plugin_text,
    count=1,
)
if plugin_count != 1:
    raise SystemExit("Impossible de synchroniser le SHA-256 dans PublisherFilePlugin.java")
publisher_plugin_source.write_text(publisher_plugin_text, encoding="utf-8")

# Verify the Android asset is the same MILO program if cap sync already ran.
android_publisher = Path("android/app/src/main/assets/public/MILO.user.js")
if android_publisher.exists() and android_publisher.read_bytes() != publisher_source.read_bytes():
    raise SystemExit("MILO Android différent du source MILO")

print(f"MILO vérifié et empreintes synchronisées: {expected_publisher_sha}")

# Hard build check: the exact Companion must already be present in the Android APK assets.
source_companion = Path("public/igor.user.js")
android_companion = Path("android/app/src/main/assets/public/igor.user.js")
if not source_companion.exists():
    raise SystemExit("IGOR source absent: public/igor.user.js")
if source_companion.stat().st_size < 1024:
    raise SystemExit(f"IGOR source invalide: {source_companion.stat().st_size} octets")
companion_text = source_companion.read_text(encoding="utf-8")
for marker in ["// @id           redacted-bannerlab-iitc", "// @version      0.6.39"]:
    if marker not in companion_text:
        raise SystemExit(f"Identité/version IGOR invalide: {marker}")
if not android_companion.exists():
    raise SystemExit("IGOR absent des assets Android après cap sync")
if android_companion.read_bytes() != source_companion.read_bytes():
    raise SystemExit("IGOR Android différent du source IGOR")
print(f"IGOR Android vérifié: {android_companion.stat().st_size} octets")

# Reinstall the custom plugin/service/MainActivity every time.
dst = Path("android/app/src/main/java/com/bannerforge/mobile")
dst.mkdir(parents=True, exist_ok=True)
for name in ["MissionOverlayPlugin.java", "MissionOverlayService.java", "RedactedOverlayService.java", "PrimeOverlayAccessibilityService.java", "TimerOverlayService.java", "BackupFolderPlugin.java", "LocationStatusPlugin.java", "IitcAutoSyncActivity.java", "IitcSyncInboxPlugin.java", "IitcBridgeLauncherPlugin.java", "IitcInstallProvider.java", "UpdateManagerPlugin.java", "UpdateInstallActivity.java", "PublisherFilePlugin.java", "MainActivity.java"]:
    source = Path("android-patch") / name
    if not source.exists():
        raise SystemExit(f"{source} absent")
    shutil.copy2(source, dst / name)

# GitHub Actions exposes GITHUB_REPOSITORY as OWNER/REPO. Inject it into the
# final Android assets so the updater follows the repository that actually built this APK.
repo = os.environ.get("RBL_GITHUB_REPOSITORY") or os.environ.get("GITHUB_REPOSITORY") or ""
update_cfg = {"repo": repo, "apkPattern": r"(?i)redacted.*bannerlab.*\.apk$|(?i)\.apk$"}
source_cfg = Path("public/update-config.json")
source_cfg.write_text(json.dumps(update_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
android_cfg = Path("android/app/src/main/assets/public/update-config.json")
android_cfg.parent.mkdir(parents=True, exist_ok=True)
android_cfg.write_text(json.dumps(update_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Updater GitHub configuré pour: {repo or '[repo injecté uniquement dans GitHub Actions]'}")

print("TEST-76 CLEAN : IGOR 0.6.39 vérifié, package TEST séparé, updater RITA et protections Android intégrés.")
