package com.bannerforge.mobile;

import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class RitaNewsReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "rita_news";
    private static final String PREFS = "rbl_rita_news";
    private static final String NEWS_URL = "https://ingress.com/news";
    private static final long PERIOD_MS = 3L * 60L * 60L * 1000L;

    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) { schedule(context); return; }
        final PendingResult pending = goAsync();
        new Thread(() -> { try { check(context.getApplicationContext()); } finally { pending.finish(); } }, "RITA-News").start();
    }

    public static void schedule(Context context) {
        createChannel(context);
        Intent i = new Intent(context, RitaNewsReceiver.class).setAction("com.bannerforge.mobile.RITA_NEWS_CHECK");
        PendingIntent pi = PendingIntent.getBroadcast(context, 7717, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, android.os.SystemClock.elapsedRealtime()+60_000L, PERIOD_MS, pi);
    }

    private static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "RITA · Actualités Ingress", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Nouvelles transmissions détectées par RITA sur ingress.com/news");
            NotificationManager nm = c.getSystemService(NotificationManager.class); if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private static void check(Context c) {
        try {
            HttpURLConnection con=(HttpURLConnection)new URL(NEWS_URL).openConnection();
            con.setConnectTimeout(12000); con.setReadTimeout(12000); con.setRequestProperty("User-Agent","RedactedBannerLab-RITA/1.1.1");
            String html; try(InputStream in=con.getInputStream()){ html=new String(in.readAllBytes(), StandardCharsets.UTF_8); }
            Pattern p=Pattern.compile("href=[\\\"']([^\\\"']*/news/[^\\\"'#?]+)[\\\"'][^>]*>(.*?)</a>", Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
            Matcher m=p.matcher(html); LinkedHashMap<String,String> found=new LinkedHashMap<>();
            while(m.find() && found.size()<20){ String u=m.group(1); if(u.startsWith("/"))u="https://ingress.com"+u; if(!u.startsWith("http"))continue; String t=m.group(2).replaceAll("<[^>]+>"," ").replaceAll("\\s+"," ").trim(); if(t.length()>2 && !t.equalsIgnoreCase("news"))found.put(u,t); }
            if(found.isEmpty()) return;
            android.content.SharedPreferences sp=c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            Set<String> seen=new HashSet<>(sp.getStringSet("seen", Collections.emptySet()));
            boolean initialized=sp.getBoolean("initialized",false);
            if(!initialized){ seen.addAll(found.keySet()); sp.edit().putStringSet("seen",seen).putBoolean("initialized",true).apply(); return; }
            for(Map.Entry<String,String> e:found.entrySet()) if(!seen.contains(e.getKey())) { notify(c,e.getValue(),e.getKey()); seen.add(e.getKey()); }
            if(seen.size()>100){ ArrayList<String> keep=new ArrayList<>(); for(String u:found.keySet())keep.add(u); seen=new HashSet<>(keep); }
            sp.edit().putStringSet("seen",seen).apply();
        } catch(Exception ignored) {}
    }

    private static void notify(Context c,String title,String url) {
        createChannel(c);
        Intent open=new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
        PendingIntent pi=PendingIntent.getActivity(c, Math.abs(url.hashCode()), open, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new NotificationCompat.Builder(c,CHANNEL_ID)
          .setSmallIcon(c.getApplicationInfo().icon).setContentTitle("RITA // TRANSMISSION DÉTECTÉE")
          .setContentText(title).setStyle(new NotificationCompat.BigTextStyle().bigText("Nouvelle communication officielle Ingress détectée.\n"+title))
          .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build();
        NotificationManagerCompat.from(c).notify(Math.abs(url.hashCode()),n);
    }
}
