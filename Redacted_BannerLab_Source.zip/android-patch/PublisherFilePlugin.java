package com.bannerforge.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@CapacitorPlugin(name = "PublisherFiles")
public class PublisherFilePlugin extends Plugin {
    private static final String PREFS = "redacted_bannerlab_publisher";
    private static final String KEY_TREE_URI = "publisher_tree_uri";
    private static final String MILO_PROGRAM_NAME = "MILO.user.js";
    private static final String MILO_PROGRAM_ASSET = "public/" + MILO_PROGRAM_NAME;
    private static final String MILO_CURRENT_BANNER = "MILO_CurrentBanner.json";
    // v1.0.15 migration: legacy names are only used to keep already-configured Chrome bookmarks alive.
    private static final String LEGACY_PROGRAM_NAME = "redacted-bannerlab-publisher.user.js";
    private static final String LEGACY_CURRENT_SESSION = "RBL_Current_Session.rblpub.json";
    private static final String EXPECTED_PUBLISHER_SHA256 = "581731bd807e075a9664c1ae44ad517595f1d160fd7c187715d6189386c7c4ee";

    private android.content.SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private Uri configuredTreeUri() {
        String raw = prefs().getString(KEY_TREE_URI, "");
        if (raw == null || raw.isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Exception e) { return null; }
    }

    private String folderLabel(Uri treeUri) {
        if (treeUri == null) return "";
        try {
            ContentResolver resolver = getContext().getContentResolver();
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
            try (Cursor c = resolver.query(docUri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) {}
        String last = treeUri.getLastPathSegment();
        return last == null ? treeUri.toString() : Uri.decode(last).replace("primary:", "Stockage/");
    }

    private JSObject folderResult(Uri uri) {
        JSObject ret = new JSObject();
        ret.put("configured", uri != null);
        ret.put("uri", uri == null ? "" : uri.toString());
        ret.put("label", folderLabel(uri));
        return ret;
    }

    @PluginMethod
    public void getFolder(PluginCall call) {
        call.resolve(folderResult(configuredTreeUri()));
    }

    @PluginMethod
    public void chooseFolder(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, intent, "folderPicked");
    }

    @ActivityCallback
    private void folderPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            JSObject ret = folderResult(configuredTreeUri());
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        Uri uri = result.getData().getData();
        int flags = result.getData().getFlags() &
                (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (flags == 0) {
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        }
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException e) {
            call.reject("Android n'a pas accordé l'accès permanent à ce dossier", e);
            return;
        }

        prefs().edit().putString(KEY_TREE_URI, uri.toString()).apply();
        JSObject ret = folderResult(uri);
        ret.put("cancelled", false);
        call.resolve(ret);
    }

    @PluginMethod
    public void savePublisher(PluginCall call) {
        try {
            Uri treeUri = requireConfiguredFolder();
            byte[] data = readAsset(MILO_PROGRAM_ASSET);
            String sha = sha256(data);
            if (!EXPECTED_PUBLISHER_SHA256.equalsIgnoreCase(sha)) {
                call.reject("MILO SHA-256 invalide");
                return;
            }
            Uri uri = writeTreeFile(treeUri, MILO_PROGRAM_NAME, "text/javascript", data);
            JSObject ret = new JSObject();
            ret.put("ok", true);
            ret.put("uri", uri.toString());
            ret.put("path", folderLabel(treeUri) + "/" + MILO_PROGRAM_NAME);
            ret.put("folderLabel", folderLabel(treeUri));
            ret.put("sha256", sha);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Impossible d'enregistrer MILO: " + safeMessage(e), e);
        }
    }

    @PluginMethod
    public void saveSession(PluginCall call) {
        try {
            Uri treeUri = requireConfiguredFolder();
            String text = call.getString("text");
            String projectName = sanitizeFileName(call.getString("projectName", "MILO_Banner.json"));
            if (text == null || text.isEmpty()) {
                call.reject("Bannière MILO vide");
                return;
            }
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            Uri current = writeTreeFile(treeUri, MILO_CURRENT_BANNER, "application/json", data);
            // Compatibility path for users whose existing Chrome bookmark still holds a handle to the old file.
            if (findChild(getContext().getContentResolver(), treeUri, LEGACY_CURRENT_SESSION) != null) {
                String legacyText = text.replace("\"format\":\"redacted-bannerlab-milo-session\"",
                        "\"format\":\"redacted-bannerlab-publisher-session\"");
                writeTreeFile(treeUri, LEGACY_CURRENT_SESSION, "application/json",
                        legacyText.getBytes(StandardCharsets.UTF_8));
            }
            if (!MILO_CURRENT_BANNER.equals(projectName)) {
                writeTreeFile(treeUri, projectName, "application/json", data);
            }
            JSObject ret = new JSObject();
            ret.put("ok", true);
            ret.put("uri", current.toString());
            ret.put("path", folderLabel(treeUri) + "/" + MILO_CURRENT_BANNER);
            ret.put("folderLabel", folderLabel(treeUri));
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Impossible d'enregistrer la bannière MILO: " + safeMessage(e), e);
        }
    }

    private Uri requireConfiguredFolder() {
        Uri treeUri = configuredTreeUri();
        if (treeUri == null) {
            throw new IllegalStateException("Aucun dossier de travail MILO choisi");
        }
        return treeUri;
    }

    private Uri findChild(ContentResolver resolver, Uri treeUri, String fileName) throws Exception {
        String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId);
        String[] projection = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
        };
        try (Cursor c = resolver.query(childrenUri, projection, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String id = c.getString(0);
                    String name = c.getString(1);
                    if (fileName.equals(name)) {
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    }
                }
            }
        }
        return null;
    }

    private Uri writeTreeFile(Uri treeUri, String displayName, String mime, byte[] data) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        Uri target = findChild(resolver, treeUri, displayName);
        if (target == null) {
            String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId);
            target = DocumentsContract.createDocument(resolver, parent, mime, displayName);
            if (target == null) throw new IllegalStateException("Android n'a pas créé le fichier");
        }

        OutputStream out = null;
        try {
            try { out = resolver.openOutputStream(target, "rwt"); } catch (Exception ignored) {}
            if (out == null) out = resolver.openOutputStream(target, "w");
            if (out == null) throw new IllegalStateException("Flux d'écriture indisponible");
            out.write(data);
            out.flush();
        } finally {
            if (out != null) try { out.close(); } catch (Exception ignored) {}
        }
        return target;
    }

    private byte[] readAsset(String path) throws Exception {
        try (InputStream in = getContext().getAssets().open(path);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private String sanitizeFileName(String value) {
        String v = value == null ? "" : value.trim();
        if (v.isEmpty()) return "MILO_Banner.json";
        v = v.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        if (!v.toLowerCase().endsWith(".json")) v += ".json";
        if (v.length() > 120) v = v.substring(0, 120);
        return v;
    }

    private String sha256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data);
        StringBuilder sb = new StringBuilder(digest.length * 2);
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private String safeMessage(Exception e) {
        String msg = e.getMessage();
        return (msg == null || msg.trim().isEmpty()) ? e.getClass().getSimpleName() : msg;
    }
}
