package com.bannerforge.mobile;

import android.content.ActivityNotFoundException;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class MissionOverlayService extends Service {
    public static final String ACTION_START = "com.bannerforge.mobile.overlay.START";
    public static final String ACTION_STOP = "com.bannerforge.mobile.overlay.STOP";
    public static final String EXTRA_SESSION = "sessionJson";
    public static final String PREFS = "rbl_mission_overlay";

    private static final int NOTIFICATION_ID = 7407;
    private static final String CHANNEL_ID = "rbl_mission_overlay";
    private static final String OVERLAY_NAME = "OSCAR"; // Overlay System for Coordinates And Routing

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private DragFrameLayout root;
    private LinearLayout expandedPanel;
    private FrameLayout bubble;
    private TextView bubbleCounterText;
    private TextView bubbleDoneText;
    private TextView bubbleUndoText;
    private TextView counterText;
    private TextView titleText;
    private TextView doneText;
    private TextView undoMissionText;
    private TextView resetBannerText;
    private TextView pauseText;
    private Button bubblePrevButton;
    private Button bubbleNextButton;
    private FrameLayout celebrationRoot;
    private boolean minimized = false;
    private long resetConfirmUntil = 0L;

    private final Runnable titleTickerRunnable = new Runnable() {
        @Override public void run() {
            if (titleText == null || minimized || titleText.getVisibility() != View.VISIBLE) return;
            CharSequence cs = titleText.getText();
            int textWidth = cs == null ? 0 : Math.round(titleText.getPaint().measureText(cs.toString()));
            int maxScroll = Math.max(0, textWidth - titleText.getWidth());
            if (maxScroll <= 0) {
                titleText.scrollTo(0, 0);
                return;
            }
            int next = titleText.getScrollX() + dp(1);
            if (next >= maxScroll) {
                titleText.scrollTo(0, 0);
                titleText.postDelayed(this, 1100L);
            } else {
                titleText.scrollTo(next, 0);
                titleText.postDelayed(this, 55L);
            }
        }
    };

    private void restartTitleTicker() {
        if (titleText == null) return;
        titleText.removeCallbacks(titleTickerRunnable);
        titleText.scrollTo(0, 0);
        if (!minimized) titleText.postDelayed(titleTickerRunnable, 900L);
    }

    private JSONObject session;
    private JSONArray missions = new JSONArray();
    private int currentIndex = 0;
    private long startedAt = 0L;
    private long finishedAt = 0L;
    private long pausedAt = 0L;
    private long pausedTotal = 0L;
    private boolean paused = false;
    private final Set<String> done = new HashSet<>();
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String json = intent != null ? intent.getStringExtra(EXTRA_SESSION) : null;
        if (json != null && !json.trim().isEmpty()) {
            loadSession(json);
        } else {
            loadSession(prefs.getString("sessionJson", ""));
        }
        if (session == null || missions.length() == 0) {
            stopSelf();
            return START_NOT_STICKY;
        }
        createOrRefreshOverlay();
        startForegroundCompat();
        saveState(true);
        return START_NOT_STICKY;
    }

    private void loadSession(String json) {
        if (json == null || json.trim().isEmpty()) return;
        try {
            JSONObject next = new JSONObject(json);
            JSONArray nextMissions = next.optJSONArray("missions");
            if (nextMissions == null || nextMissions.length() == 0) return;
            String oldId = session == null ? prefs.getString("bannerId", "") : session.optString("bannerId", "");
            String newId = next.optString("bannerId", next.optString("id", ""));
            session = next;
            missions = nextMissions;
            if (!newId.equals(oldId)) {
                done.clear();
                currentIndex = Math.max(0, Math.min(next.optInt("currentIndex", 0), missions.length() - 1));
                startedAt = next.optLong("startedAt", System.currentTimeMillis());
                finishedAt = 0L; pausedAt = 0L; pausedTotal = 0L; paused = false;
            } else {
                currentIndex = Math.max(0, Math.min(prefs.getInt("currentIndex", next.optInt("currentIndex", 0)), missions.length() - 1));
                restoreDone();
                startedAt = prefs.getLong("startedAt", next.optLong("startedAt", System.currentTimeMillis()));
                finishedAt = prefs.getLong("finishedAt", 0L); pausedAt = prefs.getLong("pausedAt", 0L); pausedTotal = prefs.getLong("pausedTotal", 0L); paused = prefs.getBoolean("paused", false);
            }
        } catch (JSONException ignored) {
            session = null;
            missions = new JSONArray();
        }
    }

    private void restoreDone() {
        done.clear();
        String raw = prefs.getString("doneJson", "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) done.add(String.valueOf(arr.optInt(i)));
        } catch (JSONException ignored) {}
    }

    private void createOrRefreshOverlay() {
        if (root == null) {
            root = new DragFrameLayout(this);
            buildExpandedPanel();
            buildBubble();

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            params = new WindowManager.LayoutParams(
                expandedWidthPx(), WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = prefs.getInt("x", dp(18));
            params.y = prefs.getInt("y", dp(130));
            windowManager.addView(root, params);
            root.post(this::clampOverlayToScreen);
        }
        refreshUi();
        if (root != null) root.post(this::clampOverlayToScreen);
    }

    private void buildExpandedPanel() {
        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.VERTICAL);
        expandedPanel.setPadding(dp(10), dp(8), dp(10), dp(9));
        expandedPanel.setBackground(panelBackground(0xFF06140D, 0xFF31ED83, 15));
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        root.addView(expandedPanel, ep);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        expandedPanel.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));

        ImageView dino = new ImageView(this);
        dino.setImageResource(R.drawable.oscar_overlay);
        dino.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams dinoLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        dinoLp.setMargins(0, 0, dp(8), 0);
        header.addView(dino, dinoLp);
        dino.setOnClickListener(v -> setMinimized(true));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(labels, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        counterText = text(OVERLAY_NAME, 11, Color.rgb(49, 237, 131), true);
        titleText = text("Mission", 10, Color.WHITE, true);
        titleText.setSingleLine(true);
        titleText.setHorizontallyScrolling(true);
        titleText.setPadding(0, dp(1), 0, 0);
        labels.addView(counterText, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        labels.addView(titleText, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button min = smallButton("−");
        min.setOnClickListener(v -> setMinimized(true));
        header.addView(min, new LinearLayout.LayoutParams(dp(34), dp(34)));

        Button close = smallButton("×");
        close.setOnClickListener(v -> stopSelf());
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        closeLp.setMargins(dp(5), 0, 0, 0);
        header.addView(close, closeLp);

        doneText = text("✓ MISSION TERMINÉE", 10, Color.WHITE, true);
        doneText.setGravity(Gravity.CENTER);
        doneText.setPadding(dp(7), dp(8), dp(7), dp(8));
        doneText.setBackground(panelBackground(0xFF10291B, 0xFF31ED83, 10));
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(39));
        doneLp.setMargins(0, dp(7), 0, 0);
        expandedPanel.addView(doneText, doneLp);
        doneText.setOnClickListener(v -> markDoneAndAdvance());

        Button open = actionButton("▶ OUVRIR LA MISSION");
        open.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(49, 237, 131)));
        open.setTextColor(Color.rgb(4, 20, 10));
        open.setOnClickListener(v -> openCurrentMission());
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(39));
        openLp.setMargins(0, dp(6), 0, 0);
        expandedPanel.addView(open, openLp);

        undoMissionText = text("↶ Annuler", 9, Color.rgb(210, 225, 215), true);
        undoMissionText.setGravity(Gravity.CENTER);
        undoMissionText.setPadding(dp(5), dp(5), dp(5), dp(5));
        undoMissionText.setBackground(panelBackground(0xFF0B2116, 0xFF28523B, 9));
        undoMissionText.setOnClickListener(v -> undoLastMission());
        LinearLayout.LayoutParams undoLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(31));
        undoLp.setMargins(0, dp(5), 0, 0);
        expandedPanel.addView(undoMissionText, undoLp);

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(29));
        footerLp.setMargins(0, dp(5), 0, 0);
        expandedPanel.addView(footer, footerLp);

        pauseText = text("⏸ Pause", 8, Color.rgb(190, 215, 198), true);
        pauseText.setGravity(Gravity.CENTER);
        pauseText.setPadding(dp(4), dp(4), dp(4), dp(4));
        pauseText.setBackground(panelBackground(0xFF0B2116, 0xFF28523B, 8));
        pauseText.setOnClickListener(v -> togglePause());
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
        pauseLp.setMargins(0, 0, dp(3), 0);
        footer.addView(pauseText, pauseLp);

        resetBannerText = text("↺ Reset", 8, Color.rgb(210, 225, 215), true);
        resetBannerText.setGravity(Gravity.CENTER);
        resetBannerText.setPadding(dp(4), dp(4), dp(4), dp(4));
        resetBannerText.setBackground(panelBackground(0xFF21140E, 0xFF6E4934, 8));
        resetBannerText.setOnClickListener(v -> requestResetBanner());
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
        resetLp.setMargins(dp(3), 0, 0, 0);
        footer.addView(resetBannerText, resetLp);
    }

    private void buildBubble() {
        bubble = new FrameLayout(this);
        bubble.setVisibility(View.GONE);
        bubble.setBackground(panelBackground(0xF207150E, 0xFF31ED83, 28));
        bubble.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.addView(bubble, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout mini = new LinearLayout(this);
        mini.setOrientation(LinearLayout.HORIZONTAL);
        mini.setGravity(Gravity.CENTER_VERTICAL);
        bubble.addView(mini, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ));

        bubblePrevButton = smallButton("‹");
        bubblePrevButton.setTextSize(15f);
        bubblePrevButton.setOnClickListener(v -> changeMission(-1));
        LinearLayout.LayoutParams prevLp = new LinearLayout.LayoutParams(dp(30), dp(30));
        prevLp.setMargins(0, 0, dp(4), 0);
        mini.addView(bubblePrevButton, prevLp);

        FrameLayout avatarWrap = new FrameLayout(this);
        avatarWrap.setForegroundGravity(Gravity.CENTER);
        LinearLayout.LayoutParams avatarWrapLp = new LinearLayout.LayoutParams(dp(54), dp(54));
        avatarWrapLp.setMargins(0, 0, dp(5), 0);
        mini.addView(avatarWrap, avatarWrapLp);
        avatarWrap.setOnClickListener(v -> setMinimized(false));

        ImageView img = new ImageView(this);
        img.setImageResource(R.drawable.oscar_overlay);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarWrap.addView(img, new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER));

        bubbleCounterText = text("M1/1", 8, Color.WHITE, true);
        bubbleCounterText.setGravity(Gravity.CENTER);
        bubbleCounterText.setBackground(panelBackground(0xF008160E, 0xFF31ED83, 10));
        FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(40), dp(19), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        badgeLp.bottomMargin = dp(-1);
        avatarWrap.addView(bubbleCounterText, badgeLp);

        bubbleDoneText = text("✓ Terminée", 8, Color.WHITE, true);
        bubbleDoneText.setGravity(Gravity.CENTER);
        bubbleDoneText.setPadding(dp(7), dp(0), dp(7), dp(0));
        bubbleDoneText.setBackground(panelBackground(0xFF10291B, 0xFF31ED83, 9));
        bubbleDoneText.setOnClickListener(v -> markDoneAndAdvance());
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30));
        doneLp.setMargins(0, 0, dp(4), 0);
        mini.addView(bubbleDoneText, doneLp);

        bubbleUndoText = text("↶ Annuler", 8, Color.WHITE, true);
        bubbleUndoText.setGravity(Gravity.CENTER);
        bubbleUndoText.setPadding(dp(7), dp(0), dp(7), dp(0));
        bubbleUndoText.setBackground(panelBackground(0xFF21140E, 0xFF8C3F36, 9));
        bubbleUndoText.setOnClickListener(v -> undoLastMission());
        LinearLayout.LayoutParams undoLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30));
        undoLp.setMargins(0, 0, dp(4), 0);
        mini.addView(bubbleUndoText, undoLp);

        bubbleNextButton = smallButton("›");
        bubbleNextButton.setTextSize(15f);
        bubbleNextButton.setOnClickListener(v -> changeMission(1));
        mini.addView(bubbleNextButton, new LinearLayout.LayoutParams(dp(30), dp(30)));
    }

    private void attachDrag(View handle, @Nullable Runnable onTap) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float startRawX, startRawY;
            int startX, startY;
            long downAt;
            float maxDistance;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRawX = event.getRawX();
                        startRawY = event.getRawY();
                        startX = params == null ? 0 : params.x;
                        startY = params == null ? 0 : params.y;
                        downAt = System.currentTimeMillis();
                        maxDistance = 0f;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (params == null) return true;
                        float dx = event.getRawX() - startRawX;
                        float dy = event.getRawY() - startRawY;
                        float distance = (float)Math.hypot(dx, dy);
                        maxDistance = Math.max(maxDistance, distance);
                        long held = System.currentTimeMillis() - downAt;
                        if (!moved && held >= 180L && distance > dp(3)) moved = true;
                        if (moved) {
                            params.x = startX + Math.round(dx);
                            params.y = startY + Math.round(dy);
                            clampOverlayToScreen();
                            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved && params != null) {
                            clampOverlayToScreen();
                            prefs.edit().putInt("x", params.x).putInt("y", params.y).apply();
                            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                        } else if (onTap != null && maxDistance <= dp(8)) {
                            onTap.run();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return true;
            }
        });
    }

    private class DragFrameLayout extends FrameLayout {
        private float downRawX, downRawY;
        private int downX, downY;
        private long downAt;
        private boolean dragging;

        DragFrameLayout(Context context) { super(context); }

        @Override public boolean onInterceptTouchEvent(MotionEvent event) {
            if (params == null) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    downX = params.x;
                    downY = params.y;
                    downAt = System.currentTimeMillis();
                    dragging = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRawX;
                    float dy = event.getRawY() - downRawY;
                    long held = System.currentTimeMillis() - downAt;
                    if (held >= 180L && Math.hypot(dx, dy) > dp(3)) {
                        dragging = true;
                        return true;
                    }
                    return false;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    return false;
            }
            return false;
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (params == null) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return true;
                    params.x = downX + Math.round(event.getRawX() - downRawX);
                    params.y = downY + Math.round(event.getRawY() - downRawY);
                    clampOverlayToScreen();
                    try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        clampOverlayToScreen();
                        prefs.edit().putInt("x", params.x).putInt("y", params.y).apply();
                        try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
                    }
                    dragging = false;
                    return true;
            }
            return true;
        }
    }

    private int screenWidthPx() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenHeightPx() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int expandedWidthPx() {
        return Math.max(dp(238), Math.min(dp(286), screenWidthPx() - dp(20)));
    }

    private void clampOverlayToScreen() {
        if (params == null) return;
        int margin = dp(8);
        int width = root != null && root.getWidth() > 0
            ? root.getWidth()
            : (minimized ? dp(248) : expandedWidthPx());
        int height = root != null && root.getHeight() > 0 ? root.getHeight() : dp(minimized ? 66 : 205);
        int maxX = Math.max(margin, screenWidthPx() - width - margin);
        int maxY = Math.max(margin, screenHeightPx() - height - margin);
        params.x = Math.max(margin, Math.min(params.x, maxX));
        params.y = Math.max(margin, Math.min(params.y, maxY));
    }

    private void setMinimized(boolean value) {
        minimized = value;
        if (titleText != null) {
            titleText.removeCallbacks(titleTickerRunnable);
            titleText.scrollTo(0, 0);
        }
        if (expandedPanel != null) expandedPanel.setVisibility(value ? View.GONE : View.VISIBLE);
        if (bubble != null) bubble.setVisibility(value ? View.VISIBLE : View.GONE);
        if (params != null) {
            params.width = value ? WindowManager.LayoutParams.WRAP_CONTENT : expandedWidthPx();
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            clampOverlayToScreen();
            try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
            if (root != null) root.post(() -> {
                clampOverlayToScreen();
                try { windowManager.updateViewLayout(root, params); } catch (Exception ignored) {}
            });
        }
        refreshUi();
        if (!value) restartTitleTicker();
    }

    private void refreshUi() {
        if (missions.length() == 0) return;
        currentIndex = Math.max(0, Math.min(currentIndex, missions.length() - 1));
        JSONObject m = missions.optJSONObject(currentIndex);
        String missionTitle = m == null ? "Mission" : m.optString("title", "Mission " + (currentIndex + 1));
        String bannerTitle = session == null ? "Redacted BannerLab" : session.optString("title", session.optString("bannerTitle", "Redacted BannerLab"));
        if (counterText != null) counterText.setText(OVERLAY_NAME + " · M" + (currentIndex + 1) + "/" + missions.length());
        if (titleText != null) {
            titleText.setText(missionTitle);
            restartTitleTicker();
        }
        if (doneText != null) {
            boolean allDone = done.size() >= missions.length();
            doneText.setText(allDone ? "🏁 FRESQUE TERMINÉE" : "✓ MISSION TERMINÉE");
            doneText.setAlpha(1f);
        }
        if (undoMissionText != null) {
            boolean canUndo = !done.isEmpty();
            undoMissionText.setText(canUndo ? "↶ Annuler la dernière validation" : "↶ Rien à annuler");
            undoMissionText.setAlpha(canUndo ? 1f : 0.42f);
        }
        if (resetBannerText != null) {
            boolean hasProgress = !done.isEmpty();
            boolean confirming = hasProgress && System.currentTimeMillis() < resetConfirmUntil;
            resetBannerText.setText(confirming ? "⚠ Confirmer reset" : "↺ Reset fresque");
            resetBannerText.setAlpha(hasProgress ? 1f : 0.42f);
        }
        if (pauseText != null) pauseText.setText(paused ? "▶ Reprendre" : "⏸ Pause");
        if (bubbleCounterText != null) {
            bubbleCounterText.setText("M" + (currentIndex + 1) + "/" + missions.length());
        }
        if (bubbleDoneText != null) {
            boolean allDone = done.size() >= missions.length();
            bubbleDoneText.setText(allDone ? "🏁 Fresque" : "✓ Terminée");
            bubbleDoneText.setAlpha(1f);
        }
        if (bubbleUndoText != null) {
            boolean canUndo = !done.isEmpty();
            bubbleUndoText.setAlpha(canUndo ? 1f : 0.42f);
        }
        if (bubblePrevButton != null) bubblePrevButton.setAlpha(currentIndex > 0 ? 1f : 0.42f);
        if (bubbleNextButton != null) bubbleNextButton.setAlpha(currentIndex < missions.length() - 1 ? 1f : 0.42f);
        prefs.edit().putString("bannerTitle", bannerTitle).putString("missionTitle", missionTitle).apply();
        updateNotification();
        saveState(true);
    }

    private void changeMission(int delta) {
        int next = Math.max(0, Math.min(currentIndex + delta, missions.length() - 1));
        if (next == currentIndex) return;
        currentIndex = next;
        refreshUi();
    }

    private void markDoneAndAdvance() {
        boolean wasComplete = done.size() >= missions.length();
        done.add(String.valueOf(currentIndex));
        boolean isComplete = done.size() >= missions.length();
        if (isComplete) {
            if (paused) { pausedTotal += Math.max(0L, System.currentTimeMillis() - pausedAt); paused = false; pausedAt = 0L; }
            if (finishedAt == 0L) finishedAt = System.currentTimeMillis();
        }
        if (currentIndex < missions.length() - 1) currentIndex++;
        refreshUi();
        if (!wasComplete && isComplete) showFinishCelebration();
    }

    private void undoLastMission() {
        if (done.isEmpty()) return;
        int target = currentIndex;
        String currentKey = String.valueOf(target);
        if (!done.contains(currentKey)) {
            target = -1;
            for (int i = currentIndex - 1; i >= 0; i--) {
                if (done.contains(String.valueOf(i))) { target = i; break; }
            }
            if (target < 0) {
                for (int i = missions.length() - 1; i >= 0; i--) {
                    if (done.contains(String.valueOf(i))) { target = i; break; }
                }
            }
        }
        if (target < 0) return;
        done.remove(String.valueOf(target));
        currentIndex = target;
        finishedAt = 0L;
        resetConfirmUntil = 0L;
        hideFinishCelebration();
        refreshUi();
    }

    private void requestResetBanner() {
        if (done.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (now < resetConfirmUntil) {
            resetBannerProgress();
            return;
        }
        resetConfirmUntil = now + 4000L;
        refreshUi();
        if (resetBannerText != null) {
            resetBannerText.postDelayed(() -> {
                if (System.currentTimeMillis() >= resetConfirmUntil) {
                    resetConfirmUntil = 0L;
                    refreshUi();
                }
            }, 4100L);
        }
    }

    private void resetBannerProgress() {
        done.clear();
        currentIndex = 0;
        startedAt = System.currentTimeMillis();
        finishedAt = 0L;
        pausedAt = 0L;
        pausedTotal = 0L;
        paused = false;
        resetConfirmUntil = 0L;
        hideFinishCelebration();
        refreshUi();
    }

    private void showFinishCelebration() {
        if (windowManager == null || celebrationRoot != null) return;

        final FrameLayout celebration = new FrameLayout(this);
        celebration.setClipChildren(false);
        celebration.setClipToPadding(false);

        FireworksView fireworks = new FireworksView(this);
        celebration.addView(fireworks, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(panelBackground(0xE607150E, 0xFF31ED83, 18));
        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
            Math.min(dp(342), screenWidthPx() - dp(24)),
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        );
        celebration.addView(card, cardLp);

        TextView finished = text("FRESQUE TERMINÉE !", 18, Color.WHITE, true);
        finished.setGravity(Gravity.CENTER);
        card.addView(finished, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView subtitle = text("Le personnel du Lab a reçu le rapport.", 10, Color.rgb(160, 222, 181), false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        subtitleLp.setMargins(0, dp(2), 0, dp(9));
        card.addView(subtitle, subtitleLp);

        LinearLayout team = new LinearLayout(this);
        team.setOrientation(LinearLayout.HORIZONTAL);
        team.setGravity(Gravity.CENTER);
        card.addView(team, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout redactedMember = teamMember(R.drawable.redacted_bannerlab_logo, "REDACTED", 64);
        LinearLayout igorMember = teamMember(R.drawable.igor_overlay, "IGOR", 46);
        LinearLayout miloMember = teamMember(R.drawable.milo_overlay, "MILO", 46);
        LinearLayout ritaMember = teamMember(R.drawable.rita_overlay, "RITA", 46);
        LinearLayout oscarMember = teamMember(R.drawable.oscar_overlay, "OSCAR", 46);
        team.addView(redactedMember, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        team.addView(igorMember, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        team.addView(miloMember, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        team.addView(ritaMember, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        team.addView(oscarMember, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView dialogue = text("REDACTED · Rapport reçu. Fresque bouclée, Agent.", 10, Color.WHITE, true);
        dialogue.setGravity(Gravity.CENTER);
        dialogue.setPadding(dp(10), dp(9), dp(10), dp(9));
        dialogue.setBackground(panelBackground(0xCC10291B, 0xAA31A968, 12));
        LinearLayout.LayoutParams dialogueLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        dialogueLp.setMargins(0, dp(9), 0, 0);
        card.addView(dialogue, dialogueLp);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        WindowManager.LayoutParams celebrationParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        );
        celebrationParams.gravity = Gravity.TOP | Gravity.START;

        try {
            windowManager.addView(celebration, celebrationParams);
            celebrationRoot = celebration;
        } catch (Exception ignored) {
            return;
        }

        card.setAlpha(0f);
        card.setScaleX(0.88f);
        card.setScaleY(0.88f);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start();

        View[] members = new View[]{redactedMember, igorMember, miloMember, ritaMember, oscarMember};
        for (int i = 0; i < members.length; i++) {
            View member = members[i];
            member.setAlpha(0f);
            member.setTranslationY(dp(16));
            member.animate().alpha(1f).translationY(0f).setStartDelay(140L + 120L * i).setDuration(330).start();
        }

        final String[] lines = new String[]{
            "REDACTED · Rapport reçu. Fresque bouclée, Agent.",
            "OSCAR · Dernière coordonnée confirmée. Aucun Agent perdu : bilan acceptable.",
            "IGOR · Parcours validé. Je range la carte avant que quelqu'un écrive dessus.",
            "MILO · Dossier classé côté publication. Pour une fois, rien ne fume.",
            "RITA · Rapport transmis. Le support n'aura presque rien à faire. Presque.",
            "REDACTED · On remballe les éprouvettes. Mission accomplie."
        };
        for (int i = 1; i < lines.length; i++) {
            final int idx = i;
            celebration.postDelayed(() -> {
                if (celebrationRoot != celebration) return;
                dialogue.animate().alpha(0f).setDuration(140).withEndAction(() -> {
                    dialogue.setText(lines[idx]);
                    dialogue.animate().alpha(1f).setDuration(200).start();
                }).start();
            }, 4200L * i);
        }

        celebration.postDelayed(() -> {
            if (celebrationRoot != celebration) return;
            celebration.animate().alpha(0f).setDuration(520).withEndAction(this::hideFinishCelebration).start();
        }, 26000L);
    }

    private LinearLayout teamMember(int drawableRes, String name, int avatarDp) {
        LinearLayout member = new LinearLayout(this);
        member.setOrientation(LinearLayout.VERTICAL);
        member.setGravity(Gravity.CENTER);

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(drawableRes);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams avatarLp = new LinearLayout.LayoutParams(dp(avatarDp), dp(avatarDp));
        member.addView(avatar, avatarLp);

        TextView label = text(name, 7, Color.rgb(187, 228, 201), true);
        label.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        labelLp.setMargins(0, dp(3), 0, 0);
        member.addView(label, labelLp);
        return member;
    }

    private void hideFinishCelebration() {
        if (celebrationRoot == null || windowManager == null) return;
        try { windowManager.removeView(celebrationRoot); } catch (Exception ignored) {}
        celebrationRoot = null;
    }

    private static class FireworkParticle {
        float x, y, vx, vy, life, maxLife, radius;
        int color;
    }

    private class FireworksView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArrayList<FireworkParticle> particles = new ArrayList<>();
        private final Random random = new Random();
        private long started = 0L;
        private long lastFrame = 0L;
        private long nextBurst = 0L;

        FireworksView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = System.currentTimeMillis();
            if (started == 0L) {
                started = now;
                lastFrame = now;
                nextBurst = now;
                for (int i = 0; i < 4; i++) spawnBurst(canvas.getWidth(), canvas.getHeight());
            }
            float dt = Math.min(0.034f, Math.max(0.001f, (now - lastFrame) / 1000f));
            lastFrame = now;

            if (now - started < 3900L && now >= nextBurst) {
                spawnBurst(canvas.getWidth(), canvas.getHeight());
                if (random.nextBoolean()) spawnBurst(canvas.getWidth(), canvas.getHeight());
                nextBurst = now + 250L + random.nextInt(260);
            }

            Iterator<FireworkParticle> it = particles.iterator();
            while (it.hasNext()) {
                FireworkParticle p = it.next();
                p.life -= dt;
                if (p.life <= 0f) {
                    it.remove();
                    continue;
                }
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.vy += dp(88) * dt;
                p.vx *= 0.992f;
                float ratio = Math.max(0f, p.life / p.maxLife);
                paint.setColor(p.color);
                paint.setAlpha(Math.round(255f * Math.min(1f, ratio * 1.35f)));
                paint.setStrokeWidth(Math.max(1f, p.radius * 0.65f));
                canvas.drawLine(p.x, p.y, p.x - p.vx * 0.025f, p.y - p.vy * 0.025f, paint);
                canvas.drawCircle(p.x, p.y, p.radius * (0.55f + ratio * 0.45f), paint);
            }

            if (now - started < 4550L || !particles.isEmpty()) postInvalidateOnAnimation();
        }

        private void spawnBurst(int width, int height) {
            if (width <= 0 || height <= 0) return;
            float cx = width * (0.12f + random.nextFloat() * 0.76f);
            float cy = height * (0.10f + random.nextFloat() * 0.48f);
            int[] colors = {
                Color.rgb(49, 237, 131),
                Color.rgb(255, 86, 190),
                Color.rgb(84, 214, 255),
                Color.rgb(255, 210, 74),
                Color.WHITE
            };
            int baseColor = colors[random.nextInt(colors.length)];
            int count = 24 + random.nextInt(20);
            float baseSpeed = dp(95 + random.nextInt(95));
            for (int i = 0; i < count; i++) {
                double angle = (Math.PI * 2d * i / count) + (random.nextDouble() - 0.5d) * 0.22d;
                float speed = baseSpeed * (0.55f + random.nextFloat() * 0.72f);
                FireworkParticle p = new FireworkParticle();
                p.x = cx;
                p.y = cy;
                p.vx = (float) Math.cos(angle) * speed;
                p.vy = (float) Math.sin(angle) * speed;
                p.maxLife = p.life = 0.85f + random.nextFloat() * 0.75f;
                p.radius = dp(1) + random.nextFloat() * dp(2);
                p.color = random.nextInt(5) == 0 ? Color.WHITE : baseColor;
                particles.add(p);
            }
        }
    }

    private void togglePause() {
        long now = System.currentTimeMillis();
        if (paused) {
            pausedTotal += Math.max(0L, now - pausedAt);
            pausedAt = 0L;
            paused = false;
        } else {
            pausedAt = now;
            paused = true;
        }
        refreshUi();
    }

    private void openCurrentMission() {
        JSONObject m = missions.optJSONObject(currentIndex);
        if (m == null) return;
        String missionId = m.optString("id", "").trim();
        if (missionId.isEmpty()) return;
        String intel = "https://intel.ingress.com/mission/" + missionId;
        Uri uri = Uri.parse("https://link.ingress.com/").buildUpon()
            .appendQueryParameter("link", intel)
            .appendQueryParameter("apn", "com.nianticproject.ingress")
            .appendQueryParameter("isi", "576505181")
            .appendQueryParameter("ibi", "com.google.ingress")
            .appendQueryParameter("ifl", "https://apps.apple.com/app/ingress/id576505181")
            .appendQueryParameter("ofl", intel)
            .build();
        // OSCAR se replie automatiquement pour laisser la carte Ingress lisible.
        setMinimized(true);
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            i.setPackage("com.nianticproject.ingress");
            startActivity(i);
        } catch (ActivityNotFoundException ex) {
            i.setPackage(null);
            try { startActivity(i); } catch (Exception ignored) {}
        }
    }

    private void saveState(boolean active) {
        JSONArray d = new JSONArray();
        for (String x : done) {
            try { d.put(Integer.parseInt(x)); } catch (Exception ignored) {}
        }
        String bannerId = session == null ? "" : session.optString("bannerId", session.optString("id", ""));
        String bannerTitle = session == null ? "" : session.optString("title", session.optString("bannerTitle", ""));
        String missionTitle = "";
        JSONObject m = missions.optJSONObject(Math.max(0, Math.min(currentIndex, Math.max(0, missions.length()-1))));
        if (m != null) missionTitle = m.optString("title", "");
        prefs.edit()
            .putBoolean("active", active)
            .putString("bannerId", bannerId)
            .putString("bannerTitle", bannerTitle)
            .putInt("currentIndex", currentIndex)
            .putInt("total", missions.length())
            .putString("missionTitle", missionTitle)
            .putString("doneJson", d.toString())
            .putString("sessionJson", session == null ? "" : session.toString())
            .putLong("startedAt", startedAt)
            .putLong("finishedAt", finishedAt)
            .putLong("pausedAt", pausedAt)
            .putLong("pausedTotal", pausedTotal)
            .putBoolean("paused", paused)
            .apply();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "RBL Mission Overlay", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Navigation dans une bannière Ingress depuis Redacted BannerLab");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pending = launch == null ? null : PendingIntent.getActivity(
            this, 0, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );
        String title = session == null ? "Redacted BannerLab" : session.optString("title", "Redacted BannerLab");
        JSONObject m = missions.optJSONObject(Math.max(0, Math.min(currentIndex, Math.max(0, missions.length()-1))));
        String subtitle = (currentIndex + 1) + "/" + missions.length() + (m == null ? "" : " · " + m.optString("title", "Mission"));
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("RBL · " + title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW);
        if (pending != null) b.setContentIntent(pending);
        return b.build();
    }

    private void startForegroundCompat() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void updateNotification() {
        if (session == null || missions.length() == 0) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(18); b.setTextColor(Color.WHITE);
        b.setPadding(0,0,0,0);
        b.setMinWidth(0); b.setMinHeight(0);
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(18, 48, 31)));
        return b;
    }

    private Button actionButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setMinWidth(0); b.setMinHeight(0);
        b.setPadding(dp(6),0,dp(6),0);
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(16, 41, 27)));
        return b;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Nullable
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        if (titleText != null) titleText.removeCallbacks(titleTickerRunnable);
        hideFinishCelebration();
        if (root != null && windowManager != null) {
            try { windowManager.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        saveState(false);
        super.onDestroy();
    }
}
