# Redacted BannerLab v1.1.1-test.92

- Ajout d’une glissière de navigation verticale sur le côté pour les fresques de 4 lignes et plus, afin de conserver les gestes d’édition sur le canvas tout en permettant de parcourir toute la fresque.
- MILO crée désormais `MILO_CurrentBanner.json` avant le test Chrome : le fichier demandé par le tutoriel existe réellement avant l’ouverture de Mission Authoring Tool.
- Le test MILO est bloqué proprement si la bannière n’est pas encore publiable, avec retour vers les éléments manquants au lieu d’ouvrir Chrome avec un fichier absent.
