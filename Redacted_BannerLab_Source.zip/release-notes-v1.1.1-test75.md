# Redacted BannerLab 1.1.1 TEST-75 CLEAN

- Portal Blaster : gain de temps fortement réduit (+1 s tous les 8 combos ; +2 s sur un boss).
- Bonus vie rare : un pickup peut rendre un cœur, jusqu’à 4 vies maximum.
- Joueur et ennemis standards utilisent les assets Drone Mk II déjà présents dans RBL.
- Boss remplacé par un méga-drone de la faction adverse.
- Logos ENL/RES affichés sur les badges et le boss.
- Machina remplacé par un noyau rouge animé dédié, plus lisible que le bloc MX.
- Aucun visuel IA ajouté.
- Base CLEAN TEST74 conservée.
- Android versionCode : 2100011075.
