@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."

REM Java 21 Temurin, adapte si besoin.
if exist "C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot\bin\java.exe" (
  set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot"
  set "PATH=%JAVA_HOME%\bin;%PATH%"
)

where node >nul 2>nul || (echo [RBL] Node.js absent & pause & exit /b 1)
where npm >nul 2>nul || (echo [RBL] npm absent & pause & exit /b 1)
where py >nul 2>nul || (echo [RBL] Python launcher py absent & pause & exit /b 1)

if not exist node_modules (
  echo [RBL] Installation npm...
  call npm install --no-audit --no-fund || exit /b 1
)

echo [RBL] Build web...
call npm run build || exit /b 1

if exist android rmdir /S /Q android
set "RBL_TEST_BUILD=1"
call npx cap add android || exit /b 1
call npx cap sync android || exit /b 1
xcopy android-res android\app\src\main\res /E /I /Y >nul
py android-patch\patch_manifest.py || exit /b 1

pushd android
call gradlew.bat assembleDebug || (popd & exit /b 1)
popd

call local-tools\copy-apk-to-drive.cmd
