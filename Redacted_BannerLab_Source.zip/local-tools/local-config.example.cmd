@echo off
REM Copie ce fichier en local-config.cmd puis adapte le chemin.
REM Exemple Google Drive Desktop :
REM set "RBL_OUTPUT_DIR=G:\Mon Drive\Redacted BannerLab Builds"
REM Exemple OneDrive :
REM set "RBL_OUTPUT_DIR=%USERPROFILE%\OneDrive\Redacted BannerLab Builds"
set "RBL_OUTPUT_DIR=%USERPROFILE%\Documents\Redacted BannerLab Builds"
