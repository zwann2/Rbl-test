@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."

if exist "%~dp0local-config.cmd" call "%~dp0local-config.cmd"
if not defined RBL_OUTPUT_DIR set "RBL_OUTPUT_DIR=%USERPROFILE%\Documents\Redacted BannerLab Builds"

set "APK=android\app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (
  echo [RBL] APK debug introuvable : %CD%\%APK%
  echo Compile d'abord dans Android Studio ou avec gradlew.bat assembleDebug.
  pause
  exit /b 1
)

if not exist "%RBL_OUTPUT_DIR%" mkdir "%RBL_OUTPUT_DIR%"
set "OUT=%RBL_OUTPUT_DIR%\Redacted-BannerLab-LOCAL-TEST.apk"
copy /Y "%APK%" "%OUT%" >nul
if errorlevel 1 (
  echo [RBL] Echec de copie vers %RBL_OUTPUT_DIR%
  pause
  exit /b 1
)

echo [RBL] APK copie :
echo %OUT%
echo.
echo Si ce dossier est synchronise avec Google Drive, l'APK apparaitra ensuite sur ton telephone.
pause
