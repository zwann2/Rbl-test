# Redacted BannerLab v1.1.1-test.104

- IGOR 0.6.44 : la résolution d’un lien `link.ingress.com/portal/<GUID>` ne peut plus mouliner indéfiniment. La voie `IITC.portal.details.request()` est limitée à 6,5 s puis IGOR bascule directement sur `getPortalDetails`.
- Timeout global de 22 s par portail manuel : en cas d’échec, IGOR renvoie un diagnostic à RBL au lieu de rester bloqué sur l’écran de chargement.
- L’extraction GUID-first reste prioritaire et ne dépend pas du portail visible sur la carte.
- Ascenseur : suppression du libellé trompeur « DERNIER ÉTAGE » affiché sur le bouton actif. L’étage visité reste simplement mis en évidence.
