#!/usr/bin/env bash
set -euo pipefail
BASE='https://raw.githubusercontent.com/le-jeu/ingress-items/62618d18af81cc4f31e8fed0b6294781a68768f4'
OUT='public/inventory'
mkdir -p "$OUT"
get(){ curl --fail --location --silent --show-error "$BASE/$1" -o "$OUT/$2"; test -s "$OUT/$2"; }
# Authentic item silhouettes
get items/xmp_buster.svg xmp.svg
get items/ultra_strike.svg ultra-strike.svg
get items/resonator.svg resonator.svg
get items/power_cube.svg power-cube.svg
get items/capsule.svg capsule.svg
get items/kinetic_capsule.svg kinetic.svg
get items/key_locker.svg key-locker.svg
get items/ada_refactor.svg ada.svg
get items/jarvis_virus.svg jarvis.svg
get items/apex_colored.svg apex.svg
get items/fracker.svg fracker.svg
get items/media.svg media.svg
get items/portal_key.svg portal_key.svg
get items/beacon_meetup.svg beacon.svg
get items/rare_battle_beacon_colored.svg battle-beacon.svg
# Authentic boxed Prime mod variants, including their own rarity colours
get boxed/boxed_portal_shield_common.svg shield-common.svg
get boxed/boxed_portal_shield_rare.svg shield-rare.svg
get boxed/boxed_portal_shield_very_rare.svg shield-vr.svg
get boxed/boxed_portal_shield_very_rare_aegis.svg aegis.svg
get boxed/boxed_heat_sink_common.svg heat-common.svg
get boxed/boxed_heat_sink_rare.svg heat-rare.svg
get boxed/boxed_heat_sink_very_rare.svg heat-vr.svg
get boxed/boxed_multi_hack_common.svg mh-common.svg
get boxed/boxed_multi_hack_rare.svg mh-rare.svg
get boxed/boxed_multi_hack_very_rare.svg mh-vr.svg
get boxed/boxed_link_amp_rare.svg link-rare.svg
get boxed/boxed_link_amp_very_rare.svg link-vr.svg
get boxed/boxed_softbank_ultra_link_very_rare.svg softbank.svg
get boxed/boxed_force_amp_rare.svg force-amp.svg
get boxed/boxed_turret_rare.svg turret.svg
get 'boxed/boxed_ito_en_transmuter_+_very_rare.svg' ito-plus.svg
get 'boxed/boxed_ito_en_transmuter_-_very_rare.svg' ito-minus.svg
printf 'Ingress inventory assets fetched: %s files\n' "$(find "$OUT" -maxdepth 1 -type f | wc -l)"
