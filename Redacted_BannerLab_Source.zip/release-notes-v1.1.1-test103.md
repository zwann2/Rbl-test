# Redacted BannerLab — v1.1.1-test.103

- Correction radicale de la résolution des Portal Keys ajoutées par lien Ingress.
- Les liens `link.ingress.com/portal/<GUID>` sont désormais traités en GUID-first : IGOR extrait le GUID exact et interroge directement `IITC.portal.details.request(guid)`.
- Plus besoin que le portail soit déjà visible sur la carte pour récupérer son nom, sa photo, ses coordonnées, sa faction et son niveau.
- Correction du décodage de `getPortalDetails` : la réponse Intel est un tableau portail et n'est plus jetée en cherchant à tort un objet.
- La recherche par coordonnées reste uniquement en fallback pour les anciens liens sans GUID.
- IGOR 0.6.43.
