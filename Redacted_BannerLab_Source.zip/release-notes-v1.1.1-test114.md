# Redacted BannerLab v1.1.1 TEST-114

- LEON : restaure le timer Drone par défaut si aucune préférence explicite ne l’a désactivé.
- LEON Android : stabilise les positions des timers flottants par identifiant et mémorise la position après clamp, afin qu’un toggle Drone ne décale plus les autres timers.
- REDACTED RUN : remplace la collision approximative par des hitboxes visuelles resserrées sur Redacted et les obstacles. Les marges transparentes des assets ne provoquent plus de défaite fantôme.
