# Différence entre la base propre fournie et TEST72

## Base fournie

- Version : **1.1.0**
- IGOR : **0.6.32**
- Ascenseur : version simple, sans cabine thématique persistante de session.
- Inventaire : total matériel uniquement ; clés gérées dans leur écran séparé.
- Glyph Lab : moteur stable d'origine, tracé calé sur les nœuds.
- Android : identité PROD dans `patch_manifest.py`.

## Ce qui s'est ajouté entre la base et TEST72

### Recherche / navigation
- Retour Bannergress vers la liste, avec recherche et position de scroll conservées.
- Retour mission vers la liste à la position précédemment consultée.
- Plusieurs correctifs de navigation et de tutoriels ont été consolidés dans les TEST55+.

### IGOR
- Passage de **0.6.32 à 0.6.35**.
- Accueil allégé : Missions / Clés & inventaire / Captures uniques.
- Libellés et boutons plus gros pour la lisibilité.
- Correction du symbole cassé devant « mettre en veille ».
- Installation / vérification d'IGOR renforcée côté Android.
- Explorateur C.O.R.E. ajouté en 0.6.35 pour inspecter Capsules / Key Lockers et le payload brut localement.

### Redacted / easter eggs
- Retour du 7-clics Redacted.
- Réactions multiples, contexte horaire, compteur et anti-répétition.
- Popup Redacted depuis le HUD.

### Ascenseur
- Thème selon le dernier étage visité pendant la session.
- Cabines dédiées Sous-sol / LEON / IGOR / RITA / Atelier / Combles.
- Bouton du dernier étage réellement allumé.
- Les libellés « Premier étage / Deuxième étage… » ont été remplacés par les descriptions utiles.
- Redacted a été intégré dans la cabine de départ.
- Les doubles « Choisis un étage » ont été retirés.
- Le thème se réinitialise au redémarrage complet de l'app.
- À partir de TEST69, le personnage de l'étage précédent réapparaît dans la cabine avec une réplique contextuelle.

### Inventaire / clés
- Beacon / Battle Beacon ajoutés.
- Portal Keys ajoutées au total inventaire, y compris celles rangées dans Capsules / Key Lockers sans double comptage.
- Exploration C.O.R.E. des conteneurs et tentative de récupération de leur nom.
- ITO EN (+) / ITO EN (-) corrigés dans TEST72.
- TEST64-71 ont ajouté plusieurs essais de couleurs/layout inspirés de Prime ; certains ont provoqué la page Inventaire vide sur Android.

### Glyph Lab
- TEST55-72 ont multiplié les essais : traînée dynamique, tête lumineuse, plein écran, progression Arcade, vibrations, timer HUD, palette Prime, reconstruction de démo SVG.
- Plusieurs régressions ont suivi : écran vide, décalage du point, traces irrégulières et comportement trop éloigné de la référence Prime.

### Android TEST
- Package séparé `com.bannerforge.mobile.test`.
- Icône TEST séparée.
- Scheme `redactedbannerlabtest://`.
- VersionCode monté jusqu'à `2100011072`.

## Choix de TEST73 CLEAN

### Conservé / réintégré
- Ascenseur thématique de session, cabine complète, destinations sobres, personnages et répliques de retour.
- IGOR 0.6.35 et son interface allégée / lisible.
- Inventaire C.O.R.E. + Beacon / Battle Beacon + correction ITO.
- Total global = matériel + Portal Keys, avec détail clés dans le sac / rangées.
- Vrais assets d'objets déjà utilisés par la base via `ingress-items`, sans recolorer violemment toute la carte.
- Glyph Lab plein écran avec coordonnées tactiles correctes, détection immédiate des nœuds, vibrations optionnelles et progression Arcade plus douce.

### Volontairement abandonné
- Les gros aplats de couleur L1-L8 / Rare / VR de TEST64.
- Les rustines de layout Inventaire TEST70/71 responsables de comportements incohérents.
- Le moteur de tracé Glyph expérimental TEST55-72 : TEST73 repart du moteur stable de la base et n'ajoute qu'un tracé lissé basé sur le chemin réel du doigt.
- La reconstruction eulérienne des glyphes introduite dans les essais TEST66.
