# Redacted BannerLab 1.1.1 TEST-79 CLEAN

- IGOR Inventaire et Clés : correction du crash d'affichage provoqué par l'ancien bouton d'ascenseur supprimé.
- IGOR Mission : un lancement explicite force désormais le parcours RBL courant vers IGOR au lieu de reprendre silencieusement un ancien état local.
- IGOR passe en 0.6.37.
- Bouton « Lancer IGOR » compact : icône globe contrainte à 20 px, plus de pavé géant.
- Portal Blaster : correction du blocage sur GO (maxLives manquait dans la portée du jeu).
- Faction Drop : vrais logos ENL/RES dans les objets.
- Faction Drop : Machina utilise désormais un noyau rouge animé.
- Faction Drop : vitesse de chute homogène et garantie d'une voie d'évitement ; les rangées dangereuses ne peuvent plus condamner les trois voies.
- Cadence Faction Drop légèrement ralentie pour laisser le temps de changer de voie.
- Android : ajout explicite de android.permission.VIBRATE.
- Vibrations renforcées légèrement dans les interactions principales.
- Android versionCode : 2100011079.
