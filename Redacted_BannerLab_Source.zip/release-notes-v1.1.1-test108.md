# Redacted BannerLab v1.1.1-test.108

- Ajout d’un tutoriel dédié au Prime HUD : autorisation overlay Android, détection d’Ingress Prime, faction et configuration.
- Relecture des traductions HUD principales FR/EN/ES/PT/DE/IT/NL.
- Correction de la cohérence de langue : Redacted utilise désormais les textes de la langue active dans le tutoriel HUD, notamment en italien.
- Conserve les correctifs TEST-107 : vrais assets Ingress et timer Drone opt-in.
