# Redacted BannerLab v1.1.1-test.116

- Papy Redacted : sélection resserrée à 2 visuels ENL et 2 visuels RES.
- Nouveau panneau Scanner plus doux : carte, portrait et anecdote avec coins arrondis.
- Le texte reste dans son cadre noir dédié.
- Les marques de faction de l’interface restent de vrais assets Android séparés des visuels.
- Une image est choisie à chaque anecdote sans répétition immédiate.
- Android TEST : versionCode 2100011119.
