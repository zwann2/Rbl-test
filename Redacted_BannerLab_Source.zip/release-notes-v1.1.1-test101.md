# Redacted BannerLab v1.1.1-test.101

- Key Sync : restauration de C.O.R.E./getInventory comme source des vraies Portal Keys présentes dans l’inventaire.
- Fusion avec le plugin IITC Keys pour conserver les quantités manuelles absentes de C.O.R.E.
- Les résolutions manuelles restent renvoyées même si C.O.R.E. est indisponible.
- Barre de navigation Fresque : quasi transparente au repos, pleine visibilité au toucher, toujours disponible à partir de 4 rangées.
- IGOR 0.6.41.
