# Redacted BannerLab v1.1.1-test.117

- RITA surveille désormais périodiquement la page officielle `ingress.com/news` en arrière-plan sur Android.
- Une notification native `RITA // TRANSMISSION DÉTECTÉE` apparaît lorsqu'une nouvelle actualité officielle est détectée.
- Premier contrôle silencieux : les actualités déjà présentes servent de référence, afin de ne pas déclencher une rafale de vieilles notifications après installation.
- Anti-doublon persistant : une actualité déjà détectée n'est pas renotifiée.
- Un appui sur la notification ouvre directement l'actualité officielle.
- Android TEST : versionCode 2100011120.
