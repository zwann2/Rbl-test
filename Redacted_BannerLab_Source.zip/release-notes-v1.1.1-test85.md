# Redacted BannerLab 1.1.1 TEST-85 CLEAN

- IGOR passe en 0.6.38.
- Mission IGOR : correction du bouton Réduire. La vue compacte plantait sur une variable de traduction `t` non définie.
- Retour Salle IGOR → Missions : la sélection IITC courante est resynchronisée immédiatement ; le hook est aussi réparé après les refresh de carte.
- Missions : limite stricte à 6 portails. Les anciens états locaux contenant 7+ portails sont tronqués à 6 au chargement et tout nouvel ajout est refusé après 6.
- « Charger le Lab dans IGOR » : le retour vers IITC est maintenant différé après le deep-link RBL afin qu’Android ne laisse plus l’utilisateur bloqué dans le Lab.
- Le payload IGOR annonce désormais correctement 0.6.38.
- Android versionCode : 2100011085.
