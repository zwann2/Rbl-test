# Redacted BannerLab 1.1.1 TEST-78 CLEAN

- Séquence d’accès au sous-sol portée à environ 4 secondes.
- Étapes visibles : vérification, accès refusé, override REDACTED, ouverture.
- Le contenu RDC / Atelier fresques est totalement masqué pendant la transition.
- `groundFloorActive` est explicitement supprimé avant et après l’accès SS.
- Arrivée directe dans l’Arcade sans flash de l’étage Fresques.
- Android versionCode : 2100011078.
