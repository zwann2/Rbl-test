# Redacted BannerLab 1.1.1 TEST-84 CLEAN

- ENL / RES : vrais SVG de faction embarqués localement dans l’APK ; plus de dépendance réseau pour ces logos.
- Faction Drop : correction du plantage juste après GO (ancienne référence à `mode` alors que le jeu est désormais un survival unique).
- Portal Blaster : un drone ennemi ou Machina qui atteint le bas coûte maintenant une vie, y compris en mode Chrono.
- Portal Blaster : les vies sont visibles dans le mode Chrono et les bonus de vie peuvent réparer une brèche.
- Sous-sol : la route SS intercepte le clic avant la fermeture de l’ascenseur et la couche opaque est peinte avant tout nettoyage de la vue précédente.
- Tutoriel overlay : ordre corrigé dans les 7 langues : essayer l’overlay → autoriser les paramètres restreints → retenter l’overlay.
- Fresques hautes : les réglages rapides, dont l’opacité des cercles, passent au-dessus du canvas et restent sticky même avec 25 lignes.
- Android versionCode : 2100011084.
