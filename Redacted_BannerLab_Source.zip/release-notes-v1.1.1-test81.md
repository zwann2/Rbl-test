# Redacted BannerLab 1.1.1 TEST-81 CLEAN

- MILO 0.5.4 : un ancien handle de fichier supprimé/déplacé est oublié automatiquement ; MILO repropose ensuite MILO_CurrentBanner.json au lieu d’afficher uniquement NotFoundError.
- Portal Blaster : correction réelle du blocage sur GO. Les helpers logos/drones étaient hors de portée de startBlaster ; ils sont désormais partagés au niveau Arcade.
- Faction Drop : suppression totale du chrono et des modes Arcade/Entraînement. Le jeu devient un survival au score jusqu’à perte des vies.
- Faction Drop : vitesse de chute et cadence augmentent progressivement avec le temps.
- Faction Drop : garantie renforcée d’une voie d’évitement dans les groupes de dangers proches.
- Faction Drop : bonus rare Redacted +1 vie, avec tête/visuel Redacted déjà présent dans les assets.
- Lab Memory : remplacement du texte MX par un noyau Machina rouge animé cohérent avec Faction Drop.
- LEON Calcul AP exact : nouvel en-tête/hero LEON avec portrait, identité complète et animation discrète.
- Android versionCode : 2100011081.
