# Redacted BannerLab 1.1.1 TEST-83 CLEAN

- Portal Blaster : les bonus qui tombent utilisent maintenant le logo de faction au lieu d’un « + » générique.
- Portal Blaster : trois modes utiles au lancement :
  - Arcade · Chrono : 45 s, impacts = pénalité de temps, vies non limitantes.
  - Arcade · Survie : 3 vies, pas de chrono, bonus de vie possibles, record activé.
  - Entraînement : 3 vies, pas de chrono et pas de record.
- Portal Blaster : les boss/combos ne rendent du temps qu’en mode Chrono.
- Portal Blaster : bonus de vie uniquement dans les modes à vies.
- Faction Drop : correction du vrai bug de spawn. L’accélération avait été injectée par erreur dans l’explosion Machina avec une variable `now` inexistante ; elle est désormais dans la boucle principale.
- Faction Drop : les logos ENL/RES et Machina recommencent donc à tomber normalement.
- Faction Drop : bonus de vie = visuel Redacted provenant de l’asset existant `redacted-dino-cutout.png`.
- Sous-sol : l’overlay opaque SS est monté AVANT de démonter l’ascenseur, pour empêcher le moindre flash du RDC/fresque au premier accès.
- Mission Launch : suppression de `MX`, remplacé par le noyau Machina animé cohérent avec Faction Drop et Lab Memory.
- Nouveaux libellés Portal Blaster traduits dans les 7 langues prioritaires.
- Android versionCode : 2100011083.
