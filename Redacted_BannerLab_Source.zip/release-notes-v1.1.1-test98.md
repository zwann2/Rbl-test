# Redacted BannerLab — v1.1.1-test.98

- Fresque : la barre de navigation verticale n'apparaît qu'à partir de 4 rangées et se limite désormais à la portion visible du canvas, sans recouvrir les commandes ni la navigation basse.
- Clés IGOR : l'ajout manuel par lien passe immédiatement en état « Résolution par IGOR… » et lance Key Sync ; les coordonnées 0,0 sont rejetées comme résultat valide et un portail résolu remplace l'entrée temporaire.
- Clés historiques : les entrées 0,0 sont signalées comme portails non identifiés au lieu d'être présentées comme des portails valides.
- MILO : le visuel canonique de l'explorateur au chapeau fourni par l'utilisateur remplace l'ancien visuel dans la salle d'IGOR et le Glyph Lab / Arcade.
- Inventaire : interface recolorée façon Prime. Les niveaux L1 à L8 ont chacun leur teinte, les raretés C/R/VR restent distinctes et les contrôles reprennent la couleur de l'objet.
- Inventaire : ajout d'un fallback graphique local quand une icône distante ne se charge pas, afin d'éviter les cases avec icône cassée.
