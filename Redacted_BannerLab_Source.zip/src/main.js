import './style.css';
import JSZip from 'jszip';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import QRCode from 'qrcode';
import { openLabArcade, closeLabArcade, handleLabArcadeBack } from './arcade.js';
import { openLeon, closeLeon } from './leon.js';
import { leonTimerText } from './leon-timers-i18n.js';
import { PRIORITY_I18N_OVERRIDES } from './i18n-priority.js';
import { opsText } from './ops-i18n.js';
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';
import { AppLauncher } from '@capacitor/app-launcher';
import { IntentLauncher, ActivityAction } from '@capgo/capacitor-intent-launcher';

const APP_VERSION = '1.1.1-test.91';
const BUILD_CODE = '2100011091';
const DISPLAY_BUILD_CODE = 'TEST-91';
const TEST_BUILD = true;
const COLS = 6;
const STEP = 544;
const TILE = 512;
const PAD = 16;
const WORLD_W = COLS * STEP;
const RENDER_W = 1200;
const MissionOverlay = registerPlugin('MissionOverlay');
// TEST-36: LEON Timers est charge a la demande. Un probleme dans ce sous-module
// ne doit jamais empecher le Lab entier de demarrer.
globalThis.__RBL_MISSION_OVERLAY__ = MissionOverlay;
let leonTimersModule = null;
let leonTimersModulePromise = null;
async function getLeonTimersModule(){
  if(leonTimersModule)return leonTimersModule;
  if(!leonTimersModulePromise){
    leonTimersModulePromise=import('./leon-timers.js').then(mod=>{leonTimersModule=mod;return mod}).catch(err=>{leonTimersModulePromise=null;throw err});
  }
  return leonTimersModulePromise;
}
async function openLeonTimers(language=APP_LANG){const mod=await getLeonTimersModule();return mod.openLeonTimers(language)}
function closeLeonTimers(notify=true){if(leonTimersModule?.closeLeonTimers)return leonTimersModule.closeLeonTimers(notify)}
const BackupFolder = registerPlugin('BackupFolder');
const LocationStatus = registerPlugin('LocationStatus');
const IitcSyncInbox = registerPlugin('IitcSyncInbox');
const IitcBridgeLauncher = registerPlugin('IitcBridgeLauncher');
const UpdateManager = registerPlugin('UpdateManager');
const PublisherFiles = registerPlugin('PublisherFiles');
const BANNERGRESS_API='https://api.bannergress.com';
const VALHALLA_API='https://valhalla1.openstreetmap.de/route';
const VALHALLA_MAX_POINTS=10;
const BANNER_WALK_CACHE_PREFIX='rbl-banner-walk-v5:';
const BANNER_FAVORITES_KEY='rbl-bannergress-favorites-v1';
const PLAY_SESSION_KEY='rbl-play-session-v1';
const PLAY_PENDING_KEY='rbl-play-pending-v1';
const BANNER_TODO_KEY='rbl-bannergress-todo-v1';
const PLAY_HISTORY_KEY='rbl-play-history-v1';
const REDACTED_OVERLAY_KEY='rbl-redacted-prime-overlay-v1';
const REDACTED_FACTION_KEY='rbl-redacted-prime-faction-v1';
const HALLOWEEN_KEY='rbl-halloween-theme-v1';
const BACKUP_AUTO_KEY='rbl-backup-auto-v1';
const BACKUP_LAST_KEY='rbl-backup-last-v1';
const BACKUP_FILE_NAME='Redacted_BannerLab_Autosave.json';
const TUTORIAL_AUTO_KEY='rbl-tutorial-auto-v3';
const TUTORIAL_PROMPT_SESSION_KEY='rbl-tutorial-prompted-v2';
const TUTORIAL_SEEN_PREFIX='rbl-tutorial-seen-v2:';
const UPDATE_CHECK_KEY='rbl-update-check-auto-v1';
const UPDATE_DOWNLOAD_KEY='rbl-update-download-auto-v1';
const UPDATE_INSTALL_KEY='rbl-update-install-auto-v1';
const UPDATE_LAST_CHECK_KEY='rbl-update-last-check-v1';
const UPDATE_IGNORE_KEY='rbl-update-ignore-v1';
const UPDATE_STAGED_META_KEY='rbl-update-staged-meta-v1';
const BRIDGE_AUTH_KEY='rbl-bridge-auth-v1';
const BRIDGE_NONCE_KEY='rbl-bridge-nonces-v2';
const PUBLISHER_SETUP_AUTH_KEY='rbl-publisher-setup-auth-v2';
const BRIDGE_MAX_AGE_MS=3*60*1000;
const PUBLISHER_SETUP_MAX_AGE_MS=10*60*1000;

function halloweenWindowOpen(now=new Date()){
  const month=now.getMonth(),day=now.getDate();
  return month===9 || (month===10 && day<=2);
}
function halloweenEnabled(){return halloweenWindowOpen()&&localStorage.getItem(HALLOWEEN_KEY)==='1'}
function applyHalloweenTheme(){document.body?.classList.toggle('rblHalloween',halloweenEnabled())}

function randomHex(byteCount=32){
  const bytes=new Uint8Array(Math.max(8,Number(byteCount)||32));
  if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(bytes);
  else for(let i=0;i<bytes.length;i++)bytes[i]=Math.floor(Math.random()*256);
  return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
}
function bridgeAuthToken(){
  let token=String(localStorage.getItem(BRIDGE_AUTH_KEY)||'').trim();
  if(/^[a-f0-9]{64}$/i.test(token))return token.toLowerCase();
  token=randomHex(32);
  localStorage.setItem(BRIDGE_AUTH_KEY,token);
  return token;
}
function publisherSetupStore(){
  try{return JSON.parse(localStorage.getItem(PUBLISHER_SETUP_AUTH_KEY)||'{}')||{}}catch(_){return {}}
}
function newPublisherSetupToken(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  const store=publisherSetupStore(),token=randomHex(32);
  store[browser]={token,createdAt:Date.now()};
  localStorage.setItem(PUBLISHER_SETUP_AUTH_KEY,JSON.stringify(store));
  return token;
}
function pendingPublisherSetupToken(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  const rec=publisherSetupStore()?.[browser];
  if(!rec||!/^[a-f0-9]{64}$/i.test(String(rec.token||''))||Math.abs(Date.now()-Number(rec.createdAt||0))>PUBLISHER_SETUP_MAX_AGE_MS)return '';
  return String(rec.token).toLowerCase();
}
function consumePublisherSetupToken(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  const store=publisherSetupStore();delete store[browser];
  localStorage.setItem(PUBLISHER_SETUP_AUTH_KEY,JSON.stringify(store));
}
function bridgeHexBytes(hex){
  const clean=String(hex||'').toLowerCase();
  if(!/^[a-f0-9]{64}$/.test(clean))throw new Error('bridge key invalid');
  return Uint8Array.from(clean.match(/../g),x=>parseInt(x,16));
}
function bridgeCanonical(host,searchParams,ts,nonce){
  const entries=[];
  for(const [k,v] of searchParams.entries()){
    if(k==='sig'||k==='ts'||k==='nonce'||k==='token')continue;
    entries.push([String(k),String(v)]);
  }
  entries.sort((a,b)=>a[0]===b[0]?a[1].localeCompare(b[1]):a[0].localeCompare(b[0]));
  const body=entries.map(([k,v])=>`${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
  return `rbl-bridge-v2\n${String(host||'')}\n${String(ts||'')}\n${String(nonce||'')}\n${body}`;
}
async function bridgeHmacHex(secretHex,message){
  if(!globalThis.crypto?.subtle)throw new Error('WebCrypto unavailable');
  const key=await crypto.subtle.importKey('raw',bridgeHexBytes(secretHex),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const sig=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(String(message||'')));
  return Array.from(new Uint8Array(sig),b=>b.toString(16).padStart(2,'0')).join('');
}
function bridgeTimingSafeHexEqual(a,b){
  a=String(a||'').toLowerCase();b=String(b||'').toLowerCase();
  if(a.length!==64||b.length!==64)return false;
  let diff=0;for(let i=0;i<64;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);
  return diff===0;
}
function bridgeRememberNonce(nonce,ts){
  nonce=String(nonce||'').toLowerCase();ts=Number(ts||0);
  if(!/^[a-f0-9]{24,128}$/.test(nonce)||!Number.isFinite(ts)||Math.abs(Date.now()-ts)>BRIDGE_MAX_AGE_MS)return false;
  let seen={};try{seen=JSON.parse(localStorage.getItem(BRIDGE_NONCE_KEY)||'{}')||{}}catch(_){seen={}}
  const cutoff=Date.now()-BRIDGE_MAX_AGE_MS*2;
  for(const [n,t] of Object.entries(seen))if(Number(t)<cutoff)delete seen[n];
  if(seen[nonce])return false;
  seen[nonce]=Date.now();localStorage.setItem(BRIDGE_NONCE_KEY,JSON.stringify(seen));
  return true;
}
async function verifySignedBridgeUrl(u){
  const host=String(u?.hostname||''),ts=String(u?.searchParams?.get('ts')||''),nonce=String(u?.searchParams?.get('nonce')||''),sig=String(u?.searchParams?.get('sig')||'').toLowerCase();
  const browser=host==='publisher-chrome-ready'?'chrome':host==='publisher-firefox-ready'?'firefox':'';
  const secret=browser?pendingPublisherSetupToken(browser):bridgeAuthToken();
  if(!secret||!/^[a-f0-9]{64}$/.test(sig)||!/^\d{10,16}$/.test(ts)||!/^[a-f0-9]{24,128}$/i.test(nonce))return false;
  if(Math.abs(Date.now()-Number(ts))>BRIDGE_MAX_AGE_MS)return false;
  const expected=await bridgeHmacHex(secret,bridgeCanonical(host,u.searchParams,ts,nonce));
  if(!bridgeTimingSafeHexEqual(sig,expected))return false;
  if(!bridgeRememberNonce(nonce,ts))return false;
  if(browser)consumePublisherSetupToken(browser);
  return true;
}
const UPDATE_CHECK_INTERVAL=12*60*60*1000;
let updateConfigCache=null;
let updateInProgress=false;
let pendingUpdateRelease=null;
let updateProgressListenerReady=false;
let updateInstallRequestInFlight=false;

let backupInProgress=false;
let backupRevision=1;
let lastBackedRevision=0;
let backupAutoTimer=null;
let backupAppActive=true;

const LANG_META={
  fr:{flag:'🇫🇷',name:'Français',locale:'fr-FR'},en:{flag:'🇬🇧',name:'English',locale:'en-GB'},es:{flag:'🇪🇸',name:'Español',locale:'es-ES'},
  pt:{flag:'🇵🇹',name:'Português',locale:'pt-PT'},de:{flag:'🇩🇪',name:'Deutsch',locale:'de-DE'},it:{flag:'🇮🇹',name:'Italiano',locale:'it-IT'},
  nl:{flag:'🇳🇱',name:'Nederlands',locale:'nl-NL'},pl:{flag:'🇵🇱',name:'Polski',locale:'pl-PL'},cs:{flag:'🇨🇿',name:'Čeština',locale:'cs-CZ'},
  ro:{flag:'🇷🇴',name:'Română',locale:'ro-RO'},tr:{flag:'🇹🇷',name:'Türkçe',locale:'tr-TR'},ru:{flag:'🇷🇺',name:'Русский',locale:'ru-RU'},
  uk:{flag:'🇺🇦',name:'Українська',locale:'uk-UA'},ja:{flag:'🇯🇵',name:'日本語',locale:'ja-JP'},ko:{flag:'🇰🇷',name:'한국어',locale:'ko-KR'},
  'zh-Hans':{flag:'🇨🇳',name:'简体中文',locale:'zh-CN'},'zh-Hant':{flag:'🇹🇼',name:'繁體中文',locale:'zh-TW'},yue:{flag:'🇭🇰',name:'廣東話',locale:'zh-HK'},
  ar:{flag:'🇸🇦',name:'العربية',locale:'ar-SA',rtl:true},id:{flag:'🇮🇩',name:'Bahasa Indonesia',locale:'id-ID'}
};
const SUPPORTED_LANGS=Object.keys(LANG_META);
function detectAppLanguage(){
  const raw=String(navigator.language||'fr').toLowerCase();
  if(raw.startsWith('yue')||raw.startsWith('zh-hk')||raw.startsWith('zh-mo'))return 'yue';
  if(raw.startsWith('zh-tw'))return 'zh-Hant';
  if(raw.startsWith('zh'))return 'zh-Hans';
  const short=raw.split('-')[0];
  return SUPPORTED_LANGS.includes(short)?short:'en';
}
let APP_LANG=localStorage.getItem('rbl-language')||detectAppLanguage();
if(!SUPPORTED_LANGS.includes(APP_LANG))APP_LANG='en';
function appLocale(){return LANG_META[APP_LANG]?.locale||'en-GB'}

const I18N={
  fr:{
    fresco:'Fresque',route:'Parcours',missions:'Missions',publish:'Publier',projects:'Projets',rows:'Rangées',
    bridgeRejected:'Lien interne refusé : authentification IGOR invalide.',
    image:'Images',framing:'Cadrage',layers:'Calques',text:'Texte',preview:'Aperçu',export:'Exporter',
    wholeFresco:'Fresque entière',oneMission:'Une mission',noMission:'Aucune mission sélectionnée',
    addImage:'Ajoute ton image',imageHint:'Elle sera cadrée directement sur la géométrie Prime.',
    circles:'Cercles Prime',grid:'Grille 512',numbers:'Numéros',enlarge:'Agrandir mission',resetMission:'Réinitialiser mission',
    prev:'Précédente',next:'Suivante',complete:'Mission complète',remaining:'Encore {n} portail(s)',
    openIitc:'Ouvrir IITC Companion',tutorial:'Tutoriel',installPlugin:'Installer / mettre à jour le plugin IITC',
    autoAdvance:'Passer automatiquement à la mission suivante à {n} portails',
    reuseLast:'Reprendre automatiquement le dernier portail comme premier de la mission suivante',
    noPortal:'Aucun portail pour cette mission.',
    action:'Action',hack:'Hack',mod:'Installer un mod',capture:'Capturer / améliorer',link:'Créer un lien',field:'Créer un champ',passphrase:'Passphrase',
    question:'Question',answer:'Réponse attendue',save:'Enregistrer',cancel:'Annuler',
    settings:'Réglages communs',commonDesc:'Description commune',titleFormat:'Format des titres',defaultType:'Type par défaut',
    location:'Localisation',visible:'Visible',hidden:'Cachée',sequential:'Séquentielle',anyOrder:'Ordre libre',
    portalsPerMission:'Portails / mission',editMission:'Éditer la mission',title:'Titre',description:'Description',
    missionReady:'Prête',missionIncomplete:'Incomplète',openRoute:'Modifier le parcours',
    publishPack:'Créer le pack BannerLab',openMat:'Ouvrir Mission Authoring Tool',
    ownWorkflow:'BannerLab utilise désormais son propre format de projet et son propre pack de publication.',
    language:'Langue',french:'Français',english:'English',spanish:'Español',
    companionStats:'Stats piétonnes dans IITC',companionStatsDesc:'Dans le mini panneau IITC : 📊 Stats inutiles calcule les km à pied estimés, temps, détour et autres absurdités.',
    duplicateBad:'{n} réutilisation(s) de portail à vérifier.',handoverOk:'La reprise fin → début de mission est autorisée.',
    pluginVersion:'IGOR 0.6.35',
    undo:'Annuler',redo:'Rétablir'
  },
  en:{
    fresco:'Banner',route:'Route',missions:'Missions',publish:'Publish',projects:'Projects',rows:'Rows',
    bridgeRejected:'Internal link rejected: invalid IGOR authentication.',
    image:'Images',framing:'Framing',layers:'Layers',text:'Text',preview:'Preview',export:'Export',
    wholeFresco:'Whole banner',oneMission:'One mission',noMission:'No mission selected',
    addImage:'Add your image',imageHint:'It will be framed directly on the Prime geometry.',
    circles:'Prime circles',grid:'512 grid',numbers:'Numbers',enlarge:'Enlarge mission',resetMission:'Reset mission',
    prev:'Previous',next:'Next',complete:'Mission complete',remaining:'{n} portal(s) remaining',
    openIitc:'Open IITC Companion',tutorial:'Tutorial',installPlugin:'Install / update IITC plugin',
    autoAdvance:'Automatically move to next mission at {n} portals',
    reuseLast:'Automatically reuse the last portal as the first portal of the next mission',
    noPortal:'No portal in this mission.',
    action:'Action',hack:'Hack',mod:'Install a mod',capture:'Capture / upgrade',link:'Create a link',field:'Create a field',passphrase:'Passphrase',
    question:'Question',answer:'Expected answer',save:'Save',cancel:'Cancel',
    settings:'Common settings',commonDesc:'Common description',titleFormat:'Title format',defaultType:'Default type',
    location:'Location',visible:'Visible',hidden:'Hidden',sequential:'Sequential',anyOrder:'Any order',
    portalsPerMission:'Portals / mission',editMission:'Edit mission',title:'Title',description:'Description',
    missionReady:'Ready',missionIncomplete:'Incomplete',openRoute:'Edit route',
    publishPack:'Create BannerLab pack',openMat:'Open Mission Authoring Tool',
    ownWorkflow:'BannerLab now uses its own project format and publication pack.',
    language:'Language',french:'Français',english:'English',spanish:'Español',
    companionStats:'Walking stats in IITC',companionStatsDesc:'In the IITC mini panel: 📊 Useless stats calculates estimated walking distance, time, detour and other nonsense.',
    duplicateBad:'{n} portal reuse(s) to review.',handoverOk:'Mission-end → next-start reuse is allowed.',
    pluginVersion:'IGOR 0.6.35',
    undo:'Undo',redo:'Redo'
  },
  es:{
    fresco:'Mosaico',route:'Recorrido',missions:'Misiones',publish:'Publicar',projects:'Proyectos',rows:'Filas',
    image:'Imágenes',framing:'Encuadre',layers:'Capas',text:'Texto',preview:'Vista previa',export:'Exportar',
    wholeFresco:'Mosaico completo',oneMission:'Una misión',noMission:'Ninguna misión seleccionada',
    addImage:'Añade tu imagen',imageHint:'Se encuadrará directamente con la geometría Prime.',
    circles:'Círculos Prime',grid:'Cuadrícula 512',numbers:'Números',enlarge:'Ampliar misión',resetMission:'Restablecer misión',
    prev:'Anterior',next:'Siguiente',complete:'Misión completa',remaining:'Faltan {n} portal(es)',
    openIitc:'Abrir IITC Companion',tutorial:'Tutorial',installPlugin:'Instalar / actualizar plugin IITC',
    autoAdvance:'Pasar automáticamente a la siguiente misión al llegar a {n} portales',
    reuseLast:'Reutilizar automáticamente el último portal como primero de la siguiente misión',
    noPortal:'No hay portales en esta misión.',
    action:'Acción',hack:'Hackear',mod:'Instalar un mod',capture:'Capturar / mejorar',link:'Crear un enlace',field:'Crear un campo',passphrase:'Contraseña',
    question:'Pregunta',answer:'Respuesta esperada',save:'Guardar',cancel:'Cancelar',
    settings:'Ajustes comunes',commonDesc:'Descripción común',titleFormat:'Formato de títulos',defaultType:'Tipo predeterminado',
    location:'Ubicación',visible:'Visible',hidden:'Oculta',sequential:'Secuencial',anyOrder:'Cualquier orden',
    portalsPerMission:'Portales / misión',editMission:'Editar misión',title:'Título',description:'Descripción',
    missionReady:'Lista',missionIncomplete:'Incompleta',openRoute:'Editar recorrido',
    publishPack:'Crear paquete BannerLab',openMat:'Abrir Mission Authoring Tool',
    ownWorkflow:'BannerLab usa ahora su propio formato de proyecto y paquete de publicación.',
    language:'Idioma',french:'Français',english:'English',spanish:'Español',
    companionStats:'Estadísticas a pie en IITC',companionStatsDesc:'En el mini panel IITC: 📊 Stats inútiles calcula distancia a pie estimada, tiempo, desvío y otras tonterías.',
    duplicateBad:'{n} reutilización(es) de portal para revisar.',handoverOk:'Se permite reutilizar fin de misión → inicio de la siguiente.',
    pluginVersion:'IGOR 0.6.35',
    undo:'Deshacer',redo:'Rehacer'
  }
};
Object.assign(I18N.fr,{"subtitle":"Fresques Ingress Prime","source":"source","bannerHelp":"<b>Mode fresque :</b> 1 doigt déplace le calque sélectionné. <b>2 doigts</b> zooment et tournent.","missionHelp":"<b>Mode mission :</b> touche un médaillon. Pour travailler confortablement, utilise <b>Agrandir mission</b>. Tu peux aussi le déplacer ici à 1 doigt.","missionSelected":"Mission {n} sélectionnée","tapMedallion":"Touche un médaillon","touchMissionFirst":"Touche d’abord la mission que tu veux recadrer.","selectMissionFirst":"Sélectionne d’abord une mission.","heavyImage":"Image très lourde. Elle peut mettre ton téléphone à genoux, ce qui serait vexant.","imported":"{w} × {h} px importés","textLayerDesc":"Chaque texte reste un calque indépendant, modifiable ou supprimable.","layer":"Calque","newText":"+ Nouveau texte","size":"Taille","outline":"Contour","color":"Couleur","outlineColor":"Couleur contour","add":"Ajouter","update":"Mettre à jour","delete":"Supprimer","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotation","center":"Centrer","reset":"Réinitialiser","done":"Terminé","transformText":"Transformer le texte","frameImage":"Cadrer l’image","pinchHint":"Le geste à deux doigts reste disponible directement sur la fresque.","missionCropOnly":"Ce cadrage ne touche qu’à ce médaillon.","resetThisMission":"Réinitialiser cette mission","individualCrop":"Recadrage individuel · 512 × 512","oneFinger":"1 doigt","move":"déplacer","twoFingers":"2 doigts","zoomRotate":"zoomer et tourner","previewPrime":"Aperçu Prime","previewApplied":"Les recadrages individuels sont déjà appliqués.","previewOrder":"Le numéro 1 est en bas à droite, puis l’ordre remonte vers la gauche et vers les rangées supérieures.","exportTitle":"Exporter {n} missions","exportIntro":"Choisis vitesse ou PNG sans perte. Les deux restent en 512 × 512.","noBackground":"Aucune image de fond n’est chargée.","missionFormat":"Format des missions","jpgFast":"JPG rapide · qualité élevée","pngLossless":"PNG sans perte · plus lent","fastEncoding":"Le mode rapide évite l’encodage PNG, qui est de loin la partie la plus lente sur téléphone.","rowRender":"Le fond est rendu une seule fois par rangée au lieu d’être recalculé six fois.","adjusted":"{n} mission(s) avec recadrage individuel.","nianticCheck":"Vérifie les règles Niantic avant soumission : droits sur l’image, contenu pertinent et pas de caractère unique dominant.","ready":"Prêt.","createZip":"Créer le ZIP","zipAssembly":"Assemblage du ZIP…","zipCreated":"ZIP créé.","zipDownloaded":"ZIP téléchargé.","saveShareZip":"Enregistrer ou partager le ZIP","exportFinished":"Export {format} terminé","exportFailed":"L’export a échoué.","newProject":"Nouveau projet","myProjects":"Mes projets","projectsSaved":"{n} projet(s) enregistré(s) sur ce téléphone.","unnamed":"Sans nom","opened":"Ouvert","open":"Ouvrir","rename":"Renommer","copy":"Copier","noSavedProject":"Aucun projet enregistré.","renameProject":"Renommer le projet","renameHint":"Un nom humainement reconnaissable, concept révolutionnaire.","projectName":"Nom du projet","projectOpened":"Projet ouvert : {name}","projectRenamed":"Projet renommé","deleteProject":"Supprimer ce projet ?","deleteWarning":"La fresque et son image enregistrée localement seront supprimées.","copyCreated":"Copie créée","projectDeleted":"Projet supprimé","newProjectCreated":"Nouveau projet créé avec Redacted","defaultProject":"Ma fresque","defaultNewProject":"Nouvelle fresque","copySuffix":"copie","versionLabel":"Version","infoPrime":"6 colonnes · 544 px · crop 512 px.","infoPlanner":"actions portail, passphrases, reprise fin→début et pack BannerLab natif.","infoCompanion":"parcours, actions, tracés multi-missions, options et statistiques piétonnes.","disclaimer":"Ingress et Ingress Prime sont des marques de Niantic. Redacted BannerLab n’est ni affilié ni approuvé par Niantic.","titleTokens":"$T = nom · $N = numéro · $M = total · $0N = 01, 02…","pluginShareText":"Plugin IGOR 0.6.35. Dans IITC Mobile, remplace la version précédente. Si IITC refuse de l’écraser, supprime une fois l’ancien plugin puis installe ce fichier.","pluginDialog":"Installer / mettre à jour IGOR 0.6.35","pluginShareFailed":"Impossible de partager le plugin IITC.","intelOpened":"IITC Mobile ouvert avec le projet BannerLab.","intelPrimeOpened":"IITC Prime ouvert avec le projet BannerLab.","intelFallback":"IITC Mobile ouvert. IGOR utilisera son dernier état synchronisé.","intelPrimeFallback":"IITC Prime ouvert. IGOR utilisera son dernier état synchronisé.","intelBrowser":"IITC non détecté : ouverture dans le navigateur.","tutorialIntro":"Construis toute la bannière dans IITC sans revenir dans BannerLab après chaque portail.","tut1Title":"Installe le plugin une seule fois","tut1Text":"Dans Parcours, utilise « Installer / mettre à jour le plugin IITC », puis ajoute le fichier comme plugin utilisateur dans IITC Mobile.","tut2Title":"Ouvre IITC depuis BannerLab","tut2Text":"BannerLab transmet le projet, la mission active et la langue au IGOR via un fragment local que le serveur Intel ne reçoit pas.","tut3Title":"Construis directement sur la carte","tut3Text":"Le IGOR permet d’ajouter, modifier ou retirer des portails, changer de mission et visualiser les tracés sans revenir dans BannerLab.","tut4Title":"Synchronise quand tu as fini","tut4Text":"Le bouton « Synchroniser BannerLab » renvoie toutes les missions modifiées dans le projet et rouvre BannerLab.","tutNote":"Tu peux déplacer et redimensionner IGOR et ranger ses réglages dans Options.","installUpdate":"Installer / mettre à jour","emptyTitleIssue":"Mission {n} : titre vide","emptyDescIssue":"Mission {n} : description vide","portalsIssue":"Mission {n} : {count}/{need} portails","missingGuidIssue":"Mission {n} : {count} GUID manquant(s)","passIssue":"Mission {n} : {count} passphrase(s) incomplète(s)","reviewCount":"{n} point(s) à vérifier","projectReady":"Projet BannerLab prêt","fixBeforePublish":"Corrige les éléments avant publication.","publisherDesc":"Le prochain pont remplira le Mission Authoring Tool directement depuis ce format natif. La soumission finale restera volontairement faite dans l’outil officiel.","packCreating":"Création du pack BannerLab…","packCreated":"Pack BannerLab créé","exportImpossible":"Export impossible : {error}","missionResetDone":"Mission {n} réinitialisée","textDeleted":"Texte supprimé","histImport":"Importer image","histMissionZoom":"Zoom mission","histMissionRotation":"Rotation mission","histTextRotation":"Rotation texte","histImageRotation":"Rotation image","histTextZoom":"Zoom texte","histImageZoom":"Zoom image","histCenterText":"Centrer texte","histCenterImage":"Centrer image","histResetText":"Réinitialiser texte","histResetImage":"Réinitialiser image","histResetMission":"Réinitialiser mission","histDeleteText":"Supprimer texte","histAddText":"Ajouter texte","histEditText":"Modifier texte"});
Object.assign(I18N.en,{"subtitle":"Ingress Prime banners","source":"source","bannerHelp":"<b>Banner mode:</b> 1 finger moves the selected layer. <b>2 fingers</b> zoom and rotate.","missionHelp":"<b>Mission mode:</b> tap a medallion. For comfortable editing, use <b>Enlarge mission</b>. You can also move it here with 1 finger.","missionSelected":"Mission {n} selected","tapMedallion":"Tap a medallion","touchMissionFirst":"Tap the mission you want to reframe first.","selectMissionFirst":"Select a mission first.","heavyImage":"Very large image. It may make your phone reconsider its life choices.","imported":"Imported {w} × {h} px","textLayerDesc":"Each text remains an independent layer that can be edited or deleted.","layer":"Layer","newText":"+ New text","size":"Size","outline":"Outline","color":"Color","outlineColor":"Outline color","add":"Add","update":"Update","delete":"Delete","zoom":"Zoom","localZoom":"Local zoom","rotation":"Rotation","center":"Center","reset":"Reset","done":"Done","transformText":"Transform text","frameImage":"Frame image","pinchHint":"Two-finger gestures remain available directly on the banner.","missionCropOnly":"This framing only affects this medallion.","resetThisMission":"Reset this mission","individualCrop":"Individual framing · 512 × 512","oneFinger":"1 finger","move":"move","twoFingers":"2 fingers","zoomRotate":"zoom and rotate","previewPrime":"Prime preview","previewApplied":"Individual mission adjustments are already applied.","previewOrder":"Number 1 is bottom-right, then numbering goes left and upward through the rows.","exportTitle":"Export {n} missions","exportIntro":"Choose speed or lossless PNG. Both stay at 512 × 512.","noBackground":"No background image is loaded.","missionFormat":"Mission format","jpgFast":"Fast JPG · high quality","pngLossless":"Lossless PNG · slower","fastEncoding":"Fast mode avoids PNG encoding, which is by far the slowest part on a phone.","rowRender":"The background is rendered once per row instead of being recalculated six times.","adjusted":"{n} mission(s) with individual framing.","nianticCheck":"Check Niantic rules before submission: image rights, relevant content, and no dominant single character.","ready":"Ready.","createZip":"Create ZIP","zipAssembly":"Building ZIP…","zipCreated":"ZIP created.","zipDownloaded":"ZIP downloaded.","saveShareZip":"Save or share ZIP","exportFinished":"{format} export complete","exportFailed":"Export failed.","newProject":"New project","myProjects":"My projects","projectsSaved":"{n} project(s) saved on this phone.","unnamed":"Unnamed","opened":"Open","open":"Open","rename":"Rename","copy":"Copy","noSavedProject":"No saved project.","renameProject":"Rename project","renameHint":"A human-readable name. A surprisingly advanced concept.","projectName":"Project name","projectOpened":"Project opened: {name}","projectRenamed":"Project renamed","deleteProject":"Delete this project?","deleteWarning":"The banner and its locally stored image will be deleted.","copyCreated":"Copy created","projectDeleted":"Project deleted","newProjectCreated":"New project created with Redacted","defaultProject":"My banner","defaultNewProject":"New banner","copySuffix":"copy","versionLabel":"Version","infoPrime":"6 columns · 544 px · 512 px crop.","infoPlanner":"portal actions, passphrases, end→start handover and native BannerLab pack.","infoCompanion":"routes, actions, multi-mission tracks, options and walking stats.","disclaimer":"Ingress and Ingress Prime are Niantic trademarks. Redacted BannerLab is not affiliated with or endorsed by Niantic.","titleTokens":"$T = name · $N = number · $M = total · $0N = 01, 02…","pluginShareText":"Companion plugin 0.6.9. Replace the previous version in IITC Mobile. If IITC refuses to overwrite it, remove the old plugin once and install this file.","pluginDialog":"Install / update IGOR 0.6.35","pluginShareFailed":"Unable to share the IITC plugin.","intelOpened":"IITC Mobile opened with the BannerLab project.","intelPrimeOpened":"IITC Prime opened with the BannerLab project.","intelFallback":"IITC Mobile opened. IGOR will use its last synchronized state.","intelPrimeFallback":"IITC Prime opened. IGOR will use its last synchronized state.","intelBrowser":"IITC not detected: opening in browser.","tutorialIntro":"Build the whole banner in IITC without returning to BannerLab after every portal.","tut1Title":"Install the plugin once","tut1Text":"From Route, use “Install / update IITC plugin”, then add the file as a user plugin in IITC Mobile.","tut2Title":"Open IITC from BannerLab","tut2Text":"BannerLab sends the project, active mission and language to IGOR through a local fragment that the Intel server never receives.","tut3Title":"Build directly on the map","tut3Text":"The Companion lets you add, edit or remove portals, change missions and see routes without returning to BannerLab.","tut4Title":"Sync when you are done","tut4Text":"“Sync BannerLab” sends all edited missions back to the project and reopens BannerLab.","tutNote":"You can move and resize IGOR and keep its settings inside Options.","installUpdate":"Install / update","emptyTitleIssue":"Mission {n}: empty title","emptyDescIssue":"Mission {n}: empty description","portalsIssue":"Mission {n}: {count}/{need} portals","missingGuidIssue":"Mission {n}: {count} missing GUID(s)","passIssue":"Mission {n}: {count} incomplete passphrase(s)","reviewCount":"{n} item(s) to review","projectReady":"BannerLab project ready","fixBeforePublish":"Fix these items before publishing.","publisherDesc":"The next bridge will fill the Mission Authoring Tool directly from this native format. Final submission will deliberately remain in the official tool.","packCreating":"Creating BannerLab pack…","packCreated":"BannerLab pack created","exportImpossible":"Export impossible: {error}","missionResetDone":"Mission {n} reset","textDeleted":"Text deleted","histImport":"Import image","histMissionZoom":"Mission zoom","histMissionRotation":"Mission rotation","histTextRotation":"Text rotation","histImageRotation":"Image rotation","histTextZoom":"Text zoom","histImageZoom":"Image zoom","histCenterText":"Center text","histCenterImage":"Center image","histResetText":"Reset text","histResetImage":"Reset image","histResetMission":"Reset mission","histDeleteText":"Delete text","histAddText":"Add text","histEditText":"Edit text"});
Object.assign(I18N.es,{"subtitle":"Mosaicos de Ingress Prime","source":"fuente","bannerHelp":"<b>Modo mosaico:</b> 1 dedo mueve la capa seleccionada. <b>2 dedos</b> amplían y giran.","missionHelp":"<b>Modo misión:</b> toca un medallón. Para trabajar cómodamente, usa <b>Ampliar misión</b>. También puedes moverlo aquí con 1 dedo.","missionSelected":"Misión {n} seleccionada","tapMedallion":"Toca un medallón","touchMissionFirst":"Toca primero la misión que quieres reencuadrar.","selectMissionFirst":"Selecciona primero una misión.","heavyImage":"Imagen muy pesada. Puede poner de rodillas al teléfono, lo cual sería bastante humillante.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto sigue siendo una capa independiente, editable o eliminable.","layer":"Capa","newText":"+ Nuevo texto","size":"Tamaño","outline":"Contorno","color":"Color","outlineColor":"Color del contorno","add":"Añadir","update":"Actualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotación","center":"Centrar","reset":"Restablecer","done":"Hecho","transformText":"Transformar texto","frameImage":"Encuadrar imagen","pinchHint":"El gesto con dos dedos sigue disponible directamente sobre el mosaico.","missionCropOnly":"Este encuadre solo afecta a este medallón.","resetThisMission":"Restablecer esta misión","individualCrop":"Encuadre individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"ampliar y girar","previewPrime":"Vista previa Prime","previewApplied":"Los ajustes individuales de las misiones ya están aplicados.","previewOrder":"El número 1 está abajo a la derecha; después la numeración avanza hacia la izquierda y sube por las filas.","exportTitle":"Exportar {n} misiones","exportIntro":"Elige velocidad o PNG sin pérdida. Ambos siguen en 512 × 512.","noBackground":"No hay imagen de fondo cargada.","missionFormat":"Formato de las misiones","jpgFast":"JPG rápido · alta calidad","pngLossless":"PNG sin pérdida · más lento","fastEncoding":"El modo rápido evita codificar PNG, que es con diferencia la parte más lenta en el teléfono.","rowRender":"El fondo se renderiza una sola vez por fila en vez de recalcularse seis veces.","adjusted":"{n} misión(es) con encuadre individual.","nianticCheck":"Comprueba las reglas de Niantic antes de enviar: derechos de imagen, contenido pertinente y ningún carácter único dominante.","ready":"Listo.","createZip":"Crear ZIP","zipAssembly":"Montando ZIP…","zipCreated":"ZIP creado.","zipDownloaded":"ZIP descargado.","saveShareZip":"Guardar o compartir ZIP","exportFinished":"Exportación {format} terminada","exportFailed":"La exportación ha fallado.","newProject":"Nuevo proyecto","myProjects":"Mis proyectos","projectsSaved":"{n} proyecto(s) guardado(s) en este teléfono.","unnamed":"Sin nombre","opened":"Abierto","open":"Abrir","rename":"Renombrar","copy":"Copiar","noSavedProject":"No hay proyectos guardados.","renameProject":"Renombrar proyecto","renameHint":"Un nombre reconocible por humanos. Concepto sorprendentemente avanzado.","projectName":"Nombre del proyecto","projectOpened":"Proyecto abierto: {name}","projectRenamed":"Proyecto renombrado","deleteProject":"¿Eliminar este proyecto?","deleteWarning":"Se eliminarán el mosaico y su imagen guardada localmente.","copyCreated":"Copia creada","projectDeleted":"Proyecto eliminado","newProjectCreated":"Nuevo proyecto creado con Redacted","defaultProject":"Mi mosaico","defaultNewProject":"Nuevo mosaico","copySuffix":"copia","versionLabel":"Versión","infoPrime":"6 columnas · 544 px · recorte 512 px.","infoPlanner":"acciones de portal, contraseñas, continuidad fin→inicio y paquete BannerLab nativo.","infoCompanion":"recorridos, acciones, trazados multi-misión, opciones y estadísticas a pie.","disclaimer":"Ingress e Ingress Prime son marcas de Niantic. Redacted BannerLab no está afiliado ni aprobado por Niantic.","titleTokens":"$T = nombre · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin IGOR 0.6.35. Sustituye la versión anterior en IITC Mobile. Si IITC se niega a sobrescribirla, elimina una vez el plugin antiguo e instala este archivo.","pluginDialog":"Instalar / actualizar IGOR 0.6.35","pluginShareFailed":"No se puede compartir el plugin IITC.","intelOpened":"IITC Mobile abierto con el proyecto BannerLab.","intelPrimeOpened":"IITC Prime abierto con el proyecto BannerLab.","intelFallback":"IITC Mobile abierto. Companion usará su último estado sincronizado.","intelPrimeFallback":"IITC Prime abierto. Companion usará su último estado sincronizado.","intelBrowser":"IITC no detectado: apertura en el navegador.","tutorialIntro":"Construye todo el mosaico en IITC sin volver a BannerLab después de cada portal.","tut1Title":"Instala el plugin una sola vez","tut1Text":"En Recorrido, usa « Instalar / actualizar plugin IITC » y añade el archivo como plugin de usuario en IITC Mobile.","tut2Title":"Abre IITC desde BannerLab","tut2Text":"BannerLab transmite el proyecto, la misión activa y el idioma al Companion mediante un fragmento local que el servidor Intel nunca recibe.","tut3Title":"Construye directamente en el mapa","tut3Text":"Companion permite añadir, modificar o quitar portales, cambiar de misión y ver los trazados sin volver a BannerLab.","tut4Title":"Sincroniza al terminar","tut4Text":"« Sincronizar BannerLab » devuelve todas las misiones modificadas al proyecto y vuelve a abrir BannerLab.","tutNote":"Puedes mover y redimensionar IGOR y guardar sus ajustes dentro de Opciones.","installUpdate":"Instalar / actualizar","emptyTitleIssue":"Misión {n}: título vacío","emptyDescIssue":"Misión {n}: descripción vacía","portalsIssue":"Misión {n}: {count}/{need} portales","missingGuidIssue":"Misión {n}: {count} GUID ausente(s)","passIssue":"Misión {n}: {count} contraseña(s) incompleta(s)","reviewCount":"{n} punto(s) por revisar","projectReady":"Proyecto BannerLab listo","fixBeforePublish":"Corrige estos elementos antes de publicar.","publisherDesc":"El próximo puente rellenará Mission Authoring Tool directamente desde este formato nativo. El envío final seguirá haciéndose voluntariamente en la herramienta oficial.","packCreating":"Creando paquete BannerLab…","packCreated":"Paquete BannerLab creado","exportImpossible":"Exportación imposible: {error}","missionResetDone":"Misión {n} restablecida","textDeleted":"Texto eliminado","histImport":"Importar imagen","histMissionZoom":"Zoom de misión","histMissionRotation":"Rotación de misión","histTextRotation":"Rotación de texto","histImageRotation":"Rotación de imagen","histTextZoom":"Zoom de texto","histImageZoom":"Zoom de imagen","histCenterText":"Centrar texto","histCenterImage":"Centrar imagen","histResetText":"Restablecer texto","histResetImage":"Restablecer imagen","histResetMission":"Restablecer misión","histDeleteText":"Eliminar texto","histAddText":"Añadir texto","histEditText":"Editar texto"});
Object.assign(I18N.fr,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directement depuis IGOR.","handoverDetail":"Le dernier portail peut devenir le premier de la mission suivante sans être considéré comme un doublon fautif.","coordsMissing":"Coordonnées introuvables.","coordsInvalid":"Coordonnées invalides.","duplicateElsewhere":"Ce portail est déjà utilisé ailleurs dans la bannière.","missionCompleteAdded":"Mission {n} complète · {next}","portalAdded":"Portail ajouté · mission {n}","syncOld":"Parcours synchronisé · ancien Companion détecté : installe la version 0.6.0.","syncOk":"Parcours IITC synchronisé · Companion {v}.","portalDefault":"Portail","bannerDefault":"Fresque"});
Object.assign(I18N.en,{"routeActionHelp":"Hack / Mod / Capture / Link / Field / Passphrase directly from IGOR.","handoverDetail":"The last portal can become the first of the next mission without being treated as an invalid duplicate.","coordsMissing":"Coordinates not found.","coordsInvalid":"Invalid coordinates.","duplicateElsewhere":"This portal is already used elsewhere in the banner.","missionCompleteAdded":"Mission {n} complete · {next}","portalAdded":"Portal added · mission {n}","syncOld":"Route synchronized · old Companion detected: install version 0.6.0.","syncOk":"IITC route synchronized · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner"});
Object.assign(I18N.es,{"routeActionHelp":"Hack / Mod / Captura / Link / Field / Contraseña directamente desIGOR.","handoverDetail":"El último portal puede ser el primero de la siguiente misión sin considerarse un duplicado incorrecto.","coordsMissing":"No se han encontrado coordenadas.","coordsInvalid":"Coordenadas no válidas.","duplicateElsewhere":"Este portal ya se utiliza en otra parte del mosaico.","missionCompleteAdded":"Misión {n} completa · {next}","portalAdded":"Portal añadido · misión {n}","syncOld":"Recorrido sincronizado · Companion antiguo detectado: instala la versión 0.6.0.","syncOk":"Recorrido IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Mosaico"});
Object.assign(I18N.fr,{"livePublish":"Préparer directement dans Mission Authoring","livePublishShort":"Publisher direct","livePreparing":"Préparation des {n} missions pour le Publisher…","liveReady":"Ouverture du Publisher intégré…","liveNativeOnly":"Le Publisher direct est disponible dans l’APK Android.","liveFailed":"Impossible d’ouvrir le Publisher : {error}","liveExperimental":"Expérimental : Mission Authoring s’ouvre dans une vue intégrée à RBL. La connexion Google est la première chose à valider sur ton téléphone.","backupTransfer":"Sauvegarde / transfert","exportPackBackup":"Exporter un pack BannerLab","openOfficialOnly":"Ouvrir le site officiel seulement","publisherPreparingImage":"Rendu mission {n}/{total}…"});
Object.assign(I18N.en,{"livePublish":"Prepare directly in Mission Authoring","livePublishShort":"Direct Publisher","livePreparing":"Preparing {n} missions for Publisher…","liveReady":"Opening integrated Publisher…","liveNativeOnly":"Direct Publisher is available in the Android APK.","liveFailed":"Unable to open Publisher: {error}","liveExperimental":"Experimental: Mission Authoring opens inside an RBL-controlled view. Google sign-in is the first thing to validate on your phone.","backupTransfer":"Backup / transfer","exportPackBackup":"Export BannerLab pack","openOfficialOnly":"Open official site only","publisherPreparingImage":"Rendering mission {n}/{total}…"});
Object.assign(I18N.es,{"livePublish":"Preparar directamente en Mission Authoring","livePublishShort":"Publisher directo","livePreparing":"Preparando {n} misiones para Publisher…","liveReady":"Abriendo Publisher integrado…","liveNativeOnly":"Publisher directo está disponible en la APK Android.","liveFailed":"No se puede abrir Publisher: {error}","liveExperimental":"Experimental: Mission Authoring se abre en una vista controlada por RBL. El inicio de sesión de Google es lo primero que hay que validar en tu teléfono.","backupTransfer":"Copia / transferencia","exportPackBackup":"Exportar paquete BannerLab","openOfficialOnly":"Abrir solo el sitio oficial","publisherPreparingImage":"Renderizando misión {n}/{total}…"});
Object.assign(I18N.fr,{"browserPublish":"Publier dans Firefox","browserPublishShort":"MILO navigateur","browserSetup":"Installer / mettre à jour MILO","browserPreparing":"Préparation de la mission {n}/{total}…","browserOpening":"Ouverture de Firefox…","browserNeed":"Le Publisher direct utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.","browserFailed":"Impossible d’ouvrir MILO : {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab pour missions.ingress.com. À installer une fois dans Violentmonkey sur Firefox Android.","browserShareDialog":"Installer MILO 0.5.3","browserShareFailed":"Impossible de partager le Publisher navigateur.","publisherUrlTooLarge":"La mission est trop lourde à transmettre au navigateur.","publisherReturn":"Retour de MILO.","publisherNoFirefox":"Firefox n’a pas été détecté. Ouverture dans le navigateur par défaut, mais le Publisher nécessite un navigateur avec userscripts."});
Object.assign(I18N.en,{"browserPublish":"Publish in Firefox","browserPublishShort":"MILO browser","browserSetup":"Install / update MILO","browserPreparing":"Preparing mission {n}/{total}…","browserOpening":"Opening Firefox…","browserNeed":"Direct Publisher uses Firefox Android + Violentmonkey so Google sign-in stays in a normal browser.","browserFailed":"Unable to open MILO: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab for missions.ingress.com. Install it once in Violentmonkey on Firefox Android.","browserShareDialog":"Install MILO 0.5.3","browserShareFailed":"Unable to share Browser Publisher.","publisherUrlTooLarge":"This mission is too large to send to the browser.","publisherReturn":"Returned from MILO.","publisherNoFirefox":"Firefox was not detected. Opening the default browser, but Publisher requires a browser with userscript support."});
Object.assign(I18N.es,{"browserPublish":"Publicar en Firefox","browserPublishShort":"MILO navegador","browserSetup":"Instalar / actualizar MILO","browserPreparing":"Preparando misión {n}/{total}…","browserOpening":"Abriendo Firefox…","browserNeed":"Publisher directo usa Firefox Android + Violentmonkey para mantener el inicio de sesión de Google en un navegador normal.","browserFailed":"No se puede abrir MILO: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab para missions.ingress.com. Instálalo una vez en Violentmonkey sobre Firefox Android.","browserShareDialog":"Instalar MILO 0.5.3","browserShareFailed":"No se puede compartir Publisher navegador.","publisherUrlTooLarge":"La misión es demasiado pesada para enviarla al navegador.","publisherReturn":"Regreso desde MILO.","publisherNoFirefox":"Firefox no detectado. Se abre el navegador predeterminado, pero Publisher necesita un navegador compatible con userscripts."});
Object.assign(I18N.fr,{"publisherBrowser":"Navigateur de publication","chromeMode":"Chrome","chromeModeSub":"Sans appli supplémentaire · 1 favori à lancer par mission","firefoxMode":"Firefox","firefoxModeSub":"Automatique après installation de Violentmonkey + Publisher","recommendedAuto":"Automatique","noExtraApp":"Sans appli en plus","publishSelected":"Publier la mission","chromeSetup":"Configurer Chrome","firefoxSetup":"Configurer Firefox","chromeReady":"Favori Chrome vérifié","firefoxReady":"MILO Firefox vérifié","notConfigured":"À configurer une fois","chromeSetupTitle":"MILO dans Chrome","chromeSetupIntro":"Chrome ne permet pas à RBL d’ajouter le favori à ta place. On réduit donc l’installation au strict minimum.","chromeStep1":"1. Copie le code du favori MILO.","chromeStep2":"2. Ouvre Mission Authoring dans Chrome et ajoute la page aux favoris.","chromeStep3":"3. Modifie ce favori : nom « MILO » et remplace son URL par le code copié.","chromeStep4":"4. Sur Mission Authoring, touche la barre d’adresse, tape « MILO », puis choisis le favori étoilé.","copyBookmarklet":"Copier le code du favori","bookmarkletCopied":"Code du favori copié","openChromeSetup":"Ouvrir Chrome pour l’installation","testChrome":"Tester le favori Chrome","chromeRunHint":"Dans Chrome : touche la barre d’adresse, tape MILO puis sélectionne le favori « MILO ».","chromeNeedsSetup":"Configure d’abord le favori Chrome MILO.","chromeOpenFail":"Impossible d’ouvrir Chrome. Ouverture dans le navigateur par défaut.","firefoxSetupTitle":"MILO dans Firefox","firefoxSetupIntro":"Firefox peut charger le Publisher automatiquement grâce à Violentmonkey. C’est le mode le plus fluide.","sharePublisher":"Partager MILO (userscript)","testFirefox":"Tester MILO dans Firefox","firefoxNeedsSetup":"Installe Violentmonkey et MILO dans Firefox avant le test.","browserSaved":"Navigateur de publication : {browser}","setupConfirmed":"Configuration vérifiée.","bookmarkletCopyFail":"Impossible de copier automatiquement. Le code est affiché ci-dessous.","bookmarkletLabel":"Code du favori","autoImpossibleChrome":"Chargement automatique impossible dans Chrome Android sans extension ou permission intrusive. Le favori reste nécessaire.","openChromePublish":"Ouverture dans Chrome…","openFirefoxPublish":"Ouverture dans Firefox…"});
Object.assign(I18N.en,{"publisherBrowser":"Publishing browser","chromeMode":"Chrome","chromeModeSub":"No extra app · run one bookmark per mission","firefoxMode":"Firefox","firefoxModeSub":"Automatic after installing Violentmonkey + Publisher","recommendedAuto":"Automatic","noExtraApp":"No extra app","publishSelected":"Publish mission","chromeSetup":"Set up Chrome","firefoxSetup":"Set up Firefox","chromeReady":"Chrome bookmark verified","firefoxReady":"MILO Firefox verified","notConfigured":"One-time setup required","chromeSetupTitle":"MILO in Chrome","chromeSetupIntro":"Chrome does not let RBL add the bookmark for you. Setup is therefore reduced to the minimum possible.","chromeStep1":"1. Copy the MILO bookmark code.","chromeStep2":"2. Open Mission Authoring in Chrome and bookmark the page.","chromeStep3":"3. Edit that bookmark: name it “MILO” and replace its URL with the copied code.","chromeStep4":"4. On Mission Authoring, tap the address bar, type “MILO”, then choose the starred bookmark.","copyBookmarklet":"Copy bookmark code","bookmarkletCopied":"Bookmark code copied","openChromeSetup":"Open Chrome for setup","testChrome":"Test Chrome bookmark","chromeRunHint":"In Chrome: tap the address bar, type MILO, then select the “MILO” bookmark.","chromeNeedsSetup":"Set up the MILO Chrome bookmark first.","chromeOpenFail":"Could not open Chrome. Opening the default browser.","firefoxSetupTitle":"MILO in Firefox","firefoxSetupIntro":"Firefox can load Publisher automatically through Violentmonkey. This is the smoothest mode.","sharePublisher":"Share MILO userscript","testFirefox":"Test MILO in Firefox","firefoxNeedsSetup":"Install Violentmonkey and MILO in Firefox before testing.","browserSaved":"Publishing browser: {browser}","setupConfirmed":"Setup verified.","bookmarkletCopyFail":"Could not copy automatically. The code is shown below.","bookmarkletLabel":"Bookmark code","autoImpossibleChrome":"Automatic loading is not possible in Chrome Android without an extension or intrusive permission. The bookmark is still required.","openChromePublish":"Opening Chrome…","openFirefoxPublish":"Opening Firefox…"});
Object.assign(I18N.es,{"publisherBrowser":"Navegador de publicación","chromeMode":"Chrome","chromeModeSub":"Sin aplicación adicional · un favorito por misión","firefoxMode":"Firefox","firefoxModeSub":"Automático tras instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sin aplicación adicional","publishSelected":"Publicar misión","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Favorito Chrome verificado","firefoxReady":"Publisher Firefox verificado","notConfigured":"Configurar una sola vez","chromeSetupTitle":"MILO dans Chrome","chromeSetupIntro":"Chrome no permite que RBL añada el favorito por ti. La instalación se reduce al mínimo posible.","chromeStep1":"1. Copia el código del favorito MILO.","chromeStep2":"2. Abre Mission Authoring en Chrome y añade la página a favoritos.","chromeStep3":"3. Edita ese favorito: nombre « MILO » y sustituye la URL por el código copiado.","chromeStep4":"4. En Mission Authoring, toca la barra de direcciones, escribe « MILO » y elige el favorito.","copyBookmarklet":"Copiar código del favorito","bookmarkletCopied":"Código del favorito copiado","openChromeSetup":"Abrir Chrome para instalar","testChrome":"Probar favorito Chrome","chromeRunHint":"En Chrome: toca la barra de direcciones, escribe MILO y selecciona « MILO ».","chromeNeedsSetup":"Configura primero el favorito Chrome MILO.","chromeOpenFail":"No se puede abrir Chrome. Se abre el navegador predeterminado.","firefoxSetupTitle":"MILO dans Firefox","firefoxSetupIntro":"Firefox puede cargar Publisher automáticamente con Violentmonkey. Es el modo más fluido.","sharePublisher":"Compartir userscript Publisher","testFirefox":"Probar Publisher Firefox","firefoxNeedsSetup":"Instala Violentmonkey y Publisher en Firefox antes de probar.","browserSaved":"Navegador de publicación: {browser}","setupConfirmed":"Configuración verificada.","bookmarkletCopyFail":"No se puede copiar automáticamente. El código aparece abajo.","bookmarkletLabel":"Código del favorito","autoImpossibleChrome":"La carga automática no es posible en Chrome Android sin extensión o permiso intrusivo. El favorito sigue siendo necesario.","openChromePublish":"Abriendo Chrome…","openFirefoxPublish":"Abriendo Firefox…"});
Object.assign(I18N.fr,{"chromeModeSub":"Sans appli supplémentaire · petit favori + Autoriser si demandé","chromeWizardTitle":"Configurer Chrome","chromeWizardIntro":"Une seule configuration. RBL mémorise ta progression.","chromeFileTitle":"Enregistrer le Publisher","chromeFileText":"Enregistre le petit fichier Publisher sur ton téléphone. Dans la feuille Android, choisis Fichiers / Enregistrer et garde-le par exemple dans Téléchargements.","chromeSaveFile":"Enregistrer publisher.js","chromeFileDone":"Fichier Publisher préparé","alreadySaved":"Je l’ai déjà enregistré","chromeBookmarkTitle":"Créer le mini favori","chromeBookmarkText":"Le favori ne contient plus le Publisher entier. Il fait seulement {n} caractères et sert à charger le fichier que tu viens d’enregistrer.","chromeBookmarkName":"Nom du favori : MILO","chromeBookmarkHow":"Dans Chrome : ouvre Mission Authoring → ⋮ → Ajouter aux favoris. Modifie ensuite le favori, mets « MILO » et colle le code dans URL.","copyMiniCode":"Copier le mini code","miniCodeCopied":"Mini code copié","openChromeBookmark":"Ouvrir Mission Authoring","bookmarkCreated":"J’ai créé le favori","chromeTestTitle":"Tester et autoriser","chromeTestText":"Le Lab ouvre Mission Authoring. Dans la barre d’adresse, tape MILO puis touche le favori étoilé « MILO ». La première fois, Chrome te demandera de choisir publisher.js. Les fois suivantes il pourra simplement demander Autoriser.","chromeTestButton":"Tester dans Chrome","chromeTestWaiting":"Dans Chrome : tape MILO → touche le favori MILO → sélectionne publisher.js si demandé → Autoriser.","chromeSetupSuccess":"Chrome est prêt","chromeSetupSuccessText":"Le favori et le fichier Publisher fonctionnent. Pour publier : RBL ouvre Chrome, tu lances MILO et tu autorises si Chrome le demande.","publishNow":"Publier maintenant","wizardPrev":"Précédent","wizardNext":"Continuer","wizardRestart":"Recommencer la configuration","stepOf":"Étape {n}/3","chromeFileShareText":"Enregistre ce fichier publisher.js dans un dossier facile à retrouver, par exemple Téléchargements. Chrome te le demandera au premier test.","chromeFileShareDialog":"Enregistrer MILO","chromeFileShareFail":"Impossible de préparer le fichier Publisher.","chromePermissionHint":"Chrome pourra redemander l’autorisation de lire publisher.js. Tu peux simplement accepter.","chromeNotAutoFavorite":"RBL ne peut pas créer un favori Chrome automatiquement. C’est la seule étape manuelle obligatoire.","codeLength":"{n} caractères","chromeStepSaved":"Étape enregistrée","chromeResetDone":"Configuration Chrome réinitialisée","chromeSelectFileHint":"Sélectionne le fichier MILO.user.js enregistré à l’étape 1."});
Object.assign(I18N.en,{"chromeModeSub":"No extra app · small bookmark + Allow when requested","chromeWizardTitle":"Set up Chrome","chromeWizardIntro":"One-time setup. RBL remembers your progress.","chromeFileTitle":"Save Publisher","chromeFileText":"Save the small Publisher file on your phone. In Android's share sheet, choose Files / Save and keep it somewhere easy such as Downloads.","chromeSaveFile":"Save publisher.js","chromeFileDone":"Publisher file prepared","alreadySaved":"I already saved it","chromeBookmarkTitle":"Create the mini bookmark","chromeBookmarkText":"The bookmark no longer contains the whole Publisher. It is only {n} characters and loads the file you just saved.","chromeBookmarkName":"Bookmark name: MILO","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Add to bookmarks. Then edit the bookmark, name it “MILO” and paste the code into URL.","copyMiniCode":"Copy mini code","miniCodeCopied":"Mini code copied","openChromeBookmark":"Open Mission Authoring","bookmarkCreated":"I created the bookmark","chromeTestTitle":"Test and authorize","chromeTestText":"RBL opens Mission Authoring. In the address bar type MILO, then tap the starred “MILO” bookmark. The first time Chrome asks you to choose publisher.js. Later it may only ask Allow.","chromeTestButton":"Test in Chrome","chromeTestWaiting":"In Chrome: type MILO → tap the MILO bookmark → select publisher.js if requested → Allow.","chromeSetupSuccess":"Chrome is ready","chromeSetupSuccessText":"The bookmark and Publisher file work. To publish: RBL opens Chrome, you run MILO and allow access if Chrome asks.","publishNow":"Publish now","wizardPrev":"Previous","wizardNext":"Continue","wizardRestart":"Restart setup","stepOf":"Step {n}/3","chromeFileShareText":"Save this publisher.js somewhere easy to find, such as Downloads. Chrome will ask for it during the first test.","chromeFileShareDialog":"Save MILO","chromeFileShareFail":"Unable to prepare Publisher file.","chromePermissionHint":"Chrome may ask again for permission to read publisher.js. You can simply allow it.","chromeNotAutoFavorite":"RBL cannot create a Chrome bookmark automatically. This is the only mandatory manual step.","codeLength":"{n} characters","chromeStepSaved":"Step saved","chromeResetDone":"Chrome setup reset","chromeSelectFileHint":"Select the MILO.user.js file saved in step 1."});

Object.assign(I18N.fr,{
  "chromeGuideStep":"Étape {n}/7",
  "chromeGuideRealScreens":"Captures réelles faites sur Chrome Android. L’apparence peut varier légèrement selon ta version.",
  "chromeGuide2Title":"Copie le mini-code",
  "chromeGuide2Text":"Copie le mini-code, puis ouvre Mission Authoring Tool dans Chrome. Cette page va simplement nous servir à créer le favori Publisher.",
  "chromeGuideOpenMat":"Ouvrir Mission Authoring Tool",
  "chromeGuide3Title":"Ajoute Mission Authoring aux favoris",
  "chromeGuide3Text":"Sur Mission Authoring, touche ⋮ en haut à droite puis l’étoile ⭐ tout en haut du menu. Chrome enregistre la page dans tes favoris.",
  "chromeGuide4Title":"Retrouve le favori",
  "chromeGuide4Text":"Ouvre ⋮ → Favoris → Favoris d’appareils mobiles. Ouvre le menu du favori Mission Authoring, puis touche Modifier.",
  "chromeGuide5Title":"Transforme-le en MILO",
  "chromeGuide5Text":"Dans Nom, écris MILO. Dans URL, sélectionne toute l’adresse missions.ingress.com, efface-la et colle le mini-code. Reviens ensuite avec ← : Chrome enregistre automatiquement.",
  "chromeGuide6Title":"Lance le favori",
  "chromeGuide6Text":"Retourne sur Mission Authoring Tool, touche la barre d’adresse et commence à taper MILO. Quand la suggestion avec l’étoile ⭐ apparaît, touche-la. C’est elle qui lance le Publisher.",
  "chromeGuide7Title":"Autorise Publisher et charge la session",
  "chromeGuide7Text":"Au premier lancement, sélectionne MILO.user.js puis touche Autoriser quand Chrome demande l’accès. Ensuite sélectionne MILO_CurrentBanner.json. Quand la fenêtre MILO apparaît dans Mission Authoring, tout est prêt.",
  "chromeGuideDone":"C’est fait →",
  "chromeGuideSourceM3":"Chrome Android · capture réelle du test",
  "chromeGuideSourceBookmarks":"Chrome Android · favoris réels du test",
  "chromeGuideSourceEdit":"Chrome Android · écran Modifier le favori",
  "chromeGuideSourceRun":"Chrome Android · suggestion du favori dans la barre d’adresse",
  "chromeGuideTestBadge":"MILO · v1.0.15"
});
Object.assign(I18N.en,{
  "chromeGuideStep":"Step {n}/7",
  "chromeGuideRealScreens":"Real Chrome Android screenshots. The exact appearance may vary slightly with your version.",
  "chromeGuide2Title":"Copy the mini code",
  "chromeGuide2Text":"Copy the bookmark code, then open Mission Authoring Tool in Chrome. Keep RBL open; you will come back here for each step.",
  "chromeGuideOpenMat":"Open Mission Authoring Tool",
  "chromeGuide3Title":"Bookmark Mission Authoring",
  "chromeGuide3Text":"In Chrome, open ⋮ then tap the ⭐ star at the top. You have created the bookmark we will turn into MILO.",
  "chromeGuide4Title":"Find the bookmark",
  "chromeGuide4Text":"Open ⋮ → Bookmarks → Mobile bookmarks. Find the Mission Authoring page you just added, tap ⋮ next to it and choose Edit.",
  "chromeGuide5Title":"Turn it into MILO",
  "chromeGuide5Text":"Set Name to MILO. In URL, remove the current address completely and paste the mini code. Go back: Chrome saves the change.",
  "chromeGuide6Title":"Run the bookmark",
  "chromeGuide6Text":"Return to Mission Authoring Tool. Tap the address bar, type MILO, then tap the bookmark suggestion. Run it from the address bar rather than the Bookmarks list.",
  "chromeGuide7Title":"Allow the two files",
  "chromeGuide7Text":"On first run, select MILO.user.js, then select MILO_CurrentBanner.json for the current banner. Publisher then takes over in Mission Authoring Tool.",
  "chromeGuideDone":"Done →",
  "chromeGuideSourceM3":"Chrome Android Material 3 Expressive · 2025 screenshot",
  "chromeGuideSourceBookmarks":"Chrome Android bookmarks manager",
  "chromeGuideSourceEdit":"Chrome Android Edit bookmark screen",
  "chromeGuideSourceRun":"Running a bookmarklet from the address bar",
  "chromeGuideTestBadge":"MILO · v1.0.15"
});
Object.assign(I18N.fr,{
  "chromeWizardTitle":"Configurer Chrome",
  "chromeWizardIntro":"Installation guidée de MILO · une seule action à la fois. Le Lab mémorise ta progression.",
  "chromeFileTitle":"Préparer MILO",
  "chromeFileText":"Choisis le dossier de travail utilisé par Redacted BannerLab. Il contiendra le programme de MILO et la session de ta bannière. Android mémorisera ce dossier pour les prochaines publications.",
  "chromeBookmarkName":"Nom du favori : MILO",
  "chromeGuide2Title":"Copier le raccourci",
  "chromeGuide2Text":"Copie le mini-code, puis ouvre Mission Authoring Tool dans Chrome. Rien d’autre à modifier pour l’instant.",
  "chromeGuide3Title":"Ajouter Mission Authoring aux favoris",
  "chromeGuide3Text":"Dans Mission Authoring Tool, ouvre le menu ⋮ puis touche l’étoile ⭐. Chrome crée simplement un favori de la page actuelle.",
  "chromeGuide4Title":"Ouvrir le favori en modification",
  "chromeGuide4Text":"Ouvre ⋮ → Favoris → Favoris d’appareils mobiles. Sur le favori Mission Authoring, ouvre son menu puis touche Modifier.",
  "chromeGuide5Title":"Renommer le favori et remplacer son URL",
  "chromeGuide5Text":"Dans Nom, écris MILO. Dans URL, efface complètement l’adresse actuelle et colle le mini-code. Reviens avec ← : Chrome enregistre automatiquement.",
  "chromeGuide6Title":"Lancer MILO",
  "chromeGuide6Text":"Retourne sur Mission Authoring Tool, touche la barre d’adresse et tape MILO. Quand le favori étoilé apparaît, touche-le.",
  "chromeGuide7Title":"Autoriser les fichiers",
  "chromeGuide7Text":"Lors du premier lancement, Chrome te demandera le programme de MILO puis la session de ta bannière. Sélectionne les deux fichiers indiqués ci-dessous et accepte l’autorisation de lecture.",
  "chromeSetupSuccess":"Configuration terminée",
  "chromeSetupSuccessText":"MILO est installé dans Chrome. Pour les prochaines bannières, ouvre Mission Authoring Tool, tape MILO dans la barre d’adresse et choisis le favori. Submit reste toujours sous ton contrôle.",
  "browserNeed":"MILO utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.",
  "browserShareFailed":"Impossible de partager MILO.",
  "publisherNoFirefox":"Firefox n’a pas été détecté. Ouverture dans le navigateur par défaut, mais MILO nécessite un navigateur compatible avec les userscripts.",
  "publisherBrowser":"Publication avec MILO",
  "firefoxModeSub":"Automatique après installation de Violentmonkey + MILO",
  "chromeFileShareText":"Enregistre MILO.user.js dans ton dossier de travail. Chrome le demandera lors de la première configuration.",
  "chromeFileShareDialog":"Enregistrer MILO.user.js",
  "chromeFileShareFail":"Impossible de préparer MILO.user.js.",
  "chromePermissionHint":"Chrome peut redemander l’autorisation de lire MILO.user.js. Tu peux simplement accepter.",
  "chromeNotAutoFavorite":"Le Lab ne peut pas créer un favori Chrome automatiquement. C’est la seule manipulation que Chrome impose.",
  "tutPublisherExplainTitle":"MILO",
  "tutPublisherExplainText":"MILO, Mission Import & Launch Operator, accompagne les missions préparées par Redacted BannerLab jusqu’à Mission Authoring Tool. Il ne clique jamais sur Submit à ta place."
});
Object.assign(I18N.fr,{
  "publisherFolderLabel":"Dossier de travail",
  "publisherFolderChoose":"Choisir le dossier",
  "publisherFolderChange":"Changer de dossier",
  "publisherFolderNone":"Aucun dossier choisi",
  "publisherFolderConfigured":"Dossier configuré",
  "publisherFolderChosen":"Dossier de travail",
  "chromeSaveFile":"Installer / mettre à jour MILO",
  "chromeFileDone":"MILO enregistré",
  "chromeFileSaved":"MILO enregistré dans :",
  "chromeFileWriteFail":"Impossible d’enregistrer MILO dans le dossier choisi.",
  "alreadySaved":"MILO est déjà installé",
  "chromeFileShareDialog":"Enregistrer MILO",
  "chromeFileShareFail":"Impossible de préparer MILO.",
  "chromePermissionHint":"Chrome pourra redemander l’autorisation de lire le programme de MILO. Tu peux simplement accepter.",
  "chromeNotAutoFavorite":"Le Lab ne peut pas créer un favori Chrome automatiquement. C’est la seule manipulation que Chrome impose.",
  "chromeTestWaiting":"Dans Chrome : tape MILO → touche le favori étoilé → sélectionne les fichiers demandés → Autoriser.",
  "chromeModeSub":"Sans appli supplémentaire · un favori Chrome",
  "firefoxModeSub":"Automatique après installation de Violentmonkey + MILO",
  "firefoxSetupIntro":"Firefox peut charger MILO automatiquement grâce à Violentmonkey. C’est le mode le plus fluide.",
  "browserNeed":"MILO utilise Firefox Android + Violentmonkey pour conserver une connexion Google normale.",
  "browserShareFailed":"Impossible de partager MILO.",
  "sourcePrivacySecurity":"Le pont IGOR est authentifié par installation et MILO pour Chrome est vérifié par SHA-256 avant exécution.",
  "publisherDescRequired":"MILO refuse une mission sans description.",
  "publisherPortalsRequired":"MILO refuse une mission avec moins de 6 portails."
});

Object.assign(I18N.en,{
  "chromeWizardTitle":"Set up Chrome with MILO",
  "chromeWizardIntro":"MILO guides you one action at a time, and the Lab remembers your progress.",
  "chromeFileTitle":"Hi Agent, I’m MILO",
  "chromeFileText":"Mission Import & Launch Operator, the Lab’s Publisher assistant. My job is to get you into Mission Authoring without losing you in Chrome bookmarks. First, choose where I keep my files.",
  "chromeBookmarkName":"Bookmark name: MILO",
  "chromeGuide2Title":"MILO prepares the secret passage",
  "chromeGuide2Text":"I live inside a tiny Chrome bookmark. Copy my mini-code, then open Mission Authoring Tool. You do not need to understand the JavaScript. That is my problem.",
  "chromeGuide3Title":"MILO needs a bookmark",
  "chromeGuide3Text":"On Mission Authoring, open ⋮ and tap ⭐. We create a normal bookmark, then I requisition it for the Lab.",
  "chromeGuide4Title":"Find my future hideout",
  "chromeGuide4Text":"Open ⋮ → Bookmarks → Mobile bookmarks. Open the Mission Authoring bookmark menu and tap Edit. That is where I move in.",
  "chromeGuide5Title":"Name the bookmark MILO",
  "chromeGuide5Text":"Set Name to MILO. In URL, completely remove missions.ingress.com and paste my mini-code. Go back with ← and Chrome saves it.",
  "chromeGuide6Title":"Wake MILO inside Mission Authoring",
  "chromeGuide6Text":"Return to Mission Authoring, tap the address bar and type MILO. When the starred bookmark appears, tap it. That is my airlock into the mission lab.",
  "chromeGuide7Title":"Give MILO his mission files",
  "chromeGuide7Text":"On first run, choose MILO.user.js and allow access. Then choose MILO_CurrentBanner.json. If my panel appears in Mission Authoring, the specimen is alive and ready.",
  "chromeSetupSuccess":"MILO is operational",
  "chromeSetupSuccessText":"MILO now knows the way into Mission Authoring. For future banners, open MAT, call MILO from the address bar and let him prepare the missions. Submit always remains under your control."
});
Object.assign(I18N.es,{
  "chromeWizardTitle":"Configurar Chrome con MILO",
  "chromeWizardIntro":"MILO te guía paso a paso y el Lab recuerda tu progreso.",
  "chromeFileTitle":"Hola Agente, soy MILO",
  "chromeFileText":"Mission Import & Launch Operator, asistente Publisher del Lab. Mi trabajo es llevarte hasta Mission Authoring sin perderte entre los favoritos de Chrome.",
  "chromeBookmarkName":"Nombre del favorito: MILO",
  "chromeGuide5Title":"Llama al favorito MILO",
  "chromeGuide6Title":"Despierta a MILO en Mission Authoring",
  "chromeSetupSuccess":"MILO está operativo"
});
Object.assign(I18N.es,{"chromeModeSub":"Sin aplicación adicional · favorito pequeño + Autorizar si se solicita","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Una sola configuración. RBL recuerda tu progreso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"Guarda el pequeño archivo Publisher en el teléfono. En la hoja de Android elige Archivos / Guardar y déjalo en un lugar fácil, por ejemplo Descargas.","chromeSaveFile":"Guardar publisher.js","chromeFileDone":"Archivo Publisher preparado","alreadySaved":"Ya lo he guardado","chromeBookmarkTitle":"Crear el mini favorito","chromeBookmarkText":"El favorito ya no contiene todo el Publisher. Solo tiene {n} caracteres y carga el archivo que acabas de guardar.","chromeBookmarkName":"Nombre del favorito: MILO","chromeBookmarkHow":"En Chrome: abre Mission Authoring → ⋮ → Añadir a favoritos. Después edita el favorito, pon « MILO » y pega el código en URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"He creado el favorito","chromeTestTitle":"Probar y autorizar","chromeTestText":"RBL abre Mission Authoring. En la barra de direcciones escribe MILO y toca el favorito « MILO ». La primera vez Chrome pedirá elegir publisher.js. Después puede pedir solo Autorizar.","chromeTestButton":"Probar en Chrome","chromeTestWaiting":"En Chrome: escribe MILO → toca el favorito MILO → selecciona publisher.js si se solicita → Autorizar.","chromeSetupSuccess":"Chrome está listo","chromeSetupSuccessText":"El favorito y el archivo Publisher funcionan. Para publicar: RBL abre Chrome, ejecutas MILO y autorizas si Chrome lo solicita.","publishNow":"Publicar ahora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuración","stepOf":"Paso {n}/3","chromeFileShareText":"Guarda este publisher.js en un lugar fácil de encontrar, por ejemplo Descargas. Chrome lo pedirá durante la primera prueba.","chromeFileShareDialog":"Guardar MILO","chromeFileShareFail":"No se puede preparar el archivo Publisher.","chromePermissionHint":"Chrome puede volver a pedir permiso para leer publisher.js. Basta con autorizar.","chromeNotAutoFavorite":"RBL no puede crear automáticamente un favorito de Chrome. Es la única etapa manual obligatoria.","codeLength":"{n} caracteres","chromeStepSaved":"Paso guardado","chromeResetDone":"Configuración Chrome reiniciada","chromeSelectFileHint":"Selecciona el archivo MILO.user.js guardado en el paso 1."});
Object.assign(I18N.fr,{"tutPublisherExplainTitle":"MILO","tutPublisherExplainText":"MILO, Mission Import & Launch Operator, prépare les missions dans Mission Authoring. Il remplit, vérifie et garde le fil de la bannière. La soumission finale reste toujours volontaire : MILO ne clique jamais sur Submit à ta place."});
Object.assign(I18N.en,{"tutPublisherExplainTitle":"MILO","tutPublisherExplainText":"MILO, Mission Import & Launch Operator, prepares missions inside Mission Authoring, keeps track of the banner and never clicks Submit for you."});
Object.assign(I18N.es,{"chromeWizardTitle":"Configurar Chrome con MILO","chromeWizardIntro":"MILO te guía paso a paso y el Lab recuerda tu progreso.","chromeFileTitle":"Hola Agente, soy MILO","chromeFileText":"Mission Import & Launch Operator, asistente Publisher del Lab. Mi trabajo es llevarte hasta Mission Authoring sin perderte entre los favoritos de Chrome.","chromeBookmarkName":"Nombre del favorito: MILO","chromeGuide5Title":"Llama al favorito MILO","chromeGuide6Title":"Despierta a MILO en Mission Authoring","chromeGuide6Text":"Vuelve a Mission Authoring, toca la barra de direcciones y escribe MILO. Cuando aparezca el favorito con la estrella ⭐, tócalo.","chromeSetupSuccess":"MILO está operativo","tutPublisherExplainTitle":"MILO","tutPublisherExplainText":"MILO, Mission Import & Launch Operator, prepara las misiones en Mission Authoring y nunca pulsa Submit por ti."});
Object.assign(I18N.fr,{"bannerDescription":"Description de la bannière","required":"Obligatoire","bannerDescriptionHint":"Cette description sert de description par défaut pour toutes les missions. Tu pourras personnaliser une mission ensuite.","bannerDescriptionRequired":"La description de la bannière est obligatoire.","describeBeforePublish":"Décris d’abord la bannière","describeBeforePublishText":"Impossible de publier tant que la bannière n’a pas de description. Elle sera appliquée par défaut à toutes les missions.","saveAndContinue":"Enregistrer et continuer","missionPublishBlocked":"Mission non publiable","missionNeedsPortals":"La mission {n} contient {count}/{need} portails. Il en faut au moins {need} pour la publier.","completeMission":"Compléter la mission","currentMissionReady":"Mission prête à publier","publishBlockedHint":"Le bouton de publication reste bloqué tant que les éléments obligatoires ne sont pas complets.","minimumSix":"Minimum : 6 portails par mission","publisherDescRequired":"Le Publisher refuse une mission sans description.","publisherPortalsRequired":"Le Publisher refuse une mission avec moins de 6 portails."});
Object.assign(I18N.en,{"bannerDescription":"Banner description","required":"Required","bannerDescriptionHint":"This is the default description for every mission. You can still customize individual missions later.","bannerDescriptionRequired":"The banner description is required.","describeBeforePublish":"Describe the banner first","describeBeforePublishText":"Publishing is blocked until the banner has a description. It will be used as the default for all missions.","saveAndContinue":"Save and continue","missionPublishBlocked":"Mission cannot be published","missionNeedsPortals":"Mission {n} has {count}/{need} portals. It needs at least {need} before publishing.","completeMission":"Complete mission","currentMissionReady":"Mission ready to publish","publishBlockedHint":"Publishing remains blocked until all mandatory items are complete.","minimumSix":"Minimum: 6 portals per mission","publisherDescRequired":"Publisher refuses missions without a description.","publisherPortalsRequired":"Publisher refuses missions with fewer than 6 portals."});
Object.assign(I18N.es,{"bannerDescription":"Descripción del mosaico","required":"Obligatorio","bannerDescriptionHint":"Esta será la descripción predeterminada de todas las misiones. Después puedes personalizar cada misión.","bannerDescriptionRequired":"La descripción del mosaico es obligatoria.","describeBeforePublish":"Describe primero el mosaico","describeBeforePublishText":"No se puede publicar hasta que el mosaico tenga una descripción. Se aplicará por defecto a todas las misiones.","saveAndContinue":"Guardar y continuar","missionPublishBlocked":"Misión no publicable","missionNeedsPortals":"La misión {n} tiene {count}/{need} portales. Necesita al menos {need} para publicarla.","completeMission":"Completar misión","currentMissionReady":"Misión lista para publicar","publishBlockedHint":"El botón de publicación permanece bloqueado hasta completar los elementos obligatorios.","minimumSix":"Mínimo: 6 portales por misión","publisherDescRequired":"Publisher rechaza una misión sin descripción.","publisherPortalsRequired":"Publisher rechaza una misión con menos de 6 portales."});
Object.assign(I18N.fr,{"playBanners":"Jouer","playHub":"Jouer une bannière","searchBannergress":"Rechercher sur Bannergress","searchPlaceholder":"Nom de bannière, ville…","search":"Rechercher","favorites":"Favoris","currentBanner":"En cours","noFavorites":"Aucune bannière favorite. Pour une fois, ton stockage local respire.","noPlaySession":"Aucune bannière en cours.","searchPrompt":"Recherche directement les bannières publiques de Bannergress.","searching":"Recherche…","searchError":"Recherche Bannergress impossible : {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favori","removeFavorite":"Retirer des favoris","playThisBanner":"Jouer cette bannière","resumeBanner":"Reprendre la bannière","stopBanner":"Arrêter l’overlay","openCurrentMission":"Ouvrir la mission actuelle","overlayPermissionTitle":"Autoriser l’overlay RBL","overlayPermissionText":"Après une installation APK, Android peut d’abord bloquer cette autorisation comme paramètre restreint. Fais les deux étapes ci-dessous dans l’ordre.","overlayPermissionButton":"Autoriser l’affichage par-dessus les applis","overlayPermissionWaiting":"Une fois l’affichage autorisé, reviens dans RBL : l’overlay démarre automatiquement.","overlayStarted":"Overlay mission démarré.","overlayFailed":"Impossible de démarrer l’overlay : {error}","bannerLoadError":"Impossible de charger cette bannière : {error}","bannerOffline":"Cette bannière ne contient aucune mission exploitable.","bannerDisabled":"{n} mission(s) désactivée(s)","addressUnknown":"Lieu non précisé","doneMissions":"{done}/{total} terminées","deepLinkOnly":"RBL ne pilote pas Ingress : l’overlay ouvre uniquement les deeplinks officiels des missions.","bannergressCredit":"Recherche via Bannergress","publisherWholeBanner":"Préparer toute la bannière","publisherWholeHint":"Une seule session navigateur : toutes les missions et leurs images sont préparées ensemble.","publisherAllRequired":"Toutes les missions doivent être complètes avant de démarrer la session de publication.","publisherSessionCreating":"Préparation de la session Publisher {n}/{total}…","publisherSessionReady":"Session Publisher prête. Enregistre le fichier puis ouvre le navigateur.","publisherSessionFileText":"Enregistre ce fichier de session RBL. Chrome/Firefox le chargera une seule fois pour toute la bannière.","publisherSessionDialog":"Enregistrer la session Publisher","publisherSessionShareFail":"Impossible de préparer la session Publisher.","chromeSessionHint":"Chrome : lance le favori MILO une seule fois, puis sélectionne le fichier de session que tu viens d’enregistrer.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement ; charge le fichier de session une seule fois.","easterEgg":"Tu l’as cherché."});
Object.assign(I18N.en,{"playBanners":"Play","playHub":"Play a banner","searchBannergress":"Search Bannergress","searchPlaceholder":"Banner name, city…","search":"Search","favorites":"Favorites","currentBanner":"Current","noFavorites":"No favorite banners yet. Your local storage is enjoying the peace.","noPlaySession":"No banner currently running.","searchPrompt":"Search public Bannergress banners directly.","searching":"Searching…","searchError":"Bannergress search failed: {error}","missionsCount":"{n} missions","distanceKm":"{n} km","favorite":"Favorite","removeFavorite":"Remove favorite","playThisBanner":"Play this banner","resumeBanner":"Resume banner","stopBanner":"Stop overlay","openCurrentMission":"Open current mission","overlayPermissionTitle":"Allow RBL overlay","overlayPermissionText":"After an APK install, Android may first block this as a restricted setting. Complete the two steps below in order.","overlayPermissionButton":"Allow display over other apps","overlayPermissionWaiting":"Once display-over-apps is allowed, return to RBL: the overlay starts automatically.","overlayStarted":"Mission overlay started.","overlayFailed":"Could not start overlay: {error}","bannerLoadError":"Could not load this banner: {error}","bannerOffline":"This banner has no usable missions.","bannerDisabled":"{n} disabled mission(s)","addressUnknown":"Location not specified","doneMissions":"{done}/{total} completed","deepLinkOnly":"RBL does not control Ingress: the overlay only opens official mission deep links.","bannergressCredit":"Search via Bannergress","publisherWholeBanner":"Prepare whole banner","publisherWholeHint":"One browser session: all missions and images are prepared together.","publisherAllRequired":"Every mission must be complete before starting the publishing session.","publisherSessionCreating":"Preparing Publisher session {n}/{total}…","publisherSessionReady":"Publisher session ready. Save the file, then open the browser.","publisherSessionFileText":"Save this RBL session file. Chrome/Firefox loads it once for the entire banner.","publisherSessionDialog":"Save Publisher session","publisherSessionShareFail":"Unable to prepare Publisher session.","chromeSessionHint":"Chrome: run the MILO bookmark once, then select the session file you just saved.","firefoxSessionHint":"Firefox: Publisher loads automatically; select the session file once.","easterEgg":"You asked for this."});
Object.assign(I18N.es,{"playBanners":"Jugar","playHub":"Jugar un mosaico","searchBannergress":"Buscar en Bannergress","searchPlaceholder":"Nombre, ciudad…","search":"Buscar","favorites":"Favoritos","currentBanner":"En curso","noFavorites":"Aún no hay mosaicos favoritos. El almacenamiento local descansa.","noPlaySession":"No hay ningún mosaico en curso.","searchPrompt":"Busca directamente mosaicos públicos de Bannergress.","searching":"Buscando…","searchError":"Error al buscar en Bannergress: {error}","missionsCount":"{n} misiones","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Quitar de favoritos","playThisBanner":"Jugar este mosaico","resumeBanner":"Reanudar mosaico","stopBanner":"Detener overlay","openCurrentMission":"Abrir misión actual","overlayPermissionTitle":"Autorizar overlay RBL","overlayPermissionText":"Android debe permitir que Redacted BannerLab aparezca sobre Ingress. Un permiso del sistema y el dinosaurio queda suelto.","overlayPermissionButton":"Permitir mostrar sobre otras apps","overlayPermissionWaiting":"Vuelve a RBL después de autorizarlo.","overlayStarted":"Overlay de misión iniciado.","overlayFailed":"No se puede iniciar el overlay: {error}","bannerLoadError":"No se puede cargar el mosaico: {error}","bannerOffline":"Este mosaico no contiene misiones utilizables.","bannerDisabled":"{n} misión(es) desactivada(s)","addressUnknown":"Lugar no indicado","doneMissions":"{done}/{total} terminadas","deepLinkOnly":"RBL no controla Ingress: el overlay solo abre deeplinks oficiales de misiones.","bannergressCredit":"Búsqueda mediante Bannergress","publisherWholeBanner":"Preparar todo el mosaico","publisherWholeHint":"Una sola sesión: todas las misiones e imágenes se preparan juntas.","publisherAllRequired":"Todas las misiones deben estar completas antes de iniciar la sesión de publicación.","publisherSessionCreating":"Preparando sesión Publisher {n}/{total}…","publisherSessionReady":"Sesión Publisher lista. Guarda el archivo y abre el navegador.","publisherSessionFileText":"Guarda este archivo de sesión RBL. Chrome/Firefox lo carga una vez para todo el mosaico.","publisherSessionDialog":"Guardar sesión Publisher","publisherSessionShareFail":"No se puede preparar la sesión Publisher.","chromeSessionHint":"Chrome: ejecuta el favorito MILO una sola vez y selecciona el archivo de sesión guardado.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente; carga el archivo de sesión una sola vez.","easterEgg":"Tú lo pediste."});
Object.assign(I18N.fr,{"playBanners":"Rechercher une fresque","playHub":"Rechercher une fresque","searchBannergress":"Rechercher une fresque","searchPlaceholder":"Nom ou mot-clé","bannerNameSearch":"Nom / mot-clé","citySearch":"Ville","authorSearch":"Auteur","cityPlaceholder":"Ex. Nantes","authorPlaceholder":"Ex. AgentName","nearMe":"Autour de moi","nearMeOn":"Ma position activée","nearMeHint":"La position remplace le filtre ville ; nom et auteur restent combinables.","locationGetting":"Récupération de ta position…","locationError":"Impossible de récupérer ta position : {error}","locationReady":"Position récupérée","searchCriteriaRequired":"Renseigne au moins un critère de recherche.","cityResolving":"Recherche de la ville…","cityNotFound":"Aucun lieu Bannergress trouvé pour « {city} ».","cityUsing":"Lieu retenu : {city}","searchPrompt":"Combine nom, ville et auteur, ou cherche les fresques proches de ta position.","currentBanner":"Reprendre","playThisBanner":"Lancer cette fresque","resumeBanner":"Reprendre cette fresque","bannerAuthor":"Auteur : {author}","overlayDrag":"≡  Déplacer","overlayMinimize":"Réduire","overlayClose":"Fermer","overlayMoved":"Position overlay enregistrée","searchReset":"Effacer","resultsCount":"{n} résultat(s)","searchFilters":"Filtres actifs","allPublicBanners":"Fresques publiques Bannergress"});
Object.assign(I18N.en,{"playBanners":"Find a banner","playHub":"Find a banner","searchBannergress":"Find a banner","searchPlaceholder":"Name or keyword","bannerNameSearch":"Name / keyword","citySearch":"City","authorSearch":"Author","cityPlaceholder":"e.g. Nantes","authorPlaceholder":"e.g. AgentName","nearMe":"Near me","nearMeOn":"My location enabled","nearMeHint":"Location replaces the city filter; name and author can still be combined.","locationGetting":"Getting your location…","locationError":"Could not get your location: {error}","locationReady":"Location acquired","searchCriteriaRequired":"Enter at least one search criterion.","cityResolving":"Looking up city…","cityNotFound":"No Bannergress place found for “{city}”.","cityUsing":"Using place: {city}","searchPrompt":"Combine name, city and author, or find banners near your location.","currentBanner":"Resume","playThisBanner":"Start this banner","resumeBanner":"Resume this banner","bannerAuthor":"Author: {author}","overlayDrag":"≡  Move","overlayMinimize":"Minimize","overlayClose":"Close","overlayMoved":"Overlay position saved","searchReset":"Clear","resultsCount":"{n} result(s)","searchFilters":"Active filters","allPublicBanners":"Public Bannergress banners"});
Object.assign(I18N.es,{"playBanners":"Buscar un mosaico","playHub":"Buscar un mosaico","searchBannergress":"Buscar un mosaico","searchPlaceholder":"Nombre o palabra clave","bannerNameSearch":"Nombre / palabra clave","citySearch":"Ciudad","authorSearch":"Autor","cityPlaceholder":"Ej. Nantes","authorPlaceholder":"Ej. AgentName","nearMe":"Cerca de mí","nearMeOn":"Mi ubicación activada","nearMeHint":"La ubicación sustituye la ciudad; nombre y autor se pueden combinar.","locationGetting":"Obteniendo tu ubicación…","locationError":"No se puede obtener tu ubicación: {error}","locationReady":"Ubicación obtenida","searchCriteriaRequired":"Introduce al menos un criterio de búsqueda.","cityResolving":"Buscando ciudad…","cityNotFound":"No se encontró ningún lugar Bannergress para « {city} ».","cityUsing":"Lugar usado: {city}","searchPrompt":"Combina nombre, ciudad y autor, o busca mosaicos cerca de tu ubicación.","currentBanner":"Reanudar","playThisBanner":"Iniciar este mosaico","resumeBanner":"Reanudar este mosaico","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Reducir","overlayClose":"Cerrar","overlayMoved":"Posición del overlay guardada","searchReset":"Borrar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros activos","allPublicBanners":"Mosaicos públicos Bannergress"});

Object.assign(I18N.fr,{"searchPrompt":"Recherche par nom et/ou zone géographique, avec un rayon réellement limité.","nearMeHint":"Utilise ta position actuelle à la place de la ville.","searchRadius":"Rayon de recherche","radiusHint":"Appliqué autour de la ville ou de ta position.","locationDisabled":"La localisation du téléphone est désactivée.","locationPermissionDenied":"BannerLab n’a pas l’autorisation d’utiliser ta position.","locationUnavailable":"Position indisponible. Vérifie que la localisation du téléphone est activée.","locationTimeout":"La position n’a pas pu être obtenue à temps. Vérifie que la localisation est activée.","openLocationSettings":"Activer la localisation","openAppSettings":"Ouvrir les réglages de l’app","cityNoCoordinates":"La ville « {city} » a été trouvée, mais sa position n’est pas exploitable.","cityUsingRadius":"Lieu retenu : {city} · rayon {radius} km","radiusResults":"{n} résultat(s) dans un rayon de {radius} km","distanceFromPoint":"à {distance}","locationChecking":"Vérification de la localisation…"});
Object.assign(I18N.en,{"searchPrompt":"Search by name and/or geographic area, with a real distance limit.","nearMeHint":"Uses your current position instead of a city.","searchRadius":"Search radius","radiusHint":"Applied around the city or your current position.","locationDisabled":"Location services are disabled on this phone.","locationPermissionDenied":"BannerLab is not allowed to use your location.","locationUnavailable":"Location unavailable. Check that phone location services are enabled.","locationTimeout":"Location could not be acquired in time. Check that location services are enabled.","openLocationSettings":"Enable location","openAppSettings":"Open app settings","cityNoCoordinates":"“{city}” was found, but its position cannot be used.","cityUsingRadius":"Using: {city} · {radius} km radius","radiusResults":"{n} result(s) within {radius} km","distanceFromPoint":"{distance} away","locationChecking":"Checking location services…"});
Object.assign(I18N.es,{"searchPrompt":"Busca por nombre y/o zona geográfica con un límite de distancia real.","nearMeHint":"Usa tu posición actual en lugar de una ciudad.","searchRadius":"Radio de búsqueda","radiusHint":"Se aplica alrededor de la ciudad o de tu posición.","locationDisabled":"La ubicación del teléfono está desactivada.","locationPermissionDenied":"BannerLab no tiene permiso para usar tu ubicación.","locationUnavailable":"Ubicación no disponible. Comprueba que la ubicación del teléfono esté activada.","locationTimeout":"No se pudo obtener la ubicación a tiempo. Comprueba que esté activada.","openLocationSettings":"Activar ubicación","openAppSettings":"Abrir ajustes de la app","cityNoCoordinates":"Se encontró « {city} », pero no se puede usar su posición.","cityUsingRadius":"Lugar usado: {city} · radio {radius} km","radiusResults":"{n} resultado(s) en un radio de {radius} km","distanceFromPoint":"a {distance}","locationChecking":"Comprobando ubicación…"});
Object.assign(I18N.fr,{"bannerInfoLabel":"Banner info","bannerImageScrollHint":"Fais défiler l’image pour voir toute la fresque."});
Object.assign(I18N.en,{"bannerInfoLabel":"Banner info","bannerImageScrollHint":"Scroll the image to see the whole banner."});
Object.assign(I18N.es,{"bannerInfoLabel":"Banner info","bannerImageScrollHint":"Desplaza la imagen para ver el mosaico completo."});
Object.assign(I18N.fr,{"publisherSessionReady":"Session enregistrée dans le dossier Publisher choisi. Ouverture de Mission Authoring…","publisherSessionFileText":"RBL enregistre automatiquement la session dans le dossier Publisher que tu as choisi.","publisherSessionDialog":"Session Publisher","chromeSessionHint":"Chrome : lance le favori MILO. La première fois, choisis MILO_CurrentBanner.json ; ensuite Chrome réutilise ce fichier.","firefoxSessionHint":"Firefox : le Publisher s’ouvre automatiquement. Charge MILO_CurrentBanner.json si la session courante n’est pas déjà connue.","publisherCurrentFile":"Fichier courant : MILO_CurrentBanner.json dans ton dossier Publisher."});
Object.assign(I18N.en,{"publisherSessionReady":"Session saved in your selected Publisher folder. Opening Mission Authoring…","publisherSessionFileText":"RBL automatically saves the session in your selected Publisher folder.","publisherSessionDialog":"Publisher session","chromeSessionHint":"Chrome: run the MILO bookmark. The first time choose MILO_CurrentBanner.json; Chrome will reuse that file afterwards.","firefoxSessionHint":"Firefox: Publisher opens automatically. Load MILO_CurrentBanner.json if the current session is not already known.","publisherCurrentFile":"Current file: MILO_CurrentBanner.json in your Publisher folder."});
Object.assign(I18N.es,{"publisherSessionReady":"Sesión guardada en Descargas/RedactedBannerLab. Abriendo Mission Authoring…","publisherSessionFileText":"RBL guarda automáticamente la sesión en Descargas/RedactedBannerLab.","publisherSessionDialog":"Sesión Publisher","chromeSessionHint":"Chrome: ejecuta el favorito MILO. La primera vez elige MILO_CurrentBanner.json; después Chrome reutilizará ese archivo.","firefoxSessionHint":"Firefox: Publisher se abre automáticamente. Carga MILO_CurrentBanner.json si la sesión actual aún no está disponible.","publisherCurrentFile":"Archivo actual: Descargas/RedactedBannerLab/MILO_CurrentBanner.json"});
Object.assign(I18N.fr,{"chromeFileText":"Choisis le dossier où RBL doit conserver le Publisher et les fichiers de session. Android mémorisera ton autorisation pour les prochaines publications.","chromeSaveFile":"Enregistrer le Publisher","chromeFileDone":"Publisher enregistré","chromeFilePath":"Le Publisher sera enregistré dans le dossier que tu choisis.","chromeFileSaved":"Publisher enregistré dans :","chromeFileWriteFail":"Impossible d’écrire le Publisher dans le dossier choisi.","chromeSelectFileHint":"Dans Chrome, sélectionne le fichier MILO.user.js dans le dossier que tu as choisi.","chromeCurrentSessionHint":"Pour la session, sélectionne MILO_CurrentBanner.json dans ce même dossier."});
Object.assign(I18N.fr,{"publisherFolderLabel":"Dossier de travail","publisherFolderChoose":"Choisir le dossier","publisherFolderChange":"Changer de dossier","publisherFolderNone":"Aucun dossier choisi","publisherFolderConfigured":"Dossier configuré","publisherFolderChosen":"Dossier de travail","publisherFolderChooseFail":"Impossible de sélectionner le dossier."});
Object.assign(I18N.en,{"chromeFileText":"Choose where RBL should keep Publisher and session files. Android will remember access to this folder for future publications.","chromeSaveFile":"Save Publisher","chromeFileDone":"Publisher saved","chromeFilePath":"Publisher will be stored in the folder you choose.","chromeFileSaved":"Publisher saved in:","chromeFileWriteFail":"Unable to write Publisher to the selected folder.","chromeSelectFileHint":"In Chrome, select MILO.user.js from the folder you chose.","chromeCurrentSessionHint":"For the session, select MILO_CurrentBanner.json from the same folder."});
Object.assign(I18N.en,{"publisherFolderLabel":"Publisher folder","publisherFolderChoose":"Choose folder","publisherFolderChange":"Change folder","publisherFolderNone":"No folder selected","publisherFolderConfigured":"Folder configured","publisherFolderChosen":"Publisher folder","publisherFolderChooseFail":"Unable to select the folder."});
Object.assign(I18N.es,{"chromeFileText":"RBL guarda Publisher directamente en Descargas/RedactedBannerLab. No hace falta la hoja de compartir de Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","chromeFilePath":"Descargas/RedactedBannerLab/MILO.user.js","chromeFileSaved":"Publisher guardado en Descargas/RedactedBannerLab.","chromeFileWriteFail":"No se puede escribir Publisher en Descargas/RedactedBannerLab.","chromeSelectFileHint":"En Chrome selecciona: Descargas/RedactedBannerLab/MILO.user.js","chromeCurrentSessionHint":"Para la sesión: Descargas/RedactedBannerLab/MILO_CurrentBanner.json"});
Object.assign(I18N.fr,{"publisherSaving":"Enregistrement…"});
Object.assign(I18N.en,{"publisherSaving":"Saving…"});
Object.assign(I18N.es,{"publisherSaving":"Guardando…"});
Object.assign(I18N.fr,{"chromeSessionHint":"Chrome : lance le favori MILO. Pour chaque nouvelle bannière préparée, Chrome te demandera explicitement MILO_CurrentBanner.json. Ensuite rien à refaire entre les missions.","chromeTestText":"Le Lab ouvre Mission Authoring. Tape MILO puis lance le favori. Chrome te demandera le Publisher, puis le JSON courant. Le JSON sera redemandé à chaque nouvelle bannière, jamais entre les missions.","chromeSetupSuccessText":"Chrome est prêt. Le Publisher reste mémorisé ; le fichier JSON de la bannière sera choisi explicitement à chaque nouvelle session pour éviter tout ancien projet fantôme.","chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis MILO_CurrentBanner.json dans le dossier Publisher sélectionné."});
Object.assign(I18N.en,{"chromeSessionHint":"Chrome: run the MILO bookmark. For every newly prepared banner, Chrome will explicitly ask for MILO_CurrentBanner.json. Nothing else is required between missions.","chromeTestText":"RBL opens Mission Authoring. Type MILO and run the bookmark. Chrome asks for Publisher, then the current JSON. The JSON is requested for each new banner, never between missions.","chromeSetupSuccessText":"Chrome is ready. Publisher stays remembered; the banner JSON is explicitly selected for each new session so stale projects cannot be reused silently.","chromeCurrentSessionHint":"For each new banner: choose MILO_CurrentBanner.json from the selected Publisher folder."});
Object.assign(I18N.es,{"chromeSessionHint":"Chrome: ejecuta el favorito MILO. Para cada nuevo mosaico preparado, Chrome pedirá explícitamente MILO_CurrentBanner.json. No habrá que repetir nada entre misiones.","chromeTestText":"RBL abre Mission Authoring. Escribe MILO y ejecuta el favorito. Chrome pide Publisher y después el JSON actual. El JSON se vuelve a pedir para cada nuevo mosaico, nunca entre misiones.","chromeSetupSuccessText":"Chrome está listo. Publisher queda memorizado; el JSON del mosaico se selecciona explícitamente en cada nueva sesión para evitar proyectos antiguos.","chromeCurrentSessionHint":"Para cada nuevo mosaico: elige Descargas/RedactedBannerLab/MILO_CurrentBanner.json."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Retour au navigateur sans recharger Mission Authoring…","chromeResumeHint":"Chrome est simplement remis au premier plan. Le Publisher recharge automatiquement MILO_CurrentBanner.json si l’autorisation est encore valide.","firefoxResumeHint":"Firefox est simplement remis au premier plan afin de conserver la session Mission Authoring.","browserResumeFallback":"Impossible de reprendre le navigateur existant. Ouverture de Mission Authoring en secours.","publisherAutoRefresh":"Le Publisher surveille désormais le fichier de session courant et recharge automatiquement une nouvelle bannière."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Returning to the browser without reloading Mission Authoring…","chromeResumeHint":"Chrome is only brought back to the foreground. Publisher automatically reloads MILO_CurrentBanner.json while permission remains valid.","firefoxResumeHint":"Firefox is only brought back to the foreground to preserve the Mission Authoring session.","browserResumeFallback":"Could not resume the existing browser. Opening Mission Authoring as fallback.","publisherAutoRefresh":"Publisher now watches the current session file and automatically reloads a newly prepared banner."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Volviendo al navegador sin recargar Mission Authoring…","chromeResumeHint":"Chrome solo vuelve al primer plano. Publisher recarga automáticamente MILO_CurrentBanner.json mientras el permiso siga válido.","firefoxResumeHint":"Firefox solo vuelve al primer plano para conservar la sesión de Mission Authoring.","browserResumeFallback":"No se puede reanudar el navegador existente. Se abre Mission Authoring como alternativa.","publisherAutoRefresh":"Publisher ahora vigila el archivo de sesión actual y recarga automáticamente una nueva pancarta."});
Object.assign(I18N.fr,{"flowLocked":"Édition de la fresque verrouillée","flowLockedText":"L’étape {step} est active. Sélectionne « 1 Fresque » pour modifier l’image, les textes ou le cadrage.","returnFresco":"Sélectionne 1 Fresque pour modifier","flowLockedToast":"Retourne sur l’étape 1 Fresque pour modifier la bannière."});
Object.assign(I18N.en,{"flowLocked":"Banner editing locked","flowLockedText":"Step {step} is active. Select “1 Banner” to edit the image, text or framing.","returnFresco":"Select 1 Banner to edit","flowLockedToast":"Return to step 1 Banner to edit the banner."});
Object.assign(I18N.es,{"flowLocked":"Edición del mosaico bloqueada","flowLockedText":"El paso {step} está activo. Selecciona « 1 Mosaico » para modificar imagen, texto o encuadre.","returnFresco":"Selecciona 1 Mosaico para editar","flowLockedToast":"Vuelve al paso 1 Mosaico para editar el mosaico."});
Object.assign(I18N.fr,{"browserResume":"Session préparée. Ouverture de l’onglet Mission Authoring RBL…","chromeResumeHint":"Chrome réutilise désormais le même onglet Mission Authoring réservé à RBL.","firefoxResumeHint":"Ouverture de Mission Authoring dans le navigateur de publication.","browserResumeFallback":"Impossible de réutiliser l’onglet RBL. Ouverture du navigateur en secours.","publisherTabReuse":"RBL utilise un identifiant d’application navigateur stable pour réutiliser le même onglet."});
Object.assign(I18N.en,{"browserResume":"Session prepared. Opening the RBL Mission Authoring tab…","chromeResumeHint":"Chrome now reuses the same Mission Authoring tab reserved for RBL.","firefoxResumeHint":"Opening Mission Authoring in the publishing browser.","browserResumeFallback":"Could not reuse the RBL tab. Opening the browser as fallback.","publisherTabReuse":"RBL uses a stable browser application ID to reuse the same tab."});
Object.assign(I18N.es,{"browserResume":"Sesión preparada. Abriendo la pestaña Mission Authoring de RBL…","chromeResumeHint":"Chrome reutiliza ahora la misma pestaña Mission Authoring reservada para RBL.","firefoxResumeHint":"Abriendo Mission Authoring en el navegador de publicación.","browserResumeFallback":"No se puede reutilizar la pestaña RBL. Abriendo el navegador como alternativa.","publisherTabReuse":"RBL usa un identificador de aplicación del navegador estable para reutilizar la misma pestaña."});
Object.assign(I18N.fr,{"todo":"À faire","history":"Historique","inProgress":"En cours","addTodo":"Ajouter à À faire","removeTodo":"Retirer de À faire","noTodo":"Aucune fresque à faire. Pour l’instant tu es raisonnable.","noHistory":"Aucune fresque jouée. Le dino s’ennuie.","bannerMap":"Carte du parcours","openMap":"Voir la carte","navigateStart":"Itinéraire vers le départ","startUnavailable":"Point de départ indisponible.","mapUnavailable":"Bannergress ne fournit pas de coordonnées exploitables pour cette fresque.","startPoint":"Départ","missionStart":"Mission {n}","shareGroup":"Partager / groupe","shareProgress":"Partager la progression","shareBanner":"Partager la fresque","shareIntro":"Le QR ouvre RBL sur la même fresque et le même numéro de mission. Aucun compte Bannergress n’est utilisé.","copyLink":"Copier le lien RBL","linkCopied":"Lien RBL copié","shareNow":"Partager","bannergressPage":"Voir sur Bannergress","joinBanner":"Rejoindre la fresque","joinAtMission":"Rejoindre à la mission {n}","sharedBannerLoaded":"Fresque partagée chargée · mission {n}","sharedBannerError":"Impossible de charger cette fresque partagée : {error}","playStats":"Stats de session","startedAt":"Début","finishedAt":"Fin","elapsed":"Durée active","estimatedDistance":"Distance estimée","missionsDone":"Missions terminées","paused":"En pause","playing":"En cours","completedBanner":"Terminée","replayBanner":"Rejouer","resumeFromHistory":"Reprendre","groupNoServer":"Mode groupe sans serveur : partage simplement le QR/lien à nouveau si le groupe change de mission.","publicOnly":"Recherche et données publiques Bannergress uniquement · aucune connexion nécessaire.","routePoints":"{n} points sur le parcours"});
Object.assign(I18N.en,{"todo":"To do","history":"History","inProgress":"In progress","addTodo":"Add to To do","removeTodo":"Remove from To do","noTodo":"No banners to do. Suspiciously reasonable.","noHistory":"No played banners yet. The dino is bored.","bannerMap":"Route map","openMap":"View map","navigateStart":"Navigate to start","startUnavailable":"Start point unavailable.","mapUnavailable":"Bannergress does not provide usable coordinates for this banner.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Share / group","shareProgress":"Share progress","shareBanner":"Share banner","shareIntro":"The QR opens RBL on the same banner and mission number. No Bannergress account is used.","copyLink":"Copy RBL link","linkCopied":"RBL link copied","shareNow":"Share","bannergressPage":"Open on Bannergress","joinBanner":"Join banner","joinAtMission":"Join at mission {n}","sharedBannerLoaded":"Shared banner loaded · mission {n}","sharedBannerError":"Could not load shared banner: {error}","playStats":"Session stats","startedAt":"Started","finishedAt":"Finished","elapsed":"Active time","estimatedDistance":"Estimated distance","missionsDone":"Missions done","paused":"Paused","playing":"In progress","completedBanner":"Completed","replayBanner":"Play again","resumeFromHistory":"Resume","groupNoServer":"Serverless group mode: share the QR/link again if the group moves to another mission.","publicOnly":"Public Bannergress search/data only · no sign-in required.","routePoints":"{n} route points"});
Object.assign(I18N.es,{"todo":"Por hacer","history":"Historial","inProgress":"En curso","addTodo":"Añadir a Por hacer","removeTodo":"Quitar de Por hacer","noTodo":"No hay mosaicos pendientes. Sospechosamente razonable.","noHistory":"No hay mosaicos jugados. El dino se aburre.","bannerMap":"Mapa del recorrido","openMap":"Ver mapa","navigateStart":"Ir al punto de inicio","startUnavailable":"Punto de inicio no disponible.","mapUnavailable":"Bannergress no proporciona coordenadas utilizables para este mosaico.","startPoint":"Inicio","missionStart":"Misión {n}","shareGroup":"Compartir / grupo","shareProgress":"Compartir progreso","shareBanner":"Compartir mosaico","shareIntro":"El QR abre RBL en el mismo mosaico y número de misión. No se usa ninguna cuenta Bannergress.","copyLink":"Copiar enlace RBL","linkCopied":"Enlace RBL copiado","shareNow":"Compartir","bannergressPage":"Abrir en Bannergress","joinBanner":"Unirse al mosaico","joinAtMission":"Unirse en la misión {n}","sharedBannerLoaded":"Mosaico compartido cargado · misión {n}","sharedBannerError":"No se puede cargar el mosaico compartido: {error}","playStats":"Estadísticas de sesión","startedAt":"Inicio","finishedAt":"Fin","elapsed":"Tiempo activo","estimatedDistance":"Distancia estimada","missionsDone":"Misiones terminadas","paused":"En pausa","playing":"En curso","completedBanner":"Terminado","replayBanner":"Jugar otra vez","resumeFromHistory":"Reanudar","groupNoServer":"Modo grupo sin servidor: comparte de nuevo el QR/enlace si el grupo cambia de misión.","publicOnly":"Solo búsqueda/datos públicos de Bannergress · no hace falta iniciar sesión.","routePoints":"{n} puntos de recorrido"});
Object.assign(I18N.fr,{"uselessStats":"Stats inutiles","loadingStats":"Calcul des trucs dont personne n’avait besoin…","statsUnavailable":"Pas assez de coordonnées pour calculer les stats inutiles.","bgDistance":"Distance Bannergress","calculatedTrack":"Tracé calculé","walkingEstimate":"Marche théorique","routeSteps":"Étapes","uniquePlaces":"Lieux distincts","revisitedPlaces":"Passages répétés","stepsPerKm":"Étapes / km","avgMissionDistance":"Moyenne / mission","longestMission":"Mission la plus longue","longestLeg":"Plus long tronçon","betweenMissions":"Transitions inter-missions","detourFactor":"Coefficient de détour","routeCoverage":"Couverture carto","missionShort":"M{n}","straightLine":"Départ → arrivée","funStatsDisclaimer":"Calculs géométriques entre les points Bannergress, pas un itinéraire routier. Donc oui, c’est scientifiquement approximatif et parfaitement satisfaisant pour des stats inutiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Stats inutiles","hideUselessStats":"Masquer les stats","statsLoaded":"Stats calculées"});
Object.assign(I18N.en,{"uselessStats":"Useless stats","loadingStats":"Calculating things nobody asked for…","statsUnavailable":"Not enough coordinates to calculate useless stats.","bgDistance":"Bannergress distance","calculatedTrack":"Calculated track","walkingEstimate":"Theoretical walking","routeSteps":"Steps","uniquePlaces":"Unique places","revisitedPlaces":"Repeated visits","stepsPerKm":"Steps / km","avgMissionDistance":"Average / mission","longestMission":"Longest mission","longestLeg":"Longest leg","betweenMissions":"Between-mission transitions","detourFactor":"Detour factor","routeCoverage":"Map coverage","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"Geometric calculations between Bannergress points, not a road route. Scientifically approximate, therefore ideal for useless stats.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Useless stats","hideUselessStats":"Hide stats","statsLoaded":"Stats calculated"});
Object.assign(I18N.es,{"uselessStats":"Estadísticas inútiles","loadingStats":"Calculando cosas que nadie necesitaba…","statsUnavailable":"No hay suficientes coordenadas para calcular estadísticas inútiles.","bgDistance":"Distancia Bannergress","calculatedTrack":"Recorrido calculado","walkingEstimate":"Caminata teórica","routeSteps":"Etapas","uniquePlaces":"Lugares distintos","revisitedPlaces":"Pasos repetidos","stepsPerKm":"Etapas / km","avgMissionDistance":"Media / misión","longestMission":"Misión más larga","longestLeg":"Tramo más largo","betweenMissions":"Transiciones entre misiones","detourFactor":"Factor de desvío","routeCoverage":"Cobertura cartográfica","missionShort":"M{n}","straightLine":"Inicio → final","funStatsDisclaimer":"Cálculos geométricos entre puntos Bannergress, no una ruta vial. Científicamente aproximado, perfecto para estadísticas inútiles.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Estadísticas inútiles","hideUselessStats":"Ocultar estadísticas","statsLoaded":"Estadísticas calculadas"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne RBL","walkingEstimate":"Temps piéton RBL","directGeometric":"Distance directe cumulée","routingDetour":"Détour du réseau piéton","routingSource":"Routage","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponible · estimation géométrique","routingLoading":"Calcul du vrai parcours piéton…","routingFailed":"Routage piéton indisponible, stats géométriques utilisées.","funStatsDisclaimer":"Distance piétonne calculée par Valhalla sur les chemins OpenStreetMap entre tous les points de la fresque. La distance directe reste affichée pour comparaison. Les chemins OSM peuvent évidemment être faux, parce que même les cartes ont leurs jours sans.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.en,{"calculatedTrack":"RBL walking distance","walkingEstimate":"RBL walking time","directGeometric":"Cumulative direct distance","routingDetour":"Pedestrian network detour","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla unavailable · geometric estimate","routingLoading":"Calculating actual walking route…","routingFailed":"Walking routing unavailable, geometric stats used.","funStatsDisclaimer":"Walking distance calculated by Valhalla over OpenStreetMap paths between every banner point. Direct distance remains for comparison. OSM paths can of course be wrong, because maps also enjoy chaos.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia a pie RBL","walkingEstimate":"Tiempo a pie RBL","directGeometric":"Distancia directa acumulada","routingDetour":"Desvío de la red peatonal","routingSource":"Enrutamiento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla no disponible · estimación geométrica","routingLoading":"Calculando la ruta peatonal real…","routingFailed":"Enrutamiento peatonal no disponible, se usan estadísticas geométricas.","funStatsDisclaimer":"Distancia a pie calculada por Valhalla sobre caminos OpenStreetMap entre todos los puntos del mosaico. La distancia directa se conserva para comparar. OSM también puede equivocarse, porque la perfección era demasiado pedir.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}"});
Object.assign(I18N.fr,{"routingNative":"Valhalla + OSM · HTTP natif Android","routingWeb":"Valhalla + OSM · navigateur","routingErrorDetail":"Échec Valhalla : {error}"});
Object.assign(I18N.en,{"routingNative":"Valhalla + OSM · Android native HTTP","routingWeb":"Valhalla + OSM · browser","routingErrorDetail":"Valhalla failed: {error}"});
Object.assign(I18N.es,{"routingNative":"Valhalla + OSM · HTTP nativo Android","routingWeb":"Valhalla + OSM · navegador","routingErrorDetail":"Error de Valhalla: {error}"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance jouable RBL","walkingEstimate":"Temps de marche RBL","routingNative":"Valhalla + OSM · portée Ingress 40 m","routingWeb":"Valhalla + OSM · portée Ingress 40 m","routingDetour":"Écart réseau / direct","funStatsDisclaimer":"RBL cherche un chemin piéton OpenStreetMap passant à moins de 40 m de chaque portail, ce qui correspond mieux à la portée de jeu Ingress que d’obliger le trajet à atteindre la coordonnée exacte du portail. La distance directe cumulée reste affichée pour comparaison.","ingressRadius":"Portée Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.en,{"calculatedTrack":"RBL playable distance","walkingEstimate":"RBL walking time","routingNative":"Valhalla + OSM · 40 m Ingress range","routingWeb":"Valhalla + OSM · 40 m Ingress range","routingDetour":"Network / direct ratio","funStatsDisclaimer":"RBL looks for an OpenStreetMap pedestrian route passing within 40 m of every portal. This better matches actual Ingress interaction range than forcing the route to reach the portal's exact coordinate. Cumulative direct distance remains visible for comparison.","ingressRadius":"Ingress range","ingressRadiusValue":"40 m"});
Object.assign(I18N.es,{"calculatedTrack":"Distancia jugable RBL","walkingEstimate":"Tiempo a pie RBL","routingNative":"Valhalla + OSM · alcance Ingress 40 m","routingWeb":"Valhalla + OSM · alcance Ingress 40 m","routingDetour":"Relación red / directa","funStatsDisclaimer":"RBL busca una ruta peatonal OpenStreetMap que pase a menos de 40 m de cada portal. Esto se ajusta mejor al alcance real de Ingress que obligar la ruta a llegar a la coordenada exacta del portal. La distancia directa acumulada sigue visible para comparar.","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m"});
Object.assign(I18N.fr,{"calculatedTrack":"Distance piétonne estimée","walkingEstimate":"Temps de marche estimé","routingNative":"Valhalla + OSM · contrôle tronçon par tronçon","routingWeb":"Valhalla + OSM · contrôle tronçon par tronçon","routingDetour":"Écart réseau / direct","correctedLegs":"Tronçons corrigés","rawValhalla":"Valhalla brut","funStatsDisclaimer":"RBL route chaque liaison portail → portail sur le réseau piéton OpenStreetMap. Chaque tronçon est contrôlé : si Valhalla propose une distance impossible ou un détour manifestement aberrant, seul ce tronçon est remplacé par sa distance directe. C’est une estimation de marche, pas une mesure GPS réelle."});
Object.assign(I18N.en,{"calculatedTrack":"Estimated walking distance","walkingEstimate":"Estimated walking time","routingNative":"Valhalla + OSM · per-leg sanity check","routingWeb":"Valhalla + OSM · per-leg sanity check","routingDetour":"Network / direct ratio","correctedLegs":"Corrected legs","rawValhalla":"Raw Valhalla","funStatsDisclaimer":"RBL routes every portal-to-portal leg on the OpenStreetMap pedestrian network. Each leg is sanity-checked: impossible shortcuts or obviously absurd detours are replaced only for that leg by direct distance. This is a walking estimate, not a GPS measurement."});
Object.assign(I18N.es,{"calculatedTrack":"Distancia peatonal estimada","walkingEstimate":"Tiempo de marcha estimado","routingNative":"Valhalla + OSM · control tramo por tramo","routingWeb":"Valhalla + OSM · control tramo por tramo","routingDetour":"Relación red / directa","correctedLegs":"Tramos corregidos","rawValhalla":"Valhalla bruto","funStatsDisclaimer":"RBL calcula cada tramo portal → portal sobre la red peatonal OpenStreetMap. Cada tramo se valida: atajos imposibles o desvíos claramente absurdos se sustituyen solo en ese tramo por la distancia directa. Es una estimación a pie, no una medición GPS real."});
Object.assign(I18N.fr,{"creditsTitle":"Crédits & remerciements","bannergressThanks":"Merci Bannergress","bannergressThanksText":"La recherche de fresques et plusieurs informations publiques affichées dans Redacted BannerLab s’appuient sur les données publiques de Bannergress. Merci à leur équipe et aux contributeurs pour l’énorme travail réalisé autour des fresques Ingress.","bannergressNoLogin":"RBL n’utilise aucun compte Bannergress : uniquement les données publiques nécessaires à la recherche et à l’affichage des fresques.","independentProject":"Redacted BannerLab est un projet indépendant et n’est ni affilié ni approuvé par Bannergress ou les services officiels Ingress.","visitBannergress":"Découvrir Bannergress","mapCredits":"Cartographie & itinéraires","mapCreditsText":"Les cartes reposent sur OpenStreetMap. Les estimations de parcours piétons utilisent le moteur de routage Valhalla.","rblCreditsFoot":"Merci à tous les outils et contributeurs qui rendent possible cet écosystème autour des missions Ingress."});
Object.assign(I18N.en,{"creditsTitle":"Credits & thanks","bannergressThanks":"Thanks Bannergress","bannergressThanksText":"Banner search and several public details displayed in Redacted BannerLab rely on public Bannergress data. Thanks to their team and contributors for the enormous amount of work around Ingress banners.","bannergressNoLogin":"RBL does not use a Bannergress account: only public data required for banner search and display.","independentProject":"Redacted BannerLab is an independent project and is not affiliated with or endorsed by Bannergress or official Ingress services.","visitBannergress":"Visit Bannergress","mapCredits":"Maps & routing","mapCreditsText":"Maps use OpenStreetMap data. Pedestrian route estimates use the Valhalla routing engine.","rblCreditsFoot":"Thanks to all the tools and contributors that make this Ingress mission ecosystem possible."});
Object.assign(I18N.es,{"creditsTitle":"Créditos y agradecimientos","bannergressThanks":"Gracias Bannergress","bannergressThanksText":"La búsqueda de mosaicos y varios datos públicos mostrados en Redacted BannerLab se apoyan en datos públicos de Bannergress. Gracias a su equipo y a sus colaboradores por el enorme trabajo realizado alrededor de los mosaicos de Ingress.","bannergressNoLogin":"RBL no utiliza ninguna cuenta Bannergress: solo los datos públicos necesarios para buscar y mostrar mosaicos.","independentProject":"Redacted BannerLab es un proyecto independiente y no está afiliado ni aprobado por Bannergress ni por los servicios oficiales de Ingress.","visitBannergress":"Visitar Bannergress","mapCredits":"Mapas y rutas","mapCreditsText":"Los mapas utilizan datos de OpenStreetMap. Las estimaciones de rutas peatonales usan el motor Valhalla.","rblCreditsFoot":"Gracias a todas las herramientas y colaboradores que hacen posible este ecosistema de misiones de Ingress."});
Object.assign(I18N.fr,{"layersTitle":"Images & calques","layersDesc":"Gère ici le fond et toutes les images superposées. Les miniatures permettent d’identifier rapidement le bon calque, puis de le sélectionner, masquer, réordonner ou grouper.","backgroundLayer":"Fond principal","addBackground":"Ajouter / remplacer le fond","addLayer":"Ajouter un calque","layerName":"Calque image","selected":"Sélectionné","visibleLayer":"Visible","hiddenLayer":"Masqué","moveUp":"Monter","moveDown":"Descendre","groupSelection":"Sélection de groupe","group":"Grouper","ungroup":"Dégrouper","groupNeedTwo":"Sélectionne au moins deux calques à grouper.","groupCreated":"Calques groupés","groupRemoved":"Groupe supprimé","deleteLayer":"Supprimer le calque","layerDeleted":"Calque supprimé","layerAdded":"Calque ajouté","backgroundReplaced":"Fond remplacé","backgroundMissing":"Aucun fond principal","backgroundFixed":"Le fond reste toujours sous les autres calques.","groupHint":"Coche plusieurs calques puis appuie sur Grouper. Un groupe se déplace, zoome et tourne ensemble.","layerOrder":"Ordre des calques","layerTransform":"Transformer le calque","groupTransform":"Transformer le groupe","renameLayer":"Renommer","duplicateLayer":"Dupliquer","layerDuplicated":"Calque dupliqué","histAddLayer":"Ajouter calque","histDeleteLayer":"Supprimer calque","histReorderLayer":"Réordonner calque","histGroupLayers":"Grouper calques","histUngroupLayers":"Dégrouper calques","histVisibilityLayer":"Visibilité calque","histRenameLayer":"Renommer calque","histDuplicateLayer":"Dupliquer calque"});
Object.assign(I18N.en,{"layersTitle":"Images & layers","layersDesc":"Manage the background and all overlaid images here. Thumbnails help identify the right layer, then select, hide, reorder or group it.","backgroundLayer":"Main background","addBackground":"Add / replace background","addLayer":"Add layer","layerName":"Image layer","selected":"Selected","visibleLayer":"Visible","hiddenLayer":"Hidden","moveUp":"Move up","moveDown":"Move down","groupSelection":"Group selection","group":"Group","ungroup":"Ungroup","groupNeedTwo":"Select at least two layers to group.","groupCreated":"Layers grouped","groupRemoved":"Group removed","deleteLayer":"Delete layer","layerDeleted":"Layer deleted","layerAdded":"Layer added","backgroundReplaced":"Background replaced","backgroundMissing":"No main background","backgroundFixed":"The background always stays below the other layers.","groupHint":"Tick several layers then tap Group. A group moves, zooms and rotates together.","layerOrder":"Layer order","layerTransform":"Transform layer","groupTransform":"Transform group","renameLayer":"Rename","duplicateLayer":"Duplicate","layerDuplicated":"Layer duplicated","histAddLayer":"Add layer","histDeleteLayer":"Delete layer","histReorderLayer":"Reorder layer","histGroupLayers":"Group layers","histUngroupLayers":"Ungroup layers","histVisibilityLayer":"Layer visibility","histRenameLayer":"Rename layer","histDuplicateLayer":"Duplicate layer"});
Object.assign(I18N.es,{"layersTitle":"Imágenes y capas","layersDesc":"Gestiona aquí el fondo y todas las imágenes superpuestas. Las miniaturas ayudan a identificar, seleccionar, ocultar, ordenar o agrupar cada capa.","backgroundLayer":"Fondo principal","addBackground":"Añadir / reemplazar fondo","addLayer":"Añadir capa","layerName":"Capa de imagen","selected":"Seleccionada","visibleLayer":"Visible","hiddenLayer":"Oculta","moveUp":"Subir","moveDown":"Bajar","groupSelection":"Selección de grupo","group":"Agrupar","ungroup":"Desagrupar","groupNeedTwo":"Selecciona al menos dos capas para agrupar.","groupCreated":"Capas agrupadas","groupRemoved":"Grupo eliminado","deleteLayer":"Eliminar capa","layerDeleted":"Capa eliminada","layerAdded":"Capa añadida","backgroundReplaced":"Fondo reemplazado","backgroundMissing":"Sin fondo principal","backgroundFixed":"El fondo siempre permanece debajo de las demás capas.","groupHint":"Marca varias capas y pulsa Agrupar. Un grupo se mueve, amplía y gira junto.","layerOrder":"Orden de capas","layerTransform":"Transformar capa","groupTransform":"Transformar grupo","renameLayer":"Renombrar","duplicateLayer":"Duplicar","layerDuplicated":"Capa duplicada","histAddLayer":"Añadir capa","histDeleteLayer":"Eliminar capa","histReorderLayer":"Reordenar capa","histGroupLayers":"Agrupar capas","histUngroupLayers":"Desagrupar capas","histVisibilityLayer":"Visibilidad capa","histRenameLayer":"Renombrar capa","histDuplicateLayer":"Duplicar capa"});
Object.assign(I18N.fr,{"layerGroupBadge":"Groupe","layerUngroup":"Dégrouper ce groupe","layerSelectHint":"Le calque sélectionné se déplace ensuite directement sur la fresque.","layerOpacity":"Opacité","layerDimensions":"{w} × {h} px","noImageContent":"Ajoute au moins une image avant d’exporter.","groupRelative":"Les réglages ci-dessous transforment tout le groupe ensemble.","groupZoom":"Zoom du groupe","groupRotation":"Rotation du groupe","clearGroupSelection":"Vider la sélection"});
Object.assign(I18N.en,{"layerGroupBadge":"Group","layerUngroup":"Ungroup this group","layerSelectHint":"The selected layer can then be moved directly on the banner.","layerOpacity":"Opacity","layerDimensions":"{w} × {h} px","noImageContent":"Add at least one image before exporting.","groupRelative":"The controls below transform the whole group together.","groupZoom":"Group zoom","groupRotation":"Group rotation","clearGroupSelection":"Clear selection"});
Object.assign(I18N.es,{"layerGroupBadge":"Grupo","layerUngroup":"Desagrupar este grupo","layerSelectHint":"La capa seleccionada se puede mover después directamente sobre el mosaico.","layerOpacity":"Opacidad","layerDimensions":"{w} × {h} px","noImageContent":"Añade al menos una imagen antes de exportar.","groupRelative":"Los controles siguientes transforman todo el grupo junto.","groupZoom":"Zoom del grupo","groupRotation":"Rotación del grupo","clearGroupSelection":"Vaciar selección"});
Object.assign(I18N.fr,{"allLayersTitle":"Calques","allLayersDesc":"Sélectionne l’élément à manipuler. Images et textes restent modifiables depuis leurs menus dédiés.","imageLayersSection":"Images","textLayersSection":"Textes","noExtraImageLayer":"Aucun calque image supplémentaire","noTextLayer":"Aucun calque texte","selectLayer":"Sélectionner","editLayer":"Modifier"});
Object.assign(I18N.en,{"allLayersTitle":"Layers","allLayersDesc":"Select the element you want to manipulate. Images and text remain editable from their dedicated menus.","imageLayersSection":"Images","textLayersSection":"Text","noExtraImageLayer":"No additional image layer","noTextLayer":"No text layer","selectLayer":"Select","editLayer":"Edit"});
Object.assign(I18N.es,{"allLayersTitle":"Capas","allLayersDesc":"Selecciona el elemento que quieres manipular. Las imágenes y los textos siguen editándose desde sus menús dedicados.","imageLayersSection":"Imágenes","textLayersSection":"Textos","noExtraImageLayer":"No hay capas de imagen adicionales","noTextLayer":"No hay capas de texto","selectLayer":"Seleccionar","editLayer":"Editar"});
Object.assign(I18N.fr,{"missionNumberQuestion":"Quel est le numéro de la mission ?"});
Object.assign(I18N.en,{"missionNumberQuestion":"What is the mission number?"});
Object.assign(I18N.es,{"missionNumberQuestion":"¿Cuál es el número de la misión?"});

Object.assign(I18N.fr,{"groupName":"Groupe {n}","groupCount":"{n} calque(s)","creatorBy":"Créé par Zw4nn","communityTitle":"Communauté & support","communityText":"Actualités, aide, bugs, suggestions et échanges autour de Redacted BannerLab.","telegramOpen":"Ouvrir Telegram","reportProblem":"Signaler un problème","reportProblemText":"Copie un diagnostic technique puis ouvre Telegram pour décrire le problème.","copyDiagnostic":"Copier le diagnostic","diagnosticCopied":"Diagnostic copié","diagnosticCopyFailed":"Impossible de copier le diagnostic","diagnosticDescription":"Description du problème :"});
Object.assign(I18N.en,{"groupName":"Group {n}","groupCount":"{n} layer(s)","creatorBy":"Created by Zw4nn","communityTitle":"Community & support","communityText":"News, help, bugs, suggestions and discussion around Redacted BannerLab.","telegramOpen":"Open Telegram","reportProblem":"Report a problem","reportProblemText":"Copy a technical diagnostic, then open Telegram to describe the problem.","copyDiagnostic":"Copy diagnostic","diagnosticCopied":"Diagnostic copied","diagnosticCopyFailed":"Unable to copy diagnostic","diagnosticDescription":"Problem description:"});
Object.assign(I18N.fr,{"sourcePrivacyTitle":"Code public & confidentialité","sourcePrivacyText":"Le code source de Redacted BannerLab est public sur GitHub. Tu peux vérifier exactement ce que fait l’application.","sourcePrivacyNoTracking":"Aucun compte RBL, aucune publicité, aucune télémétrie et aucune collecte cachée. Tes projets et images ne sont pas envoyés vers un serveur Redacted BannerLab.","sourcePrivacyLocal":"Tes projets, images, réglages et sauvegardes restent sur ton appareil, sauf quand tu choisis explicitement d’exporter, partager ou publier quelque chose.","sourcePrivacyNetwork":"Les fonctions connectées contactent uniquement les services nécessaires : GitHub pour les mises à jour, Bannergress pour les données publiques, OpenStreetMap/Valhalla pour les cartes et itinéraires, Google Maps uniquement quand tu choisis d’y ouvrir un parcours, le Mission Authoring Tool lors de la publication, et Telegram uniquement quand tu ouvres le support.","sourcePrivacySecrets":"La clé de signature Android et les secrets de build restent hors du dépôt public.","sourcePrivacySecurity":"Le pont IGOR est authentifié par installation et le Publisher Chrome est vérifié par SHA-256 avant exécution.","sourcePrivacyGithub":"Voir le code sur GitHub","footerCopyright":"© 2026 Zw4nn · Redacted BannerLab","footerCommunity":"Fait pour la communauté Ingress. Pensé d’abord côté Enlightened, mais ouvert à tous les agents : les Resistance sont aussi les bienvenus dans le Lab."});
Object.assign(I18N.en,{"sourcePrivacyTitle":"Public code & privacy","sourcePrivacyText":"Redacted BannerLab's source code is public on GitHub. You can inspect exactly what the app does.","sourcePrivacyNoTracking":"No RBL account, no ads, no telemetry and no hidden data collection. Your projects and images are not sent to a Redacted BannerLab server.","sourcePrivacyLocal":"Your projects, images, settings and backups stay on your device unless you explicitly choose to export, share or publish something.","sourcePrivacyNetwork":"Connected features only contact the services they need: GitHub for updates, Bannergress for public data, OpenStreetMap/Valhalla for maps and routes, Google Maps only when you choose to open a route there, the Mission Authoring Tool while publishing, and Telegram only when you open support.","sourcePrivacySecrets":"The Android signing key and build secrets stay outside the public repository.","sourcePrivacySecurity":"The IGOR bridge is authenticated per installation and the Chrome Publisher is SHA-256 verified before execution.","sourcePrivacyGithub":"View source on GitHub","footerCopyright":"© 2026 Zw4nn · Redacted BannerLab","footerCommunity":"Made for the Ingress community. Built first on the Enlightened side, but open to every agent: Resistance players are welcome in the Lab too."});
Object.assign(I18N.es,{"groupName":"Grupo {n}","groupCount":"{n} capa(s)","creatorBy":"Creado por Zw4nn","communityTitle":"Comunidad y soporte","communityText":"Noticias, ayuda, errores, sugerencias y conversaciones sobre Redacted BannerLab.","telegramOpen":"Abrir Telegram","reportProblem":"Informar de un problema","reportProblemText":"Copia un diagnóstico técnico y abre Telegram para describir el problema.","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","diagnosticCopyFailed":"No se pudo copiar el diagnóstico","diagnosticDescription":"Descripción del problema:"});
Object.assign(I18N.fr,{"portableProject":"Projet portable","portableProjectDesc":"Exporte une seule fresque avec ses images, calques, textes, polices, missions et parcours.","exportProject":"Exporter","shareProject":"Partager","importProject":"Importer un projet","projectExporting":"Préparation du projet…","projectExported":"Projet enregistré","projectShared":"Projet prêt à être partagé","projectImportSuccess":"Projet importé","projectImportInvalid":"Ce fichier n’est pas un projet Redacted BannerLab valide.","projectShareTitle":"Projet Redacted BannerLab","projectImportHint":"Le projet importé est ajouté sans modifier les autres projets.","telegramOpen":"Contacter le support","communityText":"Accède à la communauté et au support directement via le bot Redacted BannerLab.","reportProblemText":"Copie un diagnostic technique puis contacte le support via le bot."});
Object.assign(I18N.en,{"portableProject":"Portable project","portableProjectDesc":"Export one banner with its images, layers, text, fonts, missions and route.","exportProject":"Export","shareProject":"Share","importProject":"Import project","projectExporting":"Preparing project…","projectExported":"Project saved","projectShared":"Project ready to share","projectImportSuccess":"Project imported","projectImportInvalid":"This file is not a valid Redacted BannerLab project.","projectShareTitle":"Redacted BannerLab project","projectImportHint":"The imported project is added without changing your other projects.","telegramOpen":"Contact support","communityText":"Access the community and support directly through the Redacted BannerLab bot.","reportProblemText":"Copy a technical diagnostic, then contact support through the bot."});
Object.assign(I18N.es,{"portableProject":"Proyecto portátil","portableProjectDesc":"Exporta un solo mural con sus imágenes, capas, textos, fuentes, misiones y recorrido.","exportProject":"Exportar","shareProject":"Compartir","importProject":"Importar proyecto","projectExporting":"Preparando proyecto…","projectExported":"Proyecto guardado","projectShared":"Proyecto listo para compartir","projectImportSuccess":"Proyecto importado","projectImportInvalid":"Este archivo no es un proyecto Redacted BannerLab válido.","projectShareTitle":"Proyecto Redacted BannerLab","projectImportHint":"El proyecto importado se añade sin modificar los demás proyectos.","telegramOpen":"Contactar con soporte","communityText":"Accede a la comunidad y al soporte directamente a través del bot de Redacted BannerLab.","reportProblemText":"Copia un diagnóstico técnico y contacta con soporte a través del bot."});
Object.assign(I18N.fr,{"backupTitle":"Sauvegarde & restauration","backupText":"Sauvegarde tous les projets BannerLab, leurs réglages et leurs images dans un JSON portable.","backupFolder":"Dossier de sauvegarde","backupFolderChoose":"Choisir le dossier","backupFolderChange":"Changer le dossier","backupFolderNone":"Aucun dossier choisi","backupFolderReady":"Dossier configuré","backupAuto":"Sauvegarde automatique en arrière-plan","backupAutoHint":"Quand elle est active, BannerLab prépare régulièrement la sauvegarde après tes modifications et la force au passage en arrière-plan.","backupNow":"Sauvegarder maintenant","backupExport":"Exporter le JSON","backupImport":"Importer un JSON","backupWorking":"Création de la sauvegarde…","backupSaved":"Sauvegarde terminée","backupAutoSaved":"Sauvegarde automatique terminée","backupFailed":"Échec de la sauvegarde : {error}","backupNeedFolder":"Choisis d’abord un dossier de sauvegarde.","backupFolderError":"Impossible d’utiliser ce dossier.","backupImported":"Sauvegarde restaurée","backupInvalid":"Ce fichier n’est pas une sauvegarde Redacted BannerLab valide.","backupImportTitle":"Restaurer la sauvegarde","backupImportText":"{n} projet(s) trouvé(s) · sauvegarde du {date}","backupMerge":"Fusionner","backupReplace":"Remplacer tout","backupReplaceWarn":"Remplacer tout supprime les projets présents sur ce téléphone avant la restauration.","backupCancel":"Annuler","backupLast":"Dernière sauvegarde : {date}","backupNever":"Aucune sauvegarde effectuée","backupPortable":"Le JSON contient aussi les images. Il peut donc être volumineux, mais il se suffit à lui-même.","backupNativeOnly":"Le dossier automatique est disponible sur Android. L’export/import JSON reste disponible partout.","backupFolderChosen":"Dossier de sauvegarde enregistré","backupNoChanges":"Aucun changement à sauvegarder."});
Object.assign(I18N.en,{"backupTitle":"Backup & restore","backupText":"Back up all BannerLab projects, settings and images in one portable JSON file.","backupFolder":"Backup folder","backupFolderChoose":"Choose folder","backupFolderChange":"Change folder","backupFolderNone":"No folder selected","backupFolderReady":"Folder configured","backupAuto":"Automatic backup in background","backupAutoHint":"When enabled, BannerLab regularly prepares the backup after your changes and forces a final save when going to the background.","backupNow":"Back up now","backupExport":"Export JSON","backupImport":"Import JSON","backupWorking":"Creating backup…","backupSaved":"Backup complete","backupAutoSaved":"Automatic backup complete","backupFailed":"Backup failed: {error}","backupNeedFolder":"Choose a backup folder first.","backupFolderError":"Unable to use this folder.","backupImported":"Backup restored","backupInvalid":"This file is not a valid Redacted BannerLab backup.","backupImportTitle":"Restore backup","backupImportText":"{n} project(s) found · backup from {date}","backupMerge":"Merge","backupReplace":"Replace all","backupReplaceWarn":"Replace all deletes the projects currently stored on this device before restoring.","backupCancel":"Cancel","backupLast":"Last backup: {date}","backupNever":"No backup yet","backupPortable":"The JSON also contains the images. It can therefore be large, but it is fully self-contained.","backupNativeOnly":"Automatic folder backup is available on Android. JSON export/import remains available everywhere.","backupFolderChosen":"Backup folder saved","backupNoChanges":"No changes to back up."});
Object.assign(I18N.es,{"backupTitle":"Copia de seguridad y restauración","backupText":"Guarda todos los proyectos BannerLab, sus ajustes e imágenes en un JSON portátil.","backupFolder":"Carpeta de copia","backupFolderChoose":"Elegir carpeta","backupFolderChange":"Cambiar carpeta","backupFolderNone":"Ninguna carpeta seleccionada","backupFolderReady":"Carpeta configurada","backupAuto":"Copia automática en segundo plano","backupAutoHint":"Cuando está activa, BannerLab prepara regularmente la copia después de tus cambios y fuerza un guardado al pasar a segundo plano.","backupNow":"Guardar ahora","backupExport":"Exportar JSON","backupImport":"Importar JSON","backupWorking":"Creando copia…","backupSaved":"Copia terminada","backupAutoSaved":"Copia automática terminada","backupFailed":"Error de copia: {error}","backupNeedFolder":"Elige primero una carpeta de copia.","backupFolderError":"No se puede usar esta carpeta.","backupImported":"Copia restaurada","backupInvalid":"Este archivo no es una copia válida de Redacted BannerLab.","backupImportTitle":"Restaurar copia","backupImportText":"{n} proyecto(s) encontrado(s) · copia del {date}","backupMerge":"Fusionar","backupReplace":"Reemplazar todo","backupReplaceWarn":"Reemplazar todo elimina los proyectos presentes en este dispositivo antes de restaurar.","backupCancel":"Cancelar","backupLast":"Última copia: {date}","backupNever":"Aún no hay copia","backupPortable":"El JSON también contiene las imágenes. Puede ser grande, pero es completamente autónomo.","backupNativeOnly":"La copia automática en carpeta está disponible en Android. La exportación/importación JSON sigue disponible en todas partes.","backupFolderChosen":"Carpeta de copia guardada","backupNoChanges":"No hay cambios que guardar."});


Object.assign(I18N.fr,{"studioEdit":"Édition plein écran","studioTitle":"Studio d’édition","studioLayers":"Calques","studioTexts":"Textes","studioTools":"Outils","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"Tout","studioMissionMode":"Mission","studioFrescoMode":"Fresque","studioFullscreen":"Plein écran","studioRotateHint":"6 missions dans la hauteur · les rangées suivantes défilent vers la droite.","studioSelected":"Élément sélectionné","studioNoLayer":"Sélectionne un calque ou un texte sur le côté.","studioGroupSelect":"Sélection groupe","studioGroupNow":"Grouper","studioOpenFull":"Ouvrir le gestionnaire complet","studioOpacity":"Opacité","studioClose":"Quitter le studio","studioPan":"Défilement","studioAddText":"Ajouter un texte","studioNoText":"Aucun texte pour le moment.","studioEditText":"Modifier le texte","studioDuplicateText":"Dupliquer le texte"});
Object.assign(I18N.en,{"studioEdit":"Full-screen edit","studioTitle":"Editing studio","studioLayers":"Layers","studioTexts":"Text","studioTools":"Tools","studioFit":"6 missions","studioFitOne":"1 mission","studioFitAll":"All","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Full screen","studioRotateHint":"6 missions vertically · following rows scroll to the right.","studioSelected":"Selected item","studioNoLayer":"Select a layer or text item from the side.","studioGroupSelect":"Group selection","studioGroupNow":"Group","studioOpenFull":"Open full manager","studioOpacity":"Opacity","studioClose":"Exit studio","studioPan":"Scroll","studioAddText":"Add text","studioNoText":"No text yet.","studioEditText":"Edit text","studioDuplicateText":"Duplicate text"});
Object.assign(I18N.es,{"studioEdit":"Edición a pantalla completa","studioTitle":"Estudio de edición","studioLayers":"Capas","studioTexts":"Textos","studioTools":"Herramientas","studioFit":"6 misiones","studioFitOne":"1 misión","studioFitAll":"Todo","studioMissionMode":"Misión","studioFrescoMode":"Fresco","studioFullscreen":"Pantalla completa","studioRotateHint":"6 misiones en vertical · las filas siguientes se desplazan hacia la derecha.","studioSelected":"Elemento seleccionado","studioNoLayer":"Selecciona una capa o un texto en el lateral.","studioGroupSelect":"Selección de grupo","studioGroupNow":"Agrupar","studioOpenFull":"Abrir gestor completo","studioOpacity":"Opacidad","studioClose":"Salir del estudio","studioPan":"Desplazar","studioAddText":"Añadir texto","studioNoText":"Aún no hay textos.","studioEditText":"Editar texto","studioDuplicateText":"Duplicar texto"});
Object.assign(I18N.fr,{"font":"Police","fontWeight":"Graisse","fontItalic":"Italique","letterSpacing":"Espacement lettres","lineHeight":"Interligne","textAlign":"Alignement","alignLeft":"Gauche","alignCenter":"Centre","alignRight":"Droite","importFont":"Importer une police","fontImported":"Police importée : {name}","fontInvalid":"Cette police n’est pas prise en charge.","fontTooLarge":"Police trop volumineuse (12 Mo max).","textBackground":"Fond du texte","textBackgroundColor":"Couleur du fond","textBackgroundOpacity":"Opacité du fond","textBackgroundPadding":"Marge du fond","textBackgroundRadius":"Arrondi / radius","textTypography":"Typographie"});
Object.assign(I18N.en,{"font":"Font","fontWeight":"Weight","fontItalic":"Italic","letterSpacing":"Letter spacing","lineHeight":"Line height","textAlign":"Alignment","alignLeft":"Left","alignCenter":"Center","alignRight":"Right","importFont":"Import font","fontImported":"Font imported: {name}","fontInvalid":"This font is not supported.","fontTooLarge":"Font is too large (12 MB max).","textBackground":"Text background","textBackgroundColor":"Background color","textBackgroundOpacity":"Background opacity","textBackgroundPadding":"Background padding","textBackgroundRadius":"Corner radius","textTypography":"Typography"});
Object.assign(I18N.es,{"font":"Fuente","fontWeight":"Peso","fontItalic":"Cursiva","letterSpacing":"Espaciado de letras","lineHeight":"Interlineado","textAlign":"Alineación","alignLeft":"Izquierda","alignCenter":"Centro","alignRight":"Derecha","importFont":"Importar fuente","fontImported":"Fuente importada: {name}","fontInvalid":"Esta fuente no es compatible.","fontTooLarge":"La fuente es demasiado grande (12 MB máx.).","textBackground":"Fondo del texto","textBackgroundColor":"Color de fondo","textBackgroundOpacity":"Opacidad del fondo","textBackgroundPadding":"Margen del fondo","textBackgroundRadius":"Radio de esquinas","textTypography":"Tipografía"});
Object.assign(I18N.fr,{
  tutorialHubTitle:'Tutoriels & prise en main',tutorialHubText:'Relance une visite quand tu veux. Redacted peut expliquer seulement la partie qui t’intéresse.',
  tutorialOpen:'Voir les tutoriels',tutorialWelcomeTitle:'Bienvenue dans Redacted BannerLab',tutorialWelcomeText:'Redacted peut te faire visiter le laboratoire. Deux minutes, quelques boutons et aucun examen à la fin.',
  tutorialStart:'Commencer la visite',tutorialLater:'Plus tard',tutorialNever:'Ne plus afficher',tutorialPrevious:'Précédent',tutorialNext:'Suivant',tutorialUnderstood:'OK, j’ai compris',tutorialClose:'Fermer',tutorialDone:'Tutoriel terminé',tutorialSeen:'Déjà vu',
  tutorialQuick:'Découverte rapide',tutorialQuickDesc:'Les boutons essentiels et le parcours général de BannerLab.',tutorialBanner:'Créer une fresque',tutorialBannerDesc:'Du projet vide jusqu’à l’aperçu et l’export des missions.',
  tutorialLayers:'Images, calques & textes',tutorialLayersDesc:'Fond, images superposées, calques et atelier typographique.',tutorialIitc:'Créer le parcours avec IITC',tutorialIitcDesc:'Installer IGOR, ajouter les portails et synchroniser le tracé.',
  tutorialPublish:'Publier les missions',tutorialPublishDesc:'Préparer les missions puis utiliser le Publisher et Mission Authoring.',tutorialBackup:'Sauvegardes & projets portables',tutorialBackupDesc:'Sauvegarder BannerLab ou partager une seule fresque complète.',
  importRolesHint:'Fond principal = image de base de la fresque · Calque = image supplémentaire superposée.',
  tutProjectTitle:'Tes projets',tutProjectText:'Chaque fresque vit dans son propre projet. Tu peux ensuite l’exporter ou la partager sans embarquer tous les autres.',
  tutNameTitle:'Nom du projet',tutNameText:'Donne un nom reconnaissable à ta fresque. Oui, « test2-final-vraiment-final » fonctionne aussi, mais Redacted désapprouve.',
  tutRowsTitle:'Nombre de rangées',tutRowsText:'Une rangée contient 6 missions. Choisis ici la hauteur finale de ta fresque.',
  tutImageTitle:'Images & calques',tutImageText:'C’est ici que tu importes le fond principal et toutes les images supplémentaires. Ce même écran sert aussi à sélectionner, ordonner, masquer et grouper les calques.',
  tutBackgroundTitle:'Fond principal',tutBackgroundText:'Pour ta première vraie image, utilise Fond principal. Elle remplace l’image de base et couvre toute la fresque.',
  tutExtraLayerTitle:'Ajouter un calque',tutExtraLayerText:'Une seconde image est un calque : elle se superpose au fond et reste déplaçable, redimensionnable et masquable.',
  tutLayersTitle:'Gérer les calques image',tutLayersText:'Les miniatures te montrent immédiatement quel calque tu manipules. Tu peux le sélectionner, changer son ordre, le masquer ou cocher plusieurs images pour les grouper.',
  tutTextTitle:'Texte',tutTextText:'Ajoute du texte, choisis la police, l’espacement, le fond, le radius ou importe ta propre police.',
  tutPreviewTitle:'Aperçu',tutPreviewText:'Vérifie le rendu mission par mission avant l’export. Les recadrages individuels sont déjà appliqués.',
  tutExportTitle:'Exporter',tutExportText:'Quand tout est prêt, BannerLab génère les images 512 × 512 dans le bon ordre.',
  tutStudioTitle:'Studio plein écran',tutStudioText:'Pour les gros doigts officiellement reconnus par le laboratoire : édition plein écran, calques latéraux et navigation plus confortable.',
  tutFlowTitle:'Les 4 étapes',tutFlowText:'Fresque → Parcours → Missions → Publier. BannerLab te guide dans cet ordre sans t’obliger à tout faire d’un coup.',
  tutRouteTitle:'Parcours',tutRouteText:'Le parcours relie tes missions aux vrais portails Ingress. Le Companion IITC fait le gros du travail directement sur la carte.',
  tutCompanionTitle:'IITC Companion',tutCompanionText:'Le Companion accompagne le projet dans IITC : mission active, portails, actions et statistiques de marche.',
  tutInstallCompanionTitle:'Installer IGOR',tutInstallCompanionText:'Installe ou mets à jour le plugin une fois dans IITC Mobile. Ensuite BannerLab peut lui transmettre ton projet.',
  tutOpenIitcTitle:'Ouvrir IITC',tutOpenIitcText:'Ouvre IITC depuis BannerLab : le projet et la mission active sont transmis au Companion.',
  tutAutoRouteTitle:'Passage entre missions',tutAutoRouteText:'La mission suivante peut s’ouvrir automatiquement et reprendre le dernier portail comme premier portail. La case reste réglable ici.',
  tutPortalListTitle:'Tes portails',tutPortalListText:'Les portails ajoutés dans IITC reviennent ici avec leur GUID, coordonnées, ordre et action. Le tracé peut donc être reconstruit.',
  tutMissionsTitle:'Préparer les missions',tutMissionsText:'Avant publication, renseigne la description commune et vérifie chaque mission.',
  tutMissionDescTitle:'Description obligatoire',tutMissionDescText:'Cette description sert de base aux missions. BannerLab signale ce qui manque avant d’autoriser la publication.',
  tutPublishTitle:'Publier',tutPublishText:'Quand parcours et descriptions sont prêts, passe ici. Le Publisher prépare les missions ; la soumission finale reste volontairement dans l’outil officiel.',
  tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prépare les données et ouvre le flux de publication. Après soumission, utilise « J’ai soumis » pour vérifier l’état publié et poursuivre la synchro.',
  tutInfoTitle:'Réglages, aide & support',tutInfoText:'La roue Réglages & infos contient la langue, les sauvegardes, les tutoriels et l’accès au support via le bot Redacted BannerLab.',
  tutBackupTitle:'Sauvegarde complète',tutBackupText:'La sauvegarde JSON complète contient tous tes projets, réglages, images et polices. Sur Android, tu peux aussi choisir un dossier d’autosauvegarde.',
  tutPortableTitle:'Projet portable',tutPortableText:'Ici tu peux exporter, partager ou importer une seule fresque avec ses images, textes, polices, missions et parcours.',
  tutSupportTitle:'Besoin d’aide ?',tutSupportText:'Copie le diagnostic si nécessaire puis contacte le support. Le bot donne aussi accès au canal et au groupe de discussion.'
});
Object.assign(I18N.en,{
  tutorialHubTitle:'Tutorials & getting started',tutorialHubText:'Restart a guided tour whenever you want. Redacted can explain only the part you need.',tutorialOpen:'View tutorials',
  tutorialWelcomeTitle:'Welcome to Redacted BannerLab',tutorialWelcomeText:'Redacted can show you around the lab. Two minutes, a few buttons and no exam at the end.',tutorialStart:'Start the tour',tutorialLater:'Later',tutorialNever:'Do not show again',tutorialPrevious:'Previous',tutorialNext:'Next',tutorialUnderstood:'OK, got it',tutorialClose:'Close',tutorialDone:'Tutorial complete',tutorialSeen:'Seen',
  tutorialQuick:'Quick tour',tutorialQuickDesc:'The essential controls and the overall BannerLab workflow.',tutorialBanner:'Create a banner',tutorialBannerDesc:'From a project to previewing and exporting the missions.',tutorialLayers:'Images, layers & text',tutorialLayersDesc:'Background, overlaid images, layers and typography tools.',tutorialIitc:'Build the route with IITC',tutorialIitcDesc:'Install Companion, add portals and sync the route.',tutorialPublish:'Publish missions',tutorialPublishDesc:'Prepare missions, then use Publisher and Mission Authoring.',tutorialBackup:'Backups & portable projects',tutorialBackupDesc:'Back up BannerLab or share one complete banner.',
  importRolesHint:'Main background = base banner image · Layer = an additional overlaid image.',tutProjectTitle:'Your projects',tutProjectText:'Each banner lives in its own project. You can export or share it without taking every other project along.',tutNameTitle:'Project name',tutNameText:'Give your banner a recognizable name.',tutRowsTitle:'Number of rows',tutRowsText:'One row contains 6 missions. Choose the final banner height here.',tutImageTitle:'Images & layers',tutImageText:'Import the main background and additional images here. This same screen also selects, orders, hides and groups image layers.',tutBackgroundTitle:'Main background',tutBackgroundText:'For your first real image, use Main background. It replaces the base image and covers the banner.',tutExtraLayerTitle:'Add a layer',tutExtraLayerText:'A second image is a layer: it sits over the background and remains movable, resizable and hideable.',tutLayersTitle:'Manage image layers',tutLayersText:'Thumbnails show which image layer you are manipulating. Select it, reorder it, hide it or tick several images to group them.',tutTextTitle:'Text',tutTextText:'Add text, choose fonts, spacing, background, radius or import your own font.',tutPreviewTitle:'Preview',tutPreviewText:'Check every mission before export. Individual framing is already applied.',tutExportTitle:'Export',tutExportText:'When ready, BannerLab creates the 512 × 512 mission images in the correct order.',tutStudioTitle:'Full-screen studio',tutStudioText:'A more comfortable full-screen editor with side controls and large touch targets.',tutFlowTitle:'The 4 steps',tutFlowText:'Banner → Route → Missions → Publish. BannerLab follows this workflow.',tutRouteTitle:'Route',tutRouteText:'The route connects missions to real Ingress portals. IITC Companion does the map work.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion carries the active project, mission, portals, actions and walking stats into IITC.',tutInstallCompanionTitle:'Install Companion',tutInstallCompanionText:'Install or update the userscript once in IITC Mobile.',tutOpenIitcTitle:'Open IITC',tutOpenIitcText:'Open IITC from BannerLab so the project and active mission are passed to IGOR.',tutAutoRouteTitle:'Moving between missions',tutAutoRouteText:'The next mission can open automatically and reuse the previous last portal as its first portal.',tutPortalListTitle:'Your portals',tutPortalListText:'Portals return with GUID, coordinates, order and action, so the route can be reconstructed.',tutMissionsTitle:'Prepare missions',tutMissionsText:'Before publishing, provide the common description and check each mission.',tutMissionDescTitle:'Required description',tutMissionDescText:'BannerLab reports missing information before publication is allowed.',tutPublishTitle:'Publish',tutPublishText:'When routes and descriptions are ready, continue here. Final submission stays in the official tool.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepares the mission data and publication flow. After submission, use “I submitted” to verify the published state.',tutInfoTitle:'Settings, help & support',tutInfoText:'Settings & info contains language, backups, tutorials and support through the Redacted BannerLab bot.',tutBackupTitle:'Full backup',tutBackupText:'The full JSON includes all projects, settings, images and fonts. Android can also use an automatic backup folder.',tutPortableTitle:'Portable project',tutPortableText:'Export, share or import one banner with images, text, fonts, missions and route.',tutSupportTitle:'Need help?',tutSupportText:'Copy the diagnostic if needed, then contact support. The bot also links to the channel and discussion group.'
});
Object.assign(I18N.es,{
  tutorialHubTitle:'Tutoriales y primeros pasos',tutorialHubText:'Vuelve a iniciar una visita cuando quieras. Redacted puede explicar solo la parte que necesites.',tutorialOpen:'Ver tutoriales',tutorialWelcomeTitle:'Bienvenido a Redacted BannerLab',tutorialWelcomeText:'Redacted puede enseñarte el laboratorio. Dos minutos, algunos botones y ningún examen al final.',tutorialStart:'Empezar la visita',tutorialLater:'Más tarde',tutorialNever:'No volver a mostrar',tutorialPrevious:'Anterior',tutorialNext:'Siguiente',tutorialUnderstood:'OK, entendido',tutorialClose:'Cerrar',tutorialDone:'Tutorial terminado',tutorialSeen:'Visto',tutorialQuick:'Descubrimiento rápido',tutorialQuickDesc:'Los controles esenciales y el flujo general de BannerLab.',tutorialBanner:'Crear un mosaico',tutorialBannerDesc:'Desde el proyecto hasta la vista previa y exportación.',tutorialLayers:'Imágenes, capas y textos',tutorialLayersDesc:'Fondo, imágenes superpuestas, capas y tipografía.',tutorialIitc:'Crear el recorrido con IITC',tutorialIitcDesc:'Instalar Companion, añadir portales y sincronizar.',tutorialPublish:'Publicar misiones',tutorialPublishDesc:'Preparar misiones y usar Publisher.',tutorialBackup:'Copias y proyectos portátiles',tutorialBackupDesc:'Guardar BannerLab o compartir un solo mosaico completo.',importRolesHint:'Fondo principal = imagen base · Capa = imagen adicional superpuesta.',tutProjectTitle:'Tus proyectos',tutProjectText:'Cada mosaico vive en su propio proyecto y puede exportarse por separado.',tutNameTitle:'Nombre del proyecto',tutNameText:'Pon un nombre reconocible a tu mosaico.',tutRowsTitle:'Número de filas',tutRowsText:'Una fila contiene 6 misiones. Elige aquí la altura final.',tutImageTitle:'Imágenes y capas',tutImageText:'Aquí importas el fondo principal y las imágenes adicionales. Esta misma pantalla sirve para seleccionar, ordenar, ocultar y agrupar capas.',tutBackgroundTitle:'Fondo principal',tutBackgroundText:'Para tu primera imagen real, usa Fondo principal. Sustituye la imagen base.',tutExtraLayerTitle:'Añadir capa',tutExtraLayerText:'Una segunda imagen es una capa superpuesta que se puede mover, redimensionar y ocultar.',tutLayersTitle:'Gestionar capas de imagen',tutLayersText:'Las miniaturas muestran qué capa estás manipulando. Puedes seleccionarla, cambiar el orden, ocultarla o agrupar varias imágenes.',tutTextTitle:'Texto',tutTextText:'Añade texto, cambia fuentes, espaciado, fondo, radio o importa tu propia fuente.',tutPreviewTitle:'Vista previa',tutPreviewText:'Comprueba cada misión antes de exportar.',tutExportTitle:'Exportar',tutExportText:'BannerLab genera las imágenes 512 × 512 en el orden correcto.',tutStudioTitle:'Estudio a pantalla completa',tutStudioText:'Editor más cómodo con controles laterales y objetivos táctiles grandes.',tutFlowTitle:'Las 4 etapas',tutFlowText:'Mosaico → Recorrido → Misiones → Publicar.',tutRouteTitle:'Recorrido',tutRouteText:'El recorrido enlaza las misiones con portales Ingress reales.',tutCompanionTitle:'IITC Companion',tutCompanionText:'Companion lleva proyecto, misión, portales, acciones y estadísticas a IITC.',tutInstallCompanionTitle:'Instalar Companion',tutInstallCompanionText:'Instala o actualiza el plugin una vez en IITC Mobile.',tutOpenIitcTitle:'Abrir IITC',tutOpenIitcText:'Abre IITC desde BannerLab para transmitir proyecto y misión activa.',tutAutoRouteTitle:'Paso entre misiones',tutAutoRouteText:'La siguiente misión puede abrirse automáticamente y reutilizar el último portal.',tutPortalListTitle:'Tus portales',tutPortalListText:'Los portales vuelven con GUID, coordenadas, orden y acción.',tutMissionsTitle:'Preparar misiones',tutMissionsText:'Antes de publicar, completa la descripción y comprueba cada misión.',tutMissionDescTitle:'Descripción obligatoria',tutMissionDescText:'BannerLab avisa de lo que falta antes de publicar.',tutPublishTitle:'Publicar',tutPublishText:'Cuando todo esté listo, continúa aquí. El envío final se hace en la herramienta oficial.',tutPublisherExplainTitle:'Publisher',tutPublisherExplainText:'BannerLab prepara los datos y el flujo de publicación y después verifica el estado publicado.',tutInfoTitle:'Ajustes, ayuda y soporte',tutInfoText:'Ajustes e información contiene idioma, copias, tutoriales y soporte mediante el bot.',tutBackupTitle:'Copia completa',tutBackupText:'El JSON completo incluye proyectos, ajustes, imágenes y fuentes.',tutPortableTitle:'Proyecto portátil',tutPortableText:'Exporta, comparte o importa un solo mosaico completo.',tutSupportTitle:'¿Necesitas ayuda?',tutSupportText:'Copia el diagnóstico si hace falta y contacta con soporte mediante el bot.'
});

Object.assign(I18N.fr,{settingsInfo:'Réglages & infos'});
Object.assign(I18N.en,{settingsInfo:'Settings & info'});
Object.assign(I18N.es,{settingsInfo:'Ajustes e información'});

Object.assign(I18N.fr,{addMissionLayer:'Sur une mission',importMissionSeries:'Importer une série',missionLayer:'Calque de mission',globalLayer:'Calque global',layerScope:'Portée du calque',wholeBanner:'Fresque entière',missionTarget:'Mission associée',fitMode:'Ajustement',fitCover:'Remplir',fitContain:'Contenir',missionBadge:'M{n}',missionLayerHint:'Ce calque reste attaché à la mission {n} et est automatiquement limité à sa case.',missionSeriesTitle:'Importer une série de missions',missionSeriesText:'Associe chaque image à une mission. BannerLab les place et les recadre automatiquement.',missionSeriesDetected:'{n} image(s) détectée(s)',missionSeriesImport:'Importer les calques',missionSeriesTooMany:'Tu as sélectionné plus d’images que de missions. Plusieurs images peuvent être associées à la même mission.',missionLayerAdded:'Image ajoutée à la mission {n}',missionSeriesAdded:'{n} calque(s) de mission ajouté(s)',missionScopeMismatch:'Pour grouper des calques de mission, ils doivent appartenir à la même mission.',missionLayerTutorialTitle:'Calques liés aux missions',missionLayerTutorialText:'Ajoute une image directement à une mission : BannerLab la place, la recadre et la limite automatiquement à cette case. « Importer une série » permet d’affecter 6, 12, 18 images ou plus en une seule fois.'});
Object.assign(I18N.en,{addMissionLayer:'On a mission',importMissionSeries:'Import a series',missionLayer:'Mission layer',globalLayer:'Global layer',layerScope:'Layer scope',wholeBanner:'Whole banner',missionTarget:'Assigned mission',fitMode:'Fit',fitCover:'Fill',fitContain:'Contain',missionBadge:'M{n}',missionLayerHint:'This layer stays attached to mission {n} and is automatically clipped to its tile.',missionSeriesTitle:'Import a mission series',missionSeriesText:'Assign each image to a mission. BannerLab places and crops them automatically.',missionSeriesDetected:'{n} image(s) detected',missionSeriesImport:'Import layers',missionSeriesTooMany:'You selected more images than missions. Multiple images can be assigned to the same mission.',missionLayerAdded:'Image added to mission {n}',missionSeriesAdded:'{n} mission layer(s) added',missionScopeMismatch:'Mission layers can only be grouped when they belong to the same mission.',missionLayerTutorialTitle:'Mission-linked layers',missionLayerTutorialText:'Add an image directly to one mission: BannerLab places, crops and clips it automatically. “Import a series” assigns 6, 12, 18 images or more in one pass.'});
Object.assign(I18N.es,{addMissionLayer:'En una misión',importMissionSeries:'Importar una serie',missionLayer:'Capa de misión',globalLayer:'Capa global',layerScope:'Alcance de la capa',wholeBanner:'Mural completo',missionTarget:'Misión asociada',fitMode:'Ajuste',fitCover:'Rellenar',fitContain:'Contener',missionBadge:'M{n}',missionLayerHint:'Esta capa queda vinculada a la misión {n} y se limita automáticamente a su casilla.',missionSeriesTitle:'Importar una serie de misiones',missionSeriesText:'Asocia cada imagen a una misión. BannerLab las coloca y recorta automáticamente.',missionSeriesDetected:'{n} imagen(es) detectada(s)',missionSeriesImport:'Importar capas',missionSeriesTooMany:'Has seleccionado más imágenes que misiones. Se pueden asociar varias imágenes a la misma misión.',missionLayerAdded:'Imagen añadida a la misión {n}',missionSeriesAdded:'{n} capa(s) de misión añadida(s)',missionScopeMismatch:'Las capas de misión solo se pueden agrupar si pertenecen a la misma misión.',missionLayerTutorialTitle:'Capas vinculadas a misiones',missionLayerTutorialText:'Añade una imagen directamente a una misión: BannerLab la coloca, recorta y limita automáticamente a esa casilla. «Importar una serie» permite asignar 6, 12, 18 imágenes o más de una vez.'});

Object.assign(I18N.fr,{addLayerChoiceTitle:'Ajouter un calque',addLayerChoiceText:'Choisis où ce calque doit vivre. Tu pourras modifier sa portée plus tard.',addLayerWhole:'Sur la fresque complète',addLayerWholeText:'Une image libre sur toute la fresque, déplaçable et redimensionnable.',addLayerOneMission:'Sur une mission',addLayerOneMissionText:'Une image automatiquement placée et limitée à la mission choisie.',addLayerManyMissions:'Sur plusieurs missions',addLayerManyMissionsText:'Importe une série d’images et associe chacune à la mission voulue.',multiSelection:'Sélection multiple',multiSelectionHint:'Coche plusieurs calques pour leur appliquer une action commune, les grouper ou les supprimer.',selectionActions:'Actions sur la sélection',editSelection:'Modifier la sélection',deleteSelection:'Supprimer la sélection',selectedLayersCount:'{n} calque(s) sélectionné(s)',bulkScopeKeep:'Ne pas changer la portée',bulkMissionKeep:'Conserver les missions actuelles',bulkFitKeep:'Ne pas changer l’ajustement',bulkVisibility:'Visibilité',bulkVisibilityKeep:'Ne pas changer',bulkShow:'Afficher',bulkHide:'Masquer',bulkOpacityEnable:'Modifier l’opacité',applyToSelection:'Appliquer aux calques sélectionnés',selectionUpdated:'Calques sélectionnés modifiés',selectionDeleted:'Calques sélectionnés supprimés',deleteSelectionConfirm:'Supprimer définitivement {n} calque(s) sélectionné(s) ?',selectionEmpty:'Sélectionne au moins un calque.',layerScopeHelp:'Fresque complète : le calque peut couvrir toute la bannière. Une mission : il est automatiquement limité à la case choisie. Plusieurs missions : importe une série et affecte chaque image à sa mission.'});
Object.assign(I18N.en,{addLayerChoiceTitle:'Add a layer',addLayerChoiceText:'Choose where this layer belongs. You can change its scope later.',addLayerWhole:'On the whole banner',addLayerWholeText:'A free image over the whole banner, movable and resizable.',addLayerOneMission:'On one mission',addLayerOneMissionText:'An image automatically positioned and clipped to the selected mission.',addLayerManyMissions:'Across several missions',addLayerManyMissionsText:'Import a series of images and assign each one to the mission you want.',multiSelection:'Multiple selection',multiSelectionHint:'Tick several layers to apply a common action, group them or delete them.',selectionActions:'Selection actions',editSelection:'Edit selection',deleteSelection:'Delete selection',selectedLayersCount:'{n} selected layer(s)',bulkScopeKeep:'Keep current scope',bulkMissionKeep:'Keep current missions',bulkFitKeep:'Keep current fit',bulkVisibility:'Visibility',bulkVisibilityKeep:'Do not change',bulkShow:'Show',bulkHide:'Hide',bulkOpacityEnable:'Change opacity',applyToSelection:'Apply to selected layers',selectionUpdated:'Selected layers updated',selectionDeleted:'Selected layers deleted',deleteSelectionConfirm:'Permanently delete {n} selected layer(s)?',selectionEmpty:'Select at least one layer.',layerScopeHelp:'Whole banner: the layer can cover the entire banner. One mission: it is automatically clipped to the chosen mission. Several missions: import a series and assign each image to its mission.'});
Object.assign(I18N.es,{addLayerChoiceTitle:'Añadir una capa',addLayerChoiceText:'Elige dónde debe vivir esta capa. Podrás cambiar su alcance más tarde.',addLayerWhole:'En todo el mosaico',addLayerWholeText:'Una imagen libre sobre todo el mosaico, desplazable y redimensionable.',addLayerOneMission:'En una misión',addLayerOneMissionText:'Una imagen colocada automáticamente y limitada a la misión elegida.',addLayerManyMissions:'En varias misiones',addLayerManyMissionsText:'Importa una serie de imágenes y asigna cada una a la misión que quieras.',multiSelection:'Selección múltiple',multiSelectionHint:'Marca varias capas para aplicarles una acción común, agruparlas o eliminarlas.',selectionActions:'Acciones sobre la selección',editSelection:'Modificar selección',deleteSelection:'Eliminar selección',selectedLayersCount:'{n} capa(s) seleccionada(s)',bulkScopeKeep:'No cambiar el alcance',bulkMissionKeep:'Conservar las misiones actuales',bulkFitKeep:'No cambiar el ajuste',bulkVisibility:'Visibilidad',bulkVisibilityKeep:'No cambiar',bulkShow:'Mostrar',bulkHide:'Ocultar',bulkOpacityEnable:'Modificar opacidad',applyToSelection:'Aplicar a las capas seleccionadas',selectionUpdated:'Capas seleccionadas modificadas',selectionDeleted:'Capas seleccionadas eliminadas',deleteSelectionConfirm:'¿Eliminar definitivamente {n} capa(s) seleccionada(s)?',selectionEmpty:'Selecciona al menos una capa.',layerScopeHelp:'Mosaico completo: la capa puede cubrir todo el mosaico. Una misión: queda limitada automáticamente a la misión elegida. Varias misiones: importa una serie y asigna cada imagen a su misión.'});
Object.assign(I18N.fr,{missionLayerTutorialText:'Appuie sur « Ajouter un calque » puis choisis : fresque complète, une mission ou plusieurs missions. Pour une mission, BannerLab place et limite automatiquement l’image à sa case. Pour plusieurs missions, importe une série et affecte chaque image à la mission voulue.'});
Object.assign(I18N.en,{missionLayerTutorialText:'Tap “Add a layer”, then choose: whole banner, one mission or several missions. For one mission, BannerLab automatically positions and clips the image to its cell. For several missions, import a series and assign each image to the mission you want.'});
Object.assign(I18N.es,{missionLayerTutorialText:'Pulsa «Añadir una capa» y elige: mosaico completo, una misión o varias misiones. Para una misión, BannerLab coloca y limita automáticamente la imagen a su casilla. Para varias misiones, importa una serie y asigna cada imagen a la misión que quieras.'});

// Extended multilingual UI. Rare legacy/technical strings fall back to English.
I18N["pt"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Percurso","missions":"Missões","publish":"Publicar","projects":"Projetos","rows":"Linhas","image":"Imagens","text":"Texto","preview":"Pré-visualização","export":"Exportar","wholeFresco":"Banner completo","oneMission":"Uma missão","search":"Pesquisar","searchBannergress":"Procurar um banner","bannerNameSearch":"Nome / palavra-chave","citySearch":"Cidade","cityPlaceholder":"ex.: Nantes","nearMe":"Perto de mim","nearMeHint":"Usa a tua posição atual em vez de uma cidade.","searchRadius":"Raio de pesquisa","radiusHint":"Aplicado à volta da cidade ou da tua posição atual.","searchReset":"Limpar","searching":"A pesquisar…","locationChecking":"A verificar os serviços de localização…","locationGetting":"A obter a tua localização…","locationReady":"Localização obtida","locationDisabled":"Os serviços de localização estão desativados neste telefone.","locationPermissionDenied":"O BannerLab não tem permissão para usar a tua localização.","locationUnavailable":"Localização indisponível. Verifica se os serviços de localização estão ativos.","locationTimeout":"Não foi possível obter a localização a tempo. Verifica os serviços de localização.","openLocationSettings":"Ativar localização","openAppSettings":"Abrir definições da aplicação","settingsInfo":"Definições e informações","language":"Idioma","newProject":"Novo projeto","myProjects":"Os meus projetos","portableProject":"Projeto portátil","portableProjectDesc":"Exporta um único banner com imagens, camadas, textos, fontes, missões e percurso.","exportProject":"Exportar","shareProject":"Partilhar","importProject":"Importar projeto","projectExporting":"A preparar o projeto…","projectExported":"Projeto guardado","projectShared":"Projeto pronto para partilhar","projectImportSuccess":"Projeto importado","backupTitle":"Cópia de segurança e restauro","backupNow":"Criar cópia agora","backupExport":"Exportar JSON","backupImport":"Importar JSON","communityTitle":"Comunidade e suporte","communityText":"Acede à comunidade e ao suporte através do bot Redacted BannerLab.","reportProblem":"Comunicar um problema","reportProblemText":"Copia o diagnóstico técnico e contacta o suporte através do bot.","telegramOpen":"Contactar suporte","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","addBackground":"Adicionar / substituir fundo","addLayer":"Adicionar camada","layersTitle":"Imagens e camadas","layersDesc":"Gere aqui o fundo e todas as imagens sobrepostas. As miniaturas ajudam a identificar, selecionar, ocultar, reordenar ou agrupar cada camada.","addLayerChoiceTitle":"Adicionar uma camada","addLayerChoiceText":"Escolhe onde esta camada deve ficar. Podes alterar depois.","addLayerWhole":"No banner completo","addLayerWholeText":"Uma imagem livre sobre todo o banner.","addLayerOneMission":"Numa missão","addLayerOneMissionText":"Uma imagem colocada e limitada automaticamente à missão escolhida.","addLayerManyMissions":"Em várias missões","addLayerManyMissionsText":"Importa uma série de imagens e associa cada uma à missão desejada.","multiSelection":"Seleção múltipla","multiSelectionHint":"Seleciona várias camadas para aplicar uma ação comum, agrupar ou eliminar.","editSelection":"Modificar seleção","deleteSelection":"Eliminar seleção","clearGroupSelection":"Limpar seleção","group":"Agrupar","selectedLayersCount":"{n} camada(s) selecionada(s)","layerScope":"Âmbito da camada","wholeBanner":"Banner completo","missionTarget":"Missão associada","fitMode":"Ajuste","fitCover":"Preencher","fitContain":"Conter","layerOpacity":"Opacidade","visible":"Visível","hidden":"Oculto","font":"Tipo de letra","fontWeight":"Peso","fontItalic":"Itálico","letterSpacing":"Espaçamento das letras","lineHeight":"Entrelinha","textAlign":"Alinhamento","alignLeft":"Esquerda","alignCenter":"Centro","alignRight":"Direita","importFont":"Importar tipo de letra","textTypography":"Tipografia","studioTitle":"Estúdio de edição","studioLayers":"Camadas","studioTexts":"Textos","studioTools":"Ferramentas","studioMissionMode":"Missão","studioFrescoMode":"Banner","studioFullscreen":"Ecrã inteiro","studioPan":"Deslocamento","tutorialHubTitle":"Tutoriais e primeiros passos","tutorialHubText":"Reinicia uma visita guiada quando quiseres. Redacted pode explicar só a parte de que precisas.","tutorialQuick":"Visita rápida","tutorialQuickDesc":"Os controlos essenciais e o fluxo geral do BannerLab.","tutorialBanner":"Criar um banner","tutorialBannerDesc":"Do projeto à pré-visualização e exportação das missões.","tutorialLayers":"Imagens, camadas e texto","tutorialLayersDesc":"Fundo, imagens sobrepostas, camadas e ferramentas tipográficas.","tutorialIitc":"Criar o percurso com IITC","tutorialIitcDesc":"Instala o IGOR, adiciona portais e sincroniza o percurso.","tutorialPublish":"Publicar missões","tutorialPublishDesc":"Prepara as missões e usa o Publisher e Mission Authoring.","tutorialBackup":"Cópias e projetos portáteis","tutorialBackupDesc":"Guarda o BannerLab ou partilha um banner completo.","tutorialStart":"Começar a visita","tutorialLater":"Mais tarde","tutorialNever":"Não voltar a mostrar","tutorialClose":"Fechar","tutorialNext":"Seguinte","tutorialPrevious":"Anterior","tutorialUnderstood":"OK, percebi","tutorialWelcomeTitle":"Bem-vindo ao Redacted BannerLab","tutorialWelcomeText":"Redacted pode mostrar-te o laboratório. Dois minutos, alguns botões e nenhum exame no fim.","tutInfoTitle":"Definições, ajuda e suporte","tutInfoText":"Definições e informações contém idioma, cópias, tutoriais e suporte através do bot Redacted BannerLab.","tutSupportTitle":"Precisas de ajuda?","tutSupportText":"Copia o diagnóstico se necessário e contacta o suporte. O bot também dá acesso ao canal e ao grupo."});
I18N["de"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Route","missions":"Missionen","publish":"Veröffentlichen","projects":"Projekte","rows":"Reihen","image":"Bilder","text":"Text","preview":"Vorschau","export":"Exportieren","wholeFresco":"Gesamtes Banner","oneMission":"Eine Mission","search":"Suchen","searchBannergress":"Banner suchen","bannerNameSearch":"Name / Stichwort","citySearch":"Stadt","cityPlaceholder":"z. B. Nantes","nearMe":"In meiner Nähe","nearMeHint":"Verwendet deinen aktuellen Standort statt einer Stadt.","searchRadius":"Suchradius","radiusHint":"Gilt rund um die Stadt oder deinen aktuellen Standort.","searchReset":"Zurücksetzen","searching":"Suche…","locationChecking":"Standortdienste werden geprüft…","locationGetting":"Standort wird ermittelt…","locationReady":"Standort ermittelt","locationDisabled":"Die Standortdienste sind auf diesem Telefon deaktiviert.","locationPermissionDenied":"BannerLab darf deinen Standort nicht verwenden.","locationUnavailable":"Standort nicht verfügbar. Prüfe die Standortdienste.","locationTimeout":"Standort konnte nicht rechtzeitig ermittelt werden.","openLocationSettings":"Standort aktivieren","openAppSettings":"App-Einstellungen öffnen","settingsInfo":"Einstellungen & Infos","language":"Sprache","newProject":"Neues Projekt","myProjects":"Meine Projekte","portableProject":"Portables Projekt","portableProjectDesc":"Exportiere ein einzelnes Banner mit Bildern, Ebenen, Texten, Schriften, Missionen und Route.","exportProject":"Exportieren","shareProject":"Teilen","importProject":"Projekt importieren","projectExporting":"Projekt wird vorbereitet…","projectExported":"Projekt gespeichert","projectShared":"Projekt bereit zum Teilen","projectImportSuccess":"Projekt importiert","backupTitle":"Sichern & Wiederherstellen","backupNow":"Jetzt sichern","backupExport":"JSON exportieren","backupImport":"JSON importieren","communityTitle":"Community & Support","communityText":"Community und Support erreichst du direkt über den Redacted BannerLab Bot.","reportProblem":"Problem melden","reportProblemText":"Kopiere die technische Diagnose und kontaktiere den Support über den Bot.","telegramOpen":"Support kontaktieren","copyDiagnostic":"Diagnose kopieren","diagnosticCopied":"Diagnose kopiert","addBackground":"Hintergrund hinzufügen / ersetzen","addLayer":"Ebene hinzufügen","layersTitle":"Bilder & Ebenen","layersDesc":"Verwalte hier den Hintergrund und alle überlagerten Bilder. Miniaturen helfen beim Erkennen, Auswählen, Ausblenden, Sortieren oder Gruppieren.","addLayerChoiceTitle":"Ebene hinzufügen","addLayerChoiceText":"Wähle, wo diese Ebene liegen soll. Das kann später geändert werden.","addLayerWhole":"Auf dem gesamten Banner","addLayerWholeText":"Ein frei bewegliches Bild über dem gesamten Banner.","addLayerOneMission":"Auf einer Mission","addLayerOneMissionText":"Ein Bild, das automatisch auf die gewählte Mission gesetzt und begrenzt wird.","addLayerManyMissions":"Auf mehreren Missionen","addLayerManyMissionsText":"Importiere eine Bildserie und ordne jedes Bild einer Mission zu.","multiSelection":"Mehrfachauswahl","multiSelectionHint":"Wähle mehrere Ebenen für gemeinsame Aktionen, Gruppierung oder Löschen.","editSelection":"Auswahl bearbeiten","deleteSelection":"Auswahl löschen","clearGroupSelection":"Auswahl leeren","group":"Gruppieren","selectedLayersCount":"{n} Ebene(n) ausgewählt","layerScope":"Ebenenbereich","wholeBanner":"Gesamtes Banner","missionTarget":"Zugeordnete Mission","fitMode":"Anpassung","fitCover":"Füllen","fitContain":"Einpassen","layerOpacity":"Deckkraft","visible":"Sichtbar","hidden":"Ausgeblendet","font":"Schriftart","fontWeight":"Stärke","fontItalic":"Kursiv","letterSpacing":"Zeichenabstand","lineHeight":"Zeilenhöhe","textAlign":"Ausrichtung","alignLeft":"Links","alignCenter":"Mitte","alignRight":"Rechts","importFont":"Schrift importieren","textTypography":"Typografie","studioTitle":"Bearbeitungsstudio","studioLayers":"Ebenen","studioTexts":"Texte","studioTools":"Werkzeuge","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Vollbild","studioPan":"Scrollen","tutorialHubTitle":"Tutorials & Einstieg","tutorialHubText":"Starte jederzeit eine geführte Tour neu. Redacted erklärt auch nur den Teil, den du brauchst.","tutorialQuick":"Schnelltour","tutorialQuickDesc":"Die wichtigsten Bedienelemente und der BannerLab-Ablauf.","tutorialBanner":"Banner erstellen","tutorialBannerDesc":"Vom Projekt bis Vorschau und Export der Missionen.","tutorialLayers":"Bilder, Ebenen & Text","tutorialLayersDesc":"Hintergrund, überlagerte Bilder, Ebenen und Typografie.","tutorialIitc":"Route mit IITC erstellen","tutorialIitcDesc":"Companion installieren, Portale hinzufügen und Route synchronisieren.","tutorialPublish":"Missionen veröffentlichen","tutorialPublishDesc":"Missionen vorbereiten und Publisher/Mission Authoring verwenden.","tutorialBackup":"Backups & portable Projekte","tutorialBackupDesc":"BannerLab sichern oder ein vollständiges Banner teilen.","tutorialStart":"Tour starten","tutorialLater":"Später","tutorialNever":"Nicht mehr anzeigen","tutorialClose":"Schließen","tutorialNext":"Weiter","tutorialPrevious":"Zurück","tutorialUnderstood":"OK, verstanden","tutorialWelcomeTitle":"Willkommen bei Redacted BannerLab","tutorialWelcomeText":"Redacted kann dir das Labor zeigen. Zwei Minuten, ein paar Knöpfe und keine Prüfung am Ende.","tutInfoTitle":"Einstellungen, Hilfe & Support","tutInfoText":"Einstellungen & Infos enthält Sprache, Backups, Tutorials und Support über den Redacted BannerLab Bot.","tutSupportTitle":"Brauchst du Hilfe?","tutSupportText":"Kopiere bei Bedarf die Diagnose und kontaktiere den Support. Der Bot verlinkt auch Kanal und Gruppe."});
I18N["it"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Percorso","missions":"Missioni","publish":"Pubblica","projects":"Progetti","rows":"Righe","image":"Immagini","text":"Testo","preview":"Anteprima","export":"Esporta","wholeFresco":"Banner completo","oneMission":"Una missione","search":"Cerca","searchBannergress":"Cerca un banner","bannerNameSearch":"Nome / parola chiave","citySearch":"Città","cityPlaceholder":"es. Nantes","nearMe":"Vicino a me","nearMeHint":"Usa la tua posizione attuale invece di una città.","searchRadius":"Raggio di ricerca","radiusHint":"Applicato intorno alla città o alla tua posizione attuale.","searchReset":"Cancella","searching":"Ricerca…","locationChecking":"Controllo dei servizi di localizzazione…","locationGetting":"Recupero della posizione…","locationReady":"Posizione acquisita","locationDisabled":"I servizi di localizzazione sono disattivati su questo telefono.","locationPermissionDenied":"BannerLab non è autorizzato a usare la tua posizione.","locationUnavailable":"Posizione non disponibile. Controlla i servizi di localizzazione.","locationTimeout":"Impossibile acquisire la posizione in tempo.","openLocationSettings":"Attiva posizione","openAppSettings":"Apri impostazioni app","settingsInfo":"Impostazioni e info","language":"Lingua","newProject":"Nuovo progetto","myProjects":"I miei progetti","portableProject":"Progetto portatile","portableProjectDesc":"Esporta un solo banner con immagini, livelli, testi, font, missioni e percorso.","exportProject":"Esporta","shareProject":"Condividi","importProject":"Importa progetto","projectExporting":"Preparazione progetto…","projectExported":"Progetto salvato","projectShared":"Progetto pronto da condividere","projectImportSuccess":"Progetto importato","backupTitle":"Backup e ripristino","backupNow":"Esegui backup ora","backupExport":"Esporta JSON","backupImport":"Importa JSON","communityTitle":"Community e supporto","communityText":"Accedi alla community e al supporto tramite il bot Redacted BannerLab.","reportProblem":"Segnala un problema","reportProblemText":"Copia la diagnostica tecnica e contatta il supporto tramite il bot.","telegramOpen":"Contatta supporto","copyDiagnostic":"Copia diagnostica","diagnosticCopied":"Diagnostica copiata","addBackground":"Aggiungi / sostituisci sfondo","addLayer":"Aggiungi livello","layersTitle":"Immagini e livelli","layersDesc":"Gestisci qui lo sfondo e tutte le immagini sovrapposte. Le miniature aiutano a identificare, selezionare, nascondere, riordinare o raggruppare i livelli.","addLayerChoiceTitle":"Aggiungi un livello","addLayerChoiceText":"Scegli dove deve stare il livello. Potrai modificarlo in seguito.","addLayerWhole":"Su tutto il banner","addLayerWholeText":"Un’immagine libera su tutto il banner.","addLayerOneMission":"Su una missione","addLayerOneMissionText":"Un’immagine posizionata e ritagliata automaticamente sulla missione scelta.","addLayerManyMissions":"Su più missioni","addLayerManyMissionsText":"Importa una serie di immagini e assegna ciascuna alla missione desiderata.","multiSelection":"Selezione multipla","multiSelectionHint":"Seleziona più livelli per un’azione comune, raggrupparli o eliminarli.","editSelection":"Modifica selezione","deleteSelection":"Elimina selezione","clearGroupSelection":"Svuota selezione","group":"Raggruppa","selectedLayersCount":"{n} livello/i selezionato/i","layerScope":"Ambito livello","wholeBanner":"Banner completo","missionTarget":"Missione associata","fitMode":"Adattamento","fitCover":"Riempi","fitContain":"Contieni","layerOpacity":"Opacità","visible":"Visibile","hidden":"Nascosto","font":"Font","fontWeight":"Peso","fontItalic":"Corsivo","letterSpacing":"Spaziatura lettere","lineHeight":"Interlinea","textAlign":"Allineamento","alignLeft":"Sinistra","alignCenter":"Centro","alignRight":"Destra","importFont":"Importa font","textTypography":"Tipografia","studioTitle":"Studio di modifica","studioLayers":"Livelli","studioTexts":"Testi","studioTools":"Strumenti","studioMissionMode":"Missione","studioFrescoMode":"Banner","studioFullscreen":"Schermo intero","studioPan":"Scorrimento","tutorialHubTitle":"Tutorial e primi passi","tutorialHubText":"Riavvia una visita guidata quando vuoi. Redacted può spiegare solo la parte che ti serve.","tutorialQuick":"Tour rapido","tutorialQuickDesc":"I controlli essenziali e il flusso generale di BannerLab.","tutorialBanner":"Crea un banner","tutorialBannerDesc":"Dal progetto all’anteprima e all’esportazione delle missioni.","tutorialLayers":"Immagini, livelli e testo","tutorialLayersDesc":"Sfondo, immagini sovrapposte, livelli e strumenti tipografici.","tutorialIitc":"Crea il percorso con IITC","tutorialIitcDesc":"Installa Companion, aggiungi portali e sincronizza il percorso.","tutorialPublish":"Pubblica missioni","tutorialPublishDesc":"Prepara le missioni e usa Publisher e Mission Authoring.","tutorialBackup":"Backup e progetti portatili","tutorialBackupDesc":"Salva BannerLab o condividi un banner completo.","tutorialStart":"Avvia tour","tutorialLater":"Più tardi","tutorialNever":"Non mostrare più","tutorialClose":"Chiudi","tutorialNext":"Avanti","tutorialPrevious":"Indietro","tutorialUnderstood":"OK, capito","tutorialWelcomeTitle":"Benvenuto in Redacted BannerLab","tutorialWelcomeText":"Redacted può mostrarti il laboratorio. Due minuti, qualche pulsante e nessun esame alla fine.","tutInfoTitle":"Impostazioni, aiuto e supporto","tutInfoText":"Impostazioni e info contiene lingua, backup, tutorial e supporto tramite il bot Redacted BannerLab.","tutSupportTitle":"Serve aiuto?","tutSupportText":"Copia la diagnostica se necessario e contatta il supporto. Il bot collega anche canale e gruppo."});
I18N["ja"]=Object.assign({},I18N.en,{"fresco":"バナー","route":"ルート","missions":"ミッション","publish":"公開","projects":"プロジェクト","rows":"行","image":"画像","text":"テキスト","preview":"プレビュー","export":"エクスポート","wholeFresco":"バナー全体","oneMission":"1ミッション","search":"検索","searchBannergress":"バナーを検索","bannerNameSearch":"名前 / キーワード","citySearch":"都市","cityPlaceholder":"例：Nantes","nearMe":"現在地の近く","nearMeHint":"都市の代わりに現在地を使用します。","searchRadius":"検索範囲","radiusHint":"都市または現在地を中心に適用します。","searchReset":"クリア","searching":"検索中…","locationChecking":"位置情報サービスを確認中…","locationGetting":"現在地を取得中…","locationReady":"現在地を取得しました","locationDisabled":"この端末では位置情報サービスが無効です。","locationPermissionDenied":"BannerLab に位置情報の使用権限がありません。","locationUnavailable":"位置情報を取得できません。端末の位置情報サービスを確認してください。","locationTimeout":"時間内に位置情報を取得できませんでした。","openLocationSettings":"位置情報を有効にする","openAppSettings":"アプリ設定を開く","settingsInfo":"設定と情報","language":"言語","newProject":"新規プロジェクト","myProjects":"マイプロジェクト","portableProject":"ポータブルプロジェクト","portableProjectDesc":"画像、レイヤー、テキスト、フォント、ミッション、ルートを含むバナー1つをエクスポートします。","exportProject":"エクスポート","shareProject":"共有","importProject":"プロジェクトをインポート","projectExporting":"プロジェクトを準備中…","projectExported":"プロジェクトを保存しました","projectShared":"共有の準備ができました","projectImportSuccess":"プロジェクトをインポートしました","backupTitle":"バックアップと復元","backupNow":"今すぐバックアップ","backupExport":"JSONをエクスポート","backupImport":"JSONをインポート","communityTitle":"コミュニティとサポート","communityText":"Redacted BannerLab Bot からコミュニティとサポートにアクセスできます。","reportProblem":"問題を報告","reportProblemText":"技術診断をコピーして、Botからサポートに連絡してください。","telegramOpen":"サポートに連絡","copyDiagnostic":"診断をコピー","diagnosticCopied":"診断をコピーしました","addBackground":"背景を追加 / 置換","addLayer":"レイヤーを追加","layersTitle":"画像とレイヤー","layersDesc":"背景と重ねた画像をここで管理します。サムネイルでレイヤーを確認し、選択、非表示、並べ替え、グループ化できます。","addLayerChoiceTitle":"レイヤーを追加","addLayerChoiceText":"このレイヤーを配置する範囲を選びます。後から変更できます。","addLayerWhole":"バナー全体","addLayerWholeText":"バナー全体で自由に動かせる画像です。","addLayerOneMission":"1つのミッション","addLayerOneMissionText":"選択したミッションに自動配置され、その枠内に制限されます。","addLayerManyMissions":"複数ミッション","addLayerManyMissionsText":"複数画像を読み込み、それぞれをミッションに割り当てます。","multiSelection":"複数選択","multiSelectionHint":"複数レイヤーを選択して、一括編集・グループ化・削除できます。","editSelection":"選択を編集","deleteSelection":"選択を削除","clearGroupSelection":"選択を解除","group":"グループ化","selectedLayersCount":"{n} レイヤー選択中","layerScope":"レイヤー範囲","wholeBanner":"バナー全体","missionTarget":"割り当てミッション","fitMode":"フィット","fitCover":"塗りつぶす","fitContain":"全体を収める","layerOpacity":"不透明度","visible":"表示","hidden":"非表示","font":"フォント","fontWeight":"太さ","fontItalic":"斜体","letterSpacing":"文字間隔","lineHeight":"行間","textAlign":"配置","alignLeft":"左","alignCenter":"中央","alignRight":"右","importFont":"フォントをインポート","textTypography":"タイポグラフィ","studioTitle":"編集スタジオ","studioLayers":"レイヤー","studioTexts":"テキスト","studioTools":"ツール","studioMissionMode":"ミッション","studioFrescoMode":"バナー","studioFullscreen":"全画面","studioPan":"スクロール","tutorialHubTitle":"チュートリアルと使い方","tutorialHubText":"いつでもガイドを再開できます。必要な部分だけRedactedが説明します。","tutorialQuick":"クイックツアー","tutorialQuickDesc":"BannerLabの基本操作と全体の流れ。","tutorialBanner":"バナーを作成","tutorialBannerDesc":"プロジェクト作成からミッションのプレビューとエクスポートまで。","tutorialLayers":"画像・レイヤー・テキスト","tutorialLayersDesc":"背景、重ね画像、レイヤー、文字編集ツール。","tutorialIitc":"IITCでルートを作成","tutorialIitcDesc":"Companionをインストールし、ポータルを追加してルートを同期します。","tutorialPublish":"ミッションを公開","tutorialPublishDesc":"ミッションを準備し、PublisherとMission Authoringを使用します。","tutorialBackup":"バックアップとポータブルプロジェクト","tutorialBackupDesc":"BannerLab全体を保存するか、完成したバナー1つを共有します。","tutorialStart":"ツアー開始","tutorialLater":"後で","tutorialNever":"今後表示しない","tutorialClose":"閉じる","tutorialNext":"次へ","tutorialPrevious":"戻る","tutorialUnderstood":"OK、わかりました","tutorialWelcomeTitle":"Redacted BannerLabへようこそ","tutorialWelcomeText":"Redactedが研究所を案内します。2分、いくつかのボタン、最後に試験はありません。","tutInfoTitle":"設定・ヘルプ・サポート","tutInfoText":"設定と情報には、言語、バックアップ、チュートリアル、Redacted BannerLab Bot経由のサポートがあります。","tutSupportTitle":"助けが必要？","tutSupportText":"必要なら診断をコピーしてサポートに連絡してください。Botからチャンネルとグループにもアクセスできます。"});
I18N["ko"]=Object.assign({},I18N.en,{"fresco":"배너","route":"경로","missions":"미션","publish":"게시","projects":"프로젝트","rows":"행","image":"이미지","text":"텍스트","preview":"미리보기","export":"내보내기","wholeFresco":"전체 배너","oneMission":"미션 하나","search":"검색","searchBannergress":"배너 찾기","bannerNameSearch":"이름 / 키워드","citySearch":"도시","cityPlaceholder":"예: Nantes","nearMe":"내 주변","nearMeHint":"도시 대신 현재 위치를 사용합니다.","searchRadius":"검색 반경","radiusHint":"도시 또는 현재 위치를 중심으로 적용됩니다.","searchReset":"지우기","searching":"검색 중…","locationChecking":"위치 서비스를 확인하는 중…","locationGetting":"현재 위치를 가져오는 중…","locationReady":"위치를 가져왔습니다","locationDisabled":"이 휴대전화에서 위치 서비스가 꺼져 있습니다.","locationPermissionDenied":"BannerLab에 위치 사용 권한이 없습니다.","locationUnavailable":"위치를 사용할 수 없습니다. 위치 서비스를 확인하세요.","locationTimeout":"제시간에 위치를 가져오지 못했습니다.","openLocationSettings":"위치 켜기","openAppSettings":"앱 설정 열기","settingsInfo":"설정 및 정보","language":"언어","newProject":"새 프로젝트","myProjects":"내 프로젝트","portableProject":"휴대용 프로젝트","portableProjectDesc":"이미지, 레이어, 텍스트, 폰트, 미션, 경로가 포함된 배너 하나를 내보냅니다.","exportProject":"내보내기","shareProject":"공유","importProject":"프로젝트 가져오기","projectExporting":"프로젝트 준비 중…","projectExported":"프로젝트 저장됨","projectShared":"공유 준비 완료","projectImportSuccess":"프로젝트를 가져왔습니다","backupTitle":"백업 및 복원","backupNow":"지금 백업","backupExport":"JSON 내보내기","backupImport":"JSON 가져오기","communityTitle":"커뮤니티 및 지원","communityText":"Redacted BannerLab 봇을 통해 커뮤니티와 지원에 접근할 수 있습니다.","reportProblem":"문제 신고","reportProblemText":"기술 진단을 복사한 뒤 봇으로 지원팀에 문의하세요.","telegramOpen":"지원 문의","copyDiagnostic":"진단 복사","diagnosticCopied":"진단을 복사했습니다","addBackground":"배경 추가 / 교체","addLayer":"레이어 추가","layersTitle":"이미지 및 레이어","layersDesc":"배경과 겹쳐진 이미지를 관리합니다. 썸네일로 레이어를 확인하고 선택, 숨김, 순서 변경, 그룹화할 수 있습니다.","addLayerChoiceTitle":"레이어 추가","addLayerChoiceText":"이 레이어가 적용될 범위를 선택하세요. 나중에 변경할 수 있습니다.","addLayerWhole":"전체 배너","addLayerWholeText":"전체 배너에서 자유롭게 이동 가능한 이미지입니다.","addLayerOneMission":"미션 하나","addLayerOneMissionText":"선택한 미션에 자동으로 배치되고 그 칸 안으로 제한됩니다.","addLayerManyMissions":"여러 미션","addLayerManyMissionsText":"여러 이미지를 가져와 각 이미지에 미션을 지정합니다.","multiSelection":"다중 선택","multiSelectionHint":"여러 레이어를 선택해 함께 수정, 그룹화 또는 삭제할 수 있습니다.","editSelection":"선택 수정","deleteSelection":"선택 삭제","clearGroupSelection":"선택 비우기","group":"그룹화","selectedLayersCount":"{n}개 레이어 선택됨","layerScope":"레이어 범위","wholeBanner":"전체 배너","missionTarget":"연결된 미션","fitMode":"맞춤","fitCover":"채우기","fitContain":"맞추기","layerOpacity":"불투명도","visible":"표시","hidden":"숨김","font":"폰트","fontWeight":"굵기","fontItalic":"기울임","letterSpacing":"자간","lineHeight":"행간","textAlign":"정렬","alignLeft":"왼쪽","alignCenter":"가운데","alignRight":"오른쪽","importFont":"폰트 가져오기","textTypography":"타이포그래피","studioTitle":"편집 스튜디오","studioLayers":"레이어","studioTexts":"텍스트","studioTools":"도구","studioMissionMode":"미션","studioFrescoMode":"배너","studioFullscreen":"전체 화면","studioPan":"스크롤","tutorialHubTitle":"튜토리얼 및 시작하기","tutorialHubText":"언제든 가이드 투어를 다시 시작할 수 있습니다. 필요한 부분만 Redacted가 설명할 수도 있습니다.","tutorialQuick":"빠른 둘러보기","tutorialQuickDesc":"BannerLab의 핵심 조작과 전체 흐름.","tutorialBanner":"배너 만들기","tutorialBannerDesc":"프로젝트부터 미션 미리보기와 내보내기까지.","tutorialLayers":"이미지, 레이어 및 텍스트","tutorialLayersDesc":"배경, 겹친 이미지, 레이어, 타이포그래피 도구.","tutorialIitc":"IITC로 경로 만들기","tutorialIitcDesc":"Companion을 설치하고 포털을 추가한 뒤 경로를 동기화합니다.","tutorialPublish":"미션 게시","tutorialPublishDesc":"미션을 준비하고 Publisher와 Mission Authoring을 사용합니다.","tutorialBackup":"백업 및 휴대용 프로젝트","tutorialBackupDesc":"BannerLab 전체를 백업하거나 완성된 배너 하나를 공유합니다.","tutorialStart":"둘러보기 시작","tutorialLater":"나중에","tutorialNever":"다시 표시하지 않기","tutorialClose":"닫기","tutorialNext":"다음","tutorialPrevious":"이전","tutorialUnderstood":"확인, 알겠습니다","tutorialWelcomeTitle":"Redacted BannerLab에 오신 것을 환영합니다","tutorialWelcomeText":"Redacted가 연구실을 안내합니다. 2분, 몇 개의 버튼, 마지막 시험은 없습니다.","tutInfoTitle":"설정, 도움말 및 지원","tutInfoText":"설정 및 정보에는 언어, 백업, 튜토리얼, Redacted BannerLab 봇을 통한 지원이 있습니다.","tutSupportTitle":"도움이 필요한가요?","tutSupportText":"필요하면 진단을 복사하고 지원팀에 문의하세요. 봇에서 채널과 그룹에도 접근할 수 있습니다."});
I18N["zh-Hans"]=Object.assign({},I18N.en,{"fresco":"横幅","route":"路线","missions":"任务","publish":"发布","projects":"项目","rows":"行","image":"图片","text":"文字","preview":"预览","export":"导出","wholeFresco":"完整横幅","oneMission":"单个任务","search":"搜索","searchBannergress":"搜索横幅","bannerNameSearch":"名称 / 关键词","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"附近","nearMeHint":"使用当前位置而不是城市。","searchRadius":"搜索半径","radiusHint":"以城市或当前位置为中心。","searchReset":"清除","searching":"正在搜索…","locationChecking":"正在检查定位服务…","locationGetting":"正在获取当前位置…","locationReady":"已获取位置","locationDisabled":"此手机的定位服务已关闭。","locationPermissionDenied":"BannerLab 没有使用你位置的权限。","locationUnavailable":"无法获取位置，请检查定位服务。","locationTimeout":"未能及时获取位置。","openLocationSettings":"开启定位","openAppSettings":"打开应用设置","settingsInfo":"设置与信息","language":"语言","newProject":"新建项目","myProjects":"我的项目","portableProject":"便携项目","portableProjectDesc":"导出包含图片、图层、文字、字体、任务和路线的单个横幅。","exportProject":"导出","shareProject":"分享","importProject":"导入项目","projectExporting":"正在准备项目…","projectExported":"项目已保存","projectShared":"项目可分享","projectImportSuccess":"项目已导入","backupTitle":"备份与恢复","backupNow":"立即备份","backupExport":"导出 JSON","backupImport":"导入 JSON","communityTitle":"社区与支持","communityText":"通过 Redacted BannerLab 机器人访问社区和支持。","reportProblem":"报告问题","reportProblemText":"复制技术诊断，然后通过机器人联系支持。","telegramOpen":"联系支持","copyDiagnostic":"复制诊断","diagnosticCopied":"诊断已复制","addBackground":"添加 / 替换背景","addLayer":"添加图层","layersTitle":"图片与图层","layersDesc":"在这里管理背景和所有叠加图片。缩略图可以帮助识别、选择、隐藏、排序或分组图层。","addLayerChoiceTitle":"添加图层","addLayerChoiceText":"选择图层的作用范围，之后仍可修改。","addLayerWhole":"整个横幅","addLayerWholeText":"可在整个横幅上自由移动的图片。","addLayerOneMission":"单个任务","addLayerOneMissionText":"图片会自动放置并限制在所选任务格内。","addLayerManyMissions":"多个任务","addLayerManyMissionsText":"导入一组图片，并把每张图片分配给对应任务。","multiSelection":"多选","multiSelectionHint":"选择多个图层以统一修改、分组或删除。","editSelection":"编辑选择","deleteSelection":"删除选择","clearGroupSelection":"清空选择","group":"分组","selectedLayersCount":"已选择 {n} 个图层","layerScope":"图层范围","wholeBanner":"整个横幅","missionTarget":"关联任务","fitMode":"适配","fitCover":"填充","fitContain":"完整显示","layerOpacity":"不透明度","visible":"显示","hidden":"隐藏","font":"字体","fontWeight":"字重","fontItalic":"斜体","letterSpacing":"字间距","lineHeight":"行高","textAlign":"对齐","alignLeft":"左对齐","alignCenter":"居中","alignRight":"右对齐","importFont":"导入字体","textTypography":"排版","studioTitle":"编辑工作室","studioLayers":"图层","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任务","studioFrescoMode":"横幅","studioFullscreen":"全屏","studioPan":"滚动","tutorialHubTitle":"教程与入门","tutorialHubText":"随时重新开始引导。Redacted 也可以只解释你需要的部分。","tutorialQuick":"快速导览","tutorialQuickDesc":"BannerLab 的核心操作和整体流程。","tutorialBanner":"创建横幅","tutorialBannerDesc":"从项目创建到任务预览与导出。","tutorialLayers":"图片、图层与文字","tutorialLayersDesc":"背景、叠加图片、图层和排版工具。","tutorialIitc":"用 IITC 创建路线","tutorialIitcDesc":"安装 Companion、添加 Portal 并同步路线。","tutorialPublish":"发布任务","tutorialPublishDesc":"准备任务，然后使用 Publisher 和 Mission Authoring。","tutorialBackup":"备份与便携项目","tutorialBackupDesc":"备份整个 BannerLab，或分享一个完整横幅。","tutorialStart":"开始导览","tutorialLater":"稍后","tutorialNever":"不再显示","tutorialClose":"关闭","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"好的，明白了","tutorialWelcomeTitle":"欢迎使用 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以带你参观实验室。两分钟、几个按钮，最后没有考试。","tutInfoTitle":"设置、帮助与支持","tutInfoText":"设置与信息包含语言、备份、教程以及通过 Redacted BannerLab 机器人获得的支持。","tutSupportTitle":"需要帮助？","tutSupportText":"如有需要先复制诊断，再联系支持。机器人也提供频道和讨论组入口。"});
I18N["zh-Hant"]=Object.assign({},I18N.en,{"fresco":"橫幅","route":"路線","missions":"任務","publish":"發布","projects":"專案","rows":"列","image":"圖片","text":"文字","preview":"預覽","export":"匯出","wholeFresco":"完整橫幅","oneMission":"單一任務","search":"搜尋","searchBannergress":"搜尋橫幅","bannerNameSearch":"名稱 / 關鍵字","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"附近","nearMeHint":"使用目前位置而不是城市。","searchRadius":"搜尋半徑","radiusHint":"以城市或目前位置為中心。","searchReset":"清除","searching":"搜尋中…","locationChecking":"正在檢查定位服務…","locationGetting":"正在取得目前位置…","locationReady":"已取得位置","locationDisabled":"此手機的定位服務已關閉。","locationPermissionDenied":"BannerLab 沒有使用你位置的權限。","locationUnavailable":"無法取得位置，請檢查定位服務。","locationTimeout":"未能及時取得位置。","openLocationSettings":"開啟定位","openAppSettings":"開啟應用程式設定","settingsInfo":"設定與資訊","language":"語言","newProject":"新增專案","myProjects":"我的專案","portableProject":"可攜式專案","portableProjectDesc":"匯出包含圖片、圖層、文字、字型、任務和路線的單一橫幅。","exportProject":"匯出","shareProject":"分享","importProject":"匯入專案","projectExporting":"正在準備專案…","projectExported":"專案已儲存","projectShared":"專案可分享","projectImportSuccess":"專案已匯入","backupTitle":"備份與還原","backupNow":"立即備份","backupExport":"匯出 JSON","backupImport":"匯入 JSON","communityTitle":"社群與支援","communityText":"透過 Redacted BannerLab 機器人存取社群與支援。","reportProblem":"回報問題","reportProblemText":"複製技術診斷，然後透過機器人聯絡支援。","telegramOpen":"聯絡支援","copyDiagnostic":"複製診斷","diagnosticCopied":"診斷已複製","addBackground":"新增 / 取代背景","addLayer":"新增圖層","layersTitle":"圖片與圖層","layersDesc":"在這裡管理背景和所有疊加圖片。縮圖可協助辨識、選取、隱藏、排序或群組圖層。","addLayerChoiceTitle":"新增圖層","addLayerChoiceText":"選擇圖層的作用範圍，之後仍可修改。","addLayerWhole":"整個橫幅","addLayerWholeText":"可在整個橫幅上自由移動的圖片。","addLayerOneMission":"單一任務","addLayerOneMissionText":"圖片會自動放置並限制在所選任務格內。","addLayerManyMissions":"多個任務","addLayerManyMissionsText":"匯入一組圖片，並把每張圖片指派給對應任務。","multiSelection":"多選","multiSelectionHint":"選取多個圖層以統一修改、群組或刪除。","editSelection":"編輯選取","deleteSelection":"刪除選取","clearGroupSelection":"清空選取","group":"群組","selectedLayersCount":"已選取 {n} 個圖層","layerScope":"圖層範圍","wholeBanner":"整個橫幅","missionTarget":"關聯任務","fitMode":"適配","fitCover":"填滿","fitContain":"完整顯示","layerOpacity":"不透明度","visible":"顯示","hidden":"隱藏","font":"字型","fontWeight":"字重","fontItalic":"斜體","letterSpacing":"字距","lineHeight":"行高","textAlign":"對齊","alignLeft":"靠左","alignCenter":"置中","alignRight":"靠右","importFont":"匯入字型","textTypography":"排版","studioTitle":"編輯工作室","studioLayers":"圖層","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任務","studioFrescoMode":"橫幅","studioFullscreen":"全螢幕","studioPan":"捲動","tutorialHubTitle":"教學與入門","tutorialHubText":"隨時重新開始導覽。Redacted 也可以只解釋你需要的部分。","tutorialQuick":"快速導覽","tutorialQuickDesc":"BannerLab 的核心操作和整體流程。","tutorialBanner":"建立橫幅","tutorialBannerDesc":"從專案建立到任務預覽與匯出。","tutorialLayers":"圖片、圖層與文字","tutorialLayersDesc":"背景、疊加圖片、圖層與排版工具。","tutorialIitc":"用 IITC 建立路線","tutorialIitcDesc":"安裝 Companion、加入 Portal 並同步路線。","tutorialPublish":"發布任務","tutorialPublishDesc":"準備任務，然後使用 Publisher 和 Mission Authoring。","tutorialBackup":"備份與可攜式專案","tutorialBackupDesc":"備份整個 BannerLab，或分享一個完整橫幅。","tutorialStart":"開始導覽","tutorialLater":"稍後","tutorialNever":"不再顯示","tutorialClose":"關閉","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"好，我明白了","tutorialWelcomeTitle":"歡迎使用 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以帶你參觀實驗室。兩分鐘、幾個按鈕，最後沒有考試。","tutInfoTitle":"設定、說明與支援","tutInfoText":"設定與資訊包含語言、備份、教學，以及透過 Redacted BannerLab 機器人取得的支援。","tutSupportTitle":"需要幫忙？","tutSupportText":"需要時先複製診斷，再聯絡支援。機器人也提供頻道和討論群組入口。"});
I18N["yue"]=Object.assign({},I18N.en,{"fresco":"橫幅","route":"路線","missions":"任務","publish":"發佈","projects":"專案","rows":"行","image":"圖片","text":"文字","preview":"預覽","export":"匯出","wholeFresco":"成幅橫幅","oneMission":"一個任務","search":"搜尋","searchBannergress":"搵橫幅","bannerNameSearch":"名稱 / 關鍵字","citySearch":"城市","cityPlaceholder":"例如：Nantes","nearMe":"我附近","nearMeHint":"用你而家嘅位置，唔使輸入城市。","searchRadius":"搜尋範圍","radiusHint":"以城市或者你而家嘅位置做中心。","searchReset":"清除","searching":"搜尋緊…","locationChecking":"檢查緊定位服務…","locationGetting":"攞緊你嘅位置…","locationReady":"攞到位置喇","locationDisabled":"呢部電話嘅定位服務未開。","locationPermissionDenied":"BannerLab 未有權限使用你嘅位置。","locationUnavailable":"攞唔到位置，請檢查定位服務。","locationTimeout":"限時內攞唔到位置。","openLocationSettings":"開啟定位","openAppSettings":"開啟 App 設定","settingsInfo":"設定同資訊","language":"語言","newProject":"新專案","myProjects":"我嘅專案","portableProject":"便攜專案","portableProjectDesc":"匯出一幅包含圖片、圖層、文字、字型、任務同路線嘅橫幅。","exportProject":"匯出","shareProject":"分享","importProject":"匯入專案","projectExporting":"準備緊專案…","projectExported":"專案已儲存","projectShared":"專案可以分享喇","projectImportSuccess":"專案已匯入","backupTitle":"備份同還原","backupNow":"而家備份","backupExport":"匯出 JSON","backupImport":"匯入 JSON","communityTitle":"社群同支援","communityText":"經 Redacted BannerLab Bot 就可以去社群同搵支援。","reportProblem":"回報問題","reportProblemText":"複製技術診斷，再經 Bot 聯絡支援。","telegramOpen":"聯絡支援","copyDiagnostic":"複製診斷","diagnosticCopied":"診斷已複製","addBackground":"新增 / 更換背景","addLayer":"新增圖層","layersTitle":"圖片同圖層","layersDesc":"喺度管理背景同所有疊加圖片。縮圖可以幫你認清、揀選、隱藏、排序或者群組圖層。","addLayerChoiceTitle":"新增圖層","addLayerChoiceText":"揀呢個圖層要放喺邊個範圍，之後都可以改。","addLayerWhole":"成幅橫幅","addLayerWholeText":"一張可以喺成幅橫幅自由郁嘅圖片。","addLayerOneMission":"一個任務","addLayerOneMissionText":"圖片會自動放去指定任務，而且唔會走出個格。","addLayerManyMissions":"多個任務","addLayerManyMissionsText":"一次過匯入多張圖片，再逐張分配去任務。","multiSelection":"多選","multiSelectionHint":"揀多個圖層，一齊修改、群組或者刪除。","editSelection":"修改選取","deleteSelection":"刪除選取","clearGroupSelection":"清除選取","group":"群組","selectedLayersCount":"已揀 {n} 個圖層","layerScope":"圖層範圍","wholeBanner":"成幅橫幅","missionTarget":"指定任務","fitMode":"適配","fitCover":"填滿","fitContain":"完整顯示","layerOpacity":"透明度","visible":"顯示","hidden":"隱藏","font":"字型","fontWeight":"粗幼","fontItalic":"斜體","letterSpacing":"字距","lineHeight":"行距","textAlign":"對齊","alignLeft":"靠左","alignCenter":"置中","alignRight":"靠右","importFont":"匯入字型","textTypography":"排版","studioTitle":"編輯工作室","studioLayers":"圖層","studioTexts":"文字","studioTools":"工具","studioMissionMode":"任務","studioFrescoMode":"橫幅","studioFullscreen":"全螢幕","studioPan":"捲動","tutorialHubTitle":"教學同入門","tutorialHubText":"想幾時再睇導覽都得。Redacted 亦可以淨係講你需要嗰部分。","tutorialQuick":"快速導覽","tutorialQuickDesc":"BannerLab 最基本嘅操作同整體流程。","tutorialBanner":"整橫幅","tutorialBannerDesc":"由專案開始，到預覽同匯出任務。","tutorialLayers":"圖片、圖層同文字","tutorialLayersDesc":"背景、疊加圖片、圖層同文字工具。","tutorialIitc":"用 IITC 整路線","tutorialIitcDesc":"裝 Companion、加 Portal，再同步路線。","tutorialPublish":"發佈任務","tutorialPublishDesc":"準備好任務，再用 Publisher 同 Mission Authoring。","tutorialBackup":"備份同便攜專案","tutorialBackupDesc":"備份成個 BannerLab，或者分享一幅完整橫幅。","tutorialStart":"開始導覽","tutorialLater":"遲啲先","tutorialNever":"唔好再顯示","tutorialClose":"關閉","tutorialNext":"下一步","tutorialPrevious":"上一步","tutorialUnderstood":"OK，明喇","tutorialWelcomeTitle":"歡迎嚟到 Redacted BannerLab","tutorialWelcomeText":"Redacted 可以帶你行下個實驗室。兩分鐘、幾個掣，最後唔使考試。","tutInfoTitle":"設定、幫助同支援","tutInfoText":"設定同資訊入面有語言、備份、教學，同埋經 Redacted BannerLab Bot 嘅支援。","tutSupportTitle":"要幫手？","tutSupportText":"有需要就先複製診斷，再聯絡支援。Bot 亦可以帶你去頻道同討論群組。"});
I18N["ar"]=Object.assign({},I18N.en,{"fresco":"اللافتة","route":"المسار","missions":"المهمات","publish":"نشر","projects":"المشاريع","rows":"الصفوف","image":"الصور","text":"النص","preview":"معاينة","export":"تصدير","wholeFresco":"اللافتة كاملة","oneMission":"مهمة واحدة","search":"بحث","searchBannergress":"البحث عن لافتة","bannerNameSearch":"الاسم / كلمة مفتاحية","citySearch":"المدينة","cityPlaceholder":"مثال: Nantes","nearMe":"بالقرب مني","nearMeHint":"استخدم موقعك الحالي بدلاً من مدينة.","searchRadius":"نطاق البحث","radiusHint":"يُطبّق حول المدينة أو موقعك الحالي.","searchReset":"مسح","searching":"جارٍ البحث…","locationChecking":"جارٍ التحقق من خدمات الموقع…","locationGetting":"جارٍ الحصول على موقعك…","locationReady":"تم الحصول على الموقع","locationDisabled":"خدمات الموقع معطلة على هذا الهاتف.","locationPermissionDenied":"لا يملك BannerLab إذن استخدام موقعك.","locationUnavailable":"الموقع غير متاح. تحقق من خدمات الموقع.","locationTimeout":"تعذر الحصول على الموقع في الوقت المحدد.","openLocationSettings":"تفعيل الموقع","openAppSettings":"فتح إعدادات التطبيق","settingsInfo":"الإعدادات والمعلومات","language":"اللغة","newProject":"مشروع جديد","myProjects":"مشاريعي","portableProject":"مشروع محمول","portableProjectDesc":"صدّر لافتة واحدة مع الصور والطبقات والنصوص والخطوط والمهمات والمسار.","exportProject":"تصدير","shareProject":"مشاركة","importProject":"استيراد مشروع","projectExporting":"جارٍ تجهيز المشروع…","projectExported":"تم حفظ المشروع","projectShared":"المشروع جاهز للمشاركة","projectImportSuccess":"تم استيراد المشروع","backupTitle":"النسخ الاحتياطي والاستعادة","backupNow":"نسخ احتياطي الآن","backupExport":"تصدير JSON","backupImport":"استيراد JSON","communityTitle":"المجتمع والدعم","communityText":"ادخل إلى المجتمع والدعم مباشرة عبر بوت Redacted BannerLab.","reportProblem":"الإبلاغ عن مشكلة","reportProblemText":"انسخ التشخيص التقني ثم تواصل مع الدعم عبر البوت.","telegramOpen":"التواصل مع الدعم","copyDiagnostic":"نسخ التشخيص","diagnosticCopied":"تم نسخ التشخيص","addBackground":"إضافة / استبدال الخلفية","addLayer":"إضافة طبقة","layersTitle":"الصور والطبقات","layersDesc":"أدر الخلفية وكل الصور المتراكبة هنا. تساعد الصور المصغرة على تحديد الطبقة واختيارها وإخفائها وترتيبها أو تجميعها.","addLayerChoiceTitle":"إضافة طبقة","addLayerChoiceText":"اختر أين يجب أن تعمل هذه الطبقة. يمكنك تغيير ذلك لاحقاً.","addLayerWhole":"على اللافتة كاملة","addLayerWholeText":"صورة حرة فوق اللافتة كاملة.","addLayerOneMission":"على مهمة واحدة","addLayerOneMissionText":"صورة توضع تلقائياً وتُقص داخل المهمة المختارة.","addLayerManyMissions":"على عدة مهمات","addLayerManyMissionsText":"استورد سلسلة صور واربط كل صورة بالمهمة المطلوبة.","multiSelection":"تحديد متعدد","multiSelectionHint":"حدد عدة طبقات لتعديلها معاً أو تجميعها أو حذفها.","editSelection":"تعديل التحديد","deleteSelection":"حذف التحديد","clearGroupSelection":"مسح التحديد","group":"تجميع","selectedLayersCount":"تم تحديد {n} طبقة","layerScope":"نطاق الطبقة","wholeBanner":"اللافتة كاملة","missionTarget":"المهمة المرتبطة","fitMode":"الملاءمة","fitCover":"ملء","fitContain":"احتواء","layerOpacity":"الشفافية","visible":"ظاهر","hidden":"مخفي","font":"الخط","fontWeight":"السُمك","fontItalic":"مائل","letterSpacing":"تباعد الحروف","lineHeight":"ارتفاع السطر","textAlign":"المحاذاة","alignLeft":"يسار","alignCenter":"وسط","alignRight":"يمين","importFont":"استيراد خط","textTypography":"الطباعة","studioTitle":"استوديو التحرير","studioLayers":"الطبقات","studioTexts":"النصوص","studioTools":"الأدوات","studioMissionMode":"مهمة","studioFrescoMode":"لافتة","studioFullscreen":"ملء الشاشة","studioPan":"تمرير","tutorialHubTitle":"الدروس والبدء","tutorialHubText":"أعد تشغيل الجولة الإرشادية متى شئت. يمكن لـ Redacted شرح الجزء الذي تحتاجه فقط.","tutorialQuick":"جولة سريعة","tutorialQuickDesc":"أهم عناصر التحكم ومسار العمل العام في BannerLab.","tutorialBanner":"إنشاء لافتة","tutorialBannerDesc":"من المشروع إلى معاينة المهمات وتصديرها.","tutorialLayers":"الصور والطبقات والنص","tutorialLayersDesc":"الخلفية والصور المتراكبة والطبقات وأدوات الكتابة.","tutorialIitc":"إنشاء المسار باستخدام IITC","tutorialIitcDesc":"ثبّت Companion وأضف البوابات ثم زامن المسار.","tutorialPublish":"نشر المهمات","tutorialPublishDesc":"جهّز المهمات ثم استخدم Publisher وMission Authoring.","tutorialBackup":"النسخ الاحتياطية والمشاريع المحمولة","tutorialBackupDesc":"انسخ BannerLab احتياطياً أو شارك لافتة كاملة.","tutorialStart":"بدء الجولة","tutorialLater":"لاحقاً","tutorialNever":"عدم الإظهار مجدداً","tutorialClose":"إغلاق","tutorialNext":"التالي","tutorialPrevious":"السابق","tutorialUnderstood":"حسناً، فهمت","tutorialWelcomeTitle":"مرحباً بك في Redacted BannerLab","tutorialWelcomeText":"يمكن لـ Redacted أن يأخذك في جولة داخل المختبر. دقيقتان، بضعة أزرار، ولا اختبار في النهاية.","tutInfoTitle":"الإعدادات والمساعدة والدعم","tutInfoText":"تحتوي الإعدادات والمعلومات على اللغة والنسخ الاحتياطية والدروس والدعم عبر بوت Redacted BannerLab.","tutSupportTitle":"تحتاج مساعدة؟","tutSupportText":"انسخ التشخيص عند الحاجة ثم تواصل مع الدعم. يوفر البوت أيضاً روابط القناة والمجموعة."});
I18N["id"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Rute","missions":"Misi","publish":"Publikasikan","projects":"Proyek","rows":"Baris","image":"Gambar","text":"Teks","preview":"Pratinjau","export":"Ekspor","wholeFresco":"Seluruh banner","oneMission":"Satu misi","search":"Cari","searchBannergress":"Cari banner","bannerNameSearch":"Nama / kata kunci","citySearch":"Kota","cityPlaceholder":"mis. Nantes","nearMe":"Di dekat saya","nearMeHint":"Gunakan lokasi saat ini, bukan kota.","searchRadius":"Radius pencarian","radiusHint":"Diterapkan di sekitar kota atau lokasi saat ini.","searchReset":"Hapus","searching":"Mencari…","locationChecking":"Memeriksa layanan lokasi…","locationGetting":"Mengambil lokasi…","locationReady":"Lokasi diperoleh","locationDisabled":"Layanan lokasi dinonaktifkan di ponsel ini.","locationPermissionDenied":"BannerLab tidak diizinkan menggunakan lokasi Anda.","locationUnavailable":"Lokasi tidak tersedia. Periksa layanan lokasi.","locationTimeout":"Lokasi tidak dapat diperoleh tepat waktu.","openLocationSettings":"Aktifkan lokasi","openAppSettings":"Buka setelan aplikasi","settingsInfo":"Setelan & info","language":"Bahasa","newProject":"Proyek baru","myProjects":"Proyek saya","portableProject":"Proyek portabel","portableProjectDesc":"Ekspor satu banner dengan gambar, layer, teks, font, misi, dan rute.","exportProject":"Ekspor","shareProject":"Bagikan","importProject":"Impor proyek","projectExporting":"Menyiapkan proyek…","projectExported":"Proyek disimpan","projectShared":"Proyek siap dibagikan","projectImportSuccess":"Proyek diimpor","backupTitle":"Cadangkan & pulihkan","backupNow":"Cadangkan sekarang","backupExport":"Ekspor JSON","backupImport":"Impor JSON","communityTitle":"Komunitas & dukungan","communityText":"Akses komunitas dan dukungan melalui bot Redacted BannerLab.","reportProblem":"Laporkan masalah","reportProblemText":"Salin diagnosis teknis lalu hubungi dukungan melalui bot.","telegramOpen":"Hubungi dukungan","copyDiagnostic":"Salin diagnosis","diagnosticCopied":"Diagnosis disalin","addBackground":"Tambah / ganti latar","addLayer":"Tambah layer","layersTitle":"Gambar & layer","layersDesc":"Kelola latar dan semua gambar bertumpuk di sini. Thumbnail membantu mengenali, memilih, menyembunyikan, mengurutkan, atau mengelompokkan layer.","addLayerChoiceTitle":"Tambah layer","addLayerChoiceText":"Pilih di mana layer ini berlaku. Anda dapat mengubahnya nanti.","addLayerWhole":"Di seluruh banner","addLayerWholeText":"Gambar bebas di seluruh banner.","addLayerOneMission":"Pada satu misi","addLayerOneMissionText":"Gambar otomatis ditempatkan dan dibatasi pada misi yang dipilih.","addLayerManyMissions":"Pada beberapa misi","addLayerManyMissionsText":"Impor serangkaian gambar dan tetapkan masing-masing ke misi.","multiSelection":"Pilihan ganda","multiSelectionHint":"Pilih beberapa layer untuk tindakan bersama, kelompokkan, atau hapus.","editSelection":"Edit pilihan","deleteSelection":"Hapus pilihan","clearGroupSelection":"Kosongkan pilihan","group":"Kelompokkan","selectedLayersCount":"{n} layer dipilih","layerScope":"Cakupan layer","wholeBanner":"Seluruh banner","missionTarget":"Misi terkait","fitMode":"Penyesuaian","fitCover":"Isi","fitContain":"Muat","layerOpacity":"Opasitas","visible":"Terlihat","hidden":"Tersembunyi","font":"Font","fontWeight":"Ketebalan","fontItalic":"Miring","letterSpacing":"Jarak huruf","lineHeight":"Jarak baris","textAlign":"Perataan","alignLeft":"Kiri","alignCenter":"Tengah","alignRight":"Kanan","importFont":"Impor font","textTypography":"Tipografi","studioTitle":"Studio pengeditan","studioLayers":"Layer","studioTexts":"Teks","studioTools":"Alat","studioMissionMode":"Misi","studioFrescoMode":"Banner","studioFullscreen":"Layar penuh","studioPan":"Gulir","tutorialHubTitle":"Tutorial & mulai","tutorialHubText":"Mulai ulang tur kapan saja. Redacted dapat menjelaskan hanya bagian yang Anda perlukan.","tutorialQuick":"Tur cepat","tutorialQuickDesc":"Kontrol penting dan alur BannerLab secara umum.","tutorialBanner":"Buat banner","tutorialBannerDesc":"Dari proyek hingga pratinjau dan ekspor misi.","tutorialLayers":"Gambar, layer & teks","tutorialLayersDesc":"Latar, gambar bertumpuk, layer, dan alat tipografi.","tutorialIitc":"Buat rute dengan IITC","tutorialIitcDesc":"Pasang Companion, tambahkan portal, dan sinkronkan rute.","tutorialPublish":"Publikasikan misi","tutorialPublishDesc":"Siapkan misi lalu gunakan Publisher dan Mission Authoring.","tutorialBackup":"Cadangan & proyek portabel","tutorialBackupDesc":"Cadangkan BannerLab atau bagikan satu banner lengkap.","tutorialStart":"Mulai tur","tutorialLater":"Nanti","tutorialNever":"Jangan tampilkan lagi","tutorialClose":"Tutup","tutorialNext":"Berikutnya","tutorialPrevious":"Sebelumnya","tutorialUnderstood":"OK, paham","tutorialWelcomeTitle":"Selamat datang di Redacted BannerLab","tutorialWelcomeText":"Redacted dapat mengajak Anda berkeliling lab. Dua menit, beberapa tombol, dan tidak ada ujian di akhir.","tutInfoTitle":"Setelan, bantuan & dukungan","tutInfoText":"Setelan & info berisi bahasa, cadangan, tutorial, dan dukungan melalui bot Redacted BannerLab.","tutSupportTitle":"Butuh bantuan?","tutSupportText":"Salin diagnosis bila perlu lalu hubungi dukungan. Bot juga menyediakan tautan ke kanal dan grup."});
I18N["nl"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Route","missions":"Missies","publish":"Publiceren","projects":"Projecten","rows":"Rijen","image":"Afbeeldingen","text":"Tekst","preview":"Voorbeeld","export":"Exporteren","settingsInfo":"Instellingen & info","language":"Taal","newProject":"Nieuw project","myProjects":"Mijn projecten","search":"Zoeken","searchBannergress":"Banner zoeken","citySearch":"Stad","nearMe":"In mijn buurt","searchRadius":"Zoekstraal","addBackground":"Achtergrond toevoegen / vervangen","addLayer":"Laag toevoegen","layersTitle":"Afbeeldingen & lagen","multiSelection":"Meervoudige selectie","editSelection":"Selectie wijzigen","deleteSelection":"Selectie verwijderen","group":"Groeperen","communityTitle":"Community & support","telegramOpen":"Support contacteren","tutorialHubTitle":"Tutorials & aan de slag","tutorialStart":"Start rondleiding","tutorialLater":"Later","tutorialNever":"Niet meer tonen","tutorialNext":"Volgende","tutorialPrevious":"Vorige","tutorialUnderstood":"OK, begrepen"});
I18N["pl"]=Object.assign({},I18N.en,{"fresco":"Baner","route":"Trasa","missions":"Misje","publish":"Publikuj","projects":"Projekty","rows":"Wiersze","image":"Obrazy","text":"Tekst","preview":"Podgląd","export":"Eksportuj","settingsInfo":"Ustawienia i informacje","language":"Język","newProject":"Nowy projekt","myProjects":"Moje projekty","search":"Szukaj","searchBannergress":"Znajdź baner","citySearch":"Miasto","nearMe":"W pobliżu","searchRadius":"Promień wyszukiwania","addBackground":"Dodaj / zmień tło","addLayer":"Dodaj warstwę","layersTitle":"Obrazy i warstwy","multiSelection":"Wybór wielu","editSelection":"Edytuj zaznaczenie","deleteSelection":"Usuń zaznaczenie","group":"Grupuj","communityTitle":"Społeczność i wsparcie","telegramOpen":"Kontakt ze wsparciem","tutorialHubTitle":"Samouczki i pierwsze kroki","tutorialStart":"Rozpocznij przewodnik","tutorialLater":"Później","tutorialNever":"Nie pokazuj ponownie","tutorialNext":"Dalej","tutorialPrevious":"Wstecz","tutorialUnderstood":"OK, rozumiem"});
I18N["cs"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Trasa","missions":"Mise","publish":"Publikovat","projects":"Projekty","rows":"Řádky","image":"Obrázky","text":"Text","preview":"Náhled","export":"Exportovat","settingsInfo":"Nastavení a informace","language":"Jazyk","newProject":"Nový projekt","myProjects":"Moje projekty","search":"Hledat","searchBannergress":"Najít banner","citySearch":"Město","nearMe":"V mém okolí","searchRadius":"Poloměr hledání","addBackground":"Přidat / nahradit pozadí","addLayer":"Přidat vrstvu","layersTitle":"Obrázky a vrstvy","multiSelection":"Vícenásobný výběr","editSelection":"Upravit výběr","deleteSelection":"Smazat výběr","group":"Seskupit","communityTitle":"Komunita a podpora","telegramOpen":"Kontaktovat podporu","tutorialHubTitle":"Návody a začínáme","tutorialStart":"Spustit prohlídku","tutorialLater":"Později","tutorialNever":"Už nezobrazovat","tutorialNext":"Další","tutorialPrevious":"Předchozí","tutorialUnderstood":"OK, chápu"});
I18N["ro"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Traseu","missions":"Misiuni","publish":"Publică","projects":"Proiecte","rows":"Rânduri","image":"Imagini","text":"Text","preview":"Previzualizare","export":"Exportă","settingsInfo":"Setări și informații","language":"Limbă","newProject":"Proiect nou","myProjects":"Proiectele mele","search":"Caută","searchBannergress":"Caută un banner","citySearch":"Oraș","nearMe":"În apropiere","searchRadius":"Rază de căutare","addBackground":"Adaugă / înlocuiește fundalul","addLayer":"Adaugă strat","layersTitle":"Imagini și straturi","multiSelection":"Selecție multiplă","editSelection":"Modifică selecția","deleteSelection":"Șterge selecția","group":"Grupează","communityTitle":"Comunitate și suport","telegramOpen":"Contactează suportul","tutorialHubTitle":"Tutoriale și început","tutorialStart":"Pornește turul","tutorialLater":"Mai târziu","tutorialNever":"Nu mai afișa","tutorialNext":"Următorul","tutorialPrevious":"Anterior","tutorialUnderstood":"OK, am înțeles"});
I18N["tr"]=Object.assign({},I18N.en,{"fresco":"Banner","route":"Rota","missions":"Görevler","publish":"Yayınla","projects":"Projeler","rows":"Satırlar","image":"Görseller","text":"Metin","preview":"Önizleme","export":"Dışa aktar","settingsInfo":"Ayarlar ve bilgi","language":"Dil","newProject":"Yeni proje","myProjects":"Projelerim","search":"Ara","searchBannergress":"Banner ara","citySearch":"Şehir","nearMe":"Yakınımda","searchRadius":"Arama yarıçapı","addBackground":"Arka plan ekle / değiştir","addLayer":"Katman ekle","layersTitle":"Görseller ve katmanlar","multiSelection":"Çoklu seçim","editSelection":"Seçimi düzenle","deleteSelection":"Seçimi sil","group":"Grupla","communityTitle":"Topluluk ve destek","telegramOpen":"Destekle iletişim","tutorialHubTitle":"Eğitimler ve başlangıç","tutorialStart":"Turu başlat","tutorialLater":"Daha sonra","tutorialNever":"Bir daha gösterme","tutorialNext":"İleri","tutorialPrevious":"Geri","tutorialUnderstood":"Tamam, anladım"});
I18N["ru"]=Object.assign({},I18N.en,{"fresco":"Баннер","route":"Маршрут","missions":"Миссии","publish":"Опубликовать","projects":"Проекты","rows":"Ряды","image":"Изображения","text":"Текст","preview":"Предпросмотр","export":"Экспорт","settingsInfo":"Настройки и информация","language":"Язык","newProject":"Новый проект","myProjects":"Мои проекты","search":"Поиск","searchBannergress":"Найти баннер","citySearch":"Город","nearMe":"Рядом со мной","searchRadius":"Радиус поиска","addBackground":"Добавить / заменить фон","addLayer":"Добавить слой","layersTitle":"Изображения и слои","multiSelection":"Множественный выбор","editSelection":"Изменить выбор","deleteSelection":"Удалить выбранное","group":"Сгруппировать","communityTitle":"Сообщество и поддержка","telegramOpen":"Связаться с поддержкой","tutorialHubTitle":"Обучение и начало работы","tutorialStart":"Начать тур","tutorialLater":"Позже","tutorialNever":"Больше не показывать","tutorialNext":"Далее","tutorialPrevious":"Назад","tutorialUnderstood":"ОК, понятно"});
I18N["uk"]=Object.assign({},I18N.en,{"fresco":"Банер","route":"Маршрут","missions":"Місії","publish":"Опублікувати","projects":"Проєкти","rows":"Ряди","image":"Зображення","text":"Текст","preview":"Попередній перегляд","export":"Експорт","settingsInfo":"Налаштування та інформація","language":"Мова","newProject":"Новий проєкт","myProjects":"Мої проєкти","search":"Пошук","searchBannergress":"Знайти банер","citySearch":"Місто","nearMe":"Поруч зі мною","searchRadius":"Радіус пошуку","addBackground":"Додати / замінити фон","addLayer":"Додати шар","layersTitle":"Зображення та шари","multiSelection":"Множинний вибір","editSelection":"Змінити вибір","deleteSelection":"Видалити вибране","group":"Згрупувати","communityTitle":"Спільнота та підтримка","telegramOpen":"Зв’язатися з підтримкою","tutorialHubTitle":"Навчання та початок роботи","tutorialStart":"Почати тур","tutorialLater":"Пізніше","tutorialNever":"Більше не показувати","tutorialNext":"Далі","tutorialPrevious":"Назад","tutorialUnderstood":"Гаразд, зрозуміло"});


/* v1.0.11-r2 — traductions complètes sans fallback anglais pour DE/PT/NL */
I18N["de"]={"fresco":"Banner","route":"Route","missions":"Missionen","publish":"Veröffentlichen","projects":"Projekte","rows":"Reihen","image":"Bilder","framing":"Ausschnitt","layers":"Ebenen","text":"Text","preview":"Vorschau","export":"Exportieren","wholeFresco":"Gesamter Banner","oneMission":"Eine Mission","noMission":"Keine Mission ausgewählt","addImage":"Bild hinzufügen","imageHint":"Das Bild wird direkt an die Prime-Geometrie angepasst.","circles":"Prime-Kreise","grid":"512er-Raster","numbers":"Nummern","enlarge":"Mission vergrößern","resetMission":"Mission zurücksetzen","prev":"Zurück","next":"Weiter","complete":"Mission vollständig","remaining":"Noch {n} Portal(e)","openIitc":"IITC Companion öffnen","tutorial":"Tutorial","installPlugin":"IITC-Plugin installieren / aktualisieren","autoAdvance":"Bei {n} Portalen automatisch zur nächsten Mission wechseln","reuseLast":"Das letzte Portal automatisch als erstes Portal der nächsten Mission übernehmen","noPortal":"Diese Mission enthält noch kein Portal.","action":"Aktion","hack":"Hacken","mod":"Mod installieren","capture":"Erobern / verbessern","link":"Link erstellen","field":"Feld erstellen","passphrase":"Passphrase","question":"Frage","answer":"Erwartete Antwort","save":"Speichern","cancel":"Abbrechen","settings":"Gemeinsame Einstellungen","commonDesc":"Gemeinsame Beschreibung","titleFormat":"Titelformat","defaultType":"Standardtyp","location":"Standort","visible":"Sichtbar","hidden":"Ausgeblendet","sequential":"Nacheinander","anyOrder":"Beliebige Reihenfolge","portalsPerMission":"Portale / Mission","editMission":"Mission bearbeiten","title":"Titel","description":"Beschreibung","missionReady":"Bereit","missionIncomplete":"Unvollständig","openRoute":"Route bearbeiten","publishPack":"BannerLab-Paket erstellen","openMat":"Mission Authoring Tool öffnen","ownWorkflow":"BannerLab verwendet jetzt sein eigenes Projektformat und ein eigenes Veröffentlichungspaket.","language":"Sprache","french":"Français","english":"English","spanish":"Español","companionStats":"Fußweg-Statistiken in IITC","companionStatsDesc":"Im IITC-Minifenster berechnet 📊 Nutzlose Statistiken geschätzte Gehstrecke, Zeit, Umweg und andere Dinge, nach denen niemand gefragt hat.","duplicateBad":"{n} Portal-Wiederverwendung(en) prüfen.","handoverOk":"Die Wiederverwendung vom Missionsende zum Start der nächsten Mission ist erlaubt.","pluginVersion":"IGOR 0.6.35","undo":"Rückgängig","redo":"Wiederholen","subtitle":"Ingress-Prime-Banner","source":"Quelle","bannerHelp":"<b>Banner-Modus:</b> Mit 1 Finger verschiebst du die ausgewählte Ebene. Mit <b>2 Fingern</b> zoomst und drehst du.","missionHelp":"<b>Missionsmodus:</b> Tippe auf ein Medaillon. Für bequemes Bearbeiten nutze <b>Mission vergrößern</b>. Du kannst sie hier auch mit 1 Finger verschieben.","missionSelected":"Mission {n} ausgewählt","tapMedallion":"Tippe auf ein Medaillon","touchMissionFirst":"Tippe zuerst auf die Mission, deren Ausschnitt du ändern möchtest.","selectMissionFirst":"Wähle zuerst eine Mission aus.","heavyImage":"Sehr großes Bild. Dein Telefon könnte dabei seine Lebensentscheidungen überdenken.","imported":"{w} × {h} px importiert","textLayerDesc":"Jeder Text bleibt eine eigene Ebene und kann separat bearbeitet oder gelöscht werden.","layer":"Ebene","newText":"+ Neuer Text","size":"Größe","outline":"Kontur","color":"Farbe","outlineColor":"Konturfarbe","add":"Hinzufügen","update":"Aktualisieren","delete":"Löschen","zoom":"Zoom","localZoom":"Lokaler Zoom","rotation":"Drehung","center":"Zentrieren","reset":"Zurücksetzen","done":"Fertig","transformText":"Text transformieren","frameImage":"Bild ausrichten","pinchHint":"Die Zwei-Finger-Geste funktioniert weiterhin direkt auf dem Banner.","missionCropOnly":"Dieser Ausschnitt gilt nur für dieses Medaillon.","resetThisMission":"Diese Mission zurücksetzen","individualCrop":"Individueller Ausschnitt · 512 × 512","oneFinger":"1 Finger","move":"verschieben","twoFingers":"2 Finger","zoomRotate":"zoomen und drehen","previewPrime":"Prime-Vorschau","previewApplied":"Individuelle Missionsausschnitte sind bereits berücksichtigt.","previewOrder":"Nummer 1 liegt unten rechts. Danach läuft die Nummerierung nach links und über die oberen Reihen weiter.","exportTitle":"{n} Missionen exportieren","exportIntro":"Wähle schnelle Ausgabe oder verlustfreies PNG. Beide bleiben bei 512 × 512.","noBackground":"Kein Hintergrundbild geladen.","missionFormat":"Missionsformat","jpgFast":"Schnelles JPG · hohe Qualität","pngLossless":"Verlustfreies PNG · langsamer","fastEncoding":"Der Schnellmodus vermeidet die PNG-Kodierung, die auf dem Telefon mit Abstand am längsten dauert.","rowRender":"Der Hintergrund wird pro Reihe nur einmal gerendert statt sechsmal neu berechnet.","adjusted":"{n} Mission(en) mit individuellem Ausschnitt.","nianticCheck":"Prüfe vor dem Einreichen die Niantic-Regeln: Bildrechte, passender Inhalt und keine einzelne dominante Figur.","ready":"Bereit.","createZip":"ZIP erstellen","zipAssembly":"ZIP wird erstellt…","zipCreated":"ZIP erstellt.","zipDownloaded":"ZIP heruntergeladen.","saveShareZip":"ZIP speichern oder teilen","exportFinished":"{format}-Export abgeschlossen","exportFailed":"Export fehlgeschlagen.","newProject":"Neues Projekt","myProjects":"Meine Projekte","projectsSaved":"{n} Projekt(e) auf diesem Gerät gespeichert.","unnamed":"Unbenannt","opened":"Geöffnet","open":"Öffnen","rename":"Umbenennen","copy":"Kopieren","noSavedProject":"Kein gespeichertes Projekt.","renameProject":"Projekt umbenennen","renameHint":"Ein Name, den ein Mensch später wiedererkennt. Revolutionäres Konzept.","projectName":"Projektname","projectOpened":"Projekt geöffnet: {name}","projectRenamed":"Projekt umbenannt","deleteProject":"Dieses Projekt löschen?","deleteWarning":"Der Banner und das lokal gespeicherte Bild werden gelöscht.","copyCreated":"Kopie erstellt","projectDeleted":"Projekt gelöscht","newProjectCreated":"Neues Projekt mit Redacted erstellt","defaultProject":"Mein Banner","defaultNewProject":"Neuer Banner","copySuffix":"Kopie","versionLabel":"Version","infoPrime":"6 Spalten · 544 px · 512-px-Ausschnitt.","infoPlanner":"Portalaktionen, Passphrases, Übergabe Ende→Start und natives BannerLab-Paket.","infoCompanion":"Routen, Aktionen, Missions-übergreifende Linien, Optionen und Gehstatistiken.","disclaimer":"Ingress und Ingress Prime sind Marken von Niantic. Redacted BannerLab ist weder mit Niantic verbunden noch von Niantic unterstützt.","titleTokens":"$T = Name · $N = Nummer · $M = Gesamt · $0N = 01, 02…","pluginShareText":"Companion-Plugin 0.6.9. Ersetze in IITC Mobile die vorherige Version. Falls IITC das Überschreiben verweigert, entferne das alte Plugin einmal und installiere anschließend diese Datei.","pluginDialog":"IGOR 0.6.35 installieren / aktualisieren","pluginShareFailed":"Das IITC-Plugin konnte nicht geteilt werden.","intelOpened":"IITC Mobile mit dem BannerLab-Projekt geöffnet.","intelPrimeOpened":"IITC Prime mit dem BannerLab-Projekt geöffnet.","intelFallback":"IITC Mobile wurde geöffnet. Companion verwendet den zuletzt synchronisierten Stand.","intelPrimeFallback":"IITC Prime wurde geöffnet. Companion verwendet den zuletzt synchronisierten Stand.","intelBrowser":"IITC nicht erkannt: Öffnen im Browser.","tutorialIntro":"Baue den gesamten Banner in IITC, ohne nach jedem Portal zu BannerLab zurückzukehren.","tut1Title":"Plugin einmal installieren","tut1Text":"Unter Route auf „IITC-Plugin installieren / aktualisieren“ tippen und die Datei anschließend in IITC Mobile als Benutzer-Plugin hinzufügen.","tut2Title":"IITC aus BannerLab öffnen","tut2Text":"BannerLab übergibt Projekt, aktive Mission und Sprache über ein lokales Fragment an Companion. Der Intel-Server bekommt diese Daten nie zu sehen.","tut3Title":"Direkt auf der Karte bauen","tut3Text":"Mit Companion kannst du Portale hinzufügen, bearbeiten oder entfernen, Missionen wechseln und Routen sehen, ohne zu BannerLab zurückzukehren.","tut4Title":"Am Ende synchronisieren","tut4Text":"„BannerLab synchronisieren“ schreibt alle geänderten Missionen zurück ins Projekt und öffnet BannerLab erneut.","tutNote":"Companion lässt sich verschieben und in der Größe ändern. Seine Einstellungen findest du unter Optionen.","installUpdate":"Installieren / aktualisieren","emptyTitleIssue":"Mission {n}: Titel fehlt","emptyDescIssue":"Mission {n}: Beschreibung fehlt","portalsIssue":"Mission {n}: {count}/{need} Portale","missingGuidIssue":"Mission {n}: {count} GUID(s) fehlen","passIssue":"Mission {n}: {count} unvollständige Passphrase(s)","reviewCount":"{n} Punkt(e) prüfen","projectReady":"BannerLab-Projekt bereit","fixBeforePublish":"Behebe diese Punkte vor der Veröffentlichung.","publisherDesc":"Der nächste Schritt befüllt das Mission Authoring Tool direkt aus diesem nativen Format. Das endgültige Absenden bleibt bewusst im offiziellen Tool.","packCreating":"BannerLab-Paket wird erstellt…","packCreated":"BannerLab-Paket erstellt","exportImpossible":"Export nicht möglich: {error}","missionResetDone":"Mission {n} zurückgesetzt","textDeleted":"Text gelöscht","histImport":"Bild importieren","histMissionZoom":"Missionszoom","histMissionRotation":"Missionsdrehung","histTextRotation":"Textdrehung","histImageRotation":"Bilddrehung","histTextZoom":"Textzoom","histImageZoom":"Bildzoom","histCenterText":"Text zentrieren","histCenterImage":"Bild zentrieren","histResetText":"Text zurücksetzen","histResetImage":"Bild zurücksetzen","histResetMission":"Mission zurücksetzen","histDeleteText":"Text löschen","histAddText":"Text hinzufügen","histEditText":"Text bearbeiten","routeActionHelp":"Hack / Mod / Erobern / Link / Feld / Passphrase direkt in Companion.","handoverDetail":"Das letzte Portal darf das erste Portal der nächsten Mission werden, ohne als unerlaubtes Duplikat zu gelten.","coordsMissing":"Koordinaten nicht gefunden.","coordsInvalid":"Ungültige Koordinaten.","duplicateElsewhere":"Dieses Portal wird bereits an anderer Stelle im Banner verwendet.","missionCompleteAdded":"Mission {n} vollständig · {next}","portalAdded":"Portal hinzugefügt · Mission {n}","syncOld":"Route synchronisiert · alter Companion erkannt: Version 0.6.9 installieren.","syncOk":"IITC-Route synchronisiert · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Direkt in Mission Authoring vorbereiten","livePublishShort":"Direkter Publisher","livePreparing":"{n} Missionen für Publisher werden vorbereitet…","liveReady":"Integrierter Publisher wird geöffnet…","liveNativeOnly":"Der direkte Publisher ist in der Android-APK verfügbar.","liveFailed":"Publisher konnte nicht geöffnet werden: {error}","liveExperimental":"Experimentell: Mission Authoring wird in einer von RBL gesteuerten Ansicht geöffnet. Als Erstes muss geprüft werden, ob die Google-Anmeldung auf deinem Telefon funktioniert.","backupTransfer":"Sicherung / Übertragung","exportPackBackup":"BannerLab-Paket exportieren","openOfficialOnly":"Nur offizielle Website öffnen","publisherPreparingImage":"Mission {n}/{total} wird gerendert…","browserPublish":"In Firefox veröffentlichen","browserPublishShort":"Browser-Publisher","browserSetup":"Browser-Publisher installieren / aktualisieren","browserPreparing":"Mission {n}/{total} wird vorbereitet…","browserOpening":"Firefox wird geöffnet…","browserNeed":"Der direkte Publisher nutzt Firefox Android + Violentmonkey, damit die Google-Anmeldung in einem normalen Browser bleibt.","browserFailed":"Publisher konnte nicht geöffnet werden: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab für missions.ingress.com. Einmal in Violentmonkey unter Firefox Android installieren.","browserShareDialog":"Publisher 0.4.8 installieren","browserShareFailed":"Browser-Publisher konnte nicht geteilt werden.","publisherUrlTooLarge":"Diese Mission ist zu groß, um sie an den Browser zu übergeben.","publisherReturn":"Vom Publisher zurückgekehrt.","publisherNoFirefox":"Firefox wurde nicht erkannt. Der Standardbrowser wird geöffnet, aber Publisher benötigt einen Browser mit Userscript-Unterstützung.","publisherBrowser":"Browser zum Veröffentlichen","chromeMode":"Chrome","chromeModeSub":"Keine zusätzliche App · kleines Lesezeichen + bei Nachfrage erlauben","firefoxMode":"Firefox","firefoxModeSub":"Automatisch nach Installation von Violentmonkey + Publisher","recommendedAuto":"Automatisch","noExtraApp":"Keine zusätzliche App","publishSelected":"Mission veröffentlichen","chromeSetup":"Chrome einrichten","firefoxSetup":"Firefox einrichten","chromeReady":"Chrome-Lesezeichen geprüft","firefoxReady":"Firefox-Publisher geprüft","notConfigured":"Einmalige Einrichtung erforderlich","chromeSetupTitle":"MILO in Chrome","chromeSetupIntro":"Chrome erlaubt RBL nicht, das Lesezeichen automatisch anzulegen. Die Einrichtung ist deshalb auf das absolute Minimum reduziert.","chromeStep1":"1. Code für das RBL-Publisher-Lesezeichen kopieren.","chromeStep2":"2. Mission Authoring in Chrome öffnen und die Seite als Lesezeichen speichern.","chromeStep3":"3. Das Lesezeichen bearbeiten: „MILO“ nennen und die URL durch den kopierten Code ersetzen.","chromeStep4":"4. In Mission Authoring auf die Adressleiste tippen, „RBL“ eingeben und das Lesezeichen zum Testen auswählen.","copyBookmarklet":"Lesezeichen-Code kopieren","bookmarkletCopied":"Lesezeichen-Code kopiert","openChromeSetup":"Chrome zur Einrichtung öffnen","testChrome":"Chrome-Lesezeichen testen","chromeRunHint":"In Chrome: Adressleiste antippen, RBL eingeben und „MILO“ auswählen.","chromeNeedsSetup":"Richte zuerst das Chrome-Lesezeichen „MILO“ ein.","chromeOpenFail":"Chrome konnte nicht geöffnet werden. Der Standardbrowser wird verwendet.","firefoxSetupTitle":"MILO in Firefox","firefoxSetupIntro":"Firefox kann Publisher über Violentmonkey automatisch laden. Das ist der angenehmste Modus.","sharePublisher":"Publisher-Userscript teilen","testFirefox":"Firefox-Publisher testen","firefoxNeedsSetup":"Installiere Violentmonkey und Publisher in Firefox, bevor du testest.","browserSaved":"Browser zum Veröffentlichen: {browser}","setupConfirmed":"Einrichtung geprüft.","bookmarkletCopyFail":"Automatisches Kopieren nicht möglich. Der Code wird unten angezeigt.","bookmarkletLabel":"Lesezeichen-Code","autoImpossibleChrome":"Automatisches Laden ist in Chrome Android ohne Erweiterung oder weitreichende Berechtigung nicht möglich. Das Lesezeichen bleibt erforderlich.","openChromePublish":"Chrome wird geöffnet…","openFirefoxPublish":"Firefox wird geöffnet…","chromeWizardTitle":"Chrome einrichten","chromeWizardIntro":"Einmalige Einrichtung. RBL merkt sich deinen Fortschritt.","chromeFileTitle":"Publisher speichern","chromeFileText":"RBL speichert Publisher direkt unter Téléchargements/RedactedBannerLab. Das Android-Teilen-Menü wird nicht benötigt.","chromeSaveFile":"Publisher speichern","chromeFileDone":"Publisher gespeichert","alreadySaved":"Ich habe ihn bereits gespeichert","chromeBookmarkTitle":"Mini-Lesezeichen erstellen","chromeBookmarkText":"Das Lesezeichen enthält nicht mehr den gesamten Publisher. Es ist nur {n} Zeichen lang und lädt die gerade gespeicherte Datei.","chromeBookmarkName":"Lesezeichenname: MILO","chromeBookmarkHow":"In Chrome: Mission Authoring öffnen → ⋮ → Zu Lesezeichen hinzufügen. Danach das Lesezeichen bearbeiten, „MILO“ nennen und den Code als URL einfügen.","copyMiniCode":"Mini-Code kopieren","miniCodeCopied":"Mini-Code kopiert","openChromeBookmark":"Mission Authoring öffnen","bookmarkCreated":"Ich habe das Lesezeichen erstellt","chromeTestTitle":"Testen und erlauben","chromeTestText":"RBL öffnet Mission Authoring. Gib RBL ein und starte das Lesezeichen. Chrome fragt nach Publisher und anschließend nach der aktuellen JSON-Datei. Die JSON wird bei jedem neuen Banner neu gewählt, nicht zwischen einzelnen Missionen.","chromeTestButton":"In Chrome testen","chromeTestWaiting":"In Chrome: RBL eingeben → MILO → falls gefragt publisher.js auswählen → Erlauben.","chromeSetupSuccess":"Chrome ist bereit","chromeSetupSuccessText":"Chrome ist bereit. Publisher bleibt gespeichert; die Banner-JSON wird für jede neue Sitzung bewusst neu ausgewählt, damit kein altes Projekt unbemerkt wiederverwendet wird.","publishNow":"Jetzt veröffentlichen","wizardPrev":"Zurück","wizardNext":"Weiter","wizardRestart":"Einrichtung neu starten","stepOf":"Schritt {n}/3","chromeFileShareText":"Speichere diese publisher.js an einem leicht auffindbaren Ort, etwa in Downloads. Chrome fragt beim ersten Test danach.","chromeFileShareDialog":"MILO speichern","chromeFileShareFail":"Publisher-Datei konnte nicht vorbereitet werden.","chromePermissionHint":"Chrome kann erneut um Zugriff auf publisher.js bitten. Du kannst ihn einfach erlauben.","chromeNotAutoFavorite":"RBL kann ein Chrome-Lesezeichen nicht automatisch erstellen. Das ist der einzige zwingende manuelle Schritt.","codeLength":"{n} Zeichen","chromeStepSaved":"Schritt gespeichert","chromeResetDone":"Chrome-Einrichtung zurückgesetzt","chromeSelectFileHint":"In Chrome auswählen: Téléchargements/RedactedBannerLab/MILO.user.js","bannerDescription":"Bannerbeschreibung","required":"Erforderlich","bannerDescriptionHint":"Das ist die Standardbeschreibung für alle Missionen. Einzelne Missionen kannst du später weiterhin individuell anpassen.","bannerDescriptionRequired":"Eine Bannerbeschreibung ist erforderlich.","describeBeforePublish":"Banner zuerst beschreiben","describeBeforePublishText":"Die Veröffentlichung bleibt gesperrt, bis der Banner eine Beschreibung hat. Sie dient als Standard für alle Missionen.","saveAndContinue":"Speichern und weiter","missionPublishBlocked":"Mission kann nicht veröffentlicht werden","missionNeedsPortals":"Mission {n} hat {count}/{need} Portale. Vor der Veröffentlichung sind mindestens {need} erforderlich.","completeMission":"Mission vervollständigen","currentMissionReady":"Mission ist bereit zur Veröffentlichung","publishBlockedHint":"Die Veröffentlichung bleibt gesperrt, bis alle Pflichtangaben vollständig sind.","minimumSix":"Mindestens 6 Portale pro Mission","publisherDescRequired":"Publisher lehnt Missionen ohne Beschreibung ab.","publisherPortalsRequired":"Publisher lehnt Missionen mit weniger als 6 Portalen ab.","playBanners":"Banner finden","playHub":"Banner finden","searchBannergress":"Banner finden","searchPlaceholder":"Name oder Stichwort","search":"Suchen","favorites":"Favoriten","currentBanner":"Fortsetzen","noFavorites":"Noch keine Favoriten. Der lokale Speicher genießt die Ruhe.","noPlaySession":"Aktuell läuft kein Banner.","searchPrompt":"Suche nach Name und/oder Gebiet mit echter Entfernungsbegrenzung.","searching":"Suche läuft…","searchError":"Bannergress-Suche fehlgeschlagen: {error}","missionsCount":"{n} Missionen","distanceKm":"{n} km","favorite":"Favorit","removeFavorite":"Favorit entfernen","playThisBanner":"Diesen Banner starten","resumeBanner":"Diesen Banner fortsetzen","stopBanner":"Overlay stoppen","openCurrentMission":"Aktuelle Mission öffnen","overlayPermissionTitle":"RBL-Overlay erlauben","overlayPermissionText":"Android muss Redacted BannerLab erlauben, über Ingress angezeigt zu werden. Eine Systemberechtigung, dann kann sich der Dino um seine Angelegenheiten kümmern.","overlayPermissionButton":"Anzeige über anderen Apps erlauben","overlayPermissionWaiting":"Kehre zu RBL zurück, nachdem du die Berechtigung erteilt hast.","overlayStarted":"Missions-Overlay gestartet.","overlayFailed":"Overlay konnte nicht gestartet werden: {error}","bannerLoadError":"Dieser Banner konnte nicht geladen werden: {error}","bannerOffline":"Dieser Banner enthält keine nutzbaren Missionen.","bannerDisabled":"{n} deaktivierte Mission(en)","addressUnknown":"Standort nicht angegeben","doneMissions":"{done}/{total} abgeschlossen","deepLinkOnly":"RBL steuert Ingress nicht: Das Overlay öffnet lediglich offizielle Missions-Deep-Links.","bannergressCredit":"Suche über Bannergress","publisherWholeBanner":"Gesamten Banner vorbereiten","publisherWholeHint":"Eine Browsersitzung: Alle Missionen und Bilder werden gemeinsam vorbereitet.","publisherAllRequired":"Alle Missionen müssen vollständig sein, bevor die Veröffentlichungssitzung gestartet werden kann.","publisherSessionCreating":"Publisher-Sitzung wird vorbereitet {n}/{total}…","publisherSessionReady":"Sitzung unter Téléchargements/RedactedBannerLab gespeichert. Mission Authoring wird geöffnet…","publisherSessionFileText":"RBL speichert die Sitzung automatisch unter Téléchargements/RedactedBannerLab.","publisherSessionDialog":"Publisher-Sitzung","publisherSessionShareFail":"Publisher-Sitzung konnte nicht vorbereitet werden.","chromeSessionHint":"Chrome: Starte das Lesezeichen MILO. Für jeden neu vorbereiteten Banner fragt Chrome ausdrücklich nach MILO_CurrentBanner.json. Zwischen Missionen ist nichts weiter nötig.","firefoxSessionHint":"Firefox: Publisher öffnet automatisch. Lade MILO_CurrentBanner.json, falls die aktuelle Sitzung noch nicht bekannt ist.","easterEgg":"Du wolltest es so.","bannerNameSearch":"Name / Stichwort","citySearch":"Stadt","authorSearch":"Autor","cityPlaceholder":"z. B. Nantes","authorPlaceholder":"z. B. AgentName","nearMe":"In meiner Nähe","nearMeOn":"Mein Standort aktiviert","nearMeHint":"Verwendet deinen aktuellen Standort statt einer Stadt.","locationGetting":"Standort wird ermittelt…","locationError":"Standort konnte nicht ermittelt werden: {error}","locationReady":"Standort ermittelt","searchCriteriaRequired":"Gib mindestens ein Suchkriterium ein.","cityResolving":"Stadt wird gesucht…","cityNotFound":"Für „{city}“ wurde kein Bannergress-Ort gefunden.","cityUsing":"Verwendeter Ort: {city}","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Verschieben","overlayMinimize":"Minimieren","overlayClose":"Schließen","overlayMoved":"Overlay-Position gespeichert","searchReset":"Leeren","resultsCount":"{n} Ergebnis(se)","searchFilters":"Aktive Filter","allPublicBanners":"Öffentliche Bannergress-Banner","searchRadius":"Suchradius","radiusHint":"Gilt rund um die Stadt oder deinen aktuellen Standort.","locationDisabled":"Die Standortdienste sind auf diesem Telefon deaktiviert.","locationPermissionDenied":"BannerLab darf deinen Standort nicht verwenden.","locationUnavailable":"Standort nicht verfügbar. Prüfe, ob die Standortdienste des Telefons aktiviert sind.","locationTimeout":"Der Standort konnte nicht rechtzeitig ermittelt werden. Prüfe, ob die Standortdienste aktiviert sind.","openLocationSettings":"Standort aktivieren","openAppSettings":"App-Einstellungen öffnen","cityNoCoordinates":"„{city}“ wurde gefunden, aber die Position kann nicht verwendet werden.","cityUsingRadius":"Verwendet: {city} · Radius {radius} km","radiusResults":"{n} Ergebnis(se) innerhalb von {radius} km","distanceFromPoint":"{distance} entfernt","locationChecking":"Standortdienste werden geprüft…","publisherCurrentFile":"Aktuelle Datei: Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json","chromeFilePath":"Le Publisher sera enregistré dans le dossier que tu choisis.","chromeFileSaved":"Publisher unter Téléchargements/RedactedBannerLab gespeichert.","chromeFileWriteFail":"Publisher konnte nicht unter Téléchargements/RedactedBannerLab gespeichert werden.","chromeCurrentSessionHint":"Für jeden neuen Banner: Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json auswählen.","browserResume":"Sitzung vorbereitet. Der RBL-Tab mit Mission Authoring wird geöffnet…","chromeResumeHint":"Chrome verwendet jetzt denselben für RBL reservierten Mission-Authoring-Tab.","firefoxResumeHint":"Mission Authoring wird im Veröffentlichungsbrowser geöffnet.","browserResumeFallback":"Der RBL-Tab konnte nicht wiederverwendet werden. Browser wird ersatzweise neu geöffnet.","publisherAutoRefresh":"Publisher überwacht nun die aktuelle Sitzungsdatei und lädt einen neu vorbereiteten Banner automatisch neu.","flowLocked":"Banner-Bearbeitung gesperrt","flowLockedText":"Schritt {step} ist aktiv. Wähle „1 Banner“, um Bild, Text oder Ausschnitt zu bearbeiten.","returnFresco":"Zum Bearbeiten „1 Banner“ auswählen","flowLockedToast":"Kehre zu Schritt 1 Banner zurück, um den Banner zu bearbeiten.","publisherTabReuse":"RBL verwendet eine feste Browser-Anwendungs-ID, um denselben Tab wiederzuverwenden.","todo":"Zu erledigen","history":"Verlauf","inProgress":"Läuft","addTodo":"Zu „Zu erledigen“ hinzufügen","removeTodo":"Aus „Zu erledigen“ entfernen","noTodo":"Keine Banner zu erledigen. Verdächtig vernünftig.","noHistory":"Noch keine gespielten Banner. Der Dino langweilt sich.","bannerMap":"Routenkarte","openMap":"Karte anzeigen","navigateStart":"Zum Start navigieren","startUnavailable":"Startpunkt nicht verfügbar.","mapUnavailable":"Bannergress liefert für diesen Banner keine nutzbaren Koordinaten.","startPoint":"Start","missionStart":"Mission {n}","shareGroup":"Teilen / Gruppe","shareProgress":"Fortschritt teilen","shareBanner":"Banner teilen","shareIntro":"Der QR-Code öffnet RBL beim selben Banner und derselben Missionsnummer. Es wird kein Bannergress-Konto verwendet.","copyLink":"RBL-Link kopieren","linkCopied":"RBL-Link kopiert","shareNow":"Teilen","bannergressPage":"Auf Bannergress öffnen","joinBanner":"Banner beitreten","joinAtMission":"Bei Mission {n} einsteigen","sharedBannerLoaded":"Geteilter Banner geladen · Mission {n}","sharedBannerError":"Geteilter Banner konnte nicht geladen werden: {error}","playStats":"Sitzungsstatistik","startedAt":"Gestartet","finishedAt":"Beendet","elapsed":"Aktive Zeit","estimatedDistance":"Geschätzte Strecke","missionsDone":"Erledigte Missionen","paused":"Pausiert","playing":"Läuft","completedBanner":"Abgeschlossen","replayBanner":"Erneut spielen","resumeFromHistory":"Fortsetzen","groupNoServer":"Serverloser Gruppenmodus: Teile QR/Link erneut, wenn die Gruppe zu einer anderen Mission wechselt.","publicOnly":"Nur öffentliche Bannergress-Suche/-Daten · keine Anmeldung erforderlich.","routePoints":"{n} Routenpunkte","uselessStats":"Nutzlose Statistiken","loadingStats":"Berechne Dinge, nach denen niemand gefragt hat…","statsUnavailable":"Nicht genug Koordinaten, um nutzlose Statistiken zu berechnen.","bgDistance":"Bannergress-Distanz","calculatedTrack":"Geschätzte Gehstrecke","walkingEstimate":"Geschätzte Gehzeit","routeSteps":"Schritte","uniquePlaces":"Einmalige Orte","revisitedPlaces":"Wiederholte Besuche","stepsPerKm":"Schritte / km","avgMissionDistance":"Durchschnitt / Mission","longestMission":"Längste Mission","longestLeg":"Längster Abschnitt","betweenMissions":"Übergänge zwischen Missionen","detourFactor":"Umwegfaktor","routeCoverage":"Kartenabdeckung","missionShort":"M{n}","straightLine":"Start → Ziel","funStatsDisclaimer":"RBL routet jeden Abschnitt von Portal zu Portal über das Fußwegenetz von OpenStreetMap. Jeder Abschnitt wird auf Plausibilität geprüft: unmögliche Abkürzungen oder offensichtlich absurde Umwege werden nur für diesen Abschnitt durch die direkte Distanz ersetzt. Das ist eine Gehschätzung, keine GPS-Messung.","minutesShort":"{n} Min.","hoursMinutes":"{h} Std. {m} Min.","xFactor":"×{n}","showUselessStats":"📊 Nutzlose Statistiken","hideUselessStats":"Statistiken ausblenden","statsLoaded":"Statistiken berechnet","directGeometric":"Kumulierte direkte Distanz","routingDetour":"Netz / Direkt-Verhältnis","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla nicht verfügbar · geometrische Schätzung","routingLoading":"Tatsächliche Gehroute wird berechnet…","routingFailed":"Fußweg-Routing nicht verfügbar, geometrische Statistik wird verwendet.","routingNative":"Valhalla + OSM · Plausibilitätsprüfung pro Abschnitt","routingWeb":"Valhalla + OSM · Plausibilitätsprüfung pro Abschnitt","routingErrorDetail":"Valhalla fehlgeschlagen: {error}","ingressRadius":"Ingress-Reichweite","ingressRadiusValue":"40 m","correctedLegs":"Korrigierte Abschnitte","rawValhalla":"Valhalla roh","creditsTitle":"Credits & Danke","bannergressThanks":"Danke, Bannergress","bannergressThanksText":"Die Bannersuche und mehrere öffentliche Details in Redacted BannerLab basieren auf öffentlichen Bannergress-Daten. Danke an das Team und alle Mitwirkenden für die enorme Arbeit rund um Ingress-Banner.","bannergressNoLogin":"RBL verwendet kein Bannergress-Konto, sondern nur öffentliche Daten, die für Suche und Anzeige erforderlich sind.","independentProject":"Redacted BannerLab ist ein unabhängiges Projekt und weder mit Bannergress noch mit offiziellen Ingress-Diensten verbunden oder von ihnen unterstützt.","visitBannergress":"Bannergress besuchen","mapCredits":"Karten & Routing","mapCreditsText":"Die Karten verwenden OpenStreetMap-Daten. Schätzungen für Fußwege nutzen die Routing-Engine Valhalla.","rblCreditsFoot":"Danke an alle Tools und Mitwirkenden, die dieses Ingress-Missionsökosystem möglich machen.","layersTitle":"Bilder & Ebenen","layersDesc":"Verwalte hier den Hintergrund und alle darüberliegenden Bilder. Die Vorschaubilder helfen dir, die richtige Ebene zu finden; anschließend kannst du sie auswählen, ausblenden, umsortieren oder gruppieren.","backgroundLayer":"Haupthintergrund","addBackground":"Hintergrund hinzufügen / ersetzen","addLayer":"Ebene hinzufügen","layerName":"Bildebene","selected":"Ausgewählt","visibleLayer":"Sichtbar","hiddenLayer":"Ausgeblendet","moveUp":"Nach oben","moveDown":"Nach unten","groupSelection":"Auswahl gruppieren","group":"Gruppieren","ungroup":"Gruppierung aufheben","groupNeedTwo":"Wähle mindestens zwei Ebenen zum Gruppieren aus.","groupCreated":"Ebenen gruppiert","groupRemoved":"Gruppierung aufgehoben","deleteLayer":"Ebene löschen","layerDeleted":"Ebene gelöscht","layerAdded":"Ebene hinzugefügt","backgroundReplaced":"Hintergrund ersetzt","backgroundMissing":"Kein Haupthintergrund","backgroundFixed":"Der Hintergrund bleibt immer unter den anderen Ebenen.","groupHint":"Markiere mehrere Ebenen und tippe auf Gruppieren. Eine Gruppe wird gemeinsam verschoben, gezoomt und gedreht.","layerOrder":"Ebenenreihenfolge","layerTransform":"Ebene transformieren","groupTransform":"Gruppe transformieren","renameLayer":"Umbenennen","duplicateLayer":"Duplizieren","layerDuplicated":"Ebene dupliziert","histAddLayer":"Ebene hinzufügen","histDeleteLayer":"Ebene löschen","histReorderLayer":"Ebene umsortieren","histGroupLayers":"Ebenen gruppieren","histUngroupLayers":"Ebenengruppierung aufheben","histVisibilityLayer":"Ebenensichtbarkeit","histRenameLayer":"Ebene umbenennen","histDuplicateLayer":"Ebene duplizieren","layerGroupBadge":"Gruppe","layerUngroup":"Diese Gruppe aufheben","layerSelectHint":"Die ausgewählte Ebene kann anschließend direkt auf dem Banner verschoben werden.","layerOpacity":"Deckkraft","layerDimensions":"{w} × {h} px","noImageContent":"Füge vor dem Export mindestens ein Bild hinzu.","groupRelative":"Die folgenden Regler transformieren die gesamte Gruppe gemeinsam.","groupZoom":"Gruppenzoom","groupRotation":"Gruppendrehung","clearGroupSelection":"Auswahl leeren","allLayersTitle":"Ebenen","allLayersDesc":"Wähle das Element aus, das du bearbeiten möchtest. Bilder und Texte bleiben zusätzlich in ihren jeweiligen Menüs editierbar.","imageLayersSection":"Bilder","textLayersSection":"Text","noExtraImageLayer":"Keine zusätzliche Bildebene","noTextLayer":"Keine Textebene","selectLayer":"Auswählen","editLayer":"Bearbeiten","missionNumberQuestion":"Wie lautet die Missionsnummer?","groupName":"Gruppe {n}","groupCount":"{n} Ebene(n)","creatorBy":"Erstellt von Zw4nn","communityTitle":"Community & Support","communityText":"Community und Support erreichst du direkt über den Redacted-BannerLab-Bot.","telegramOpen":"Support kontaktieren","reportProblem":"Problem melden","reportProblemText":"Kopiere eine technische Diagnose und kontaktiere anschließend den Support über den Bot.","copyDiagnostic":"Diagnose kopieren","diagnosticCopied":"Diagnose kopiert","diagnosticCopyFailed":"Diagnose konnte nicht kopiert werden","diagnosticDescription":"Problembeschreibung:","portableProject":"Portables Projekt","portableProjectDesc":"Exportiere einen einzelnen Banner samt Bildern, Ebenen, Text, Schriften, Missionen und Route.","exportProject":"Exportieren","shareProject":"Teilen","importProject":"Projekt importieren","projectExporting":"Projekt wird vorbereitet…","projectExported":"Projekt gespeichert","projectShared":"Projekt zum Teilen bereit","projectImportSuccess":"Projekt importiert","projectImportInvalid":"Diese Datei ist kein gültiges Redacted-BannerLab-Projekt.","projectShareTitle":"Redacted-BannerLab-Projekt","projectImportHint":"Das importierte Projekt wird hinzugefügt, ohne deine anderen Projekte zu verändern.","backupTitle":"Sichern & Wiederherstellen","backupText":"Sichere alle BannerLab-Projekte, Einstellungen und Bilder in einer portablen JSON-Datei.","backupFolder":"Sicherungsordner","backupFolderChoose":"Ordner auswählen","backupFolderChange":"Ordner ändern","backupFolderNone":"Kein Ordner ausgewählt","backupFolderReady":"Ordner eingerichtet","backupAuto":"Automatische Sicherung im Hintergrund","backupAutoHint":"Wenn aktiviert, bereitet BannerLab nach Änderungen regelmäßig eine Sicherung vor und erzwingt beim Wechsel in den Hintergrund eine letzte Speicherung.","backupNow":"Jetzt sichern","backupExport":"JSON exportieren","backupImport":"JSON importieren","backupWorking":"Sicherung wird erstellt…","backupSaved":"Sicherung abgeschlossen","backupAutoSaved":"Automatische Sicherung abgeschlossen","backupFailed":"Sicherung fehlgeschlagen: {error}","backupNeedFolder":"Wähle zuerst einen Sicherungsordner.","backupFolderError":"Dieser Ordner kann nicht verwendet werden.","backupImported":"Sicherung wiederhergestellt","backupInvalid":"Diese Datei ist keine gültige Redacted-BannerLab-Sicherung.","backupImportTitle":"Sicherung wiederherstellen","backupImportText":"{n} Projekt(e) gefunden · Sicherung vom {date}","backupMerge":"Zusammenführen","backupReplace":"Alles ersetzen","backupReplaceWarn":"Alles ersetzen löscht vor der Wiederherstellung die derzeit auf diesem Gerät gespeicherten Projekte.","backupCancel":"Abbrechen","backupLast":"Letzte Sicherung: {date}","backupNever":"Noch keine Sicherung","backupPortable":"Die JSON-Datei enthält auch die Bilder. Sie kann daher groß werden, ist dafür aber vollständig eigenständig.","backupNativeOnly":"Automatische Ordnersicherungen sind unter Android verfügbar. JSON-Export und -Import funktionieren weiterhin überall.","backupFolderChosen":"Sicherungsordner gespeichert","backupNoChanges":"Keine Änderungen zu sichern.","studioEdit":"Im Vollbild bearbeiten","studioTitle":"Bearbeitungsstudio","studioLayers":"Ebenen","studioTexts":"Text","studioTools":"Werkzeuge","studioFit":"6 Missionen","studioFitOne":"1 Mission","studioFitAll":"Alle","studioMissionMode":"Mission","studioFrescoMode":"Banner","studioFullscreen":"Vollbild","studioRotateHint":"6 Missionen vertikal · weitere Reihen werden nach rechts gescrollt.","studioSelected":"Ausgewähltes Element","studioNoLayer":"Wähle seitlich eine Ebene oder ein Textelement aus.","studioGroupSelect":"Auswahl gruppieren","studioGroupNow":"Gruppieren","studioOpenFull":"Komplette Verwaltung öffnen","studioOpacity":"Deckkraft","studioClose":"Studio verlassen","studioPan":"Verschieben","studioAddText":"Text hinzufügen","studioNoText":"Noch kein Text.","studioEditText":"Text bearbeiten","studioDuplicateText":"Text duplizieren","font":"Schriftart","fontWeight":"Schriftstärke","fontItalic":"Kursiv","letterSpacing":"Zeichenabstand","lineHeight":"Zeilenhöhe","textAlign":"Ausrichtung","alignLeft":"Links","alignCenter":"Zentriert","alignRight":"Rechts","importFont":"Schrift importieren","fontImported":"Schrift importiert: {name}","fontInvalid":"Diese Schrift wird nicht unterstützt.","fontTooLarge":"Die Schriftdatei ist zu groß (max. 12 MB).","textBackground":"Texthintergrund","textBackgroundColor":"Hintergrundfarbe","textBackgroundOpacity":"Hintergrund-Deckkraft","textBackgroundPadding":"Innenabstand des Hintergrunds","textBackgroundRadius":"Eckenradius","textTypography":"Typografie","tutorialHubTitle":"Tutorials & Einstieg","tutorialHubText":"Starte jederzeit erneut eine geführte Tour. Redacted erklärt dir auch nur den Teil, den du gerade brauchst.","tutorialOpen":"Tutorials anzeigen","tutorialWelcomeTitle":"Willkommen bei Redacted BannerLab","tutorialWelcomeText":"Redacted kann dir das Labor zeigen. Zwei Minuten, ein paar Buttons und am Ende nicht einmal eine Prüfung.","tutorialStart":"Tour starten","tutorialLater":"Später","tutorialNever":"Nicht mehr anzeigen","tutorialPrevious":"Zurück","tutorialNext":"Weiter","tutorialUnderstood":"OK, verstanden","tutorialClose":"Schließen","tutorialDone":"Tutorial abgeschlossen","tutorialSeen":"Gesehen","tutorialQuick":"Kurztour","tutorialQuickDesc":"Die wichtigsten Bedienelemente und der gesamte BannerLab-Ablauf.","tutorialBanner":"Banner erstellen","tutorialBannerDesc":"Vom Projekt bis zur Vorschau und zum Export der Missionen.","tutorialLayers":"Bilder, Ebenen & Text","tutorialLayersDesc":"Hintergrund, überlagerte Bilder, Ebenen und Typografie-Werkzeuge.","tutorialIitc":"Route mit IITC erstellen","tutorialIitcDesc":"Companion installieren, Portale hinzufügen und Route synchronisieren.","tutorialPublish":"Missionen veröffentlichen","tutorialPublishDesc":"Missionen vorbereiten und anschließend Publisher und Mission Authoring verwenden.","tutorialBackup":"Sicherungen & portable Projekte","tutorialBackupDesc":"BannerLab sichern oder einen vollständigen Banner teilen.","importRolesHint":"Haupthintergrund = Basisbild des Banners · Ebene = zusätzlich darüberliegendes Bild.","tutProjectTitle":"Deine Projekte","tutProjectText":"Jeder Banner lebt in seinem eigenen Projekt. Du kannst ihn exportieren oder teilen, ohne alle anderen Projekte mitzuschleppen.","tutNameTitle":"Projektname","tutNameText":"Gib deinem Banner einen Namen, den du später wiedererkennst.","tutRowsTitle":"Anzahl der Reihen","tutRowsText":"Eine Reihe enthält 6 Missionen. Hier legst du die endgültige Höhe des Banners fest.","tutImageTitle":"Bilder & Ebenen","tutImageText":"Importiere hier den Haupthintergrund und zusätzliche Bilder. Auf demselben Bildschirm kannst du Bildebenen auswählen, sortieren, ausblenden und gruppieren.","tutBackgroundTitle":"Haupthintergrund","tutBackgroundText":"Für dein erstes richtiges Bild nimm Haupthintergrund. Es ersetzt das Basisbild und bedeckt den Banner.","tutExtraLayerTitle":"Ebene hinzufügen","tutExtraLayerText":"Ein zweites Bild wird als Ebene über den Hintergrund gelegt und bleibt verschiebbar, skalierbar und ausblendbar.","tutLayersTitle":"Bildebenen verwalten","tutLayersText":"An den Vorschaubildern erkennst du, welche Bildebene du gerade bearbeitest. Wähle sie aus, sortiere sie um, blende sie aus oder markiere mehrere Bilder zum Gruppieren.","tutTextTitle":"Text","tutTextText":"Füge Text hinzu, wähle Schrift, Abstände, Hintergrund und Eckenradius oder importiere eine eigene Schriftart.","tutPreviewTitle":"Vorschau","tutPreviewText":"Prüfe vor dem Export jede Mission. Individuelle Ausschnitte sind bereits berücksichtigt.","tutExportTitle":"Export","tutExportText":"Wenn alles passt, erzeugt BannerLab die 512 × 512 großen Missionsbilder in der richtigen Reihenfolge.","tutStudioTitle":"Vollbild-Studio","tutStudioText":"Ein komfortabler Vollbildeditor mit seitlichen Bedienelementen und großen Touch-Flächen.","tutFlowTitle":"Die 4 Schritte","tutFlowText":"Banner → Route → Missionen → Veröffentlichen. BannerLab folgt genau diesem Ablauf.","tutRouteTitle":"Route","tutRouteText":"Die Route verbindet die Missionen mit echten Ingress-Portalen. IITC Companion übernimmt die Kartenarbeit.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion nimmt aktives Projekt, Mission, Portale, Aktionen und Gehstatistiken mit nach IITC.","tutInstallCompanionTitle":"Companion installieren","tutInstallCompanionText":"Installiere oder aktualisiere das Userscript einmal in IITC Mobile.","tutOpenIitcTitle":"IITC öffnen","tutOpenIitcText":"Öffne IITC aus BannerLab, damit Projekt und aktive Mission an Companion übergeben werden.","tutAutoRouteTitle":"Zwischen Missionen wechseln","tutAutoRouteText":"Die nächste Mission kann automatisch geöffnet werden und das letzte Portal der vorherigen Mission als erstes übernehmen.","tutPortalListTitle":"Deine Portale","tutPortalListText":"Portale kommen mit GUID, Koordinaten, Reihenfolge und Aktion zurück, damit die Route vollständig rekonstruiert werden kann.","tutMissionsTitle":"Missionen vorbereiten","tutMissionsText":"Gib vor der Veröffentlichung die gemeinsame Beschreibung an und prüfe jede Mission.","tutMissionDescTitle":"Pflichtbeschreibung","tutMissionDescText":"BannerLab weist auf fehlende Angaben hin, bevor eine Veröffentlichung erlaubt wird.","tutPublishTitle":"Veröffentlichen","tutPublishText":"Wenn Route und Beschreibungen fertig sind, geht es hier weiter. Das endgültige Absenden bleibt im offiziellen Tool.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab bereitet Missionsdaten und Veröffentlichungsablauf vor. Nach dem Absenden prüfst du mit „Ich habe eingereicht“, ob die Mission veröffentlicht wurde.","tutInfoTitle":"Einstellungen, Hilfe & Support","tutInfoText":"Unter Einstellungen & Infos findest du Sprache, Sicherungen, Tutorials und Support über den Redacted-BannerLab-Bot.","tutBackupTitle":"Vollständige Sicherung","tutBackupText":"Die vollständige JSON enthält alle Projekte, Einstellungen, Bilder und Schriften. Unter Android kann zusätzlich ein automatischer Sicherungsordner verwendet werden.","tutPortableTitle":"Portables Projekt","tutPortableText":"Exportiere, teile oder importiere einen einzelnen Banner mit Bildern, Text, Schriften, Missionen und Route.","tutSupportTitle":"Hilfe nötig?","tutSupportText":"Kopiere bei Bedarf die Diagnose und kontaktiere den Support. Der Bot verlinkt außerdem Kanal und Diskussionsgruppe.","settingsInfo":"Einstellungen & Infos","addMissionLayer":"Auf einer Mission","importMissionSeries":"Serie importieren","missionLayer":"Missionsebene","globalLayer":"Globale Ebene","layerScope":"Ebenenbereich","wholeBanner":"Gesamter Banner","missionTarget":"Zugeordnete Mission","fitMode":"Anpassung","fitCover":"Füllen","fitContain":"Einpassen","missionBadge":"M{n}","missionLayerHint":"Diese Ebene bleibt mit Mission {n} verbunden und wird automatisch auf deren Kachel begrenzt.","missionSeriesTitle":"Missionsserie importieren","missionSeriesText":"Ordne jedes Bild einer Mission zu. BannerLab platziert und beschneidet die Bilder automatisch.","missionSeriesDetected":"{n} Bild(er) erkannt","missionSeriesImport":"Ebenen importieren","missionSeriesTooMany":"Du hast mehr Bilder als Missionen ausgewählt. Einer Mission können mehrere Bilder zugeordnet werden.","missionLayerAdded":"Bild zu Mission {n} hinzugefügt","missionSeriesAdded":"{n} Missionsebene(n) hinzugefügt","missionScopeMismatch":"Missionsebenen können nur gruppiert werden, wenn sie derselben Mission zugeordnet sind.","missionLayerTutorialTitle":"Mit Missionen verknüpfte Ebenen","missionLayerTutorialText":"Tippe auf „Ebene hinzufügen“ und wähle: gesamter Banner, eine Mission oder mehrere Missionen. Bei einer Mission platziert BannerLab das Bild automatisch in der richtigen Kachel und begrenzt es darauf. Für mehrere Missionen importierst du eine Serie und ordnest jedes Bild der gewünschten Mission zu.","addLayerChoiceTitle":"Ebene hinzufügen","addLayerChoiceText":"Wähle, wohin diese Ebene gehört. Du kannst den Bereich später jederzeit ändern.","addLayerWhole":"Auf dem gesamten Banner","addLayerWholeText":"Ein frei bewegliches und skalierbares Bild über dem gesamten Banner.","addLayerOneMission":"Auf einer Mission","addLayerOneMissionText":"Ein Bild, das automatisch auf der ausgewählten Mission platziert und auf deren Kachel begrenzt wird.","addLayerManyMissions":"Auf mehreren Missionen","addLayerManyMissionsText":"Importiere eine Bildserie und ordne jedes Bild der gewünschten Mission zu.","multiSelection":"Mehrfachauswahl","multiSelectionHint":"Markiere mehrere Ebenen, um eine gemeinsame Aktion anzuwenden, sie zu gruppieren oder zu löschen.","selectionActions":"Aktionen für Auswahl","editSelection":"Auswahl bearbeiten","deleteSelection":"Auswahl löschen","selectedLayersCount":"{n} Ebene(n) ausgewählt","bulkScopeKeep":"Aktuellen Bereich beibehalten","bulkMissionKeep":"Aktuelle Missionen beibehalten","bulkFitKeep":"Aktuelle Anpassung beibehalten","bulkVisibility":"Sichtbarkeit","bulkVisibilityKeep":"Nicht ändern","bulkShow":"Einblenden","bulkHide":"Ausblenden","bulkOpacityEnable":"Deckkraft ändern","applyToSelection":"Auf ausgewählte Ebenen anwenden","selectionUpdated":"Ausgewählte Ebenen aktualisiert","selectionDeleted":"Ausgewählte Ebenen gelöscht","deleteSelectionConfirm":"{n} ausgewählte Ebene(n) endgültig löschen?","selectionEmpty":"Wähle mindestens eine Ebene aus.","layerScopeHelp":"Gesamter Banner: Die Ebene kann den ganzen Banner bedecken. Eine Mission: Sie wird automatisch auf die gewählte Mission begrenzt. Mehrere Missionen: Importiere eine Serie und ordne jedes Bild seiner Mission zu."};
I18N["pt"]={"fresco":"Banner","route":"Percurso","missions":"Missões","publish":"Publicar","projects":"Projetos","rows":"Linhas","image":"Imagens","framing":"Enquadramento","layers":"Camadas","text":"Texto","preview":"Pré-visualização","export":"Exportar","wholeFresco":"Banner completo","oneMission":"Uma missão","noMission":"Nenhuma missão selecionada","addImage":"Adicionar imagem","imageHint":"Será enquadrada diretamente na geometria Prime.","circles":"Círculos Prime","grid":"Grelha 512","numbers":"Números","enlarge":"Ampliar missão","resetMission":"Repor missão","prev":"Anterior","next":"Seguinte","complete":"Missão concluída","remaining":"Faltam {n} portal(is)","openIitc":"Abrir IITC Companion","tutorial":"Tutorial","installPlugin":"Instalar / atualizar plugin IITC","autoAdvance":"Passar automaticamente à missão seguinte quando chegar a {n} portais","reuseLast":"Reutilizar automaticamente o último portal como primeiro da missão seguinte","noPortal":"Esta missão ainda não tem portais.","action":"Ação","hack":"Hackear","mod":"Instalar um mod","capture":"Capturar / melhorar","link":"Criar um link","field":"Criar um campo","passphrase":"Passphrase","question":"Pergunta","answer":"Resposta esperada","save":"Guardar","cancel":"Cancelar","settings":"Definições comuns","commonDesc":"Descrição comum","titleFormat":"Formato dos títulos","defaultType":"Tipo predefinido","location":"Localização","visible":"Visível","hidden":"Oculta","sequential":"Sequencial","anyOrder":"Qualquer ordem","portalsPerMission":"Portais / missão","editMission":"Editar missão","title":"Título","description":"Descrição","missionReady":"Pronta","missionIncomplete":"Incompleta","openRoute":"Editar percurso","publishPack":"Criar pacote BannerLab","openMat":"Abrir Mission Authoring Tool","ownWorkflow":"O BannerLab usa agora o seu próprio formato de projeto e o seu próprio pacote de publicação.","language":"Idioma","french":"Français","english":"English","spanish":"Español","companionStats":"Estatísticas de caminhada no IITC","companionStatsDesc":"No pequeno painel do IITC, 📊 Estatísticas inúteis calcula distância estimada a pé, tempo, desvios e outras coisas que ninguém pediu.","duplicateBad":"{n} reutilização(ões) de portal a verificar.","handoverOk":"É permitida a reutilização do fim de uma missão no início da seguinte.","pluginVersion":"IGOR 0.6.35","undo":"Desfazer","redo":"Refazer","subtitle":"Banners Ingress Prime","source":"origem","bannerHelp":"<b>Modo banner:</b> 1 dedo move a camada selecionada. <b>2 dedos</b> fazem zoom e rodam.","missionHelp":"<b>Modo missão:</b> toca num medalhão. Para editar com mais conforto, usa <b>Ampliar missão</b>. Também o podes mover aqui com 1 dedo.","missionSelected":"Missão {n} selecionada","tapMedallion":"Toca num medalhão","touchMissionFirst":"Toca primeiro na missão cujo enquadramento queres ajustar.","selectMissionFirst":"Seleciona primeiro uma missão.","heavyImage":"Imagem muito pesada. Pode levar o teu telemóvel a repensar as escolhas de vida.","imported":"{w} × {h} px importados","textLayerDesc":"Cada texto continua numa camada independente, que podes editar ou eliminar separadamente.","layer":"Camada","newText":"+ Novo texto","size":"Tamanho","outline":"Contorno","color":"Cor","outlineColor":"Cor do contorno","add":"Adicionar","update":"Atualizar","delete":"Eliminar","zoom":"Zoom","localZoom":"Zoom local","rotation":"Rotação","center":"Centrar","reset":"Repor","done":"Concluído","transformText":"Transformar texto","frameImage":"Enquadrar imagem","pinchHint":"Os gestos com dois dedos continuam disponíveis diretamente sobre o banner.","missionCropOnly":"Este enquadramento afeta apenas este medalhão.","resetThisMission":"Repor esta missão","individualCrop":"Enquadramento individual · 512 × 512","oneFinger":"1 dedo","move":"mover","twoFingers":"2 dedos","zoomRotate":"fazer zoom e rodar","previewPrime":"Pré-visualização Prime","previewApplied":"Os ajustes individuais das missões já estão aplicados.","previewOrder":"O número 1 fica em baixo à direita; depois a numeração segue para a esquerda e sobe pelas restantes linhas.","exportTitle":"Exportar {n} missões","exportIntro":"Escolhe rapidez ou PNG sem perdas. Ambos mantêm 512 × 512.","noBackground":"Não há imagem de fundo carregada.","missionFormat":"Formato das missões","jpgFast":"JPG rápido · alta qualidade","pngLossless":"PNG sem perdas · mais lento","fastEncoding":"O modo rápido evita a codificação PNG, que é de longe a parte mais lenta num telemóvel.","rowRender":"O fundo é renderizado uma única vez por linha, em vez de ser recalculado seis vezes.","adjusted":"{n} missão(ões) com enquadramento individual.","nianticCheck":"Confirma as regras da Niantic antes de submeter: direitos sobre a imagem, conteúdo pertinente e nenhuma personagem única dominante.","ready":"Pronto.","createZip":"Criar ZIP","zipAssembly":"A criar ZIP…","zipCreated":"ZIP criado.","zipDownloaded":"ZIP descarregado.","saveShareZip":"Guardar ou partilhar ZIP","exportFinished":"Exportação {format} concluída","exportFailed":"A exportação falhou.","newProject":"Novo projeto","myProjects":"Os meus projetos","projectsSaved":"{n} projeto(s) guardado(s) neste dispositivo.","unnamed":"Sem nome","opened":"Aberto","open":"Abrir","rename":"Mudar nome","copy":"Copiar","noSavedProject":"Nenhum projeto guardado.","renameProject":"Mudar nome do projeto","renameHint":"Um nome que um ser humano consiga reconhecer mais tarde. Conceito surpreendentemente avançado.","projectName":"Nome do projeto","projectOpened":"Projeto aberto: {name}","projectRenamed":"Projeto renomeado","deleteProject":"Eliminar este projeto?","deleteWarning":"O banner e a imagem guardada localmente serão eliminados.","copyCreated":"Cópia criada","projectDeleted":"Projeto eliminado","newProjectCreated":"Novo projeto criado com Redacted","defaultProject":"O meu banner","defaultNewProject":"Novo banner","copySuffix":"cópia","versionLabel":"Versão","infoPrime":"6 colunas · 544 px · recorte de 512 px.","infoPlanner":"ações de portal, passphrases, passagem fim→início e pacote BannerLab nativo.","infoCompanion":"percursos, ações, traçados entre missões, opções e estatísticas de caminhada.","disclaimer":"Ingress e Ingress Prime são marcas da Niantic. O Redacted BannerLab não é afiliado nem aprovado pela Niantic.","titleTokens":"$T = nome · $N = número · $M = total · $0N = 01, 02…","pluginShareText":"Plugin IGOR 0.6.35. No IITC Mobile, substitui a versão anterior. Se o IITC não permitir substituí-la, remove uma vez o plugin antigo e instala este ficheiro.","pluginDialog":"Instalar / atualizar IGOR 0.6.35","pluginShareFailed":"Não foi possível partilhar o plugin IITC.","intelOpened":"IITC Mobile aberto com o projeto BannerLab.","intelPrimeOpened":"IITC Prime aberto com o projeto BannerLab.","intelFallback":"IITC Mobile aberto. O Companion vai usar o último estado sincronizado.","intelPrimeFallback":"IITC Prime aberto. O Companion vai usar o último estado sincronizado.","intelBrowser":"IITC não detetado: a abrir no navegador.","tutorialIntro":"Constrói o banner completo no IITC sem voltar ao BannerLab depois de cada portal.","tut1Title":"Instala o plugin uma única vez","tut1Text":"Em Percurso, usa “Instalar / atualizar plugin IITC” e depois adiciona o ficheiro como plugin de utilizador no IITC Mobile.","tut2Title":"Abre o IITC a partir do BannerLab","tut2Text":"O BannerLab envia o projeto, a missão ativa e o idioma ao IGOR através de um fragmento local que nunca chega ao servidor Intel.","tut3Title":"Constrói diretamente no mapa","tut3Text":"O Companion permite adicionar, editar ou remover portais, mudar de missão e ver os percursos sem voltar ao BannerLab.","tut4Title":"Sincroniza quando terminares","tut4Text":"“Sincronizar BannerLab” devolve todas as missões alteradas ao projeto e volta a abrir o BannerLab.","tutNote":"Podes mover e redimensionar o IGOR e guardar as respetivas definições em Opções.","installUpdate":"Instalar / atualizar","emptyTitleIssue":"Missão {n}: título em falta","emptyDescIssue":"Missão {n}: descrição em falta","portalsIssue":"Missão {n}: {count}/{need} portais","missingGuidIssue":"Missão {n}: faltam {count} GUID(s)","passIssue":"Missão {n}: {count} passphrase(s) incompleta(s)","reviewCount":"{n} ponto(s) a verificar","projectReady":"Projeto BannerLab pronto","fixBeforePublish":"Corrige estes pontos antes de publicar.","publisherDesc":"O próximo passo preenche o Mission Authoring Tool diretamente a partir deste formato nativo. A submissão final continuará, de propósito, a ser feita na ferramenta oficial.","packCreating":"A criar pacote BannerLab…","packCreated":"Pacote BannerLab criado","exportImpossible":"Não foi possível exportar: {error}","missionResetDone":"Missão {n} reposta","textDeleted":"Texto eliminado","histImport":"Importar imagem","histMissionZoom":"Zoom da missão","histMissionRotation":"Rotação da missão","histTextRotation":"Rotação do texto","histImageRotation":"Rotação da imagem","histTextZoom":"Zoom do texto","histImageZoom":"Zoom da imagem","histCenterText":"Centrar texto","histCenterImage":"Centrar imagem","histResetText":"Repor texto","histResetImage":"Repor imagem","histResetMission":"Repor missão","histDeleteText":"Eliminar texto","histAddText":"Adicionar texto","histEditText":"Editar texto","routeActionHelp":"Hack / Mod / Capturar / Link / Campo / Passphrase diretamente no IGOR.","handoverDetail":"O último portal pode tornar-se o primeiro da missão seguinte sem ser tratado como duplicado inválido.","coordsMissing":"Coordenadas não encontradas.","coordsInvalid":"Coordenadas inválidas.","duplicateElsewhere":"Este portal já é usado noutro ponto do banner.","missionCompleteAdded":"Missão {n} concluída · {next}","portalAdded":"Portal adicionado · missão {n}","syncOld":"Percurso sincronizado · Companion antigo detetado: instala a versão 0.6.9.","syncOk":"Percurso IITC sincronizado · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Preparar diretamente no Mission Authoring","livePublishShort":"Publisher direto","livePreparing":"A preparar {n} missões para o Publisher…","liveReady":"A abrir o Publisher integrado…","liveNativeOnly":"O Publisher direto está disponível na APK Android.","liveFailed":"Não foi possível abrir o Publisher: {error}","liveExperimental":"Experimental: o Mission Authoring abre numa vista controlada pelo RBL. A primeira coisa a validar no teu telemóvel é o início de sessão Google.","backupTransfer":"Cópia de segurança / transferência","exportPackBackup":"Exportar pacote BannerLab","openOfficialOnly":"Abrir apenas o site oficial","publisherPreparingImage":"A renderizar missão {n}/{total}…","browserPublish":"Publicar no Firefox","browserPublishShort":"Publisher no navegador","browserSetup":"Instalar / atualizar Publisher do navegador","browserPreparing":"A preparar missão {n}/{total}…","browserOpening":"A abrir Firefox…","browserNeed":"O Publisher direto usa Firefox Android + Violentmonkey para que o início de sessão Google continue num navegador normal.","browserFailed":"Não foi possível abrir o Publisher: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab para missions.ingress.com. Instala uma vez no Violentmonkey do Firefox Android.","browserShareDialog":"Instalar MILO 0.5.3","browserShareFailed":"Não foi possível partilhar o Publisher do navegador.","publisherUrlTooLarge":"Esta missão é demasiado grande para ser enviada para o navegador.","publisherReturn":"Regresso do Publisher.","publisherNoFirefox":"Firefox não foi detetado. A abrir o navegador predefinido, mas o Publisher precisa de um navegador com suporte para userscripts.","publisherBrowser":"Navegador de publicação","chromeMode":"Chrome","chromeModeSub":"Sem aplicação extra · pequeno marcador + Permitir quando solicitado","firefoxMode":"Firefox","firefoxModeSub":"Automático depois de instalar Violentmonkey + Publisher","recommendedAuto":"Automático","noExtraApp":"Sem aplicação extra","publishSelected":"Publicar missão","chromeSetup":"Configurar Chrome","firefoxSetup":"Configurar Firefox","chromeReady":"Marcador do Chrome verificado","firefoxReady":"Publisher do Firefox verificado","notConfigured":"É necessária uma configuração única","chromeSetupTitle":"Publisher para Chrome","chromeSetupIntro":"O Chrome não permite que o RBL crie o marcador por ti. Por isso a configuração foi reduzida ao mínimo humanamente possível.","chromeStep1":"1. Copia o código do marcador MILO.","chromeStep2":"2. Abre o Mission Authoring no Chrome e guarda a página nos marcadores.","chromeStep3":"3. Edita esse marcador: chama-lhe “MILO” e substitui o URL pelo código copiado.","chromeStep4":"4. No Mission Authoring, toca na barra de endereço, escreve “RBL” e escolhe o marcador para o testar.","copyBookmarklet":"Copiar código do marcador","bookmarkletCopied":"Código do marcador copiado","openChromeSetup":"Abrir Chrome para configurar","testChrome":"Testar marcador do Chrome","chromeRunHint":"No Chrome: toca na barra de endereço, escreve RBL e escolhe “MILO”.","chromeNeedsSetup":"Configura primeiro o marcador MILO no Chrome.","chromeOpenFail":"Não foi possível abrir o Chrome. A abrir o navegador predefinido.","firefoxSetupTitle":"Publisher para Firefox","firefoxSetupIntro":"O Firefox pode carregar o Publisher automaticamente através do Violentmonkey. É o modo mais simples.","sharePublisher":"Partilhar userscript do Publisher","testFirefox":"Testar Publisher no Firefox","firefoxNeedsSetup":"Instala o Violentmonkey e o Publisher no Firefox antes de testar.","browserSaved":"Navegador de publicação: {browser}","setupConfirmed":"Configuração verificada.","bookmarkletCopyFail":"Não foi possível copiar automaticamente. O código aparece abaixo.","bookmarkletLabel":"Código do marcador","autoImpossibleChrome":"O carregamento automático não é possível no Chrome Android sem uma extensão ou uma permissão intrusiva. O marcador continua a ser necessário.","openChromePublish":"A abrir Chrome…","openFirefoxPublish":"A abrir Firefox…","chromeWizardTitle":"Configurar Chrome","chromeWizardIntro":"Configuração única. O RBL guarda o teu progresso.","chromeFileTitle":"Guardar Publisher","chromeFileText":"O RBL guarda o Publisher diretamente em Téléchargements/RedactedBannerLab. Não é necessário abrir a folha de partilha do Android.","chromeSaveFile":"Guardar Publisher","chromeFileDone":"Publisher guardado","alreadySaved":"Já o guardei","chromeBookmarkTitle":"Criar o mini marcador","chromeBookmarkText":"O marcador já não contém o Publisher completo. Tem apenas {n} caracteres e carrega o ficheiro que acabaste de guardar.","chromeBookmarkName":"Nome do marcador: MILO","chromeBookmarkHow":"No Chrome: abre Mission Authoring → ⋮ → Adicionar aos marcadores. Depois edita o marcador, chama-lhe “MILO” e cola o código no campo URL.","copyMiniCode":"Copiar mini código","miniCodeCopied":"Mini código copiado","openChromeBookmark":"Abrir Mission Authoring","bookmarkCreated":"Criei o marcador","chromeTestTitle":"Testar e autorizar","chromeTestText":"O RBL abre o Mission Authoring. Escreve RBL e executa o marcador. O Chrome pede o Publisher e depois o JSON atual. O JSON é pedido para cada banner novo, nunca entre missões do mesmo banner.","chromeTestButton":"Testar no Chrome","chromeTestWaiting":"No Chrome: escreve RBL → MILO → escolhe publisher.js se for pedido → Permitir.","chromeSetupSuccess":"Chrome pronto","chromeSetupSuccessText":"O Chrome está pronto. O Publisher fica memorizado; o JSON do banner é escolhido explicitamente para cada nova sessão, para evitar reutilizar um projeto antigo sem dar por isso.","publishNow":"Publicar agora","wizardPrev":"Anterior","wizardNext":"Continuar","wizardRestart":"Reiniciar configuração","stepOf":"Passo {n}/3","chromeFileShareText":"Guarda este publisher.js num local fácil de encontrar, como Downloads. O Chrome vai pedi-lo durante o primeiro teste.","chromeFileShareDialog":"Guardar MILO","chromeFileShareFail":"Não foi possível preparar o ficheiro do Publisher.","chromePermissionHint":"O Chrome pode voltar a pedir permissão para ler publisher.js. Basta permitir.","chromeNotAutoFavorite":"O RBL não consegue criar um marcador do Chrome automaticamente. É o único passo manual obrigatório.","codeLength":"{n} caracteres","chromeStepSaved":"Passo guardado","chromeResetDone":"Configuração do Chrome reposta","chromeSelectFileHint":"No Chrome, seleciona: Téléchargements/RedactedBannerLab/MILO.user.js","bannerDescription":"Descrição do banner","required":"Obrigatório","bannerDescriptionHint":"Esta é a descrição predefinida para todas as missões. Ainda podes personalizar missões individuais mais tarde.","bannerDescriptionRequired":"A descrição do banner é obrigatória.","describeBeforePublish":"Descreve primeiro o banner","describeBeforePublishText":"A publicação fica bloqueada até o banner ter uma descrição. Ela será usada como predefinição para todas as missões.","saveAndContinue":"Guardar e continuar","missionPublishBlocked":"A missão não pode ser publicada","missionNeedsPortals":"A missão {n} tem {count}/{need} portais. Precisa de pelo menos {need} antes da publicação.","completeMission":"Completar missão","currentMissionReady":"Missão pronta a publicar","publishBlockedHint":"A publicação continua bloqueada até todos os elementos obrigatórios estarem completos.","minimumSix":"Mínimo: 6 portais por missão","publisherDescRequired":"O Publisher recusa missões sem descrição.","publisherPortalsRequired":"O Publisher recusa missões com menos de 6 portais.","playBanners":"Encontrar um banner","playHub":"Encontrar um banner","searchBannergress":"Encontrar um banner","searchPlaceholder":"Nome ou palavra-chave","search":"Pesquisar","favorites":"Favoritos","currentBanner":"Retomar","noFavorites":"Ainda não há banners favoritos. O armazenamento local agradece a paz.","noPlaySession":"Não há nenhum banner em curso.","searchPrompt":"Pesquisa por nome e/ou zona geográfica, com um limite real de distância.","searching":"A pesquisar…","searchError":"Falha na pesquisa Bannergress: {error}","missionsCount":"{n} missões","distanceKm":"{n} km","favorite":"Favorito","removeFavorite":"Remover dos favoritos","playThisBanner":"Iniciar este banner","resumeBanner":"Retomar este banner","stopBanner":"Parar sobreposição","openCurrentMission":"Abrir missão atual","overlayPermissionTitle":"Permitir sobreposição do RBL","overlayPermissionText":"O Android tem de permitir que o Redacted BannerLab apareça sobre o Ingress. Uma autorização do sistema e depois o dinossauro pode tratar da vida dele.","overlayPermissionButton":"Permitir sobreposição sobre outras aplicações","overlayPermissionWaiting":"Volta ao RBL depois de concederes a permissão.","overlayStarted":"Sobreposição da missão iniciada.","overlayFailed":"Não foi possível iniciar a sobreposição: {error}","bannerLoadError":"Não foi possível carregar este banner: {error}","bannerOffline":"Este banner não tem missões utilizáveis.","bannerDisabled":"{n} missão(ões) desativada(s)","addressUnknown":"Localização não indicada","doneMissions":"{done}/{total} concluídas","deepLinkOnly":"O RBL não controla o Ingress: a sobreposição limita-se a abrir deep links oficiais das missões.","bannergressCredit":"Pesquisa através do Bannergress","publisherWholeBanner":"Preparar banner completo","publisherWholeHint":"Uma única sessão no navegador: todas as missões e imagens são preparadas em conjunto.","publisherAllRequired":"Todas as missões têm de estar completas antes de iniciar a sessão de publicação.","publisherSessionCreating":"A preparar sessão do Publisher {n}/{total}…","publisherSessionReady":"Sessão guardada em Téléchargements/RedactedBannerLab. A abrir Mission Authoring…","publisherSessionFileText":"O RBL guarda automaticamente a sessão em Téléchargements/RedactedBannerLab.","publisherSessionDialog":"Sessão do Publisher","publisherSessionShareFail":"Não foi possível preparar a sessão do Publisher.","chromeSessionHint":"Chrome: executa o marcador MILO. Para cada banner acabado de preparar, o Chrome pede explicitamente MILO_CurrentBanner.json. Não é preciso fazer mais nada entre missões.","firefoxSessionHint":"Firefox: o Publisher abre automaticamente. Carrega MILO_CurrentBanner.json se a sessão atual ainda não for conhecida.","easterEgg":"Tu é que pediste isto.","bannerNameSearch":"Nome / palavra-chave","citySearch":"Cidade","authorSearch":"Autor","cityPlaceholder":"ex.: Nantes","authorPlaceholder":"ex.: AgentName","nearMe":"Perto de mim","nearMeOn":"A minha localização está ativa","nearMeHint":"Usa a tua posição atual em vez de uma cidade.","locationGetting":"A obter localização…","locationError":"Não foi possível obter a localização: {error}","locationReady":"Localização obtida","searchCriteriaRequired":"Introduz pelo menos um critério de pesquisa.","cityResolving":"A procurar cidade…","cityNotFound":"Não foi encontrado nenhum local Bannergress para “{city}”.","cityUsing":"Local utilizado: {city}","bannerAuthor":"Autor: {author}","overlayDrag":"≡  Mover","overlayMinimize":"Minimizar","overlayClose":"Fechar","overlayMoved":"Posição da sobreposição guardada","searchReset":"Limpar","resultsCount":"{n} resultado(s)","searchFilters":"Filtros ativos","allPublicBanners":"Banners públicos do Bannergress","searchRadius":"Raio de pesquisa","radiusHint":"Aplicado em torno da cidade ou da tua posição atual.","locationDisabled":"Os serviços de localização estão desativados neste telemóvel.","locationPermissionDenied":"O BannerLab não tem permissão para usar a tua localização.","locationUnavailable":"Localização indisponível. Confirma se os serviços de localização do telemóvel estão ativos.","locationTimeout":"Não foi possível obter a localização a tempo. Confirma se os serviços de localização estão ativos.","openLocationSettings":"Ativar localização","openAppSettings":"Abrir definições da aplicação","cityNoCoordinates":"“{city}” foi encontrada, mas a sua posição não pode ser utilizada.","cityUsingRadius":"A usar: {city} · raio de {radius} km","radiusResults":"{n} resultado(s) num raio de {radius} km","distanceFromPoint":"a {distance}","locationChecking":"A verificar serviços de localização…","publisherCurrentFile":"Ficheiro atual: Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json","chromeFilePath":"Le Publisher sera enregistré dans le dossier que tu choisis.","chromeFileSaved":"Publisher guardado em Téléchargements/RedactedBannerLab.","chromeFileWriteFail":"Não foi possível guardar o Publisher em Téléchargements/RedactedBannerLab.","chromeCurrentSessionHint":"Para cada banner novo: escolhe Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json.","browserResume":"Sessão preparada. A abrir o separador RBL do Mission Authoring…","chromeResumeHint":"O Chrome reutiliza agora o mesmo separador do Mission Authoring reservado ao RBL.","firefoxResumeHint":"A abrir Mission Authoring no navegador de publicação.","browserResumeFallback":"Não foi possível reutilizar o separador RBL. A abrir o navegador como alternativa.","publisherAutoRefresh":"O Publisher passa a vigiar o ficheiro da sessão atual e recarrega automaticamente um novo banner preparado.","flowLocked":"Edição do banner bloqueada","flowLockedText":"O passo {step} está ativo. Seleciona “1 Banner” para editar a imagem, o texto ou o enquadramento.","returnFresco":"Seleciona 1 Banner para editar","flowLockedToast":"Volta ao passo 1 Banner para editar o banner.","publisherTabReuse":"O RBL usa um identificador fixo da aplicação do navegador para reutilizar o mesmo separador.","todo":"A fazer","history":"Histórico","inProgress":"Em curso","addTodo":"Adicionar a A fazer","removeTodo":"Remover de A fazer","noTodo":"Não há banners por fazer. Suspeitosamente sensato.","noHistory":"Ainda não jogaste nenhum banner. O dinossauro está aborrecido.","bannerMap":"Mapa do percurso","openMap":"Ver mapa","navigateStart":"Navegar até ao início","startUnavailable":"Ponto de partida indisponível.","mapUnavailable":"O Bannergress não fornece coordenadas utilizáveis para este banner.","startPoint":"Início","missionStart":"Missão {n}","shareGroup":"Partilhar / grupo","shareProgress":"Partilhar progresso","shareBanner":"Partilhar banner","shareIntro":"O QR abre o RBL no mesmo banner e no mesmo número de missão. Não é usada nenhuma conta Bannergress.","copyLink":"Copiar link RBL","linkCopied":"Link RBL copiado","shareNow":"Partilhar","bannergressPage":"Abrir no Bannergress","joinBanner":"Entrar no banner","joinAtMission":"Entrar na missão {n}","sharedBannerLoaded":"Banner partilhado carregado · missão {n}","sharedBannerError":"Não foi possível carregar o banner partilhado: {error}","playStats":"Estatísticas da sessão","startedAt":"Iniciado","finishedAt":"Terminado","elapsed":"Tempo ativo","estimatedDistance":"Distância estimada","missionsDone":"Missões concluídas","paused":"Em pausa","playing":"Em curso","completedBanner":"Concluído","replayBanner":"Jogar novamente","resumeFromHistory":"Retomar","groupNoServer":"Modo de grupo sem servidor: volta a partilhar o QR/link se o grupo passar para outra missão.","publicOnly":"Apenas pesquisa/dados públicos do Bannergress · sem início de sessão.","routePoints":"{n} pontos no percurso","uselessStats":"Estatísticas inúteis","loadingStats":"A calcular coisas que ninguém pediu…","statsUnavailable":"Não há coordenadas suficientes para calcular estatísticas inúteis.","bgDistance":"Distância Bannergress","calculatedTrack":"Distância estimada a pé","walkingEstimate":"Tempo estimado a pé","routeSteps":"Passos","uniquePlaces":"Locais únicos","revisitedPlaces":"Visitas repetidas","stepsPerKm":"Passos / km","avgMissionDistance":"Média / missão","longestMission":"Missão mais longa","longestLeg":"Troço mais longo","betweenMissions":"Transições entre missões","detourFactor":"Fator de desvio","routeCoverage":"Cobertura do mapa","missionShort":"M{n}","straightLine":"Início → fim","funStatsDisclaimer":"O RBL calcula cada troço entre portais na rede pedonal do OpenStreetMap. Cada troço é verificado: atalhos impossíveis ou desvios claramente absurdos são substituídos apenas nesse troço pela distância direta. É uma estimativa a pé, não uma medição GPS.","minutesShort":"{n} min","hoursMinutes":"{h} h {m} min","xFactor":"×{n}","showUselessStats":"📊 Estatísticas inúteis","hideUselessStats":"Ocultar estatísticas","statsLoaded":"Estatísticas calculadas","directGeometric":"Distância direta acumulada","routingDetour":"Relação rede / direto","routingSource":"Roteamento","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla indisponível · estimativa geométrica","routingLoading":"A calcular o percurso pedonal real…","routingFailed":"Roteamento pedonal indisponível; foram usadas estatísticas geométricas.","routingNative":"Valhalla + OSM · verificação por troço","routingWeb":"Valhalla + OSM · verificação por troço","routingErrorDetail":"Falha do Valhalla: {error}","ingressRadius":"Alcance Ingress","ingressRadiusValue":"40 m","correctedLegs":"Troços corrigidos","rawValhalla":"Valhalla bruto","creditsTitle":"Créditos & agradecimentos","bannergressThanks":"Obrigado, Bannergress","bannergressThanksText":"A pesquisa de banners e vários detalhes públicos apresentados no Redacted BannerLab usam dados públicos do Bannergress. Obrigado à equipa e aos colaboradores pelo enorme trabalho em torno dos banners de Ingress.","bannergressNoLogin":"O RBL não usa uma conta Bannergress: apenas os dados públicos necessários para pesquisar e mostrar banners.","independentProject":"O Redacted BannerLab é um projeto independente e não é afiliado nem aprovado pelo Bannergress ou pelos serviços oficiais de Ingress.","visitBannergress":"Visitar Bannergress","mapCredits":"Mapas & roteamento","mapCreditsText":"Os mapas usam dados do OpenStreetMap. As estimativas de percurso pedonal usam o motor de roteamento Valhalla.","rblCreditsFoot":"Obrigado a todas as ferramentas e colaboradores que tornam possível este ecossistema de missões Ingress.","layersTitle":"Imagens & camadas","layersDesc":"Gere aqui o fundo e todas as imagens sobrepostas. As miniaturas ajudam a identificar a camada certa; depois podes selecioná-la, ocultá-la, reordená-la ou agrupá-la.","backgroundLayer":"Fundo principal","addBackground":"Adicionar / substituir fundo","addLayer":"Adicionar camada","layerName":"Camada de imagem","selected":"Selecionada","visibleLayer":"Visível","hiddenLayer":"Oculta","moveUp":"Subir","moveDown":"Descer","groupSelection":"Agrupar seleção","group":"Agrupar","ungroup":"Desagrupar","groupNeedTwo":"Seleciona pelo menos duas camadas para as agrupar.","groupCreated":"Camadas agrupadas","groupRemoved":"Grupo desfeito","deleteLayer":"Eliminar camada","layerDeleted":"Camada eliminada","layerAdded":"Camada adicionada","backgroundReplaced":"Fundo substituído","backgroundMissing":"Sem fundo principal","backgroundFixed":"O fundo fica sempre por baixo das restantes camadas.","groupHint":"Seleciona várias camadas e toca em Agrupar. Um grupo move-se, amplia-se e roda em conjunto.","layerOrder":"Ordem das camadas","layerTransform":"Transformar camada","groupTransform":"Transformar grupo","renameLayer":"Mudar nome","duplicateLayer":"Duplicar","layerDuplicated":"Camada duplicada","histAddLayer":"Adicionar camada","histDeleteLayer":"Eliminar camada","histReorderLayer":"Reordenar camada","histGroupLayers":"Agrupar camadas","histUngroupLayers":"Desagrupar camadas","histVisibilityLayer":"Visibilidade da camada","histRenameLayer":"Mudar nome da camada","histDuplicateLayer":"Duplicar camada","layerGroupBadge":"Grupo","layerUngroup":"Desagrupar este grupo","layerSelectHint":"Depois de selecionada, a camada pode ser movida diretamente sobre o banner.","layerOpacity":"Opacidade","layerDimensions":"{w} × {h} px","noImageContent":"Adiciona pelo menos uma imagem antes de exportar.","groupRelative":"Os controlos abaixo transformam o grupo inteiro em conjunto.","groupZoom":"Zoom do grupo","groupRotation":"Rotação do grupo","clearGroupSelection":"Limpar seleção","allLayersTitle":"Camadas","allLayersDesc":"Seleciona o elemento que queres manipular. Imagens e textos continuam editáveis nos respetivos menus.","imageLayersSection":"Imagens","textLayersSection":"Texto","noExtraImageLayer":"Nenhuma camada de imagem adicional","noTextLayer":"Nenhuma camada de texto","selectLayer":"Selecionar","editLayer":"Editar","missionNumberQuestion":"Qual é o número da missão?","groupName":"Grupo {n}","groupCount":"{n} camada(s)","creatorBy":"Criado por Zw4nn","communityTitle":"Comunidade & suporte","communityText":"Acede à comunidade e ao suporte diretamente através do bot Redacted BannerLab.","telegramOpen":"Contactar suporte","reportProblem":"Comunicar um problema","reportProblemText":"Copia um diagnóstico técnico e depois contacta o suporte através do bot.","copyDiagnostic":"Copiar diagnóstico","diagnosticCopied":"Diagnóstico copiado","diagnosticCopyFailed":"Não foi possível copiar o diagnóstico","diagnosticDescription":"Descrição do problema:","portableProject":"Projeto portátil","portableProjectDesc":"Exporta um único banner com imagens, camadas, texto, fontes, missões e percurso.","exportProject":"Exportar","shareProject":"Partilhar","importProject":"Importar projeto","projectExporting":"A preparar projeto…","projectExported":"Projeto guardado","projectShared":"Projeto pronto a partilhar","projectImportSuccess":"Projeto importado","projectImportInvalid":"Este ficheiro não é um projeto Redacted BannerLab válido.","projectShareTitle":"Projeto Redacted BannerLab","projectImportHint":"O projeto importado é adicionado sem alterar os teus outros projetos.","backupTitle":"Cópia de segurança & restauro","backupText":"Guarda todos os projetos, definições e imagens do BannerLab num único ficheiro JSON portátil.","backupFolder":"Pasta de cópias de segurança","backupFolderChoose":"Escolher pasta","backupFolderChange":"Mudar pasta","backupFolderNone":"Nenhuma pasta selecionada","backupFolderReady":"Pasta configurada","backupAuto":"Cópia de segurança automática em segundo plano","backupAutoHint":"Quando ativada, o BannerLab prepara regularmente uma cópia de segurança após as tuas alterações e força uma gravação final quando a aplicação passa para segundo plano.","backupNow":"Fazer cópia agora","backupExport":"Exportar JSON","backupImport":"Importar JSON","backupWorking":"A criar cópia de segurança…","backupSaved":"Cópia de segurança concluída","backupAutoSaved":"Cópia automática concluída","backupFailed":"Falha na cópia de segurança: {error}","backupNeedFolder":"Escolhe primeiro uma pasta de cópias de segurança.","backupFolderError":"Não foi possível usar esta pasta.","backupImported":"Cópia de segurança restaurada","backupInvalid":"Este ficheiro não é uma cópia de segurança válida do Redacted BannerLab.","backupImportTitle":"Restaurar cópia de segurança","backupImportText":"{n} projeto(s) encontrado(s) · cópia de {date}","backupMerge":"Fundir","backupReplace":"Substituir tudo","backupReplaceWarn":"Substituir tudo elimina os projetos atualmente guardados neste dispositivo antes do restauro.","backupCancel":"Cancelar","backupLast":"Última cópia: {date}","backupNever":"Ainda não há cópia de segurança","backupPortable":"O JSON também contém as imagens. Pode por isso ficar grande, mas é completamente autónomo.","backupNativeOnly":"A cópia automática para pasta está disponível no Android. A exportação/importação JSON continua disponível em todas as plataformas.","backupFolderChosen":"Pasta de cópias guardada","backupNoChanges":"Não há alterações para guardar.","studioEdit":"Editar em ecrã inteiro","studioTitle":"Estúdio de edição","studioLayers":"Camadas","studioTexts":"Texto","studioTools":"Ferramentas","studioFit":"6 missões","studioFitOne":"1 missão","studioFitAll":"Tudo","studioMissionMode":"Missão","studioFrescoMode":"Banner","studioFullscreen":"Ecrã inteiro","studioRotateHint":"6 missões na vertical · as linhas seguintes deslocam-se para a direita.","studioSelected":"Elemento selecionado","studioNoLayer":"Seleciona uma camada ou um texto na lateral.","studioGroupSelect":"Agrupar seleção","studioGroupNow":"Agrupar","studioOpenFull":"Abrir gestor completo","studioOpacity":"Opacidade","studioClose":"Sair do estúdio","studioPan":"Deslocar","studioAddText":"Adicionar texto","studioNoText":"Ainda não há texto.","studioEditText":"Editar texto","studioDuplicateText":"Duplicar texto","font":"Fonte","fontWeight":"Espessura","fontItalic":"Itálico","letterSpacing":"Espaçamento entre letras","lineHeight":"Altura da linha","textAlign":"Alinhamento","alignLeft":"Esquerda","alignCenter":"Centro","alignRight":"Direita","importFont":"Importar fonte","fontImported":"Fonte importada: {name}","fontInvalid":"Esta fonte não é suportada.","fontTooLarge":"A fonte é demasiado grande (máx. 12 MB).","textBackground":"Fundo do texto","textBackgroundColor":"Cor do fundo","textBackgroundOpacity":"Opacidade do fundo","textBackgroundPadding":"Margem interna do fundo","textBackgroundRadius":"Raio dos cantos","textTypography":"Tipografia","tutorialHubTitle":"Tutoriais & primeiros passos","tutorialHubText":"Volta a iniciar uma visita guiada quando quiseres. O Redacted pode explicar apenas a parte de que precisas.","tutorialOpen":"Ver tutoriais","tutorialWelcomeTitle":"Bem-vindo ao Redacted BannerLab","tutorialWelcomeText":"O Redacted pode mostrar-te o laboratório. Dois minutos, alguns botões e nem sequer há exame no fim.","tutorialStart":"Iniciar visita","tutorialLater":"Mais tarde","tutorialNever":"Não voltar a mostrar","tutorialPrevious":"Anterior","tutorialNext":"Seguinte","tutorialUnderstood":"OK, percebi","tutorialClose":"Fechar","tutorialDone":"Tutorial concluído","tutorialSeen":"Visto","tutorialQuick":"Visita rápida","tutorialQuickDesc":"Os controlos essenciais e o fluxo geral do BannerLab.","tutorialBanner":"Criar um banner","tutorialBannerDesc":"Do projeto à pré-visualização e exportação das missões.","tutorialLayers":"Imagens, camadas & texto","tutorialLayersDesc":"Fundo, imagens sobrepostas, camadas e ferramentas de tipografia.","tutorialIitc":"Criar o percurso com IITC","tutorialIitcDesc":"Instala o IGOR, adiciona portais e sincroniza o percurso.","tutorialPublish":"Publicar missões","tutorialPublishDesc":"Prepara as missões e depois usa o Publisher e o Mission Authoring.","tutorialBackup":"Cópias de segurança & projetos portáteis","tutorialBackupDesc":"Faz uma cópia do BannerLab ou partilha um banner completo.","importRolesHint":"Fundo principal = imagem base do banner · Camada = imagem adicional sobreposta.","tutProjectTitle":"Os teus projetos","tutProjectText":"Cada banner vive no seu próprio projeto. Podes exportá-lo ou partilhá-lo sem levar todos os outros projetos atrás.","tutNameTitle":"Nome do projeto","tutNameText":"Dá ao banner um nome que reconheças mais tarde.","tutRowsTitle":"Número de linhas","tutRowsText":"Cada linha contém 6 missões. Escolhe aqui a altura final do banner.","tutImageTitle":"Imagens & camadas","tutImageText":"Importa aqui o fundo principal e imagens adicionais. Neste mesmo ecrã também podes selecionar, ordenar, ocultar e agrupar camadas de imagem.","tutBackgroundTitle":"Fundo principal","tutBackgroundText":"Para a primeira imagem real, usa Fundo principal. Substitui a imagem base e cobre o banner.","tutExtraLayerTitle":"Adicionar camada","tutExtraLayerText":"Uma segunda imagem torna-se uma camada: fica por cima do fundo e continua móvel, redimensionável e ocultável.","tutLayersTitle":"Gerir camadas de imagem","tutLayersText":"As miniaturas mostram qual camada estás a manipular. Seleciona-a, muda a ordem, oculta-a ou marca várias imagens para as agrupar.","tutTextTitle":"Texto","tutTextText":"Adiciona texto, escolhe fontes, espaçamento, fundo e raio dos cantos ou importa a tua própria fonte.","tutPreviewTitle":"Pré-visualização","tutPreviewText":"Verifica cada missão antes de exportar. Os enquadramentos individuais já estão aplicados.","tutExportTitle":"Exportar","tutExportText":"Quando estiver tudo pronto, o BannerLab cria as imagens 512 × 512 das missões pela ordem correta.","tutStudioTitle":"Estúdio em ecrã inteiro","tutStudioText":"Um editor mais confortável em ecrã inteiro, com controlos laterais e grandes zonas táteis.","tutFlowTitle":"Os 4 passos","tutFlowText":"Banner → Percurso → Missões → Publicar. O BannerLab segue este fluxo.","tutRouteTitle":"Percurso","tutRouteText":"O percurso liga as missões a portais reais do Ingress. O IITC Companion trata do trabalho no mapa.","tutCompanionTitle":"IITC Companion","tutCompanionText":"O Companion leva para o IITC o projeto ativo, a missão, os portais, as ações e as estatísticas de caminhada.","tutInstallCompanionTitle":"Instalar Companion","tutInstallCompanionText":"Instala ou atualiza uma vez o userscript no IITC Mobile.","tutOpenIitcTitle":"Abrir IITC","tutOpenIitcText":"Abre o IITC a partir do BannerLab para enviar o projeto e a missão ativa ao IGOR.","tutAutoRouteTitle":"Passar entre missões","tutAutoRouteText":"A missão seguinte pode abrir automaticamente e reutilizar o último portal da missão anterior como primeiro.","tutPortalListTitle":"Os teus portais","tutPortalListText":"Os portais regressam com GUID, coordenadas, ordem e ação, para que o percurso possa ser reconstruído.","tutMissionsTitle":"Preparar missões","tutMissionsText":"Antes de publicar, indica a descrição comum e verifica cada missão.","tutMissionDescTitle":"Descrição obrigatória","tutMissionDescText":"O BannerLab assinala informação em falta antes de permitir a publicação.","tutPublishTitle":"Publicar","tutPublishText":"Quando percurso e descrições estiverem prontos, continua aqui. A submissão final continua na ferramenta oficial.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"O BannerLab prepara os dados das missões e o fluxo de publicação. Depois da submissão, usa “Já submeti” para confirmar o estado publicado.","tutInfoTitle":"Definições, ajuda & suporte","tutInfoText":"Definições & info contém idioma, cópias de segurança, tutoriais e suporte através do bot Redacted BannerLab.","tutBackupTitle":"Cópia de segurança completa","tutBackupText":"O JSON completo inclui todos os projetos, definições, imagens e fontes. No Android também podes usar uma pasta de cópia automática.","tutPortableTitle":"Projeto portátil","tutPortableText":"Exporta, partilha ou importa um único banner com imagens, texto, fontes, missões e percurso.","tutSupportTitle":"Precisas de ajuda?","tutSupportText":"Copia o diagnóstico se for necessário e contacta o suporte. O bot também dá acesso ao canal e ao grupo de discussão.","settingsInfo":"Definições & info","addMissionLayer":"Numa missão","importMissionSeries":"Importar série","missionLayer":"Camada de missão","globalLayer":"Camada global","layerScope":"Âmbito da camada","wholeBanner":"Banner completo","missionTarget":"Missão associada","fitMode":"Ajuste","fitCover":"Preencher","fitContain":"Conter","missionBadge":"M{n}","missionLayerHint":"Esta camada fica associada à missão {n} e é automaticamente limitada à respetiva célula.","missionSeriesTitle":"Importar série de missões","missionSeriesText":"Associa cada imagem a uma missão. O BannerLab posiciona e recorta tudo automaticamente.","missionSeriesDetected":"{n} imagem(ns) detetada(s)","missionSeriesImport":"Importar camadas","missionSeriesTooMany":"Selecionaste mais imagens do que missões. Podes associar várias imagens à mesma missão.","missionLayerAdded":"Imagem adicionada à missão {n}","missionSeriesAdded":"{n} camada(s) de missão adicionada(s)","missionScopeMismatch":"As camadas de missão só podem ser agrupadas quando pertencem à mesma missão.","missionLayerTutorialTitle":"Camadas associadas a missões","missionLayerTutorialText":"Toca em “Adicionar camada” e escolhe: banner completo, uma missão ou várias missões. Para uma missão, o BannerLab posiciona e limita automaticamente a imagem à respetiva célula. Para várias missões, importa uma série e associa cada imagem à missão pretendida.","addLayerChoiceTitle":"Adicionar camada","addLayerChoiceText":"Escolhe onde esta camada deve ficar. Podes alterar o âmbito mais tarde.","addLayerWhole":"No banner completo","addLayerWholeText":"Uma imagem livre sobre todo o banner, móvel e redimensionável.","addLayerOneMission":"Numa missão","addLayerOneMissionText":"Uma imagem posicionada automaticamente e limitada à missão selecionada.","addLayerManyMissions":"Em várias missões","addLayerManyMissionsText":"Importa uma série de imagens e associa cada uma à missão que quiseres.","multiSelection":"Seleção múltipla","multiSelectionHint":"Marca várias camadas para aplicar uma ação comum, agrupá-las ou eliminá-las.","selectionActions":"Ações da seleção","editSelection":"Editar seleção","deleteSelection":"Eliminar seleção","selectedLayersCount":"{n} camada(s) selecionada(s)","bulkScopeKeep":"Manter âmbito atual","bulkMissionKeep":"Manter missões atuais","bulkFitKeep":"Manter ajuste atual","bulkVisibility":"Visibilidade","bulkVisibilityKeep":"Não alterar","bulkShow":"Mostrar","bulkHide":"Ocultar","bulkOpacityEnable":"Alterar opacidade","applyToSelection":"Aplicar às camadas selecionadas","selectionUpdated":"Camadas selecionadas atualizadas","selectionDeleted":"Camadas selecionadas eliminadas","deleteSelectionConfirm":"Eliminar definitivamente {n} camada(s) selecionada(s)?","selectionEmpty":"Seleciona pelo menos uma camada.","layerScopeHelp":"Banner completo: a camada pode cobrir todo o banner. Uma missão: fica automaticamente limitada à missão escolhida. Várias missões: importa uma série e associa cada imagem à respetiva missão."};
I18N["nl"]={"fresco":"Banner","route":"Route","missions":"Missies","publish":"Publiceren","projects":"Projecten","rows":"Rijen","image":"Afbeeldingen","framing":"Uitsnede","layers":"Lagen","text":"Tekst","preview":"Voorbeeld","export":"Exporteren","wholeFresco":"Hele banner","oneMission":"Eén missie","noMission":"Geen missie geselecteerd","addImage":"Voeg je afbeelding toe","imageHint":"De afbeelding wordt direct op de Prime-geometrie uitgesneden.","circles":"Prime-cirkels","grid":"512-raster","numbers":"Nummers","enlarge":"Missie vergroten","resetMission":"Missie resetten","prev":"Vorige","next":"Volgende","complete":"Missie voltooid","remaining":"Nog {n} portal(s)","openIitc":"IITC Companion openen","tutorial":"Handleiding","installPlugin":"IITC-plugin installeren / bijwerken","autoAdvance":"Na {n} portals automatisch naar de volgende missie gaan","reuseLast":"Laatste portal automatisch als eerste portal van de volgende missie gebruiken","noPortal":"Deze missie heeft nog geen portals.","action":"Actie","hack":"Hack","mod":"Mod installeren","capture":"Veroveren / upgraden","link":"Link maken","field":"Field maken","passphrase":"Passphrase","question":"Vraag","answer":"Verwacht antwoord","save":"Opslaan","cancel":"Annuleren","settings":"Algemene instellingen","commonDesc":"Algemene beschrijving","titleFormat":"Titelopmaak","defaultType":"Standaardtype","location":"Locatie","visible":"Zichtbaar","hidden":"Verborgen","sequential":"Op volgorde","anyOrder":"Willekeurige volgorde","portalsPerMission":"Portals / missie","editMission":"Missie bewerken","title":"Titel","description":"Beschrijving","missionReady":"Klaar","missionIncomplete":"Onvolledig","openRoute":"Route bewerken","publishPack":"BannerLab-pakket maken","openMat":"Mission Authoring Tool openen","ownWorkflow":"BannerLab gebruikt nu zijn eigen projectformaat en publicatiepakket.","language":"Taal","french":"Français","english":"English","spanish":"Español","companionStats":"Wandelstatistieken in IITC","companionStatsDesc":"In het IITC-minipaneel berekent 📊 Nutteloze statistieken de geschatte wandelafstand, tijd, omwegen en andere onzin.","duplicateBad":"{n} hergebruikte portal(s) controleren.","handoverOk":"Hergebruik van missie-einde → start van de volgende missie is toegestaan.","pluginVersion":"IGOR 0.6.35","undo":"Ongedaan maken","redo":"Opnieuw","subtitle":"Ingress Prime-banners","source":"bron","bannerHelp":"<b>Bannermodus:</b> met 1 vinger verplaats je de geselecteerde laag. Met <b>2 vingers</b> zoom en draai je.","missionHelp":"<b>Missiemodus:</b> tik op een medaillon. Gebruik <b>Missie vergroten</b> voor comfortabeler bewerken. Je kunt de missie hier ook met 1 vinger verplaatsen.","missionSelected":"Missie {n} geselecteerd","tapMedallion":"Tik op een medaillon","touchMissionFirst":"Tik eerst op de missie waarvan je de uitsnede wilt aanpassen.","selectMissionFirst":"Selecteer eerst een missie.","heavyImage":"Erg grote afbeelding. Je telefoon kan hierdoor zijn levenskeuzes gaan heroverwegen.","imported":"Geïmporteerd: {w} × {h} px","textLayerDesc":"Elke tekst blijft een aparte laag die je afzonderlijk kunt bewerken of verwijderen.","layer":"Laag","newText":"+ Nieuwe tekst","size":"Grootte","outline":"Omlijning","color":"Kleur","outlineColor":"Kleur omlijning","add":"Toevoegen","update":"Bijwerken","delete":"Verwijderen","zoom":"Zoom","localZoom":"Lokale zoom","rotation":"Rotatie","center":"Centreren","reset":"Resetten","done":"Klaar","transformText":"Tekst transformeren","frameImage":"Afbeelding kaderen","pinchHint":"Gebaren met twee vingers blijven rechtstreeks op de banner beschikbaar.","missionCropOnly":"Deze uitsnede geldt alleen voor dit medaillon.","resetThisMission":"Deze missie resetten","individualCrop":"Individuele uitsnede · 512 × 512","oneFinger":"1 vinger","move":"verplaatsen","twoFingers":"2 vingers","zoomRotate":"zoomen en draaien","previewPrime":"Prime-voorbeeld","previewApplied":"Individuele missie-aanpassingen zijn al toegepast.","previewOrder":"Nummer 1 staat rechtsonder; daarna loopt de nummering naar links en vervolgens rij voor rij omhoog.","exportTitle":"{n} missies exporteren","exportIntro":"Kies snelheid of verliesvrije PNG. Beide blijven 512 × 512.","noBackground":"Er is geen achtergrondafbeelding geladen.","missionFormat":"Missieformaat","jpgFast":"Snelle JPG · hoge kwaliteit","pngLossless":"Verliesvrije PNG · langzamer","fastEncoding":"De snelle modus vermijdt PNG-codering, veruit het langzaamste deel op een telefoon.","rowRender":"De achtergrond wordt één keer per rij gerenderd in plaats van zes keer opnieuw berekend.","adjusted":"{n} missie(s) met individuele uitsnede.","nianticCheck":"Controleer vóór het indienen de Niantic-regels: afbeeldingsrechten, relevante inhoud en geen dominant enkel teken.","ready":"Klaar.","createZip":"ZIP maken","zipAssembly":"ZIP wordt opgebouwd…","zipCreated":"ZIP gemaakt.","zipDownloaded":"ZIP gedownload.","saveShareZip":"ZIP opslaan of delen","exportFinished":"{format}-export voltooid","exportFailed":"Export mislukt.","newProject":"Nieuw project","myProjects":"Mijn projecten","projectsSaved":"{n} project(en) opgeslagen op deze telefoon.","unnamed":"Naamloos","opened":"Geopend","open":"Openen","rename":"Hernoemen","copy":"Kopiëren","noSavedProject":"Geen opgeslagen project.","renameProject":"Project hernoemen","renameHint":"Een naam die mensen kunnen lezen. Verrassend geavanceerd concept.","projectName":"Projectnaam","projectOpened":"Project geopend: {name}","projectRenamed":"Project hernoemd","deleteProject":"Dit project verwijderen?","deleteWarning":"De banner en de lokaal opgeslagen afbeelding worden verwijderd.","copyCreated":"Kopie gemaakt","projectDeleted":"Project verwijderd","newProjectCreated":"Nieuw project gemaakt met Redacted","defaultProject":"Mijn banner","defaultNewProject":"Nieuwe banner","copySuffix":"kopie","versionLabel":"Versie","infoPrime":"6 kolommen · 544 px · uitsnede van 512 px.","infoPlanner":"portalacties, passphrases, overdracht einde→start en het native BannerLab-pakket.","infoCompanion":"routes, acties, meerdere missies, opties en wandelstatistieken.","disclaimer":"Ingress en Ingress Prime zijn handelsmerken van Niantic. Redacted BannerLab is niet verbonden met of goedgekeurd door Niantic.","titleTokens":"$T = naam · $N = nummer · $M = totaal · $0N = 01, 02…","pluginShareText":"Companion-plugin 0.6.9. Vervang de vorige versie in IITC Mobile. Als IITC hem niet wil overschrijven, verwijder de oude plugin één keer en installeer dit bestand.","pluginDialog":"IGOR 0.6.35 installeren / bijwerken","pluginShareFailed":"IITC-plugin kon niet worden gedeeld.","intelOpened":"IITC Mobile geopend met het BannerLab-project.","intelPrimeOpened":"IITC Prime geopend met het BannerLab-project.","intelFallback":"IITC Mobile geopend. Companion gebruikt de laatst gesynchroniseerde status.","intelPrimeFallback":"IITC Prime geopend. Companion gebruikt de laatst gesynchroniseerde status.","intelBrowser":"IITC niet gevonden: openen in browser.","tutorialIntro":"Bouw de volledige banner in IITC zonder na elke portal terug te keren naar BannerLab.","tut1Title":"Installeer de plugin één keer","tut1Text":"Gebruik onder Route “IITC-plugin installeren / bijwerken” en voeg het bestand daarna als gebruikersplugin toe in IITC Mobile.","tut2Title":"Open IITC vanuit BannerLab","tut2Text":"BannerLab geeft project, actieve missie en taal via een lokaal fragment door aan Companion. De Intel-server krijgt die gegevens nooit te zien.","tut3Title":"Bouw rechtstreeks op de kaart","tut3Text":"Met Companion kun je portals toevoegen, bewerken of verwijderen, van missie wisselen en routes bekijken zonder terug te gaan naar BannerLab.","tut4Title":"Synchroniseer als je klaar bent","tut4Text":"“BannerLab synchroniseren” stuurt alle bewerkte missies terug naar het project en opent BannerLab opnieuw.","tutNote":"Je kunt Companion verplaatsen en van grootte veranderen; de instellingen blijven onder Opties bewaard.","installUpdate":"Installeren / bijwerken","emptyTitleIssue":"Missie {n}: titel ontbreekt","emptyDescIssue":"Missie {n}: beschrijving ontbreekt","portalsIssue":"Missie {n}: {count}/{need} portals","missingGuidIssue":"Missie {n}: {count} ontbrekende GUID(s)","passIssue":"Missie {n}: {count} onvolledige passphrase(s)","reviewCount":"{n} punt(en) controleren","projectReady":"BannerLab-project klaar","fixBeforePublish":"Los deze punten op vóór publicatie.","publisherDesc":"De volgende brug vult het Mission Authoring Tool rechtstreeks vanuit dit native formaat. Het definitieve indienen blijft bewust in de officiële tool.","packCreating":"BannerLab-pakket wordt gemaakt…","packCreated":"BannerLab-pakket gemaakt","exportImpossible":"Export niet mogelijk: {error}","missionResetDone":"Missie {n} gereset","textDeleted":"Tekst verwijderd","histImport":"Afbeelding importeren","histMissionZoom":"Missiezoom","histMissionRotation":"Missierotatie","histTextRotation":"Tekstrotatie","histImageRotation":"Afbeeldingsrotatie","histTextZoom":"Tekstzoom","histImageZoom":"Afbeeldingszoom","histCenterText":"Tekst centreren","histCenterImage":"Afbeelding centreren","histResetText":"Tekst resetten","histResetImage":"Afbeelding resetten","histResetMission":"Missie resetten","histDeleteText":"Tekst verwijderen","histAddText":"Tekst toevoegen","histEditText":"Tekst bewerken","routeActionHelp":"Hack / Mod / Veroveren / Link / Field / Passphrase rechtstreeks vanuit Companion.","handoverDetail":"De laatste portal kan de eerste van de volgende missie worden zonder als ongeldig duplicaat te gelden.","coordsMissing":"Coördinaten niet gevonden.","coordsInvalid":"Ongeldige coördinaten.","duplicateElsewhere":"Deze portal wordt elders in de banner al gebruikt.","missionCompleteAdded":"Missie {n} voltooid · {next}","portalAdded":"Portal toegevoegd · missie {n}","syncOld":"Route gesynchroniseerd · ouIGOR gevonden: installeer versie 0.6.9.","syncOk":"IITC-route gesynchroniseerd · Companion {v}.","portalDefault":"Portal","bannerDefault":"Banner","livePublish":"Rechtstreeks voorbereiden in Mission Authoring","livePublishShort":"Directe Publisher","livePreparing":"{n} missies voorbereiden voor Publisher…","liveReady":"Geïntegreerde Publisher openen…","liveNativeOnly":"Directe Publisher is beschikbaar in de Android-APK.","liveFailed":"Publisher kon niet worden geopend: {error}","liveExperimental":"Experimenteel: Mission Authoring opent in een door RBL beheerde weergave. Google-aanmelding is het eerste dat je op je telefoon moet controleren.","backupTransfer":"Back-up / overdracht","exportPackBackup":"BannerLab-pakket exporteren","openOfficialOnly":"Alleen officiële site openen","publisherPreparingImage":"Missie {n}/{total} renderen…","browserPublish":"Publiceren in Firefox","browserPublishShort":"Browser-Publisher","browserSetup":"Browser-Publisher installeren / bijwerken","browserPreparing":"Missie {n}/{total} voorbereiden…","browserOpening":"Firefox openen…","browserNeed":"Directe Publisher gebruikt Firefox Android + Violentmonkey zodat Google-aanmelding in een gewone browser blijft.","browserFailed":"Publisher kon niet worden geopend: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab voor missions.ingress.com. Installeer hem één keer in Violentmonkey op Firefox Android.","browserShareDialog":"Publisher 0.4.8 installeren","browserShareFailed":"Browser-Publisher kon niet worden gedeeld.","publisherUrlTooLarge":"Deze missie is te groot om naar de browser te sturen.","publisherReturn":"Teruggekeerd uit Publisher.","publisherNoFirefox":"Firefox is niet gevonden. De standaardbrowser wordt geopend, maar Publisher vereist een browser met userscript-ondersteuning.","publisherBrowser":"Publicatiebrowser","chromeMode":"Chrome","chromeModeSub":"Geen extra app · klein bladwijzer-script + Toestaan wanneer gevraagd","firefoxMode":"Firefox","firefoxModeSub":"Automatisch na installatie van Violentmonkey + Publisher","recommendedAuto":"Automatisch","noExtraApp":"Geen extra app","publishSelected":"Missie publiceren","chromeSetup":"Chrome instellen","firefoxSetup":"Firefox instellen","chromeReady":"Chrome-bladwijzer gecontroleerd","firefoxReady":"Firefox-Publisher gecontroleerd","notConfigured":"Eenmalige instelling vereist","chromeSetupTitle":"Chrome-Publisher","chromeSetupIntro":"Chrome laat RBL de bladwijzer niet voor je aanmaken. De instelling is daarom tot het minimum beperkt.","chromeStep1":"1. Kopieer de code van de MILO-bladwijzer.","chromeStep2":"2. Open Mission Authoring in Chrome en maak een bladwijzer van de pagina.","chromeStep3":"3. Bewerk die bladwijzer: noem hem “MILO” en vervang de URL door de gekopieerde code.","chromeStep4":"4. Tik in Mission Authoring op de adresbalk, typ “RBL” en kies de bladwijzer om te testen.","copyBookmarklet":"Bladwijzercode kopiëren","bookmarkletCopied":"Bladwijzercode gekopieerd","openChromeSetup":"Chrome openen voor instelling","testChrome":"Chrome-bladwijzer testen","chromeRunHint":"In Chrome: tik op de adresbalk, typ RBL en selecteer “MILO”.","chromeNeedsSetup":"Stel eerst de MILO-bladwijzer in Chrome in.","chromeOpenFail":"Chrome kon niet worden geopend. De standaardbrowser wordt geopend.","firefoxSetupTitle":"Firefox-Publisher","firefoxSetupIntro":"Firefox kan Publisher automatisch laden via Violentmonkey. Dit is de soepelste modus.","sharePublisher":"Publisher-userscript delen","testFirefox":"Firefox-Publisher testen","firefoxNeedsSetup":"Installeer Violentmonkey en Publisher in Firefox voordat je test.","browserSaved":"Publicatiebrowser: {browser}","setupConfirmed":"Instelling gecontroleerd.","bookmarkletCopyFail":"Automatisch kopiëren lukte niet. De code staat hieronder.","bookmarkletLabel":"Bladwijzercode","autoImpossibleChrome":"Automatisch laden is in Chrome Android niet mogelijk zonder extensie of ingrijpende toestemming. De bladwijzer blijft nodig.","openChromePublish":"Chrome openen…","openFirefoxPublish":"Firefox openen…","chromeWizardTitle":"Chrome instellen","chromeWizardIntro":"Eenmalige instelling. RBL onthoudt je voortgang.","chromeFileTitle":"Publisher opslaan","chromeFileText":"RBL slaat Publisher rechtstreeks op in Documenten/RedactedBannerLab. Het Android-deelvenster is niet nodig.","chromeSaveFile":"Publisher opslaan","chromeFileDone":"Publisher opgeslagen","alreadySaved":"Ik heb hem al opgeslagen","chromeBookmarkTitle":"Mini-bladwijzer maken","chromeBookmarkText":"De bladwijzer bevat niet meer de volledige Publisher. Hij is slechts {n} tekens lang en laadt het bestand dat je net hebt opgeslagen.","chromeBookmarkName":"Naam bladwijzer: MILO","chromeBookmarkHow":"In Chrome: open Mission Authoring → ⋮ → Toevoegen aan bladwijzers. Bewerk daarna de bladwijzer, noem hem “MILO” en plak de code in URL.","copyMiniCode":"Minicode kopiëren","miniCodeCopied":"Minicode gekopieerd","openChromeBookmark":"Mission Authoring openen","bookmarkCreated":"Ik heb de bladwijzer gemaakt","chromeTestTitle":"Testen en toestaan","chromeTestText":"RBL opent Mission Authoring. Typ RBL en voer de bladwijzer uit. Chrome vraagt om Publisher en daarna om de huidige JSON. De JSON wordt bij elke nieuwe banner gevraagd, nooit tussen missies.","chromeTestButton":"Testen in Chrome","chromeTestWaiting":"In Chrome: typ RBL → MILO → selecteer publisher.js indien gevraagd → Toestaan.","chromeSetupSuccess":"Chrome is klaar","chromeSetupSuccessText":"Chrome is klaar. Publisher blijft onthouden; de banner-JSON wordt voor elke nieuwe sessie expliciet gekozen zodat oude projecten niet stilletjes opnieuw gebruikt worden.","publishNow":"Nu publiceren","wizardPrev":"Vorige","wizardNext":"Doorgaan","wizardRestart":"Instelling opnieuw starten","stepOf":"Stap {n}/3","chromeFileShareText":"Sla deze publisher.js op een makkelijk te vinden plek op, bijvoorbeeld Downloads. Chrome vraagt er tijdens de eerste test om.","chromeFileShareDialog":"MILO opslaan","chromeFileShareFail":"Publisher-bestand kon niet worden voorbereid.","chromePermissionHint":"Chrome kan opnieuw toestemming vragen om publisher.js te lezen. Gewoon toestaan.","chromeNotAutoFavorite":"RBL kan geen Chrome-bladwijzer automatisch aanmaken. Dit is de enige verplichte handmatige stap.","codeLength":"{n} tekens","chromeStepSaved":"Stap opgeslagen","chromeResetDone":"Chrome-instelling gereset","chromeSelectFileHint":"Selecteer in Chrome: Téléchargements/RedactedBannerLab/MILO.user.js","bannerDescription":"Bannerbeschrijving","required":"Verplicht","bannerDescriptionHint":"Dit is de standaardbeschrijving voor elke missie. Je kunt individuele missies later nog aanpassen.","bannerDescriptionRequired":"De bannerbeschrijving is verplicht.","describeBeforePublish":"Beschrijf eerst de banner","describeBeforePublishText":"Publiceren is geblokkeerd totdat de banner een beschrijving heeft. Die wordt als standaard voor alle missies gebruikt.","saveAndContinue":"Opslaan en doorgaan","missionPublishBlocked":"Missie kan niet worden gepubliceerd","missionNeedsPortals":"Missie {n} heeft {count}/{need} portals. Er zijn minimaal {need} nodig vóór publicatie.","completeMission":"Missie voltooien","currentMissionReady":"Missie klaar om te publiceren","publishBlockedHint":"Publiceren blijft geblokkeerd tot alle verplichte onderdelen compleet zijn.","minimumSix":"Minimum: 6 portals per missie","publisherDescRequired":"Publisher weigert missies zonder beschrijving.","publisherPortalsRequired":"Publisher weigert missies met minder dan 6 portals.","playBanners":"Banner zoeken","playHub":"Banner zoeken","searchBannergress":"Banner zoeken","searchPlaceholder":"Naam of trefwoord","search":"Zoeken","favorites":"Favorieten","currentBanner":"Hervatten","noFavorites":"Nog geen favorieten. Je lokale opslag geniet van de rust.","noPlaySession":"Er is momenteel geen banner actief.","searchPrompt":"Zoek op naam en/of geografisch gebied, met een echte afstandslimiet.","searching":"Zoeken…","searchError":"Bannergress-zoekopdracht mislukt: {error}","missionsCount":"{n} missies","distanceKm":"{n} km","favorite":"Favoriet","removeFavorite":"Uit favorieten verwijderen","playThisBanner":"Deze banner starten","resumeBanner":"Deze banner hervatten","stopBanner":"Overlay stoppen","openCurrentMission":"Huidige missie openen","overlayPermissionTitle":"RBL-overlay toestaan","overlayPermissionText":"Android moet Redacted BannerLab toestaan boven Ingress te verschijnen. Eén systeemtoestemming, daarna kan de dinosaurus weer gewoon zijn werk doen.","overlayPermissionButton":"Weergave boven andere apps toestaan","overlayPermissionWaiting":"Keer terug naar RBL nadat je toestemming hebt gegeven.","overlayStarted":"Missie-overlay gestart.","overlayFailed":"Overlay kon niet worden gestart: {error}","bannerLoadError":"Deze banner kon niet worden geladen: {error}","bannerOffline":"Deze banner bevat geen bruikbare missies.","bannerDisabled":"{n} uitgeschakelde missie(s)","addressUnknown":"Locatie niet opgegeven","doneMissions":"{done}/{total} voltooid","deepLinkOnly":"RBL bestuurt Ingress niet: de overlay opent alleen officiële missie-deeplinks.","bannergressCredit":"Zoeken via Bannergress","publisherWholeBanner":"Hele banner voorbereiden","publisherWholeHint":"Eén browsersessie: alle missies en afbeeldingen worden samen voorbereid.","publisherAllRequired":"Elke missie moet compleet zijn voordat de publicatiesessie start.","publisherSessionCreating":"Publisher-sessie {n}/{total} voorbereiden…","publisherSessionReady":"Sessie opgeslagen in Téléchargements/RedactedBannerLab. Mission Authoring openen…","publisherSessionFileText":"RBL slaat de sessie automatisch op in Téléchargements/RedactedBannerLab.","publisherSessionDialog":"Publisher-sessie","publisherSessionShareFail":"Publisher-sessie kon niet worden voorbereid.","chromeSessionHint":"Chrome: voer de MILO-bladwijzer uit. Voor elke nieuw voorbereide banner vraagt Chrome expliciet om MILO_CurrentBanner.json. Tussen missies is niets extra nodig.","firefoxSessionHint":"Firefox: Publisher opent automatisch. Laad MILO_CurrentBanner.json als de huidige sessie nog niet bekend is.","easterEgg":"Je hebt hierom gevraagd.","bannerNameSearch":"Naam / trefwoord","citySearch":"Plaats","authorSearch":"Auteur","cityPlaceholder":"bijv. Nantes","authorPlaceholder":"bijv. AgentName","nearMe":"Bij mij in de buurt","nearMeOn":"Huidige locatie ingeschakeld","nearMeHint":"Gebruikt je huidige locatie in plaats van een plaats.","locationGetting":"Locatie ophalen…","locationError":"Locatie kon niet worden opgehaald: {error}","locationReady":"Locatie gevonden","searchCriteriaRequired":"Vul minstens één zoekcriterium in.","cityResolving":"Plaats opzoeken…","cityNotFound":"Geen Bannergress-plaats gevonden voor “{city}”.","cityUsing":"Gebruikte plaats: {city}","bannerAuthor":"Auteur: {author}","overlayDrag":"≡ Verplaatsen","overlayMinimize":"Minimaliseren","overlayClose":"Sluiten","overlayMoved":"Overlaypositie opgeslagen","searchReset":"Wissen","resultsCount":"{n} resultaat/resultaten","searchFilters":"Actieve filters","allPublicBanners":"Openbare Bannergress-banners","searchRadius":"Zoekradius","radiusHint":"Wordt toegepast rond de plaats of je huidige locatie.","locationDisabled":"Locatieservices zijn op deze telefoon uitgeschakeld.","locationPermissionDenied":"BannerLab heeft geen toestemming om je locatie te gebruiken.","locationUnavailable":"Locatie niet beschikbaar. Controleer of locatieservices op de telefoon zijn ingeschakeld.","locationTimeout":"Locatie kon niet op tijd worden bepaald. Controleer of locatieservices zijn ingeschakeld.","openLocationSettings":"Locatie inschakelen","openAppSettings":"App-instellingen openen","cityNoCoordinates":"“{city}” is gevonden, maar de positie kan niet worden gebruikt.","cityUsingRadius":"Gebruikt: {city} · radius {radius} km","radiusResults":"{n} resultaat/resultaten binnen {radius} km","distanceFromPoint":"{distance} verderop","locationChecking":"Locatieservices controleren…","publisherCurrentFile":"Huidig bestand: Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json","chromeFilePath":"Le Publisher sera enregistré dans le dossier que tu choisis.","chromeFileSaved":"Publisher opgeslagen in Téléchargements/RedactedBannerLab.","chromeFileWriteFail":"Publisher kon niet naar Téléchargements/RedactedBannerLab worden geschreven.","chromeCurrentSessionHint":"Voor elke nieuwe banner: kies Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json.","browserResume":"Sessie voorbereid. RBL Mission Authoring-tab openen…","chromeResumeHint":"Chrome hergebruikt nu hetzelfde Mission Authoring-tabblad dat voor RBL is gereserveerd.","firefoxResumeHint":"Mission Authoring openen in de publicatiebrowser.","browserResumeFallback":"RBL-tab kon niet worden hergebruikt. Browser openen als fallback.","publisherAutoRefresh":"Publisher bewaakt nu het huidige sessiebestand en laadt een nieuw voorbereide banner automatisch opnieuw.","flowLocked":"Bannerbewerking vergrendeld","flowLockedText":"Stap {step} is actief. Kies “1 Banner” om afbeelding, tekst of uitsnede te bewerken.","returnFresco":"Kies 1 Banner om te bewerken","flowLockedToast":"Ga terug naar stap 1 Banner om de banner te bewerken.","publisherTabReuse":"RBL gebruikt een stabiele browser-app-ID om hetzelfde tabblad te hergebruiken.","todo":"Te doen","history":"Geschiedenis","inProgress":"Bezig","addTodo":"Toevoegen aan Te doen","removeTodo":"Verwijderen uit Te doen","noTodo":"Geen banners te doen. Verdacht redelijk.","noHistory":"Nog geen banners gespeeld. De dinosaurus verveelt zich.","bannerMap":"Routekaart","openMap":"Kaart bekijken","navigateStart":"Naar start navigeren","startUnavailable":"Startpunt niet beschikbaar.","mapUnavailable":"Bannergress levert geen bruikbare coördinaten voor deze banner.","startPoint":"Start","missionStart":"Missie {n}","shareGroup":"Delen / groep","shareProgress":"Voortgang delen","shareBanner":"Banner delen","shareIntro":"De QR-code opent RBL op dezelfde banner en hetzelfde missienummer. Er wordt geen Bannergress-account gebruikt.","copyLink":"RBL-link kopiëren","linkCopied":"RBL-link gekopieerd","shareNow":"Delen","bannergressPage":"Openen op Bannergress","joinBanner":"Deelnemen aan banner","joinAtMission":"Instappen bij missie {n}","sharedBannerLoaded":"Gedeelde banner geladen · missie {n}","sharedBannerError":"Gedeelde banner kon niet worden geladen: {error}","playStats":"Sessiestatistieken","startedAt":"Gestart","finishedAt":"Voltooid","elapsed":"Actieve tijd","estimatedDistance":"Geschatte afstand","missionsDone":"Missies voltooid","paused":"Gepauzeerd","playing":"Bezig","completedBanner":"Voltooid","replayBanner":"Opnieuw spelen","resumeFromHistory":"Hervatten","groupNoServer":"Serverloze groepsmodus: deel de QR/link opnieuw als de groep naar een andere missie gaat.","publicOnly":"Alleen openbare Bannergress-zoekopdracht/-gegevens · geen login nodig.","routePoints":"{n} routepunten","uselessStats":"Nutteloze statistieken","loadingStats":"Dingen berekenen waar niemand om vroeg…","statsUnavailable":"Niet genoeg coördinaten om nutteloze statistieken te berekenen.","bgDistance":"Bannergress-afstand","calculatedTrack":"Geschatte wandelafstand","walkingEstimate":"Geschatte wandeltijd","routeSteps":"Etappes","uniquePlaces":"Unieke locaties","revisitedPlaces":"Herhaalde bezoeken","stepsPerKm":"Etappes / km","avgMissionDistance":"Gemiddeld / missie","longestMission":"Langste missie","longestLeg":"Langste etappe","betweenMissions":"Overgangen tussen missies","detourFactor":"Omwegfactor","routeCoverage":"Kaartdekking","missionShort":"M{n}","straightLine":"Start → finish","funStatsDisclaimer":"RBL routeert elke portal-naar-portal-etappe over het voetgangersnetwerk van OpenStreetMap. Elke etappe wordt gecontroleerd: onmogelijke shortcuts of duidelijk absurde omwegen worden alleen voor die etappe vervangen door de directe afstand. Dit is een wandelinschatting, geen GPS-meting.","minutesShort":"{n} min","hoursMinutes":"{h} u {m}","xFactor":"×{n}","showUselessStats":"📊 Nutteloze statistieken","hideUselessStats":"Statistieken verbergen","statsLoaded":"Statistieken berekend","directGeometric":"Opgetelde directe afstand","routingDetour":"Netwerk / direct","routingSource":"Routering","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla niet beschikbaar · geometrische schatting","routingLoading":"Werkelijke wandelroute berekenen…","routingFailed":"Wandelroutering niet beschikbaar, geometrische statistieken gebruikt.","routingNative":"Valhalla + OSM · controle per etappe","routingWeb":"Valhalla + OSM · controle per etappe","routingErrorDetail":"Valhalla mislukt: {error}","ingressRadius":"Ingress-bereik","ingressRadiusValue":"40 m","correctedLegs":"Gecorrigeerde etappes","rawValhalla":"Ruwe Valhalla","creditsTitle":"Credits & dank","bannergressThanks":"Bedankt, Bannergress","bannergressThanksText":"Bannerzoeken en diverse openbare details in Redacted BannerLab gebruiken openbare Bannergress-gegevens. Dank aan hun team en bijdragers voor het enorme werk rond Ingress-banners.","bannergressNoLogin":"RBL gebruikt geen Bannergress-account: alleen openbare gegevens die nodig zijn voor zoeken en tonen.","independentProject":"Redacted BannerLab is een onafhankelijk project en is niet verbonden met of goedgekeurd door Bannergress of officiële Ingress-diensten.","visitBannergress":"Bannergress bezoeken","mapCredits":"Kaarten & routering","mapCreditsText":"Kaarten gebruiken OpenStreetMap-gegevens. Schattingen van wandelroutes gebruiken de Valhalla-routeringsengine.","rblCreditsFoot":"Dank aan alle tools en bijdragers die dit Ingress-missie-ecosysteem mogelijk maken.","layersTitle":"Afbeeldingen & lagen","layersDesc":"Beheer hier de achtergrond en alle afbeeldingen erboven. Miniaturen helpen de juiste laag te herkennen; daarna kun je selecteren, verbergen, herschikken of groeperen.","backgroundLayer":"Hoofdachtergrond","addBackground":"Achtergrond toevoegen / vervangen","addLayer":"Laag toevoegen","layerName":"Afbeeldingslaag","selected":"Geselecteerd","visibleLayer":"Zichtbaar","hiddenLayer":"Verborgen","moveUp":"Omhoog","moveDown":"Omlaag","groupSelection":"Selectie groeperen","group":"Groeperen","ungroup":"Groep opheffen","groupNeedTwo":"Selecteer minstens twee lagen om te groeperen.","groupCreated":"Lagen gegroepeerd","groupRemoved":"Groep opgeheven","deleteLayer":"Laag verwijderen","layerDeleted":"Laag verwijderd","layerAdded":"Laag toegevoegd","backgroundReplaced":"Achtergrond vervangen","backgroundMissing":"Geen hoofdachtergrond","backgroundFixed":"De achtergrond blijft altijd onder de andere lagen.","groupHint":"Vink meerdere lagen aan en tik op Groeperen. Een groep verplaatst, zoomt en draait samen.","layerOrder":"Laagvolgorde","layerTransform":"Laag transformeren","groupTransform":"Groep transformeren","renameLayer":"Hernoemen","duplicateLayer":"Dupliceren","layerDuplicated":"Laag gedupliceerd","histAddLayer":"Laag toevoegen","histDeleteLayer":"Laag verwijderen","histReorderLayer":"Laag herschikken","histGroupLayers":"Lagen groeperen","histUngroupLayers":"Groep opheffen","histVisibilityLayer":"Laagzichtbaarheid","histRenameLayer":"Laag hernoemen","histDuplicateLayer":"Laag dupliceren","layerGroupBadge":"Groep","layerUngroup":"Deze groep opheffen","layerSelectHint":"De geselecteerde laag kan daarna rechtstreeks op de banner worden verplaatst.","layerOpacity":"Dekking","layerDimensions":"{w} × {h} px","noImageContent":"Voeg minstens één afbeelding toe vóór export.","groupRelative":"De bediening hieronder transformeert de hele groep tegelijk.","groupZoom":"Groepszoom","groupRotation":"Groepsrotatie","clearGroupSelection":"Selectie wissen","allLayersTitle":"Lagen","allLayersDesc":"Selecteer het element dat je wilt bewerken. Afbeeldingen en tekst blijven ook vanuit hun eigen menu's bewerkbaar.","imageLayersSection":"Afbeeldingen","textLayersSection":"Tekst","noExtraImageLayer":"Geen extra afbeeldingslaag","noTextLayer":"Geen tekstlaag","selectLayer":"Selecteren","editLayer":"Bewerken","missionNumberQuestion":"Wat is het nummer van de missie?","groupName":"Groep {n}","groupCount":"{n} laag/lagen","creatorBy":"Gemaakt door Zw4nn","communityTitle":"Community & support","communityText":"Ga rechtstreeks naar de community en support via de Redacted BannerLab-bot.","telegramOpen":"Contact opnemen met support","reportProblem":"Probleem melden","reportProblemText":"Kopieer een technische diagnose en neem daarna via de bot contact op met support.","copyDiagnostic":"Diagnose kopiëren","diagnosticCopied":"Diagnose gekopieerd","diagnosticCopyFailed":"Diagnose kon niet worden gekopieerd","diagnosticDescription":"Beschrijving van het probleem:","portableProject":"Draagbaar project","portableProjectDesc":"Exporteer één banner met afbeeldingen, lagen, tekst, lettertypen, missies en route.","exportProject":"Exporteren","shareProject":"Delen","importProject":"Project importeren","projectExporting":"Project voorbereiden…","projectExported":"Project opgeslagen","projectShared":"Project klaar om te delen","projectImportSuccess":"Project geïmporteerd","projectImportInvalid":"Dit bestand is geen geldig Redacted BannerLab-project.","projectShareTitle":"Redacted BannerLab-project","projectImportHint":"Het geïmporteerde project wordt toegevoegd zonder je andere projecten te wijzigen.","backupTitle":"Back-up & herstellen","backupText":"Bewaar alle BannerLab-projecten, instellingen en afbeeldingen in één draagbaar JSON-bestand.","backupFolder":"Back-upmap","backupFolderChoose":"Map kiezen","backupFolderChange":"Map wijzigen","backupFolderNone":"Geen map geselecteerd","backupFolderReady":"Map ingesteld","backupAuto":"Automatische back-up op de achtergrond","backupAutoHint":"Wanneer ingeschakeld, bereidt BannerLab na wijzigingen regelmatig een back-up voor en forceert bij naar de achtergrond gaan een laatste opslag.","backupNow":"Nu back-up maken","backupExport":"JSON exporteren","backupImport":"JSON importeren","backupWorking":"Back-up maken…","backupSaved":"Back-up voltooid","backupAutoSaved":"Automatische back-up voltooid","backupFailed":"Back-up mislukt: {error}","backupNeedFolder":"Kies eerst een back-upmap.","backupFolderError":"Deze map kan niet worden gebruikt.","backupImported":"Back-up hersteld","backupInvalid":"Dit bestand is geen geldige Redacted BannerLab-back-up.","backupImportTitle":"Back-up herstellen","backupImportText":"{n} project(en) gevonden · back-up van {date}","backupMerge":"Samenvoegen","backupReplace":"Alles vervangen","backupReplaceWarn":"Alles vervangen verwijdert eerst de projecten die momenteel op dit apparaat zijn opgeslagen.","backupCancel":"Annuleren","backupLast":"Laatste back-up: {date}","backupNever":"Nog geen back-up","backupPortable":"De JSON bevat ook de afbeeldingen. Het bestand kan dus groot zijn, maar is volledig zelfstandig.","backupNativeOnly":"Automatische mapback-up is beschikbaar op Android. JSON-export/import blijft overal beschikbaar.","backupFolderChosen":"Back-upmap opgeslagen","backupNoChanges":"Geen wijzigingen om te back-uppen.","studioEdit":"Bewerken op volledig scherm","studioTitle":"Bewerkingsstudio","studioLayers":"Lagen","studioTexts":"Tekst","studioTools":"Gereedschap","studioFit":"6 missies","studioFitOne":"1 missie","studioFitAll":"Alles","studioMissionMode":"Missie","studioFrescoMode":"Banner","studioFullscreen":"Volledig scherm","studioRotateHint":"6 missies verticaal · volgende rijen scrollen naar rechts.","studioSelected":"Geselecteerd item","studioNoLayer":"Selecteer een laag of tekst in het zijpaneel.","studioGroupSelect":"Groepsselectie","studioGroupNow":"Groeperen","studioOpenFull":"Volledige beheerder openen","studioOpacity":"Dekking","studioClose":"Studio verlaten","studioPan":"Scrollen","studioAddText":"Tekst toevoegen","studioNoText":"Nog geen tekst.","studioEditText":"Tekst bewerken","studioDuplicateText":"Tekst dupliceren","font":"Lettertype","fontWeight":"Gewicht","fontItalic":"Cursief","letterSpacing":"Letterafstand","lineHeight":"Regelhoogte","textAlign":"Uitlijning","alignLeft":"Links","alignCenter":"Midden","alignRight":"Rechts","importFont":"Lettertype importeren","fontImported":"Lettertype geïmporteerd: {name}","fontInvalid":"Dit lettertype wordt niet ondersteund.","fontTooLarge":"Lettertypebestand is te groot (max. 12 MB).","textBackground":"Tekstachtergrond","textBackgroundColor":"Achtergrondkleur","textBackgroundOpacity":"Achtergronddekking","textBackgroundPadding":"Binnenruimte achtergrond","textBackgroundRadius":"Hoekradius","textTypography":"Typografie","tutorialHubTitle":"Handleidingen & aan de slag","tutorialHubText":"Start wanneer je wilt opnieuw een rondleiding. Redacted kan ook alleen uitleggen wat je op dat moment nodig hebt.","tutorialOpen":"Handleidingen bekijken","tutorialWelcomeTitle":"Welkom bij Redacted BannerLab","tutorialWelcomeText":"Redacted kan je het lab laten zien. Twee minuten, een paar knoppen en geen examen aan het eind.","tutorialStart":"Rondleiding starten","tutorialLater":"Later","tutorialNever":"Niet meer tonen","tutorialPrevious":"Vorige","tutorialNext":"Volgende","tutorialUnderstood":"OK, begrepen","tutorialClose":"Sluiten","tutorialDone":"Handleiding voltooid","tutorialSeen":"Gezien","tutorialQuick":"Snelle rondleiding","tutorialQuickDesc":"De belangrijkste bediening en de algemene BannerLab-workflow.","tutorialBanner":"Banner maken","tutorialBannerDesc":"Van project tot voorbeeld en export van de missies.","tutorialLayers":"Afbeeldingen, lagen & tekst","tutorialLayersDesc":"Achtergrond, overliggende afbeeldingen, lagen en typografie.","tutorialIitc":"Route bouwen met IITC","tutorialIitcDesc":"Installeer Companion, voeg portals toe en synchroniseer de route.","tutorialPublish":"Missies publiceren","tutorialPublishDesc":"Bereid missies voor en gebruik daarna Publisher en Mission Authoring.","tutorialBackup":"Back-ups & draagbare projecten","tutorialBackupDesc":"Maak een back-up van BannerLab of deel één volledige banner.","importRolesHint":"Hoofdachtergrond = basisafbeelding van de banner · Laag = extra afbeelding erboven.","tutProjectTitle":"Je projecten","tutProjectText":"Elke banner zit in zijn eigen project. Je kunt hem exporteren of delen zonder alle andere projecten mee te slepen.","tutNameTitle":"Projectnaam","tutNameText":"Geef je banner een herkenbare naam.","tutRowsTitle":"Aantal rijen","tutRowsText":"Eén rij bevat 6 missies. Kies hier de uiteindelijke hoogte van de banner.","tutImageTitle":"Afbeeldingen & lagen","tutImageText":"Importeer hier de hoofdachtergrond en extra afbeeldingen. In hetzelfde scherm selecteer, orden, verberg en groepeer je afbeeldingslagen.","tutBackgroundTitle":"Hoofdachtergrond","tutBackgroundText":"Gebruik Hoofdachtergrond voor je eerste echte afbeelding. Die vervangt de basisafbeelding en vult de banner.","tutExtraLayerTitle":"Laag toevoegen","tutExtraLayerText":"Een tweede afbeelding is een laag: die ligt boven de achtergrond en blijft verplaatsbaar, schaalbaar en verbergbaar.","tutLayersTitle":"Afbeeldingslagen beheren","tutLayersText":"Miniaturen laten zien welke afbeeldingslaag je bewerkt. Selecteer hem, verander de volgorde, verberg hem of vink meerdere afbeeldingen aan om te groeperen.","tutTextTitle":"Tekst","tutTextText":"Voeg tekst toe, kies lettertypen, afstanden, achtergrond en radius, of importeer je eigen lettertype.","tutPreviewTitle":"Voorbeeld","tutPreviewText":"Controleer elke missie vóór export. Individuele uitsneden zijn al toegepast.","tutExportTitle":"Export","tutExportText":"Als alles klaar is, maakt BannerLab de 512 × 512-missieafbeeldingen in de juiste volgorde.","tutStudioTitle":"Studio op volledig scherm","tutStudioText":"Een comfortabelere editor op volledig scherm met bediening aan de zijkant en grote aanraakvlakken.","tutFlowTitle":"De 4 stappen","tutFlowText":"Banner → Route → Missies → Publiceren. BannerLab volgt deze workflow.","tutRouteTitle":"Route","tutRouteText":"De route koppelt missies aan echte Ingress-portals. IITC Companion doet het kaartwerk.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion neemt het actieve project, de missie, portals, acties en wandelstatistieken mee naar IITC.","tutInstallCompanionTitle":"Companion installeren","tutInstallCompanionText":"Installeer of update het userscript één keer in IITC Mobile.","tutOpenIitcTitle":"IITC openen","tutOpenIitcText":"Open IITC vanuit BannerLab zodat project en actieve missie aan Companion worden doorgegeven.","tutAutoRouteTitle":"Tussen missies schakelen","tutAutoRouteText":"De volgende missie kan automatisch openen en de laatste portal van de vorige als eerste hergebruiken.","tutPortalListTitle":"Je portals","tutPortalListText":"Portals komen terug met GUID, coördinaten, volgorde en actie, zodat de route opnieuw kan worden opgebouwd.","tutMissionsTitle":"Missies voorbereiden","tutMissionsText":"Vul vóór publicatie de algemene beschrijving in en controleer elke missie.","tutMissionDescTitle":"Verplichte beschrijving","tutMissionDescText":"BannerLab meldt ontbrekende informatie voordat publiceren wordt toegestaan.","tutPublishTitle":"Publiceren","tutPublishText":"Als routes en beschrijvingen klaar zijn, ga je hier verder. Het definitieve indienen blijft in de officiële tool.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab bereidt missiegegevens en de publicatiestroom voor. Gebruik na het indienen “Ik heb ingediend” om de gepubliceerde status te controleren.","tutInfoTitle":"Instellingen, hulp & support","tutInfoText":"Instellingen & info bevat taal, back-ups, handleidingen en support via de Redacted BannerLab-bot.","tutBackupTitle":"Volledige back-up","tutBackupText":"De volledige JSON bevat alle projecten, instellingen, afbeeldingen en lettertypen. Android kan ook een automatische back-upmap gebruiken.","tutPortableTitle":"Draagbaar project","tutPortableText":"Exporteer, deel of importeer één banner met afbeeldingen, tekst, lettertypen, missies en route.","tutSupportTitle":"Hulp nodig?","tutSupportText":"Kopieer zo nodig de diagnose en neem contact op met support. De bot linkt ook naar het kanaal en de discussiegroep.","settingsInfo":"Instellingen & info","addMissionLayer":"Op een missie","importMissionSeries":"Serie importeren","missionLayer":"Missielaag","globalLayer":"Globale laag","layerScope":"Bereik van laag","wholeBanner":"Hele banner","missionTarget":"Toegewezen missie","fitMode":"Passend maken","fitCover":"Vullen","fitContain":"Passen","missionBadge":"M{n}","missionLayerHint":"Deze laag blijft gekoppeld aan missie {n} en wordt automatisch tot die tegel begrensd.","missionSeriesTitle":"Missieserie importeren","missionSeriesText":"Wijs elke afbeelding aan een missie toe. BannerLab plaatst en snijdt ze automatisch bij.","missionSeriesDetected":"{n} afbeelding(en) gevonden","missionSeriesImport":"Lagen importeren","missionSeriesTooMany":"Je hebt meer afbeeldingen dan missies geselecteerd. Meerdere afbeeldingen mogen aan dezelfde missie worden toegewezen.","missionLayerAdded":"Afbeelding toegevoegd aan missie {n}","missionSeriesAdded":"{n} missielaag/lagen toegevoegd","missionScopeMismatch":"Missielagen kunnen alleen worden gegroepeerd als ze bij dezelfde missie horen.","missionLayerTutorialTitle":"Aan missies gekoppelde lagen","missionLayerTutorialText":"Tik op “Laag toevoegen” en kies: hele banner, één missie of meerdere missies. Bij één missie plaatst en begrenst BannerLab de afbeelding automatisch in de juiste cel. Bij meerdere missies importeer je een serie en wijs je elke afbeelding aan de gewenste missie toe.","addLayerChoiceTitle":"Laag toevoegen","addLayerChoiceText":"Kies waar deze laag bij hoort. Je kunt dit later aanpassen.","addLayerWhole":"Op de hele banner","addLayerWholeText":"Een vrije afbeelding boven de hele banner, verplaatsbaar en schaalbaar.","addLayerOneMission":"Op één missie","addLayerOneMissionText":"Een afbeelding die automatisch op de gekozen missie wordt geplaatst en begrensd.","addLayerManyMissions":"Over meerdere missies","addLayerManyMissionsText":"Importeer een serie afbeeldingen en wijs elke afbeelding aan de gewenste missie toe.","multiSelection":"Meervoudige selectie","multiSelectionHint":"Vink meerdere lagen aan om een gezamenlijke actie toe te passen, ze te groeperen of te verwijderen.","selectionActions":"Acties voor selectie","editSelection":"Selectie bewerken","deleteSelection":"Selectie verwijderen","selectedLayersCount":"{n} laag/lagen geselecteerd","bulkScopeKeep":"Huidig bereik behouden","bulkMissionKeep":"Huidige missies behouden","bulkFitKeep":"Huidige passing behouden","bulkVisibility":"Zichtbaarheid","bulkVisibilityKeep":"Niet wijzigen","bulkShow":"Tonen","bulkHide":"Verbergen","bulkOpacityEnable":"Dekking wijzigen","applyToSelection":"Toepassen op geselecteerde lagen","selectionUpdated":"Geselecteerde lagen bijgewerkt","selectionDeleted":"Geselecteerde lagen verwijderd","deleteSelectionConfirm":"{n} geselecteerde laag/lagen definitief verwijderen?","selectionEmpty":"Selecteer minstens één laag.","layerScopeHelp":"Hele banner: de laag kan de volledige banner bedekken. Eén missie: de laag wordt automatisch tot de gekozen missie begrensd. Meerdere missies: importeer een serie en wijs elke afbeelding aan zijn missie toe."};
// Italiano completo: tutte le stringhe UI principali, incluse le funzioni Studio e Publisher.
Object.assign(I18N.it,{"fresco":"Banner","framing":"Inquadratura","layers":"Livelli","noMission":"Nessuna missione selezionata","addImage":"Aggiungi la tua immagine","imageHint":"Verrà inquadrata direttamente sulla geometria Prime.","circles":"Cerchi Prime","grid":"Griglia 512","numbers":"Numeri","enlarge":"Ingrandisci missione","resetMission":"Reimposta missione","prev":"Precedente","next":"Successiva","complete":"Missione completa","remaining":"Mancano {n} portale/i","openIitc":"Apri IITC Companion","tutorial":"Tutorial","installPlugin":"Installa / aggiorna il plugin IITC","autoAdvance":"Passa automaticamente alla missione successiva a {n} portali","reuseLast":"Riutilizza automaticamente l’ultimo portale come primo della missione successiva","noPortal":"Nessun portale in questa missione.","action":"Azione","hack":"Hack","mod":"Installa un mod","capture":"Cattura / potenzia","link":"Crea un link","field":"Crea un campo","passphrase":"Passphrase","question":"Domanda","answer":"Risposta prevista","save":"Salva","cancel":"Annulla","settings":"Impostazioni comuni","commonDesc":"Descrizione comune","titleFormat":"Formato dei titoli","defaultType":"Tipo predefinito","location":"Posizione","sequential":"Sequenziale","anyOrder":"Ordine libero","portalsPerMission":"Portali / missione","editMission":"Modifica missione","title":"Titolo","description":"Descrizione","missionReady":"Pronta","missionIncomplete":"Incompleta","openRoute":"Modifica percorso","publishPack":"Crea pacchetto BannerLab","openMat":"Apri Mission Authoring Tool","ownWorkflow":"BannerLab usa ora il proprio formato di progetto e il proprio pacchetto di pubblicazione.","french":"Français","english":"English","spanish":"Español","companionStats":"Statistiche a piedi in IITC","companionStatsDesc":"Nel mini pannello IITC: 📊 Statistiche inutili calcola distanza a piedi stimata, tempo, deviazione e altre assurdità.","duplicateBad":"{n} riutilizzo/i di portale da verificare.","handoverOk":"È consentito riutilizzare la fine di una missione come inizio della successiva.","pluginVersion":"IGOR 0.6.35","undo":"Annulla","redo":"Ripristina","subtitle":"Banner Ingress Prime","source":"sorgente","bannerHelp":"<b>Modalità banner:</b> 1 dito sposta il livello selezionato. <b>2 dita</b> eseguono zoom e rotazione.","missionHelp":"<b>Modalità missione:</b> tocca un medaglione. Per lavorare più comodamente, usa <b>Ingrandisci missione</b>. Puoi anche spostarlo qui con 1 dito.","missionSelected":"Missione {n} selezionata","tapMedallion":"Tocca un medaglione","touchMissionFirst":"Tocca prima la missione che vuoi reinquadrare.","selectMissionFirst":"Seleziona prima una missione.","heavyImage":"Immagine molto pesante. Potrebbe mettere in ginocchio il telefono, con notevole disappunto per entrambi.","imported":"Importati {w} × {h} px","textLayerDesc":"Ogni testo resta un livello indipendente, modificabile o eliminabile.","layer":"Livello","newText":"+ Nuovo testo","size":"Dimensione","outline":"Contorno","color":"Colore","outlineColor":"Colore contorno","add":"Aggiungi","update":"Aggiorna","delete":"Elimina","zoom":"Zoom","localZoom":"Zoom locale","rotation":"Rotazione","center":"Centra","reset":"Reimposta","done":"Fatto","transformText":"Trasforma testo","frameImage":"Inquadra immagine","pinchHint":"I gesti a due dita restano disponibili direttamente sul banner.","missionCropOnly":"Questa inquadratura riguarda solo questo medaglione.","resetThisMission":"Reimposta questa missione","individualCrop":"Inquadratura individuale · 512 × 512","oneFinger":"1 dito","move":"sposta","twoFingers":"2 dita","zoomRotate":"zoom e rotazione","previewPrime":"Anteprima Prime","previewApplied":"Le regolazioni individuali delle missioni sono già applicate.","previewOrder":"Il numero 1 è in basso a destra, poi la numerazione procede verso sinistra e sale nelle righe superiori.","exportTitle":"Esporta {n} missioni","exportIntro":"Scegli velocità oppure PNG senza perdita. Entrambi restano a 512 × 512.","noBackground":"Nessuna immagine di sfondo caricata.","missionFormat":"Formato missioni","jpgFast":"JPG rapido · alta qualità","pngLossless":"PNG senza perdita · più lento","fastEncoding":"La modalità rapida evita la codifica PNG, che è di gran lunga la parte più lenta su telefono.","rowRender":"Lo sfondo viene renderizzato una sola volta per riga invece di essere ricalcolato sei volte.","adjusted":"{n} missione/i con inquadratura individuale.","nianticCheck":"Controlla le regole Niantic prima dell’invio: diritti sull’immagine, contenuto pertinente e nessun singolo personaggio dominante.","ready":"Pronto.","createZip":"Crea ZIP","zipAssembly":"Creazione ZIP…","zipCreated":"ZIP creato.","zipDownloaded":"ZIP scaricato.","saveShareZip":"Salva o condividi ZIP","exportFinished":"Esportazione {format} completata","exportFailed":"Esportazione non riuscita.","projectsSaved":"{n} progetto/i salvato/i su questo telefono.","unnamed":"Senza nome","opened":"Aperto","open":"Apri","rename":"Rinomina","copy":"Copia","noSavedProject":"Nessun progetto salvato.","renameProject":"Rinomina progetto","renameHint":"Un nome leggibile da un essere umano. Concetto sorprendentemente avanzato.","projectName":"Nome progetto","projectOpened":"Progetto aperto: {name}","projectRenamed":"Progetto rinominato","deleteProject":"Eliminare questo progetto?","deleteWarning":"Il banner e la sua immagine salvata localmente verranno eliminati.","copyCreated":"Copia creata","projectDeleted":"Progetto eliminato","newProjectCreated":"Nuovo progetto creato con Redacted","defaultProject":"Il mio banner","defaultNewProject":"Nuovo banner","copySuffix":"copia","versionLabel":"Versione","infoPrime":"6 colonne · 544 px · ritaglio 512 px.","infoPlanner":"azioni portale, passphrase, passaggio fine→inizio e pacchetto BannerLab nativo.","infoCompanion":"percorsi, azioni, tracciati multi-missione, opzioni e statistiche a piedi.","disclaimer":"Ingress e Ingress Prime sono marchi di Niantic. Redacted BannerLab non è affiliato né approvato da Niantic.","titleTokens":"$T = nome · $N = numero · $M = totale · $0N = 01, 02…","pluginShareText":"Plugin IGOR 0.6.35. Sostituisci la versione precedente in IITC Mobile. Se IITC rifiuta di sovrascriverla, rimuovi una volta il vecchio plugin e installa questo file.","pluginDialog":"Installa / aggiorna IGOR 0.6.35","pluginShareFailed":"Impossibile condividere il plugin IITC.","intelOpened":"IITC Mobile aperto con il progetto BannerLab.","intelPrimeOpened":"IITC Prime aperto con il progetto BannerLab.","intelFallback":"IITC Mobile aperto. Companion userà l’ultimo stato sincronizzato.","intelPrimeFallback":"IITC Prime aperto. Companion userà l’ultimo stato sincronizzato.","intelBrowser":"IITC non rilevato: apertura nel browser.","tutorialIntro":"Costruisci l’intero banner in IITC senza tornare a BannerLab dopo ogni portale.","tut1Title":"Installa il plugin una sola volta","tut1Text":"Da Percorso, usa “Installa / aggiorna il plugin IITC”, poi aggiungi il file come plugin utente in IITC Mobile.","tut2Title":"Apri IITC da BannerLab","tut2Text":"BannerLab invia progetto, missione attiva e lingua a Companion tramite un frammento locale che il server Intel non riceve mai.","tut3Title":"Costruisci direttamente sulla mappa","tut3Text":"IGOR permette di aggiungere, modificare o rimuovere portali, cambiare missione e visualizzare i percorsi senza tornare a BannerLab.","tut4Title":"Sincronizza quando hai finito","tut4Text":"“Sincronizza BannerLab” rimanda al progetto tutte le missioni modificate e riapre BannerLab.","tutNote":"Puoi spostare e ridimensionare Companion e conservare le sue impostazioni in Opzioni.","installUpdate":"Installa / aggiorna","emptyTitleIssue":"Missione {n}: titolo vuoto","emptyDescIssue":"Missione {n}: descrizione vuota","portalsIssue":"Missione {n}: {count}/{need} portali","missingGuidIssue":"Missione {n}: {count} GUID mancante/i","passIssue":"Missione {n}: {count} passphrase incompleta/e","reviewCount":"{n} elemento/i da verificare","projectReady":"Progetto BannerLab pronto","fixBeforePublish":"Correggi questi elementi prima di pubblicare.","publisherDesc":"Il prossimo ponte compilerà il Mission Authoring Tool direttamente da questo formato nativo. L’invio finale resterà volutamente nell’strumento ufficiale.","packCreating":"Creazione pacchetto BannerLab…","packCreated":"Pacchetto BannerLab creato","exportImpossible":"Esportazione impossibile: {error}","missionResetDone":"Missione {n} reimpostata","textDeleted":"Testo eliminato","histImport":"Importa immagine","histMissionZoom":"Zoom missione","histMissionRotation":"Rotazione missione","histTextRotation":"Rotazione testo","histImageRotation":"Rotazione immagine","histTextZoom":"Zoom testo","histImageZoom":"Zoom immagine","histCenterText":"Centra testo","histCenterImage":"Centra immagine","histResetText":"Reimposta testo","histResetImage":"Reimposta immagine","histResetMission":"Reimposta missione","histDeleteText":"Elimina testo","histAddText":"Aggiungi testo","histEditText":"Modifica testo","routeActionHelp":"Hack / Mod / Cattura / Link / Campo / Passphrase direttamente da Companion.","handoverDetail":"L’ultimo portale può diventare il primo della missione successiva senza essere considerato un duplicato non valido.","coordsMissing":"Coordinate non trovate.","coordsInvalid":"Coordinate non valide.","duplicateElsewhere":"Questo portale è già usato altrove nel banner.","missionCompleteAdded":"Missione {n} completa · {next}","portalAdded":"Portale aggiunto · missione {n}","syncOld":"Percorso sincronizzato · rilevato IGOR obsoleto: installa la versione 0.6.0.","syncOk":"Percorso IITC sincronizzato · Companion {v}.","portalDefault":"Portale","bannerDefault":"Banner","livePublish":"Prepara direttamente in Mission Authoring","livePublishShort":"Publisher diretto","livePreparing":"Preparazione di {n} missioni per Publisher…","liveReady":"Apertura del Publisher integrato…","liveNativeOnly":"Publisher diretto è disponibile nell’APK Android.","liveFailed":"Impossibile aprire Publisher: {error}","liveExperimental":"Sperimentale: Mission Authoring si apre in una vista controllata da RBL. L’accesso Google è la prima cosa da verificare sul telefono.","backupTransfer":"Backup / trasferimento","exportPackBackup":"Esporta pacchetto BannerLab","openOfficialOnly":"Apri solo il sito ufficiale","publisherPreparingImage":"Rendering missione {n}/{total}…","browserPublish":"Pubblica in Firefox","browserPublishShort":"Publisher nel browser","browserSetup":"Installa / aggiorna Browser Publisher","browserPreparing":"Preparazione missione {n}/{total}…","browserOpening":"Apertura di Firefox…","browserNeed":"Publisher diretto usa Firefox Android + Violentmonkey, così l’accesso Google resta in un browser normale.","browserFailed":"Impossibile aprire Publisher: {error}","browserShareText":"MILO 0.5.3 · Redacted BannerLab per missions.ingress.com. Installalo una volta in Violentmonkey su Firefox Android.","browserShareDialog":"Installa Publisher 0.4.8","browserShareFailed":"Impossibile condividere Browser Publisher.","publisherUrlTooLarge":"Questa missione è troppo grande per essere inviata al browser.","publisherReturn":"Ritorno da Publisher.","publisherNoFirefox":"Firefox non è stato rilevato. Apertura del browser predefinito, ma Publisher richiede un browser con supporto userscript.","publisherBrowser":"Browser di pubblicazione","chromeMode":"Chrome","chromeModeSub":"Nessuna app aggiuntiva · piccolo segnalibro + Consenti quando richiesto","firefoxMode":"Firefox","firefoxModeSub":"Automatico dopo l’installazione di Violentmonkey + Publisher","recommendedAuto":"Automatico","noExtraApp":"Nessuna app aggiuntiva","publishSelected":"Pubblica missione","chromeSetup":"Configura Chrome","firefoxSetup":"Configura Firefox","chromeReady":"Segnalibro Chrome verificato","firefoxReady":"Firefox Publisher verificato","notConfigured":"Configurazione iniziale richiesta","chromeSetupTitle":"MILO in Chrome","chromeSetupIntro":"Chrome non permette a RBL di aggiungere il segnalibro al posto tuo. La configurazione è quindi ridotta al minimo possibile.","chromeStep1":"1. Copia il codice del segnalibro MILO.","chromeStep2":"2. Apri Mission Authoring in Chrome e aggiungi la pagina ai segnalibri.","chromeStep3":"3. Modifica il segnalibro: chiamalo “MILO” e sostituisci il suo URL con il codice copiato.","chromeStep4":"4. In Mission Authoring, tocca la barra degli indirizzi, digita “RBL”, poi scegli il segnalibro per provarlo.","copyBookmarklet":"Copia codice segnalibro","bookmarkletCopied":"Codice segnalibro copiato","openChromeSetup":"Apri Chrome per la configurazione","testChrome":"Prova segnalibro Chrome","chromeRunHint":"In Chrome: tocca la barra degli indirizzi, digita RBL, poi seleziona “MILO”.","chromeNeedsSetup":"Configura prima il segnalibro Chrome MILO.","chromeOpenFail":"Impossibile aprire Chrome. Apertura del browser predefinito.","firefoxSetupTitle":"MILO in Firefox","firefoxSetupIntro":"Firefox può caricare Publisher automaticamente tramite Violentmonkey. È la modalità più fluida.","sharePublisher":"Condividi userscript Publisher","testFirefox":"Prova Firefox Publisher","firefoxNeedsSetup":"Installa Violentmonkey e Publisher in Firefox prima di provarlo.","browserSaved":"Browser di pubblicazione: {browser}","setupConfirmed":"Configurazione verificata.","bookmarkletCopyFail":"Impossibile copiare automaticamente. Il codice è mostrato qui sotto.","bookmarkletLabel":"Codice segnalibro","autoImpossibleChrome":"Il caricamento automatico non è possibile in Chrome Android senza un’estensione o un’autorizzazione invasiva. Il segnalibro resta necessario.","openChromePublish":"Apertura di Chrome…","openFirefoxPublish":"Apertura di Firefox…","chromeWizardTitle":"Configura Chrome","chromeWizardIntro":"Configurazione una tantum. RBL ricorda i tuoi progressi.","chromeFileTitle":"Salva Publisher","chromeFileText":"RBL salva Publisher direttamente in Téléchargements/RedactedBannerLab. Non serve il pannello di condivisione Android.","chromeSaveFile":"Salva Publisher","chromeFileDone":"Publisher salvato","alreadySaved":"L’ho già salvato","chromeBookmarkTitle":"Crea il mini segnalibro","chromeBookmarkText":"Il segnalibro non contiene più l’intero Publisher. È lungo solo {n} caratteri e carica il file appena salvato.","chromeBookmarkName":"Nome segnalibro: MILO","chromeBookmarkHow":"In Chrome: apri Mission Authoring → ⋮ → Aggiungi ai segnalibri. Poi modifica il segnalibro, chiamalo “MILO” e incolla il codice nel campo URL.","copyMiniCode":"Copia mini codice","miniCodeCopied":"Mini codice copiato","openChromeBookmark":"Apri Mission Authoring","bookmarkCreated":"Ho creato il segnalibro","chromeTestTitle":"Prova e autorizza","chromeTestText":"RBL apre Mission Authoring. Digita RBL ed esegui il segnalibro. Chrome chiede Publisher, poi il JSON corrente. Il JSON viene richiesto per ogni nuovo banner, mai tra una missione e l’altra.","chromeTestButton":"Prova in Chrome","chromeTestWaiting":"In Chrome: digita RBL → MILO → seleziona publisher.js se richiesto → Consenti.","chromeSetupSuccess":"Chrome è pronto","chromeSetupSuccessText":"Chrome è pronto. Publisher resta memorizzato; il JSON del banner viene selezionato esplicitamente per ogni nuova sessione, così i vecchi progetti non possono essere riutilizzati di nascosto.","publishNow":"Pubblica ora","wizardPrev":"Precedente","wizardNext":"Continua","wizardRestart":"Ricomincia configurazione","stepOf":"Passaggio {n}/3","chromeFileShareText":"Salva questo publisher.js in un posto facile da trovare, per esempio Download. Chrome lo chiederà durante il primo test.","chromeFileShareDialog":"Salva MILO","chromeFileShareFail":"Impossibile preparare il file Publisher.","chromePermissionHint":"Chrome potrebbe chiedere di nuovo il permesso di leggere publisher.js. Puoi semplicemente consentirlo.","chromeNotAutoFavorite":"RBL non può creare automaticamente un segnalibro Chrome. Questo è l’unico passaggio manuale obbligatorio.","codeLength":"{n} caratteri","chromeStepSaved":"Passaggio salvato","chromeResetDone":"Configurazione Chrome reimpostata","chromeSelectFileHint":"In Chrome seleziona: Téléchargements/RedactedBannerLab/MILO.user.js","bannerDescription":"Descrizione banner","required":"Obbligatorio","bannerDescriptionHint":"Questa è la descrizione predefinita per ogni missione. Potrai comunque personalizzare le singole missioni in seguito.","bannerDescriptionRequired":"La descrizione del banner è obbligatoria.","describeBeforePublish":"Descrivi prima il banner","describeBeforePublishText":"La pubblicazione è bloccata finché il banner non ha una descrizione. Verrà usata come valore predefinito per tutte le missioni.","saveAndContinue":"Salva e continua","missionPublishBlocked":"La missione non può essere pubblicata","missionNeedsPortals":"La missione {n} ha {count}/{need} portali. Ne servono almeno {need} prima della pubblicazione.","completeMission":"Completa missione","currentMissionReady":"Missione pronta per la pubblicazione","publishBlockedHint":"La pubblicazione resta bloccata finché tutti gli elementi obbligatori non sono completi.","minimumSix":"Minimo: 6 portali per missione","publisherDescRequired":"Publisher rifiuta le missioni senza descrizione.","publisherPortalsRequired":"Publisher rifiuta le missioni con meno di 6 portali.","playBanners":"Trova un banner","playHub":"Trova un banner","searchPlaceholder":"Nome o parola chiave","favorites":"Preferiti","currentBanner":"Riprendi","noFavorites":"Nessun banner preferito. La memoria locale si sta godendo una pace sospetta.","noPlaySession":"Nessun banner attualmente in corso.","searchPrompt":"Cerca per nome e/o area geografica, con un vero limite di distanza.","searchError":"Ricerca Bannergress non riuscita: {error}","missionsCount":"{n} missioni","distanceKm":"{n} km","favorite":"Preferito","removeFavorite":"Rimuovi dai preferiti","playThisBanner":"Avvia questo banner","resumeBanner":"Riprendi questo banner","stopBanner":"Ferma overlay","openCurrentMission":"Apri missione corrente","overlayPermissionTitle":"Consenti overlay RBL","overlayPermissionText":"Android deve consentire a Redacted BannerLab di apparire sopra Ingress. Un solo permesso di sistema, poi il dinosauro può tornare a farsi gli affari suoi.","overlayPermissionButton":"Consenti visualizzazione sopra altre app","overlayPermissionWaiting":"Torna a RBL dopo aver concesso il permesso.","overlayStarted":"Overlay missione avviato.","overlayFailed":"Impossibile avviare l’overlay: {error}","bannerLoadError":"Impossibile caricare questo banner: {error}","bannerOffline":"Questo banner non contiene missioni utilizzabili.","bannerDisabled":"{n} missione/i disabilitata/e","addressUnknown":"Posizione non specificata","doneMissions":"{done}/{total} completate","deepLinkOnly":"RBL non controlla Ingress: l’overlay apre solo i deep link ufficiali delle missioni.","bannergressCredit":"Ricerca tramite Bannergress","publisherWholeBanner":"Prepara l’intero banner","publisherWholeHint":"Una sola sessione browser: tutte le missioni e le immagini vengono preparate insieme.","publisherAllRequired":"Ogni missione deve essere completa prima di avviare la sessione di pubblicazione.","publisherSessionCreating":"Preparazione sessione Publisher {n}/{total}…","publisherSessionReady":"Sessione salvata in Téléchargements/RedactedBannerLab. Apertura di Mission Authoring…","publisherSessionFileText":"RBL salva automaticamente la sessione in Téléchargements/RedactedBannerLab.","publisherSessionDialog":"Sessione Publisher","publisherSessionShareFail":"Impossibile preparare la sessione Publisher.","chromeSessionHint":"Chrome: esegui il segnalibro MILO. Per ogni nuovo banner preparato, Chrome chiederà esplicitamente MILO_CurrentBanner.json. Non serve altro tra una missione e l’altra.","firefoxSessionHint":"Firefox: Publisher si apre automaticamente. Carica MILO_CurrentBanner.json se la sessione corrente non è già nota.","easterEgg":"L’hai chiesto tu.","authorSearch":"Autore","authorPlaceholder":"es. AgentName","nearMeOn":"La mia posizione è attiva","locationError":"Impossibile ottenere la posizione: {error}","searchCriteriaRequired":"Inserisci almeno un criterio di ricerca.","cityResolving":"Ricerca città…","cityNotFound":"Nessun luogo Bannergress trovato per “{city}”.","cityUsing":"Luogo utilizzato: {city}","bannerAuthor":"Autore: {author}","overlayDrag":"≡  Sposta","overlayMinimize":"Riduci","overlayClose":"Chiudi","overlayMoved":"Posizione overlay salvata","resultsCount":"{n} risultato/i","searchFilters":"Filtri attivi","allPublicBanners":"Banner pubblici Bannergress","cityNoCoordinates":"“{city}” è stata trovata, ma la sua posizione non può essere utilizzata.","cityUsingRadius":"Utilizzo: {city} · raggio {radius} km","radiusResults":"{n} risultato/i entro {radius} km","distanceFromPoint":"A {distance} di distanza","publisherCurrentFile":"File corrente: Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json","chromeFilePath":"Le Publisher sera enregistré dans le dossier que tu choisis.","chromeFileSaved":"Publisher salvato in Téléchargements/RedactedBannerLab.","chromeFileWriteFail":"Impossibile scrivere Publisher in Téléchargements/RedactedBannerLab.","chromeCurrentSessionHint":"Per ogni nuovo banner: scegli Téléchargements/RedactedBannerLab/MILO_CurrentBanner.json.","browserResume":"Sessione preparata. Apertura della scheda RBL Mission Authoring…","chromeResumeHint":"Chrome riutilizza ora la stessa scheda Mission Authoring riservata a RBL.","firefoxResumeHint":"Apertura di Mission Authoring nel browser di pubblicazione.","browserResumeFallback":"Impossibile riutilizzare la scheda RBL. Apertura del browser come ripiego.","publisherAutoRefresh":"Publisher ora controlla il file della sessione corrente e ricarica automaticamente un nuovo banner preparato.","flowLocked":"Modifica banner bloccata","flowLockedText":"È attivo il passaggio {step}. Seleziona “1 Banner” per modificare immagine, testo o inquadratura.","returnFresco":"Seleziona 1 Banner per modificare","flowLockedToast":"Torna al passaggio 1 Banner per modificare il banner.","publisherTabReuse":"RBL usa un ID applicazione browser stabile per riutilizzare la stessa scheda.","todo":"Da fare","history":"Cronologia","inProgress":"In corso","addTodo":"Aggiungi a Da fare","removeTodo":"Rimuovi da Da fare","noTodo":"Nessun banner da fare. Quasi sospettosamente ragionevole.","noHistory":"Nessun banner giocato finora. Il dinosauro si annoia.","bannerMap":"Mappa del percorso","openMap":"Visualizza mappa","navigateStart":"Naviga verso la partenza","startUnavailable":"Punto di partenza non disponibile.","mapUnavailable":"Bannergress non fornisce coordinate utilizzabili per questo banner.","startPoint":"Partenza","missionStart":"Missione {n}","shareGroup":"Condividi / gruppo","shareProgress":"Condividi avanzamento","shareBanner":"Condividi banner","shareIntro":"Il QR apre RBL sullo stesso banner e sullo stesso numero di missione. Non viene usato alcun account Bannergress.","copyLink":"Copia link RBL","linkCopied":"Link RBL copiato","shareNow":"Condividi","bannergressPage":"Apri su Bannergress","joinBanner":"Unisciti al banner","joinAtMission":"Unisciti alla missione {n}","sharedBannerLoaded":"Banner condiviso caricato · missione {n}","sharedBannerError":"Impossibile caricare il banner condiviso: {error}","playStats":"Statistiche sessione","startedAt":"Iniziato","finishedAt":"Terminato","elapsed":"Tempo attivo","estimatedDistance":"Distanza stimata","missionsDone":"Missioni completate","paused":"In pausa","playing":"In corso","completedBanner":"Completato","replayBanner":"Gioca di nuovo","resumeFromHistory":"Riprendi","groupNoServer":"Modalità gruppo senza server: condividi di nuovo il QR/link se il gruppo passa a un’altra missione.","publicOnly":"Solo ricerca/dati pubblici Bannergress · nessun accesso richiesto.","routePoints":"{n} punti del percorso","uselessStats":"Statistiche inutili","loadingStats":"Calcolo di cose che nessuno ha chiesto…","statsUnavailable":"Coordinate insufficienti per calcolare le statistiche inutili.","bgDistance":"Distanza Bannergress","calculatedTrack":"Distanza a piedi stimata","walkingEstimate":"Tempo a piedi stimato","routeSteps":"Passi","uniquePlaces":"Luoghi unici","revisitedPlaces":"Visite ripetute","stepsPerKm":"Passi / km","avgMissionDistance":"Media / missione","longestMission":"Missione più lunga","longestLeg":"Tratto più lungo","betweenMissions":"Transizioni tra missioni","detourFactor":"Fattore di deviazione","routeCoverage":"Copertura mappa","missionShort":"M{n}","straightLine":"Partenza → arrivo","funStatsDisclaimer":"RBL calcola ogni tratto da portale a portale sulla rete pedonale OpenStreetMap. Ogni tratto viene controllato: scorciatoie impossibili o deviazioni chiaramente assurde vengono sostituite, solo per quel tratto, dalla distanza diretta. È una stima a piedi, non una misurazione GPS.","minutesShort":"{n} min","hoursMinutes":"{h} h {m}","xFactor":"×{n}","showUselessStats":"📊 Statistiche inutili","hideUselessStats":"Nascondi statistiche","statsLoaded":"Statistiche calcolate","directGeometric":"Distanza diretta cumulativa","routingDetour":"Rapporto rete / diretto","routingSource":"Routing","routingValhalla":"Valhalla + OpenStreetMap","routingFallback":"Valhalla non disponibile · stima geometrica","routingLoading":"Calcolo del percorso pedonale reale…","routingFailed":"Routing pedonale non disponibile, usate statistiche geometriche.","routingNative":"Valhalla + OSM · controllo per tratto","routingWeb":"Valhalla + OSM · controllo per tratto","routingErrorDetail":"Errore Valhalla: {error}","ingressRadius":"Raggio Ingress","ingressRadiusValue":"40 m","correctedLegs":"Tratti corretti","rawValhalla":"Valhalla grezzo","creditsTitle":"Crediti e ringraziamenti","bannergressThanks":"Grazie Bannergress","bannergressThanksText":"La ricerca dei banner e diversi dettagli pubblici mostrati in Redacted BannerLab si basano sui dati pubblici di Bannergress. Grazie al loro team e ai collaboratori per l’enorme lavoro svolto intorno ai banner Ingress.","bannergressNoLogin":"RBL non usa un account Bannergress: utilizza solo i dati pubblici necessari alla ricerca e alla visualizzazione dei banner.","independentProject":"Redacted BannerLab è un progetto indipendente e non è affiliato né approvato da Bannergress o dai servizi ufficiali Ingress.","visitBannergress":"Visita Bannergress","mapCredits":"Mappe e routing","mapCreditsText":"Le mappe usano dati OpenStreetMap. Le stime dei percorsi pedonali usano il motore di routing Valhalla.","rblCreditsFoot":"Grazie a tutti gli strumenti e ai collaboratori che rendono possibile questo ecosistema di missioni Ingress.","backgroundLayer":"Sfondo principale","layerName":"Livello immagine","selected":"Selezionato","visibleLayer":"Visibile","hiddenLayer":"Nascosto","moveUp":"Sposta su","moveDown":"Sposta giù","groupSelection":"Seleziona per gruppo","ungroup":"Separa gruppo","groupNeedTwo":"Seleziona almeno due livelli da raggruppare.","groupCreated":"Livelli raggruppati","groupRemoved":"Gruppo rimosso","deleteLayer":"Elimina livello","layerDeleted":"Livello eliminato","layerAdded":"Livello aggiunto","backgroundReplaced":"Sfondo sostituito","backgroundMissing":"Nessuno sfondo principale","backgroundFixed":"Lo sfondo resta sempre sotto gli altri livelli.","groupHint":"Seleziona più livelli, poi tocca Raggruppa. Un gruppo si sposta, si ingrandisce e ruota insieme.","layerOrder":"Ordine livelli","layerTransform":"Trasforma livello","groupTransform":"Trasforma gruppo","renameLayer":"Rinomina","duplicateLayer":"Duplica","layerDuplicated":"Livello duplicato","histAddLayer":"Aggiungi livello","histDeleteLayer":"Elimina livello","histReorderLayer":"Riordina livello","histGroupLayers":"Raggruppa livelli","histUngroupLayers":"Separa livelli","histVisibilityLayer":"Visibilità livello","histRenameLayer":"Rinomina livello","histDuplicateLayer":"Duplica livello","layerGroupBadge":"Gruppo","layerUngroup":"Separa questo gruppo","layerSelectHint":"Il livello selezionato può poi essere spostato direttamente sul banner.","layerDimensions":"{w} × {h} px","noImageContent":"Aggiungi almeno un’immagine prima di esportare.","groupRelative":"I controlli qui sotto trasformano l’intero gruppo insieme.","groupZoom":"Zoom gruppo","groupRotation":"Rotazione gruppo","allLayersTitle":"Livelli","allLayersDesc":"Seleziona l’elemento che vuoi manipolare. Immagini e testo restano modificabili dai rispettivi menu.","imageLayersSection":"Immagini","textLayersSection":"Testo","noExtraImageLayer":"Nessun livello immagine aggiuntivo","noTextLayer":"Nessun livello di testo","selectLayer":"Seleziona","editLayer":"Modifica","missionNumberQuestion":"Qual è il numero della missione?","groupName":"Gruppo {n}","groupCount":"{n} livello/i","creatorBy":"Creato da Zw4nn","diagnosticCopyFailed":"Impossibile copiare la diagnostica","diagnosticDescription":"Descrizione del problema:","projectImportInvalid":"Questo file non è un progetto Redacted BannerLab valido.","projectShareTitle":"Progetto Redacted BannerLab","projectImportHint":"Il progetto importato viene aggiunto senza modificare gli altri progetti.","backupText":"Salva tutti i progetti, le impostazioni e le immagini di BannerLab in un unico file JSON portatile.","backupFolder":"Cartella di backup","backupFolderChoose":"Scegli cartella","backupFolderChange":"Cambia cartella","backupFolderNone":"Nessuna cartella selezionata","backupFolderReady":"Cartella configurata","backupAuto":"Backup automatico in background","backupAutoHint":"Quando è attivo, BannerLab prepara regolarmente il backup dopo le modifiche e forza un salvataggio finale quando passa in background.","backupWorking":"Creazione backup…","backupSaved":"Backup completato","backupAutoSaved":"Backup automatico completato","backupFailed":"Backup non riuscito: {error}","backupNeedFolder":"Scegli prima una cartella di backup.","backupFolderError":"Impossibile usare questa cartella.","backupImported":"Backup ripristinato","backupInvalid":"Questo file non è un backup Redacted BannerLab valido.","backupImportTitle":"Ripristina backup","backupImportText":"{n} progetto/i trovato/i · backup del {date}","backupMerge":"Unisci","backupReplace":"Sostituisci tutto","backupReplaceWarn":"Sostituisci tutto elimina i progetti attualmente salvati su questo dispositivo prima del ripristino.","backupCancel":"Annulla","backupLast":"Ultimo backup: {date}","backupNever":"Nessun backup ancora","backupPortable":"Il JSON contiene anche le immagini. Può quindi essere grande, ma è completamente autosufficiente.","backupNativeOnly":"Il backup automatico in una cartella è disponibile su Android. L’esportazione/importazione JSON resta disponibile ovunque.","backupFolderChosen":"Cartella di backup salvata","backupNoChanges":"Nessuna modifica da salvare nel backup.","studioEdit":"Modifica a schermo intero","studioFit":"6 missioni","studioFitOne":"1 missione","studioFitAll":"Tutte","studioFrescoMode":"Banner","studioRotateHint":"6 missioni in verticale · le righe successive scorrono verso destra.","studioSelected":"Elemento selezionato","studioNoLayer":"Seleziona un livello o un elemento di testo dal pannello laterale.","studioGroupSelect":"Selezione gruppo","studioGroupNow":"Raggruppa","studioOpenFull":"Apri gestione completa","studioOpacity":"Opacità","studioClose":"Esci dallo studio","studioAddText":"Aggiungi testo","studioNoText":"Nessun testo per ora.","studioEditText":"Modifica testo","studioDuplicateText":"Duplica testo","font":"Font","fontImported":"Font importato: {name}","fontInvalid":"Questo font non è supportato.","fontTooLarge":"Il font è troppo grande (massimo 12 MB).","textBackground":"Sfondo del testo","textBackgroundColor":"Colore sfondo","textBackgroundOpacity":"Opacità sfondo","textBackgroundPadding":"Spaziatura interna sfondo","textBackgroundRadius":"Raggio angoli","tutorialOpen":"Visualizza tutorial","tutorialDone":"Tutorial completato","tutorialSeen":"Visto","importRolesHint":"Sfondo principale = immagine di base del banner · Livello = immagine aggiuntiva sovrapposta.","tutProjectTitle":"I tuoi progetti","tutProjectText":"Ogni banner vive nel proprio progetto. Puoi esportarlo o condividerlo senza trascinarti dietro tutti gli altri progetti.","tutNameTitle":"Nome progetto","tutNameText":"Dai al tuo banner un nome riconoscibile.","tutRowsTitle":"Numero di righe","tutRowsText":"Una riga contiene 6 missioni. Scegli qui l’altezza finale del banner.","tutImageTitle":"Immagini e livelli","tutImageText":"Importa qui lo sfondo principale e le immagini aggiuntive. Questa stessa schermata permette anche di selezionare, ordinare, nascondere e raggruppare i livelli immagine.","tutBackgroundTitle":"Sfondo principale","tutBackgroundText":"Per la prima vera immagine usa Sfondo principale. Sostituisce l’immagine di base e copre il banner.","tutExtraLayerTitle":"Aggiungi un livello","tutExtraLayerText":"Una seconda immagine è un livello: si trova sopra lo sfondo e resta spostabile, ridimensionabile e nascondibile.","tutLayersTitle":"Gestisci i livelli immagine","tutLayersText":"Le miniature mostrano quale livello immagine stai manipolando. Selezionalo, riordinalo, nascondilo oppure seleziona più immagini per raggrupparle.","tutTextTitle":"Testo","tutTextText":"Aggiungi testo, scegli font, spaziatura, sfondo, raggio oppure importa un tuo font.","tutPreviewTitle":"Anteprima","tutPreviewText":"Controlla ogni missione prima dell’esportazione. L’inquadratura individuale è già applicata.","tutExportTitle":"Esportazione","tutExportText":"Quando è tutto pronto, BannerLab crea le immagini missione da 512 × 512 nell’ordine corretto.","tutStudioTitle":"Studio a schermo intero","tutStudioText":"Un editor a schermo intero più comodo, con controlli laterali e ampie aree touch.","tutFlowTitle":"I 4 passaggi","tutFlowText":"Banner → Percorso → Missioni → Pubblica. BannerLab segue questo flusso.","tutRouteTitle":"Percorso","tutRouteText":"Il percorso collega le missioni ai veri portali Ingress. IITC Companion si occupa del lavoro sulla mappa.","tutCompanionTitle":"IITC Companion","tutCompanionText":"Companion porta in IITC il progetto attivo, la missione, i portali, le azioni e le statistiche a piedi.","tutInstallCompanionTitle":"Installa Companion","tutInstallCompanionText":"Installa o aggiorna lo userscript una sola volta in IITC Mobile.","tutOpenIitcTitle":"Apri IITC","tutOpenIitcText":"Apri IITC da BannerLab affinché progetto e missione attiva vengano passati a Companion.","tutAutoRouteTitle":"Passare da una missione all’altra","tutAutoRouteText":"La missione successiva può aprirsi automaticamente e riutilizzare l’ultimo portale della precedente come primo portale.","tutPortalListTitle":"I tuoi portali","tutPortalListText":"I portali tornano con GUID, coordinate, ordine e azione, così il percorso può essere ricostruito.","tutMissionsTitle":"Prepara le missioni","tutMissionsText":"Prima di pubblicare, inserisci la descrizione comune e controlla ogni missione.","tutMissionDescTitle":"Descrizione obbligatoria","tutMissionDescText":"BannerLab segnala le informazioni mancanti prima di consentire la pubblicazione.","tutPublishTitle":"Pubblica","tutPublishText":"Quando percorsi e descrizioni sono pronti, continua qui. L’invio finale resta nello strumento ufficiale.","tutPublisherExplainTitle":"Publisher","tutPublisherExplainText":"BannerLab prepara i dati delle missioni e il flusso di pubblicazione. Dopo l’invio, usa “Ho inviato” per verificare lo stato pubblicato.","tutBackupTitle":"Backup completo","tutBackupText":"Il JSON completo include tutti i progetti, le impostazioni, le immagini e i font. Android può anche usare una cartella di backup automatico.","tutPortableTitle":"Progetto portatile","tutPortableText":"Esporta, condividi o importa un banner con immagini, testo, font, missioni e percorso.","addMissionLayer":"Su una missione","importMissionSeries":"Importa una serie","missionLayer":"Livello missione","globalLayer":"Livello globale","missionBadge":"M{n}","missionLayerHint":"Questo livello resta collegato alla missione {n} e viene ritagliato automaticamente alla sua casella.","missionSeriesTitle":"Importa una serie di missioni","missionSeriesText":"Assegna ogni immagine a una missione. BannerLab le posiziona e le ritaglia automaticamente.","missionSeriesDetected":"{n} immagine/i rilevata/e","missionSeriesImport":"Importa livelli","missionSeriesTooMany":"Hai selezionato più immagini che missioni. È possibile assegnare più immagini alla stessa missione.","missionLayerAdded":"Immagine aggiunta alla missione {n}","missionSeriesAdded":"{n} livello/i missione aggiunto/i","missionScopeMismatch":"I livelli missione possono essere raggruppati solo se appartengono alla stessa missione.","missionLayerTutorialTitle":"Livelli collegati alle missioni","missionLayerTutorialText":"Tocca “Aggiungi un livello”, poi scegli: intero banner, una missione o più missioni. Per una missione, BannerLab posiziona e ritaglia automaticamente l’immagine nella sua casella. Per più missioni, importa una serie e assegna ogni immagine alla missione desiderata.","selectionActions":"Azioni selezione","bulkScopeKeep":"Mantieni ambito attuale","bulkMissionKeep":"Mantieni missioni attuali","bulkFitKeep":"Mantieni adattamento attuale","bulkVisibility":"Visibilità","bulkVisibilityKeep":"Non modificare","bulkShow":"Mostra","bulkHide":"Nascondi","bulkOpacityEnable":"Modifica opacità","applyToSelection":"Applica ai livelli selezionati","selectionUpdated":"Livelli selezionati aggiornati","selectionDeleted":"Livelli selezionati eliminati","deleteSelectionConfirm":"Eliminare definitivamente {n} livello/i selezionato/i?","selectionEmpty":"Seleziona almeno un livello.","layerScopeHelp":"Intero banner: il livello può coprire tutto il banner. Una missione: viene ritagliato automaticamente sulla missione scelta. Più missioni: importa una serie e assegna ogni immagine alla propria missione."});
// IITC IGOR 0.6.35: téléchargement/enregistrement natif du plugin.
Object.assign(I18N["fr"],{pluginInstallChoiceTitle:"Installer IGOR 0.6.35",pluginInstallChoiceText:"Choisis l’installation directe dans IITC Mobile ou enregistre une copie vérifiée du fichier .user.js dans Téléchargements.",pluginOpenIitc:"Ouvrir directement avec IITC",pluginOpenIitcText:"BannerLab transmet le fichier .user.js à IITC Mobile, qui ouvre directement son écran d’installation du plugin.",pluginSaveFile:"Enregistrer le fichier",pluginSaveFileText:"Enregistre une copie vérifiée de igor.user.js directement dans Téléchargements.",pluginOpenedIitc:"Plugin envoyé à IITC Mobile. Confirme son installation dans IITC.",pluginOpenFailed:"IITC Mobile n’a pas pu être ouvert. Tu peux enregistrer le fichier à la place."});
Object.assign(I18N["en"],{pluginInstallChoiceTitle:"Install IGOR 0.6.35",pluginInstallChoiceText:"Choose direct installation in IITC Mobile or save a verified .user.js copy to Downloads.",pluginOpenIitc:"Open directly with IITC",pluginOpenIitcText:"BannerLab sends the .user.js file to IITC Mobile, which opens its plugin installation screen directly.",pluginSaveFile:"Save the file",pluginSaveFileText:"Saves a verified copy of igor.user.js directly to Downloads.",pluginOpenedIitc:"Plugin sent to IITC Mobile. Confirm its installation in IITC.",pluginOpenFailed:"IITC Mobile could not be opened. You can save the file instead."});
Object.assign(I18N["de"],{pluginInstallChoiceTitle:"IGOR 0.6.35 installieren",pluginInstallChoiceText:"Wähle die direkte Installation in IITC Mobile oder speichere eine geprüfte .user.js-Kopie im Download-Ordner.",pluginOpenIitc:"Direkt mit IITC öffnen",pluginOpenIitcText:"BannerLab übergibt die .user.js-Datei an IITC Mobile, das direkt den Installationsbildschirm für das Plugin öffnet.",pluginSaveFile:"Datei speichern",pluginSaveFileText:"Speichert eine geprüfte Kopie von igor.user.js direkt im Download-Ordner.",pluginOpenedIitc:"Plugin an IITC Mobile übergeben. Bestätige die Installation in IITC.",pluginOpenFailed:"IITC Mobile konnte nicht geöffnet werden. Du kannst stattdessen die Datei speichern."});
Object.assign(I18N["nl"],{pluginInstallChoiceTitle:"IGOR 0.6.35 installeren",pluginInstallChoiceText:"Kies directe installatie in IITC Mobile of sla een gecontroleerde .user.js-kopie op in Downloads.",pluginOpenIitc:"Direct openen met IITC",pluginOpenIitcText:"BannerLab stuurt het .user.js-bestand naar IITC Mobile, dat meteen het installatiescherm van de plugin opent.",pluginSaveFile:"Bestand opslaan",pluginSaveFileText:"Slaat een gecontroleerde kopie van igor.user.js rechtstreeks op in Downloads.",pluginOpenedIitc:"Plugin naar IITC Mobile gestuurd. Bevestig de installatie in IITC.",pluginOpenFailed:"IITC Mobile kon niet worden geopend. Je kunt het bestand in plaats daarvan opslaan."});
Object.assign(I18N["pt"],{pluginInstallChoiceTitle:"Instalar IGOR 0.6.35",pluginInstallChoiceText:"Escolhe a instalação direta no IITC Mobile ou guarda uma cópia verificada do .user.js em Transferências.",pluginOpenIitc:"Abrir diretamente com IITC",pluginOpenIitcText:"O BannerLab envia o ficheiro .user.js para o IITC Mobile, que abre diretamente o ecrã de instalação do plugin.",pluginSaveFile:"Guardar o ficheiro",pluginSaveFileText:"Guarda uma cópia verificada de igor.user.js diretamente em Transferências.",pluginOpenedIitc:"Plugin enviado para o IITC Mobile. Confirma a instalação no IITC.",pluginOpenFailed:"Não foi possível abrir o IITC Mobile. Podes guardar o ficheiro em alternativa."});
Object.assign(I18N["es"],{pluginInstallChoiceTitle:"Instalar IGOR 0.6.35",pluginInstallChoiceText:"Elige la instalación directa en IITC Mobile o guarda una copia verificada del .user.js en Descargas.",pluginOpenIitc:"Abrir directamente con IITC",pluginOpenIitcText:"BannerLab envía el archivo .user.js a IITC Mobile, que abre directamente la pantalla de instalación del plugin.",pluginSaveFile:"Guardar el archivo",pluginSaveFileText:"Guarda una copia verificada de igor.user.js directamente en Descargas.",pluginOpenedIitc:"Plugin enviado a IITC Mobile. Confirma la instalación en IITC.",pluginOpenFailed:"No se ha podido abrir IITC Mobile. Puedes guardar el archivo en su lugar."});
Object.assign(I18N["it"],{pluginInstallChoiceTitle:"Installa IGOR 0.6.35",pluginInstallChoiceText:"Scegli l’installazione diretta in IITC Mobile oppure salva una copia verificata del .user.js in Download.",pluginOpenIitc:"Apri direttamente con IITC",pluginOpenIitcText:"BannerLab invia il file .user.js a IITC Mobile, che apre direttamente la schermata di installazione del plugin.",pluginSaveFile:"Salva il file",pluginSaveFileText:"Salva una copia verificata di igor.user.js direttamente in Download.",pluginOpenedIitc:"Plugin inviato a IITC Mobile. Conferma l’installazione in IITC.",pluginOpenFailed:"Impossibile aprire IITC Mobile. Puoi salvare il file al suo posto."});
Object.assign(I18N["fr"],{pluginSaved:"Plugin IITC enregistré. Ouvre IITC Mobile et installe ce fichier comme plugin utilisateur.",pluginSaveFailed:"Impossible d’enregistrer le plugin IITC."});
Object.assign(I18N["en"],{pluginSaved:"IITC plugin saved. Open IITC Mobile and install this file as a user plugin.",pluginSaveFailed:"Unable to save the IITC plugin."});
Object.assign(I18N["es"],{pluginSaved:"Plugin IITC guardado. Abre IITC Mobile e instala este archivo como plugin de usuario.",pluginSaveFailed:"No se ha podido guardar el plugin IITC."});
Object.assign(I18N["pt"],{pluginSaved:"Plugin IITC guardado. Abre o IITC Mobile e instala este ficheiro como plugin de utilizador.",pluginSaveFailed:"Não foi possível guardar o plugin IITC."});
Object.assign(I18N["de"],{pluginSaved:"IITC-Plugin gespeichert. Öffne IITC Mobile und installiere diese Datei als Benutzer-Plugin.",pluginSaveFailed:"Das IITC-Plugin konnte nicht gespeichert werden."});
Object.assign(I18N["it"],{pluginSaved:"Plugin IITC salvato. Apri IITC Mobile e installa questo file come plugin utente.",pluginSaveFailed:"Impossibile salvare il plugin IITC."});
Object.assign(I18N["nl"],{pluginSaved:"IITC-plugin opgeslagen. Open IITC Mobile en installeer dit bestand als gebruikersplugin.",pluginSaveFailed:"Het IITC-plugin kon niet worden opgeslagen."});
Object.assign(I18N["pl"],{pluginSaved:"Wtyczka IITC została zapisana. Otwórz IITC Mobile i zainstaluj ten plik jako wtyczkę użytkownika.",pluginSaveFailed:"Nie udało się zapisać wtyczki IITC."});
Object.assign(I18N["cs"],{pluginSaved:"Plugin IITC byl uložen. Otevři IITC Mobile a nainstaluj tento soubor jako uživatelský plugin.",pluginSaveFailed:"Plugin IITC se nepodařilo uložit."});
Object.assign(I18N["ro"],{pluginSaved:"Pluginul IITC a fost salvat. Deschide IITC Mobile și instalează acest fișier ca plugin de utilizator.",pluginSaveFailed:"Pluginul IITC nu a putut fi salvat."});
Object.assign(I18N["tr"],{pluginSaved:"IITC eklentisi kaydedildi. IITC Mobile’ı aç ve bu dosyayı kullanıcı eklentisi olarak yükle.",pluginSaveFailed:"IITC eklentisi kaydedilemedi."});
Object.assign(I18N["ru"],{pluginSaved:"Плагин IITC сохранён. Открой IITC Mobile и установи этот файл как пользовательский плагин.",pluginSaveFailed:"Не удалось сохранить плагин IITC."});
Object.assign(I18N["uk"],{pluginSaved:"Плагін IITC збережено. Відкрий IITC Mobile та встанови цей файл як користувацький плагін.",pluginSaveFailed:"Не вдалося зберегти плагін IITC."});
Object.assign(I18N["ja"],{pluginSaved:"IITCプラグインを保存しました。IITC Mobileを開き、このファイルをユーザープラグインとしてインストールしてください。",pluginSaveFailed:"IITCプラグインを保存できませんでした。"});
Object.assign(I18N["ko"],{pluginSaved:"IITC 플러그인을 저장했습니다. IITC Mobile을 열고 이 파일을 사용자 플러그인으로 설치하세요.",pluginSaveFailed:"IITC 플러그인을 저장하지 못했습니다."});
Object.assign(I18N["zh-Hans"],{pluginSaved:"IITC 插件已保存。打开 IITC Mobile，并将此文件安装为用户插件。",pluginSaveFailed:"无法保存 IITC 插件。"});
Object.assign(I18N["zh-Hant"],{pluginSaved:"IITC 外掛已儲存。開啟 IITC Mobile，並將此檔案安裝為使用者外掛。",pluginSaveFailed:"無法儲存 IITC 外掛。"});
Object.assign(I18N["yue"],{pluginSaved:"IITC 外掛已經儲存。打開 IITC Mobile，將呢個檔案安裝做使用者外掛。",pluginSaveFailed:"儲存唔到 IITC 外掛。"});
Object.assign(I18N["ar"],{pluginSaved:"تم حفظ إضافة IITC. افتح IITC Mobile وثبّت هذا الملف كإضافة مستخدم.",pluginSaveFailed:"تعذّر حفظ إضافة IITC."});
Object.assign(I18N["id"],{pluginSaved:"Plugin IITC disimpan. Buka IITC Mobile lalu pasang file ini sebagai plugin pengguna.",pluginSaveFailed:"Plugin IITC tidak dapat disimpan."});
Object.assign(I18N.fr,{iitcDirectTitle:'Companion IITC',iitcDirectText:'BannerLab installe et met à jour directement IGOR dans IITC_Mobile/plugins. L’accès au dossier n’est demandé qu’une seule fois.',iitcInstalled:'Installé',iitcAvailable:'Disponible',iitcNotInstalled:'Non installé',iitcAccessMissing:'Accès IITC_Mobile non configuré',iitcUpToDate:'À jour ✓',iitcBuildUpdate:'Même version · build différent',iitcChooseInstall:'Choisir IITC_Mobile et installer',iitcInstall:'Installer',iitcUpdate:'Mettre à jour',iitcReinstall:'Réinstaller',iitcChangeFolder:'Changer de dossier',iitcSaveCopy:'Enregistrer une copie',iitcDirectDone:'Companion IITC installé et vérifié.',iitcDirectUpdated:'Companion IITC mis à jour et vérifié.',iitcLegacyMigrated:'Ancienne identité du Companion supprimée automatiquement.',iitcFolderHint:'À la première utilisation, sélectionne le dossier IITC_Mobile ou directement son sous-dossier plugins.',iitcFolderError:'Sélectionne le dossier IITC_Mobile (ou IITC_Mobile/plugins).',iitcInstallInIitc:'Installer via IITC',iitcOpenPlugins:'Companion installé · ouverture d’IITC…',iitcEnableHint:'Première installation : IITC affichera sa propre confirmation d’installation. Valide-la, puis active BannerLab une fois dans Plugins → Mission. Si IGOR existe déjà, le Lab le met à jour directement car l’import IITC ne sait pas écraser un fichier existant.'});
Object.assign(I18N.en,{iitcDirectTitle:'IITC Companion',iitcDirectText:'BannerLab installs and updates IGOR directly in IITC_Mobile/plugins. Folder access is requested only once.',iitcInstalled:'Installed',iitcAvailable:'Available',iitcNotInstalled:'Not installed',iitcAccessMissing:'IITC_Mobile access not configured',iitcUpToDate:'Up to date ✓',iitcBuildUpdate:'Same version · different build',iitcChooseInstall:'Choose IITC_Mobile and install',iitcInstall:'Install',iitcUpdate:'Update',iitcReinstall:'Reinstall',iitcChangeFolder:'Change folder',iitcSaveCopy:'Save a copy',iitcDirectDone:'IITC Companion installed and verified.',iitcDirectUpdated:'IITC Companion updated and verified.',iitcLegacyMigrated:'Previous Companion identity removed automatically.',iitcFolderHint:'On first use, select the IITC_Mobile folder or its plugins subfolder directly.',iitcFolderError:'Select the IITC_Mobile folder (or IITC_Mobile/plugins).',iitcInstallInIitc:'Install via IITC',iitcOpenPlugins:'Companion installed · opening IITC…',iitcEnableHint:'First install: IITC will show its own installation confirmation. Accept it, then enable BannerLab once in Plugins → Mission. If IGOR already exists, the Lab updates it directly because IITC import cannot overwrite an existing file.'});
Object.assign(I18N.de,{iitcDirectTitle:'IITC Companion',iitcDirectText:'BannerLab installiert und aktualisiert den IGOR direkt in IITC_Mobile/plugins. Der Ordnerzugriff wird nur einmal angefordert.',iitcInstalled:'Installiert',iitcAvailable:'Verfügbar',iitcNotInstalled:'Nicht installiert',iitcAccessMissing:'IITC_Mobile-Zugriff nicht eingerichtet',iitcUpToDate:'Aktuell ✓',iitcBuildUpdate:'Gleiche Version · anderer Build',iitcChooseInstall:'IITC_Mobile wählen und installieren',iitcInstall:'Installieren',iitcUpdate:'Aktualisieren',iitcReinstall:'Neu installieren',iitcChangeFolder:'Ordner ändern',iitcSaveCopy:'Kopie speichern',iitcDirectDone:'IITC Companion installiert und geprüft.',iitcDirectUpdated:'IITC Companion aktualisiert und geprüft.',iitcLegacyMigrated:'Alte Companion-Identität automatisch entfernt.',iitcFolderHint:'Wähle bei der ersten Nutzung IITC_Mobile oder direkt dessen Unterordner plugins.',iitcFolderError:'Wähle IITC_Mobile (oder IITC_Mobile/plugins).',iitcInstallInIitc:'Über IITC installieren',iitcOpenPlugins:'Companion installiert · IITC wird geöffnet…',iitcEnableHint:'Bei der ersten Installation zeigt IITC seine eigene Installationsbestätigung. Bestätige sie und aktiviere BannerLab einmal unter Plugins → Mission. Existiert IGOR bereits, aktualisiert das Lab ihn direkt, da IITC beim Import keine vorhandene Datei überschreibt.'});
Object.assign(I18N.nl,{iitcDirectTitle:'IITC Companion',iitcDirectText:'BannerLab installeert en werkt IGOR rechtstreeks bij in IITC_Mobile/plugins. Maptoegang wordt slechts één keer gevraagd.',iitcInstalled:'Geïnstalleerd',iitcAvailable:'Beschikbaar',iitcNotInstalled:'Niet geïnstalleerd',iitcAccessMissing:'Toegang tot IITC_Mobile niet ingesteld',iitcUpToDate:'Up-to-date ✓',iitcBuildUpdate:'Zelfde versie · andere build',iitcChooseInstall:'IITC_Mobile kiezen en installeren',iitcInstall:'Installeren',iitcUpdate:'Bijwerken',iitcReinstall:'Opnieuw installeren',iitcChangeFolder:'Map wijzigen',iitcSaveCopy:'Kopie opslaan',iitcDirectDone:'IITC Companion geïnstalleerd en gecontroleerd.',iitcDirectUpdated:'IITC Companion bijgewerkt en gecontroleerd.',iitcLegacyMigrated:'OuIGOR-identiteit automatisch verwijderd.',iitcFolderHint:'Selecteer bij het eerste gebruik IITC_Mobile of direct de submap plugins.',iitcFolderError:'Selecteer IITC_Mobile (of IITC_Mobile/plugins).',iitcInstallInIitc:'Via IITC installeren',iitcOpenPlugins:'Companion geïnstalleerd · IITC-plug-ins openen…',iitcEnableHint:'Bij de eerste installatie toont IITC zijn eigen installatiebevestiging. Bevestig die en activeer BannerLab één keer via Plugins → Mission. Bestaat IGOR al, dan werkt het Lab hem rechtstreeks bij omdat IITC-import geen bestaand bestand kan overschrijven.'});
Object.assign(I18N.pt,{iitcDirectTitle:'Companion IITC',iitcDirectText:'O BannerLab instala e atualiza diretamente o IGOR em IITC_Mobile/plugins. O acesso à pasta só é pedido uma vez.',iitcInstalled:'Instalado',iitcAvailable:'Disponível',iitcNotInstalled:'Não instalado',iitcAccessMissing:'Acesso a IITC_Mobile não configurado',iitcUpToDate:'Atualizado ✓',iitcBuildUpdate:'Mesma versão · build diferente',iitcChooseInstall:'Escolher IITC_Mobile e instalar',iitcInstall:'Instalar',iitcUpdate:'Atualizar',iitcReinstall:'Reinstalar',iitcChangeFolder:'Alterar pasta',iitcSaveCopy:'Guardar uma cópia',iitcDirectDone:'Companion IITC instalado e verificado.',iitcDirectUpdated:'Companion IITC atualizado e verificado.',iitcLegacyMigrated:'Identidade antiga do IGOR removida automaticamente.',iitcFolderHint:'Na primeira utilização, seleciona IITC_Mobile ou diretamente a subpasta plugins.',iitcFolderError:'Seleciona IITC_Mobile (ou IITC_Mobile/plugins).',iitcInstallInIitc:'Instalar via IITC',iitcOpenPlugins:'Companion instalado · a abrir os plugins do IITC…',iitcEnableHint:'Na primeira instalação, o IITC mostrará a própria confirmação de instalação. Confirma e depois ativa o BannerLab uma vez em Plugins → Mission. Se o IGOR já existir, o Lab atualiza-o diretamente porque a importação do IITC não consegue substituir um ficheiro existente.'});
Object.assign(I18N.es,{iitcDirectTitle:'Companion IITC',iitcDirectText:'BannerLab instala y actualiza directamente IGOR en IITC_Mobile/plugins. El acceso a la carpeta solo se solicita una vez.',iitcInstalled:'Instalado',iitcAvailable:'Disponible',iitcNotInstalled:'No instalado',iitcAccessMissing:'Acceso a IITC_Mobile no configurado',iitcUpToDate:'Actualizado ✓',iitcBuildUpdate:'Misma versión · build diferente',iitcChooseInstall:'Elegir IITC_Mobile e instalar',iitcInstall:'Instalar',iitcUpdate:'Actualizar',iitcReinstall:'Reinstalar',iitcChangeFolder:'Cambiar carpeta',iitcSaveCopy:'Guardar una copia',iitcDirectDone:'Companion IITC instalado y verificado.',iitcDirectUpdated:'Companion IITC actualizado y verificado.',iitcLegacyMigrated:'Identidad anterior dIGOR eliminada automáticamente.',iitcFolderHint:'En el primer uso, selecciona IITC_Mobile o directamente su subcarpeta plugins.',iitcFolderError:'Selecciona IITC_Mobile (o IITC_Mobile/plugins).',iitcInstallInIitc:'Instalar mediante IITC',iitcOpenPlugins:'Companion instalado · abriendo IITC…',iitcEnableHint:'En la primera instalación, IITC mostrará su propia confirmación de instalación. Acéptala y después activa BannerLab una vez en Plugins → Mission. Si IGOR ya existe, el Lab lo actualiza directamente porque la importación de IITC no puede sobrescribir un archivo existente.'});
Object.assign(I18N.it,{iitcDirectTitle:'Companion IITC',iitcDirectText:'BannerLab installa e aggiorna direttamente IGOR in IITC_Mobile/plugins. L’accesso alla cartella viene richiesto una sola volta.',iitcInstalled:'Installato',iitcAvailable:'Disponibile',iitcNotInstalled:'Non installato',iitcAccessMissing:'Accesso a IITC_Mobile non configurato',iitcUpToDate:'Aggiornato ✓',iitcBuildUpdate:'Stessa versione · build diversa',iitcChooseInstall:'Scegli IITC_Mobile e installa',iitcInstall:'Installa',iitcUpdate:'Aggiorna',iitcReinstall:'Reinstalla',iitcChangeFolder:'Cambia cartella',iitcSaveCopy:'Salva una copia',iitcDirectDone:'Companion IITC installato e verificato.',iitcDirectUpdated:'Companion IITC aggiornato e verificato.',iitcLegacyMigrated:'Vecchia identità dIGOR rimossa automaticamente.',iitcFolderHint:'Al primo utilizzo seleziona IITC_Mobile o direttamente la sottocartella plugins.',iitcFolderError:'Seleziona IITC_Mobile (o IITC_Mobile/plugins).',iitcInstallInIitc:'Installa tramite IITC',iitcOpenPlugins:'Companion installato · apertura IITC…',iitcEnableHint:'Alla prima installazione IITC mostrerà la propria conferma di installazione. Conferma e poi attiva BannerLab una volta in Plugins → Mission. Se IGOR esiste già, il Lab lo aggiorna direttamente perché l’importazione IITC non può sovrascrivere un file esistente.'});
Object.assign(I18N.fr,{pluginShareText:'IGOR 0.6.39. BannerLab l’installe et le met désormais à jour directement dans IITC_Mobile/plugins.',tut1Text:'Dans Parcours, utilise « Installer / mettre à jour le plugin IITC ». La première fois, autorise le dossier IITC_Mobile ; ensuite BannerLab remplace directement IGOR.'});
Object.assign(I18N.fr,{tut2Text:'Ouvre IITC depuis le Lab : pour un projet déjà connu, IGOR reprend d’abord sa mémoire locale. Si tu as modifié le projet directement dans le Lab entre-temps, utilise ensuite « ↓ Charger depuis le Lab » dans IITC.',tut4Text:'Quand tu veux renvoyer ton travail IITC, utilise « ↑ Envoyer vers le Lab ». Les échanges restent volontaires : le Lab n’écrase jamais la mémoire IITC sans « ↓ Charger depuis le Lab ».'});
Object.assign(I18N.en,{pluginShareText:'IGOR 0.6.39. BannerLab now installs and updates it directly in IITC_Mobile/plugins.',tut1Text:'In Route, use “Install / update IITC plugin”. The first time, grant access to IITC_Mobile; after that BannerLab replaces IGOR directly.'});
Object.assign(I18N.de,{pluginShareText:'IGOR 0.6.39. BannerLab installiert und aktualisiert ihn jetzt direkt in IITC_Mobile/plugins.',tut1Text:'Verwende unter Route „IITC-Plugin installieren/aktualisieren“. Beim ersten Mal IITC_Mobile freigeben; danach ersetzt BannerLab den IGOR direkt.'});
Object.assign(I18N.nl,{pluginShareText:'IGOR 0.6.39. BannerLab installeert en werkt hem nu rechtstreeks bij in IITC_Mobile/plugins.',tut1Text:'Gebruik in Route “IITC-plugin installeren/bijwerken”. Geef de eerste keer toegang tot IITC_Mobile; daarna vervangt BannerLab IGOR rechtstreeks.'});
Object.assign(I18N.pt,{pluginShareText:'IGOR 0.6.39. O BannerLab instala-o e atualiza-o agora diretamente em IITC_Mobile/plugins.',tut1Text:'Em Percurso, usa “Instalar / atualizar plugin IITC”. Na primeira vez autoriza IITC_Mobile; depois o BannerLab substitui diretamente o IGOR.'});
Object.assign(I18N.es,{pluginShareText:'IGOR 0.6.39. BannerLab ahora lo instala y actualiza directamente en IITC_Mobile/plugins.',tut1Text:'En Ruta, usa “Instalar / actualizar plugin IITC”. La primera vez autoriza IITC_Mobile; después BannerLab reemplaza directamente IGOR.'});
Object.assign(I18N.it,{pluginShareText:'IGOR 0.6.39. BannerLab ora lo installa e aggiorna direttamente in IITC_Mobile/plugins.',tut1Text:'In Percorso usa “Installa / aggiorna plugin IITC”. La prima volta autorizza IITC_Mobile; poi BannerLab sostituisce direttamente IGOR.'});

// Chaînes utilisées hors des écrans principaux : éviter les textes codés en dur lors des exports et diagnostics.
Object.assign(I18N.fr,{close:'Fermer'});
Object.assign(I18N.en,{close:'Close'});
Object.assign(I18N.es,{close:'Cerrar'});
Object.assign(I18N.pt,{close:'Fechar'});
Object.assign(I18N.de,{close:'Schließen'});
Object.assign(I18N.nl,{close:'Sluiten'});
Object.assign(I18N.it,{close:'Chiudi'});
Object.assign(I18N.fr,{missionLabel:'Mission {n}',syncUnreadable:'Synchronisation IITC illisible.',canvasExportFailed:'Export du canvas impossible.',projectSaveFailed:'Impossible d’enregistrer le projet.',platformLabel:'Plateforme',orderRowsLine:'{rows} rangée(s) · {missions} missions',orderTitle:'Ordre de création :',orderItem:'{file} : rangée {row} depuis le haut, colonne {col} depuis la gauche{adjusted}',orderAdjusted:' · recadrage individuel'});
Object.assign(I18N.en,{missionLabel:'Mission {n}',syncUnreadable:'IITC synchronization data could not be read.',canvasExportFailed:'Canvas export failed.',projectSaveFailed:'Unable to save the project.',platformLabel:'Platform',orderRowsLine:'{rows} row(s) · {missions} missions',orderTitle:'Creation order:',orderItem:'{file}: row {row} from the top, column {col} from the left{adjusted}',orderAdjusted:' · individual framing'});
Object.assign(I18N.es,{missionLabel:'Misión {n}',syncUnreadable:'No se pueden leer los datos de sincronización de IITC.',canvasExportFailed:'No se ha podido exportar el lienzo.',projectSaveFailed:'No se ha podido guardar el proyecto.',platformLabel:'Plataforma',orderRowsLine:'{rows} fila(s) · {missions} misiones',orderTitle:'Orden de creación:',orderItem:'{file}: fila {row} desde arriba, columna {col} desde la izquierda{adjusted}',orderAdjusted:' · encuadre individual'});
Object.assign(I18N.pt,{missionLabel:'Missão {n}',syncUnreadable:'Não foi possível ler os dados de sincronização do IITC.',canvasExportFailed:'Não foi possível exportar a tela.',projectSaveFailed:'Não foi possível guardar o projeto.',platformLabel:'Plataforma',orderRowsLine:'{rows} linha(s) · {missions} missões',orderTitle:'Ordem de criação:',orderItem:'{file}: linha {row} a partir do topo, coluna {col} a partir da esquerda{adjusted}',orderAdjusted:' · enquadramento individual'});
Object.assign(I18N.de,{missionLabel:'Mission {n}',syncUnreadable:'Die IITC-Synchronisationsdaten konnten nicht gelesen werden.',canvasExportFailed:'Canvas-Export fehlgeschlagen.',projectSaveFailed:'Projekt konnte nicht gespeichert werden.',platformLabel:'Plattform',orderRowsLine:'{rows} Reihe(n) · {missions} Missionen',orderTitle:'Erstellungsreihenfolge:',orderItem:'{file}: Reihe {row} von oben, Spalte {col} von links{adjusted}',orderAdjusted:' · individueller Ausschnitt'});
Object.assign(I18N.nl,{missionLabel:'Missie {n}',syncUnreadable:'De IITC-synchronisatiegegevens konden niet worden gelezen.',canvasExportFailed:'Canvas exporteren is mislukt.',projectSaveFailed:'Het project kon niet worden opgeslagen.',platformLabel:'Platform',orderRowsLine:'{rows} rij(en) · {missions} missies',orderTitle:'Aanmaakvolgorde:',orderItem:'{file}: rij {row} vanaf boven, kolom {col} vanaf links{adjusted}',orderAdjusted:' · individuele uitsnede'});
Object.assign(I18N.it,{missionLabel:'Missione {n}',syncUnreadable:'Impossibile leggere i dati di sincronizzazione IITC.',canvasExportFailed:'Esportazione canvas non riuscita.',projectSaveFailed:'Impossibile salvare il progetto.',platformLabel:'Piattaforma',orderRowsLine:'{rows} riga/he · {missions} missioni',orderTitle:'Ordine di creazione:',orderItem:'{file}: riga {row} dall’alto, colonna {col} da sinistra{adjusted}',orderAdjusted:' · inquadratura individuale'});
// Branding IGOR — nom visible uniquement. Les identifiants techniques du Companion restent inchangés.
Object.assign(I18N.fr,{igorTitle:'🧪 IGOR',igorSubtitle:'Assistant IITC du Lab',igorConnected:'IGOR est connecté à IITC',pluginVersion:'0.6.39',openIitc:'Ouvrir IGOR dans IITC',installPlugin:'Installer / mettre à jour IGOR',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectText:'Assistant IITC du Lab. Redacted BannerLab installe et met à jour IGOR dans IITC_Mobile/plugins ; l’accès au dossier n’est demandé qu’une seule fois.',iitcDirectDone:'IGOR installé et vérifié.',iitcDirectUpdated:'IGOR mis à jour et vérifié.',iitcLegacyMigrated:'Ancienne identité technique du Companion nettoyée automatiquement.',iitcInstallInIitc:'Installer IGOR via IITC',iitcOpenPlugins:'IGOR installé · ouverture d’IITC…',pluginDialog:'Installer / mettre à jour IGOR 0.6.39',pluginShareText:'IGOR 0.6.39 · Assistant IITC du Lab.',tutCompanionTitle:'🧪 IGOR',tutCompanionText:'IGOR est l’assistant IITC du Lab : projet actif, missions, portails, actions, tracés et mémoire locale.',tutInstallCompanionTitle:'Installe IGOR',tutInstallCompanionText:'Installe ou mets à jour IGOR une seule fois dans IITC Mobile.',tutOpenIitcText:'Ouvre IITC depuis Redacted BannerLab afin que le projet et la mission active soient transmis à IGOR.'});
Object.assign(I18N.en,{igorTitle:'🧪 IGOR',igorSubtitle:'The Lab’s IITC assistant',igorConnected:'IGOR is connected to IITC',pluginVersion:'0.6.39',openIitc:'Open IGOR in IITC',installPlugin:'Install / update IGOR',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectText:'The Lab’s IITC assistant. Redacted BannerLab installs and updates IGOR in IITC_Mobile/plugins; folder access is requested only once.',iitcDirectDone:'IGOR installed and verified.',iitcDirectUpdated:'IGOR updated and verified.',iitcInstallInIitc:'Install IGOR via IITC',iitcOpenPlugins:'IGOR installed · opening IITC…',pluginDialog:'Install / update IGOR 0.6.39',pluginShareText:'IGOR 0.6.39 · The Lab’s IITC assistant.',tutCompanionTitle:'🧪 IGOR',tutCompanionText:'IGOR is the Lab’s IITC assistant: active project, missions, portals, actions, routes and local memory.',tutInstallCompanionTitle:'Install IGOR',tutInstallCompanionText:'Install or update IGOR once in IITC Mobile.',tutOpenIitcText:'Open IITC from Redacted BannerLab so the active project and mission are handed to IGOR.'});
Object.assign(I18N.de,{igorTitle:'🧪 IGOR',igorSubtitle:'IITC-Assistent des Labs',igorConnected:'IGOR ist mit IITC verbunden',pluginVersion:'0.6.39',openIitc:'IGOR in IITC öffnen',installPlugin:'IGOR installieren / aktualisieren',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectDone:'IGOR installiert und geprüft.',iitcDirectUpdated:'IGOR aktualisiert und geprüft.',iitcInstallInIitc:'IGOR über IITC installieren'});
Object.assign(I18N.nl,{igorTitle:'🧪 IGOR',igorSubtitle:'IITC-assistent van het Lab',igorConnected:'IGOR is verbonden met IITC',pluginVersion:'0.6.39',openIitc:'IGOR openen in IITC',installPlugin:'IGOR installeren / bijwerken',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectDone:'IGOR geïnstalleerd en gecontroleerd.',iitcDirectUpdated:'IGOR bijgewerkt en gecontroleerd.',iitcInstallInIitc:'IGOR via IITC installeren'});
Object.assign(I18N.pt,{igorTitle:'🧪 IGOR',igorSubtitle:'Assistente IITC do Lab',igorConnected:'IGOR está ligado ao IITC',pluginVersion:'0.6.39',openIitc:'Abrir IGOR no IITC',installPlugin:'Instalar / atualizar IGOR',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectDone:'IGOR instalado e verificado.',iitcDirectUpdated:'IGOR atualizado e verificado.',iitcInstallInIitc:'Instalar IGOR via IITC'});
Object.assign(I18N.es,{igorTitle:'🧪 IGOR',igorSubtitle:'Asistente IITC del Lab',igorConnected:'IGOR está conectado a IITC',pluginVersion:'0.6.39',openIitc:'Abrir IGOR en IITC',installPlugin:'Instalar / actualizar IGOR',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectDone:'IGOR instalado y verificado.',iitcDirectUpdated:'IGOR actualizado y verificado.',iitcInstallInIitc:'Instalar IGOR mediante IITC'});
Object.assign(I18N.it,{igorTitle:'🧪 IGOR',igorSubtitle:'Assistente IITC del Lab',igorConnected:'IGOR è collegato a IITC',pluginVersion:'0.6.39',openIitc:'Apri IGOR in IITC',installPlugin:'Installa / aggiorna IGOR',iitcDirectTitle:'🧪 IGOR 0.6.39',iitcDirectDone:'IGOR installato e verificato.',iitcDirectUpdated:'IGOR aggiornato e verificato.',iitcInstallInIitc:'Installa IGOR tramite IITC'});

Object.assign(I18N.fr,{infoMilo:'assistant de publication des missions dans Mission Authoring Tool.',infoRita:'assistante Telegram du Lab pour le support, les informations et les échanges.',infoLeon:'calculateur AP du Lab : objectif de niveau, import des stats, bonus en cours et plan TOUT PILE.',telegramOpen:'Contacter RITA',communityText:'Accède à la communauté et au support directement via RITA, le bot Telegram du Lab.',reportProblemText:'Copie un diagnostic technique puis contacte RITA pour décrire le problème.'});
Object.assign(I18N.en,{infoMilo:'mission publishing assistant for Mission Authoring Tool.',infoRita:'the Lab’s Telegram assistant for support, information and community links.',infoLeon:'the Lab AP calculator: level target, stats import, live bonuses and exact AP plan.',telegramOpen:'Contact RITA',communityText:'Access the community and support through RITA, the Lab Telegram bot.',reportProblemText:'Copy a technical diagnostic, then contact RITA to describe the problem.'});
Object.assign(I18N.fr,{updateTitle:'Mises à jour',updateIgorTitle:'🧪 IGOR surveille le Lab',updateIgorText:'IGOR vérifie GitHub Releases, télécharge et contrôle l’APK. L’installation ne démarre qu’après un appui séparé sur Installer.',updateCurrent:'Version actuelle',updateLatest:'Dernière version',updateAutoCheck:'Rechercher automatiquement',updateAutoDownload:'Télécharger automatiquement',updateAutoInstall:'Installer automatiquement',updateCheckNow:'Rechercher maintenant',updateChecking:'IGOR inspecte les éprouvettes GitHub…',updateUpToDate:'Le Lab est à jour ✓',updateAvailable:'Mise à jour disponible',updateDownloadInstall:'Télécharger',updateDownload:'Télécharger',updateInstall:'Installer',updateIgnore:'Ignorer cette version',updateIgnored:'Version ignorée',updatePermission:'Autoriser les mises à jour',updatePermissionText:'Android doit autoriser Redacted BannerLab à installer ses propres mises à jour depuis cette source. Cette autorisation n’est demandée qu’une fois.',updateOpenPermission:'Autoriser RBL',updateDownloading:'Téléchargement',updateVerifying:'Vérification de l’APK…',updateReady:'APK téléchargé et vérifié · prêt à installer',updateInstalling:'Préparation de l’installation Android…',updatePendingAndroid:'Demande d’installation transmise à Android. Attente de la confirmation système…',updateError:'Échec de la mise à jour',updateRepoMissing:'Dépôt GitHub non injecté dans ce build.',updateDigestMissing:'Cette release ne fournit pas de SHA-256 exploitable. Installation automatique refusée.',updateNoApk:'Aucun APK RBL trouvé dans la dernière release.',updateReleaseNotes:'Notes de version'});
Object.assign(I18N.en,{updateTitle:'Updates',updateIgorTitle:'🧪 IGOR watches the Lab',updateIgorText:'IGOR checks GitHub Releases, downloads and verifies the APK. Installation starts only after a separate tap on Install.',updateCurrent:'Current version',updateLatest:'Latest version',updateAutoCheck:'Check automatically',updateAutoDownload:'Download automatically',updateAutoInstall:'Install automatically',updateCheckNow:'Check now',updateChecking:'IGOR is inspecting the GitHub test tubes…',updateUpToDate:'The Lab is up to date ✓',updateAvailable:'Update available',updateDownloadInstall:'Download',updateDownload:'Download',updateInstall:'Install',updateIgnore:'Ignore this version',updateIgnored:'Version ignored',updatePermission:'Allow updates',updatePermissionText:'Android must allow Redacted BannerLab to install its own updates from this source. This is requested only once.',updateOpenPermission:'Allow RBL',updateDownloading:'Downloading',updateVerifying:'Verifying APK…',updateReady:'APK downloaded and verified · ready to install',updateInstalling:'Preparing Android installation…',updatePendingAndroid:'Installation request sent to Android. Waiting for the system confirmation…',updateError:'Update failed',updateRepoMissing:'GitHub repository was not injected into this build.',updateDigestMissing:'This release has no usable SHA-256. Automatic install refused.',updateNoApk:'No RBL APK found in the latest release.',updateReleaseNotes:'Release notes'});
Object.assign(I18N.de,{updateTitle:'Updates',updateIgorTitle:'🧪 IGOR überwacht das Lab',updateIgorText:'IGOR prüft GitHub Releases, lädt das APK, kontrolliert Prüfsumme und Signatur und startet dann das Update.',updateCurrent:'Aktuelle Version',updateLatest:'Neueste Version',updateAutoCheck:'Automatisch prüfen',updateAutoDownload:'Automatisch herunterladen',updateAutoInstall:'Automatisch installieren',updateCheckNow:'Jetzt prüfen',updateUpToDate:'Das Lab ist aktuell ✓',updateAvailable:'Update verfügbar',updateDownloadInstall:'Herunterladen',updateIgnore:'Diese Version ignorieren'});
Object.assign(I18N.nl,{updateTitle:'Updates',updateIgorTitle:'🧪 IGOR bewaakt het Lab',updateIgorText:'IGOR controleert GitHub Releases, downloadt de APK, verifieert hash en handtekening en start daarna de update.',updateCurrent:'Huidige versie',updateLatest:'Nieuwste versie',updateAutoCheck:'Automatisch controleren',updateAutoDownload:'Automatisch downloaden',updateAutoInstall:'Automatisch installeren',updateCheckNow:'Nu controleren',updateUpToDate:'Het Lab is bijgewerkt ✓',updateAvailable:'Update beschikbaar',updateDownloadInstall:'Downloaden',updateIgnore:'Deze versie negeren'});
Object.assign(I18N.pt,{updateTitle:'Atualizações',updateIgorTitle:'🧪 IGOR vigia o Lab',updateIgorText:'IGOR verifica as GitHub Releases, transfere o APK, valida o hash e a assinatura e inicia a atualização.',updateCurrent:'Versão atual',updateLatest:'Versão mais recente',updateAutoCheck:'Verificar automaticamente',updateAutoDownload:'Transferir automaticamente',updateAutoInstall:'Instalar automaticamente',updateCheckNow:'Verificar agora',updateUpToDate:'O Lab está atualizado ✓',updateAvailable:'Atualização disponível',updateDownloadInstall:'Transferir',updateIgnore:'Ignorar esta versão'});
Object.assign(I18N.es,{updateTitle:'Actualizaciones',updateIgorTitle:'🧪 IGOR vigila el Lab',updateIgorText:'IGOR comprueba GitHub Releases, descarga el APK, verifica su hash y firma y luego inicia la actualización.',updateCurrent:'Versión actual',updateLatest:'Última versión',updateAutoCheck:'Buscar automáticamente',updateAutoDownload:'Descargar automáticamente',updateAutoInstall:'Instalar automáticamente',updateCheckNow:'Buscar ahora',updateUpToDate:'El Lab está actualizado ✓',updateAvailable:'Actualización disponible',updateDownloadInstall:'Descargar',updateIgnore:'Ignorar esta versión'});
Object.assign(I18N.it,{updateTitle:'Aggiornamenti',updateIgorTitle:'🧪 IGOR sorveglia il Lab',updateIgorText:'IGOR controlla le GitHub Releases, scarica l’APK, verifica hash e firma e poi avvia l’aggiornamento.',updateCurrent:'Versione attuale',updateLatest:'Ultima versione',updateAutoCheck:'Controlla automaticamente',updateAutoDownload:'Scarica automaticamente',updateAutoInstall:'Installa automaticamente',updateCheckNow:'Controlla ora',updateUpToDate:'Il Lab è aggiornato ✓',updateAvailable:'Aggiornamento disponibile',updateDownloadInstall:'Scarica',updateIgnore:'Ignora questa versione'});

Object.assign(I18N.fr,{
  "overlayDrawStepTitle":"1 · Essayer d’activer l’overlay",
  "overlayDrawStepText":"Commence par demander l’affichage par-dessus les autres applications. Sur une APK installée manuellement, Android peut bloquer cette première tentative : c’est normal et cela rend ensuite « Autoriser les paramètres restreints » disponible.",
  "overlayRestrictedStepTitle":"2 · Autoriser les paramètres restreints",
  "overlayRestrictedStepText":"Après la première tentative bloquée, ouvre la fiche de Redacted BannerLab, puis le menu ⋮ et touche « Autoriser les paramètres restreints ».",
  "overlayRestrictedButton":"Ouvrir la fiche de RBL",
  "overlayRestrictedReturned":"Paramètres restreints vérifiés. Reviens maintenant dans RBL et retente l’activation.",
  "overlayPermissionStillBlocked":"Première tentative bloquée. Passe maintenant à l’étape 2 pour autoriser les paramètres restreints.",
  "overlayRetryStepTitle":"3 · Retenter l’overlay",
  "overlayRetryStepText":"Reviens dans RBL et relance l’autorisation d’affichage par-dessus les autres applications.",
  "overlayRetryButton":"Retenter l’activation"
});
Object.assign(I18N.en,{
  "overlayDrawStepTitle":"1 · Try to enable the overlay",
  "overlayDrawStepText":"First request display over other apps. On a sideloaded APK, Android may block this first attempt: that is expected and makes “Allow restricted settings” available afterwards.",
  "overlayRestrictedStepTitle":"2 · Allow restricted settings",
  "overlayRestrictedStepText":"After the first blocked attempt, open Redacted BannerLab app info, open the ⋮ menu and tap “Allow restricted settings”.",
  "overlayRestrictedButton":"Open RBL app info",
  "overlayRestrictedReturned":"Restricted settings checked. Return to RBL and retry the overlay permission.",
  "overlayPermissionStillBlocked":"First attempt blocked. Continue with step 2 and allow restricted settings.",
  "overlayRetryStepTitle":"3 · Retry the overlay",
  "overlayRetryStepText":"Return to RBL and request display over other apps again.",
  "overlayRetryButton":"Retry activation"
});
Object.assign(I18N.es,{
  "overlayDrawStepTitle":"1 · Intentar activar el overlay",
  "overlayDrawStepText":"Primero solicita mostrar sobre otras aplicaciones. En una APK instalada manualmente, Android puede bloquear este primer intento: es normal y hace que después aparezca «Permitir ajustes restringidos».",
  "overlayRestrictedStepTitle":"2 · Permitir ajustes restringidos",
  "overlayRestrictedStepText":"Después del primer intento bloqueado, abre la información de Redacted BannerLab, el menú ⋮ y toca «Permitir ajustes restringidos».",
  "overlayRestrictedButton":"Abrir información de RBL",
  "overlayRestrictedReturned":"Ajustes restringidos comprobados. Vuelve a RBL e intenta de nuevo el permiso del overlay.",
  "overlayPermissionStillBlocked":"Primer intento bloqueado. Sigue con el paso 2 y permite los ajustes restringidos.",
  "overlayRetryStepTitle":"3 · Reintentar el overlay",
  "overlayRetryStepText":"Vuelve a RBL y solicita otra vez mostrar sobre otras aplicaciones.",
  "overlayRetryButton":"Reintentar activación"
});
Object.assign(I18N.de,{
  "overlayDrawStepTitle":"1 · Overlay zuerst aktivieren",
  "overlayDrawStepText":"Fordere zuerst die Anzeige über anderen Apps an. Bei einer manuell installierten APK kann Android diesen ersten Versuch blockieren. Das ist normal und macht danach „Eingeschränkte Einstellungen zulassen“ verfügbar.",
  "overlayRestrictedStepTitle":"2 · Eingeschränkte Einstellungen erlauben",
  "overlayRestrictedStepText":"Nach dem blockierten ersten Versuch öffne die App-Info von Redacted BannerLab, das Menü ⋮ und tippe auf „Eingeschränkte Einstellungen zulassen“.",
  "overlayRestrictedButton":"RBL-App-Info öffnen",
  "overlayRestrictedReturned":"Eingeschränkte Einstellungen geprüft. Kehre zu RBL zurück und versuche die Overlay-Berechtigung erneut.",
  "overlayPermissionStillBlocked":"Erster Versuch blockiert. Fahre mit Schritt 2 fort und erlaube eingeschränkte Einstellungen.",
  "overlayRetryStepTitle":"3 · Overlay erneut versuchen",
  "overlayRetryStepText":"Kehre zu RBL zurück und fordere die Anzeige über anderen Apps erneut an.",
  "overlayRetryButton":"Aktivierung erneut versuchen"
});
Object.assign(I18N.nl,{
  "overlayDrawStepTitle":"1 · Probeer de overlay te activeren",
  "overlayDrawStepText":"Vraag eerst weergave boven andere apps aan. Bij een handmatig geïnstalleerde APK kan Android deze eerste poging blokkeren. Dat is normaal en maakt daarna ‘Beperkte instellingen toestaan’ beschikbaar.",
  "overlayRestrictedStepTitle":"2 · Beperkte instellingen toestaan",
  "overlayRestrictedStepText":"Open na de geblokkeerde eerste poging de app-info van Redacted BannerLab, open het menu ⋮ en tik op ‘Beperkte instellingen toestaan’.",
  "overlayRestrictedButton":"RBL-app-info openen",
  "overlayRestrictedReturned":"Beperkte instellingen gecontroleerd. Ga terug naar RBL en probeer de overlay opnieuw.",
  "overlayPermissionStillBlocked":"Eerste poging geblokkeerd. Ga verder met stap 2 en sta beperkte instellingen toe.",
  "overlayRetryStepTitle":"3 · Overlay opnieuw proberen",
  "overlayRetryStepText":"Ga terug naar RBL en vraag weergave boven andere apps opnieuw aan.",
  "overlayRetryButton":"Activering opnieuw proberen"
});
Object.assign(I18N.pt,{
  "overlayDrawStepTitle":"1 · Tentar ativar o overlay",
  "overlayDrawStepText":"Primeiro pede a apresentação sobre outras aplicações. Numa APK instalada manualmente, o Android pode bloquear esta primeira tentativa. É normal e faz com que «Permitir definições restritas» fique disponível depois.",
  "overlayRestrictedStepTitle":"2 · Permitir definições restritas",
  "overlayRestrictedStepText":"Depois da primeira tentativa bloqueada, abre as informações do Redacted BannerLab, o menu ⋮ e toca em «Permitir definições restritas».",
  "overlayRestrictedButton":"Abrir informações da RBL",
  "overlayRestrictedReturned":"Definições restritas verificadas. Volta à RBL e tenta novamente a autorização do overlay.",
  "overlayPermissionStillBlocked":"Primeira tentativa bloqueada. Segue agora o passo 2 e permite as definições restritas.",
  "overlayRetryStepTitle":"3 · Tentar novamente o overlay",
  "overlayRetryStepText":"Volta à RBL e pede novamente a apresentação sobre outras aplicações.",
  "overlayRetryButton":"Tentar ativação novamente"
});
Object.assign(I18N.it,{
  "overlayDrawStepTitle":"1 · Prova ad attivare l’overlay",
  "overlayDrawStepText":"Per prima cosa richiedi la visualizzazione sopra le altre app. Con un APK installato manualmente Android può bloccare questo primo tentativo. È normale e rende poi disponibile «Consenti impostazioni con limitazioni».",
  "overlayRestrictedStepTitle":"2 · Consenti impostazioni con limitazioni",
  "overlayRestrictedStepText":"Dopo il primo tentativo bloccato, apri le informazioni di Redacted BannerLab, il menu ⋮ e tocca «Consenti impostazioni con limitazioni».",
  "overlayRestrictedButton":"Apri info app RBL",
  "overlayRestrictedReturned":"Impostazioni con limitazioni verificate. Torna in RBL e riprova il permesso dell’overlay.",
  "overlayPermissionStillBlocked":"Primo tentativo bloccato. Continua con il punto 2 e consenti le impostazioni con limitazioni.",
  "overlayRetryStepTitle":"3 · Riprova l’overlay",
  "overlayRetryStepText":"Torna in RBL e richiedi di nuovo la visualizzazione sopra le altre app.",
  "overlayRetryButton":"Riprova attivazione"
});

// Build 11408: final French copy for the MILO Chrome assistant.
// Keep this after the historical overrides above so old Publisher/RBL wording cannot leak back in.
Object.assign(I18N.fr,{
  "chromeWizardTitle":"Configurer Chrome",
  "chromeWizardIntro":"Installation guidée de MILO · une seule action à la fois. Le Lab mémorise ta progression.",
  "chromeFileTitle":"Préparer MILO",
  "chromeFileText":"Choisis le dossier de travail utilisé par Redacted BannerLab. Il contiendra le programme de MILO et la session de ta bannière. Android mémorisera ce dossier pour les prochaines publications.",
  "chromeGuide2Title":"Copier le raccourci",
  "chromeGuide2Text":"Copie le mini-code, puis ouvre Mission Authoring Tool dans Chrome. Rien d’autre à modifier pour l’instant.",
  "chromeGuide3Title":"Ajouter Mission Authoring aux favoris",
  "chromeGuide3Text":"Dans Mission Authoring Tool, ouvre le menu ⋮ puis touche l’étoile ⭐. Chrome crée simplement un favori de la page actuelle.",
  "chromeGuide4Title":"Ouvrir le favori en modification",
  "chromeGuide4Text":"Ouvre ⋮ → Favoris → Favoris d’appareils mobiles. Sur le favori Mission Authoring, ouvre son menu puis touche Modifier.",
  "chromeGuide5Title":"Renommer le favori et remplacer son URL",
  "chromeGuide5Text":"Dans Nom, écris MILO. Dans URL, efface complètement l’adresse actuelle et colle le mini-code. Reviens avec ← : Chrome enregistre automatiquement.",
  "chromeGuide6Title":"Lancer MILO",
  "chromeGuide6Text":"Retourne sur Mission Authoring Tool, touche la barre d’adresse et tape MILO. Quand le favori étoilé apparaît, touche-le.",
  "chromeGuide7Title":"Autoriser les fichiers",
  "chromeGuide7Text":"Lors du premier lancement, Chrome te demandera le programme de MILO puis la session de ta bannière. Sélectionne les deux fichiers indiqués ci-dessous et accepte l’autorisation de lecture.",
  "chromeSetupSuccess":"Configuration terminée",
  "chromeSetupSuccessText":"MILO est installé dans Chrome. Pour les prochaines bannières, ouvre Mission Authoring Tool, tape MILO dans la barre d’adresse et choisis le favori. Submit reste toujours sous ton contrôle.",
  "publisherFolderLabel":"Dossier de travail",
  "publisherFolderChoose":"Choisir le dossier",
  "publisherFolderChange":"Changer de dossier",
  "publisherFolderNone":"Aucun dossier choisi",
  "publisherFolderConfigured":"Dossier configuré",
  "publisherFolderChosen":"Dossier de travail",
  "chromeSaveFile":"Installer / mettre à jour MILO",
  "chromeFileDone":"MILO enregistré",
  "chromeFileSaved":"MILO enregistré dans :",
  "chromeFileWriteFail":"Impossible d’enregistrer MILO dans le dossier choisi.",
  "alreadySaved":"MILO est déjà installé",
  "chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis MILO_CurrentBanner.json dans ton dossier de travail.",
  "chromeSessionHint":"Chrome : lance le favori MILO. À la première utilisation, choisis les fichiers demandés ; ensuite rien à refaire entre les missions.",
  "chromeTestText":"Le Lab ouvre Mission Authoring Tool. Tape MILO dans la barre d’adresse, lance le favori puis choisis les fichiers demandés par Chrome.",
  "chromeTestWaiting":"Dans Chrome : tape MILO → touche le favori étoilé → sélectionne les fichiers demandés → Autoriser.",
  "chromeNotAutoFavorite":"Le Lab ne peut pas créer un favori Chrome automatiquement. C’est la seule manipulation que Chrome impose."
});

// v1.0.15 · MILO naming. This override stays late so historical Publisher/RBL wording cannot leak into the current wizard.
Object.assign(I18N.fr,{
  "chromeGuideTestBadge":"MILO · v1.0.15",
  "chromeFileText":"Choisis le dossier de travail utilisé par Redacted BannerLab. Il contiendra MILO.user.js et MILO_CurrentBanner.json. Android mémorisera ce dossier pour les prochaines publications.",
  "chromeCurrentSessionHint":"À chaque nouvelle bannière : choisis MILO_CurrentBanner.json dans ton dossier de travail.",
  "chromeSelectFileHint":"Dans Chrome, sélectionne MILO.user.js : c’est le programme de MILO.",
  "publisherCurrentFile":"Bannière courante : MILO_CurrentBanner.json dans le dossier de travail.",
  "chromeSessionHint":"Chrome : lance le favori MILO. À la première utilisation, sélectionne MILO.user.js puis MILO_CurrentBanner.json.",
  "chromeGuide7Text":"Lors du premier lancement, Chrome te demandera MILO.user.js puis MILO_CurrentBanner.json. Sélectionne ces deux fichiers et accepte l’autorisation de lecture.",
  "chromeSetupSuccessText":"MILO est installé dans Chrome. Pour les prochaines bannières, ouvre Mission Authoring Tool, tape MILO dans la barre d’adresse et choisis le favori. Submit reste toujours sous ton contrôle."
});

// Publisher storage switched to the Android Storage Access Framework in build 11403.
// Until every locale has dedicated copy, use the English fallback for these path-sensitive
// strings so no translated screen points users to the retired fixed Downloads folder.
for(const lang of Object.keys(I18N)){
  if(lang==='fr'||lang==='en')continue;
  for(const key of ['publisherSessionReady','publisherSessionFileText','publisherCurrentFile','chromeFileText','chromeFilePath','chromeFileSaved','chromeFileWriteFail','chromeSelectFileHint','chromeCurrentSessionHint','publisherFolderLabel','publisherFolderChoose','publisherFolderChange','publisherFolderNone','publisherFolderConfigured','publisherFolderChosen','publisherFolderChooseFail']){
    if(I18N.en[key])I18N[lang][key]=I18N.en[key];
  }
}

Object.assign(I18N.fr,{circleOpacity:'Opacité des cercles'});
Object.assign(I18N.en,{circleOpacity:'Circle opacity'});
Object.assign(I18N.es,{circleOpacity:'Opacidad de los círculos'});
Object.assign(I18N.pt,{circleOpacity:'Opacidade dos círculos'});
Object.assign(I18N.de,{circleOpacity:'Kreis-Deckkraft'});
Object.assign(I18N.it,{circleOpacity:'Opacità dei cerchi'});
Object.assign(I18N.nl,{circleOpacity:'Dekking van cirkels'});

Object.assign(I18N.fr,{activeProject:'Projet actif'});
Object.assign(I18N.en,{activeProject:'Active project'});
Object.assign(I18N.es,{activeProject:'Proyecto activo'});
Object.assign(I18N.pt,{activeProject:'Projeto ativo'});
Object.assign(I18N.de,{activeProject:'Aktives Projekt'});
Object.assign(I18N.it,{activeProject:'Progetto attivo'});
Object.assign(I18N.nl,{activeProject:'Actief project'});

// Production 1.0.16.1 refresh: cleaner Bannergress explorer copy.
// These keys intentionally avoid implementation jargon (RBL/overlay) in the user-facing explorer.
Object.assign(I18N.fr,{
  playHub:'Explorer les fresques',
  playHubIntro:'Fresques publiques proposées par Bannergress. Recherche, enregistre et retrouve simplement tes parcours.',
  searchTab:'Chercher',
  searchBannergress:'Trouver une fresque',
  searchPrompt:'Par nom, ville ou autour de ta position.',
  searchSource:'Bannergress',
  nearMe:'Utiliser ma position',
  nearMeOn:'Position actuelle utilisée',
  nearMeHint:'La ville est remplacée par ta position. Le rayon s’applique autour du point choisi.',
  publicOnly:'Données publiques issues de Bannergress.',
  deepLinkOnly:'Les missions s’ouvrent ensuite directement dans Ingress Prime.',
  noPlaySession:'Aucune fresque en cours.',
  noHistory:'Aucune fresque terminée pour le moment.',
  explorerHint:'Nom, ville ou position : garde uniquement les filtres qui te sont utiles.',
  currentTab:'En cours'
});
Object.assign(I18N.en,{
  playHub:'Explore banners',
  playHubIntro:'Public Bannergress banners. Search, save and quickly get back to your current routes.',
  searchTab:'Search',
  searchBannergress:'Find a banner',
  searchPrompt:'By name, city or around your current position.',
  searchSource:'Bannergress',
  nearMe:'Use my location',
  nearMeOn:'Current location in use',
  nearMeHint:'Your location replaces the city filter. The radius applies around the selected point.',
  publicOnly:'Public data provided by Bannergress.',
  deepLinkOnly:'Missions then open directly in Ingress Prime.',
  noPlaySession:'No banner in progress.',
  noHistory:'No completed banner yet.',
  explorerHint:'Name, city or location: keep only the filters you need.',
  currentTab:'In progress'
});
for(const lang of Object.keys(I18N)){
  if(lang==='fr'||lang==='en')continue;
  for(const key of ['playHubIntro','searchTab','searchSource','explorerHint','currentTab']){
    I18N[lang][key]=I18N.en[key];
  }
}

// Keep the seven priority languages complete even when late feature blocks were added with English fallbacks.
for(const [lang,pack] of Object.entries(PRIORITY_I18N_OVERRIDES)){
  if(I18N[lang])Object.assign(I18N[lang],pack);
}

const TEST32_I18N={
  "fr": {
    "redactedOverlayTitle": "Overlay Redacted pour Ingress Prime",
    "redactedOverlayText": "Affiche Redacted en bulle flottante au-dessus des autres applications. Déplace-le librement ; un appui rouvre le Lab.",
    "redactedOverlayToggle": "Activer l’overlay Redacted",
    "redactedOverlayOn": "Overlay Redacted activé",
    "redactedOverlayOff": "Overlay Redacted désactivé",
    "redactedOverlayNeedsPermission": "Autorisation Android requise",
    "redactedOverlayUnavailable": "Disponible uniquement dans l’application Android",
    "redactedOverlayPermissionTitle": "Autoriser l’overlay Redacted",
    "redactedOverlayPermissionText": "Android doit autoriser BannerLab à s’afficher par-dessus Ingress Prime. Une fois accordée, Redacted pourra rester en bulle flottante.",
    "redactedOverlayReady": "Redacted est prêt à flotter au-dessus d’Ingress Prime.",
    "elevatorBackLabel": "Retour à l’ascenseur",
    "leonStatsTitle": "Statistiques / AP",
    "leonStatsTut": "Colle simplement tes AP ou le partage de statistiques Ingress : LEON détecte les données utiles tout seul.",
    "leonTargetTitle": "Objectif",
    "leonTargetTut": "Choisis le niveau visé ou un total d’AP personnalisé. LEON travaille uniquement vers un objectif exact.",
    "leonActionsTitle": "Actions autorisées",
    "leonActionsTut": "Coche les actions que tu acceptes d’utiliser. LEON cherchera ensuite la combinaison exacte la plus pratique.",
    "leonCalcTitle": "Calculer le tout pile",
    "leonCalcTut": "Lance le calcul pour obtenir le plan exact. Si le bonus AP rend le total impossible, LEON te dira à quel point il peut s’approcher.",
    "ritaTelegramTut": "RITA ouvre directement le support du Lab dans Telegram.",
    "testEditionTitle": "Édition TEST isolée",
    "testVersion": "Version TEST",
    "testPackage": "Package",
    "testPackageSeparate": "séparé de PROD"
  },
  "en": {
    "redactedOverlayTitle": "Redacted overlay for Ingress Prime",
    "redactedOverlayText": "Shows Redacted as a floating bubble above other apps. Drag him anywhere; tap to reopen the Lab.",
    "redactedOverlayToggle": "Enable Redacted overlay",
    "redactedOverlayOn": "Redacted overlay enabled",
    "redactedOverlayOff": "Redacted overlay disabled",
    "redactedOverlayNeedsPermission": "Android permission required",
    "redactedOverlayUnavailable": "Available only in the Android app",
    "redactedOverlayPermissionTitle": "Allow Redacted overlay",
    "redactedOverlayPermissionText": "Android must allow BannerLab to display over Ingress Prime. Once granted, Redacted can stay as a floating bubble.",
    "redactedOverlayReady": "Redacted is ready to float above Ingress Prime.",
    "elevatorBackLabel": "Back to elevator",
    "leonStatsTitle": "Stats / AP",
    "leonStatsTut": "Paste your AP or the Ingress stats share text and LEON will detect the useful data automatically.",
    "leonTargetTitle": "Target",
    "leonTargetTut": "Choose the target level or a custom AP total. LEON always works toward an exact target.",
    "leonActionsTitle": "Allowed actions",
    "leonActionsTut": "Enable the actions you allow. LEON then searches for the most practical exact combination.",
    "leonCalcTitle": "Calculate exact plan",
    "leonCalcTut": "Run the calculation to get the exact plan. If the AP multiplier makes it impossible, LEON will tell you how close it can get.",
    "ritaTelegramTut": "RITA opens the Lab support directly in Telegram.",
    "testEditionTitle": "Isolated TEST edition",
    "testVersion": "TEST version",
    "testPackage": "Package",
    "testPackageSeparate": "separate from PROD"
  },
  "es": {
    "redactedOverlayTitle": "Overlay Redacted para Ingress Prime",
    "redactedOverlayText": "Muestra a Redacted como una burbuja flotante sobre otras aplicaciones. Muévelo libremente; un toque vuelve a abrir el Lab.",
    "redactedOverlayToggle": "Activar overlay Redacted",
    "redactedOverlayOn": "Overlay Redacted activado",
    "redactedOverlayOff": "Overlay Redacted desactivado",
    "redactedOverlayNeedsPermission": "Se requiere permiso de Android",
    "redactedOverlayUnavailable": "Disponible solo en la aplicación Android",
    "redactedOverlayPermissionTitle": "Autorizar overlay Redacted",
    "redactedOverlayPermissionText": "Android debe permitir que BannerLab se muestre sobre Ingress Prime. Una vez autorizado, Redacted puede permanecer como burbuja flotante.",
    "redactedOverlayReady": "Redacted está listo para flotar sobre Ingress Prime.",
    "elevatorBackLabel": "Volver al ascensor",
    "leonStatsTitle": "Estadísticas / AP",
    "leonStatsTut": "Pega tus AP o el texto «Compartir estadísticas» de Ingress y LEON detectará automáticamente los datos útiles.",
    "leonTargetTitle": "Objetivo",
    "leonTargetTut": "Elige el nivel objetivo o un total de AP personalizado. LEON siempre trabaja hacia un objetivo exacto.",
    "leonActionsTitle": "Acciones permitidas",
    "leonActionsTut": "Activa las acciones que aceptas usar. LEON buscará la combinación exacta más práctica.",
    "leonCalcTitle": "Calcular plan exacto",
    "leonCalcTut": "Inicia el cálculo para obtener el plan exacto. Si el multiplicador AP lo hace imposible, LEON indicará cuánto puede acercarse.",
    "ritaTelegramTut": "RITA abre directamente el soporte del Lab en Telegram.",
    "testEditionTitle": "Edición TEST aislada",
    "testVersion": "Versión TEST",
    "testPackage": "Paquete",
    "testPackageSeparate": "separado de PROD"
  },
  "pt": {
    "redactedOverlayTitle": "Overlay Redacted para Ingress Prime",
    "redactedOverlayText": "Mostra o Redacted como uma bolha flutuante sobre outras aplicações. Move-o livremente; um toque reabre o Lab.",
    "redactedOverlayToggle": "Ativar overlay Redacted",
    "redactedOverlayOn": "Overlay Redacted ativado",
    "redactedOverlayOff": "Overlay Redacted desativado",
    "redactedOverlayNeedsPermission": "É necessária autorização do Android",
    "redactedOverlayUnavailable": "Disponível apenas na aplicação Android",
    "redactedOverlayPermissionTitle": "Autorizar overlay Redacted",
    "redactedOverlayPermissionText": "O Android tem de permitir que o BannerLab apareça sobre o Ingress Prime. Depois disso, o Redacted pode ficar numa bolha flutuante.",
    "redactedOverlayReady": "O Redacted está pronto para flutuar sobre o Ingress Prime.",
    "elevatorBackLabel": "Voltar ao elevador",
    "leonStatsTitle": "Estatísticas / AP",
    "leonStatsTut": "Cola os teus AP ou o texto «Partilhar estatísticas» do Ingress e o LEON deteta automaticamente os dados úteis.",
    "leonTargetTitle": "Objetivo",
    "leonTargetTut": "Escolhe o nível pretendido ou um total de AP personalizado. O LEON trabalha sempre para um objetivo exato.",
    "leonActionsTitle": "Ações autorizadas",
    "leonActionsTut": "Ativa as ações que aceitas usar. O LEON procura depois a combinação exata mais prática.",
    "leonCalcTitle": "Calcular plano exato",
    "leonCalcTut": "Inicia o cálculo para obter o plano exato. Se o multiplicador AP o tornar impossível, o LEON indica quão perto consegue chegar.",
    "ritaTelegramTut": "A RITA abre diretamente o suporte do Lab no Telegram.",
    "testEditionTitle": "Edição TEST isolada",
    "testVersion": "Versão TEST",
    "testPackage": "Pacote",
    "testPackageSeparate": "separado da PROD"
  },
  "de": {
    "redactedOverlayTitle": "Redacted-Overlay für Ingress Prime",
    "redactedOverlayText": "Zeigt Redacted als schwebende Blase über anderen Apps. Du kannst ihn verschieben; ein Tippen öffnet das Lab erneut.",
    "redactedOverlayToggle": "Redacted-Overlay aktivieren",
    "redactedOverlayOn": "Redacted-Overlay aktiviert",
    "redactedOverlayOff": "Redacted-Overlay deaktiviert",
    "redactedOverlayNeedsPermission": "Android-Berechtigung erforderlich",
    "redactedOverlayUnavailable": "Nur in der Android-App verfügbar",
    "redactedOverlayPermissionTitle": "Redacted-Overlay erlauben",
    "redactedOverlayPermissionText": "Android muss BannerLab erlauben, über Ingress Prime angezeigt zu werden. Danach kann Redacted als schwebende Blase sichtbar bleiben.",
    "redactedOverlayReady": "Redacted ist bereit, über Ingress Prime zu schweben.",
    "elevatorBackLabel": "Zurück zum Aufzug",
    "leonStatsTitle": "Statistik / AP",
    "leonStatsTut": "Füge deine AP oder den Ingress-Text „Statistiken teilen“ ein; LEON erkennt die nützlichen Daten automatisch.",
    "leonTargetTitle": "Ziel",
    "leonTargetTut": "Wähle das Ziellevel oder eine eigene AP-Summe. LEON arbeitet immer auf ein exaktes Ziel hin.",
    "leonActionsTitle": "Erlaubte Aktionen",
    "leonActionsTut": "Aktiviere die Aktionen, die du verwenden möchtest. LEON sucht anschließend die praktischste exakte Kombination.",
    "leonCalcTitle": "Exakten Plan berechnen",
    "leonCalcTut": "Starte die Berechnung für einen exakten Plan. Falls der AP-Multiplikator das unmöglich macht, zeigt LEON die beste Annäherung.",
    "ritaTelegramTut": "RITA öffnet den Lab-Support direkt in Telegram.",
    "testEditionTitle": "Isolierte TEST-Ausgabe",
    "testVersion": "TEST-Version",
    "testPackage": "Paket",
    "testPackageSeparate": "getrennt von PROD"
  },
  "it": {
    "redactedOverlayTitle": "Overlay Redacted per Ingress Prime",
    "redactedOverlayText": "Mostra Redacted come bolla mobile sopra le altre app. Puoi spostarlo liberamente; un tocco riapre il Lab.",
    "redactedOverlayToggle": "Attiva overlay Redacted",
    "redactedOverlayOn": "Overlay Redacted attivato",
    "redactedOverlayOff": "Overlay Redacted disattivato",
    "redactedOverlayNeedsPermission": "Autorizzazione Android necessaria",
    "redactedOverlayUnavailable": "Disponibile solo nell’app Android",
    "redactedOverlayPermissionTitle": "Autorizza overlay Redacted",
    "redactedOverlayPermissionText": "Android deve consentire a BannerLab di apparire sopra Ingress Prime. Dopo l’autorizzazione, Redacted può restare come bolla mobile.",
    "redactedOverlayReady": "Redacted è pronto a fluttuare sopra Ingress Prime.",
    "elevatorBackLabel": "Torna all’ascensore",
    "leonStatsTitle": "Statistiche / AP",
    "leonStatsTut": "Incolla i tuoi AP o il testo «Condividi statistiche» di Ingress e LEON rileverà automaticamente i dati utili.",
    "leonTargetTitle": "Obiettivo",
    "leonTargetTut": "Scegli il livello obiettivo o un totale AP personalizzato. LEON lavora sempre verso un obiettivo esatto.",
    "leonActionsTitle": "Azioni consentite",
    "leonActionsTut": "Attiva le azioni che accetti di usare. LEON cercherà quindi la combinazione esatta più pratica.",
    "leonCalcTitle": "Calcola piano esatto",
    "leonCalcTut": "Avvia il calcolo per ottenere il piano esatto. Se il moltiplicatore AP lo rende impossibile, LEON indicherà quanto può avvicinarsi.",
    "ritaTelegramTut": "RITA apre direttamente il supporto del Lab in Telegram.",
    "testEditionTitle": "Edizione TEST isolata",
    "testVersion": "Versione TEST",
    "testPackage": "Pacchetto",
    "testPackageSeparate": "separato da PROD"
  },
  "nl": {
    "redactedOverlayTitle": "Redacted-overlay voor Ingress Prime",
    "redactedOverlayText": "Toont Redacted als zwevende bubbel boven andere apps. Sleep hem waar je wilt; tik om het Lab opnieuw te openen.",
    "redactedOverlayToggle": "Redacted-overlay inschakelen",
    "redactedOverlayOn": "Redacted-overlay ingeschakeld",
    "redactedOverlayOff": "Redacted-overlay uitgeschakeld",
    "redactedOverlayNeedsPermission": "Android-toestemming vereist",
    "redactedOverlayUnavailable": "Alleen beschikbaar in de Android-app",
    "redactedOverlayPermissionTitle": "Redacted-overlay toestaan",
    "redactedOverlayPermissionText": "Android moet BannerLab toestaan boven Ingress Prime te verschijnen. Daarna kan Redacted als zwevende bubbel zichtbaar blijven.",
    "redactedOverlayReady": "Redacted is klaar om boven Ingress Prime te zweven.",
    "elevatorBackLabel": "Terug naar de lift",
    "leonStatsTitle": "Statistieken / AP",
    "leonStatsTut": "Plak je AP of de Ingress-tekst “Statistieken delen”; LEON haalt de nuttige gegevens er automatisch uit.",
    "leonTargetTitle": "Doel",
    "leonTargetTut": "Kies het doelniveau of een aangepast AP-totaal. LEON werkt altijd naar een exact doel.",
    "leonActionsTitle": "Toegestane acties",
    "leonActionsTut": "Schakel de acties in die je wilt gebruiken. LEON zoekt daarna de praktischste exacte combinatie.",
    "leonCalcTitle": "Exact plan berekenen",
    "leonCalcTut": "Start de berekening voor een exact plan. Als de AP-multiplier dat onmogelijk maakt, toont LEON hoe dicht hij kan komen.",
    "ritaTelegramTut": "RITA opent de Lab-support rechtstreeks in Telegram.",
    "testEditionTitle": "Afzonderlijke TEST-editie",
    "testVersion": "TEST-versie",
    "testPackage": "Pakket",
    "testPackageSeparate": "gescheiden van PROD"
  }
};
for(const [lang,pack] of Object.entries(TEST32_I18N))if(I18N[lang])Object.assign(I18N[lang],pack);

const TEST37_I18N={
  fr:{primeHudFaction:'Faction du néon',primeHudFactionHint:'ENL = vert · RES = bleu. Le cadre et les capteurs suivent la faction choisie.',primeHudMoveRedacted:'Sur le Scanner, fais simplement glisser la tête de REDACTED pour la déplacer. Sa position est mémorisée.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Surcouche calibrable pour Ingress Prime. Place toi-même les zones importantes puis le Lab suit tes gestes pour adapter le HUD.',redactedOverlayPermissionText:'Autorise le Lab à s’afficher par-dessus les autres applications. Le HUD ne lira pas le contenu de Prime : les repères sont placés manuellement.',redactedOverlayToggle:'Activer le Prime HUD',redactedOverlayOn:'Prime HUD activé',redactedOverlayOff:'Prime HUD désactivé',redactedOverlayReady:'Prime HUD prêt.',primeHudCalibrate:'Calibrer les repères',primeHudMap:'Carte',primeHudProfile:'Profil',primeHudInventory:'Inventaire',primeHudAttack:'Attaque',primeHudAccessibility:'Autoriser les gestes',primeHudUsage:'Détection de Prime',primeHudReset:'Réinitialiser les repères',primeHudResync:'Resynchroniser',primeHudAccessNeeded:'Active le service « Redacted Prime HUD » dans Accessibilité pour que les gestes soient rejoués dans Prime.',primeHudUsageNeeded:'Autorise l’accès aux données d’utilisation pour masquer automatiquement le HUD hors d’Ingress Prime.',primeHudCalibStarted:'Calibration {state} lancée dans Prime. Déplace les cadres et redimensionne-les par le coin inférieur droit.',primeHudResetDone:'Repères remis à zéro.',primeHudStateSet:'État resynchronisé : {state}'},
  en:{primeHudFaction:'Neon faction',primeHudFactionHint:'ENL = green · RES = blue. The frame and sensors follow the selected faction.',primeHudMoveRedacted:'On the Scanner, simply drag REDACTED’s head to move it. Its position is remembered.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'A calibratable overlay for Ingress Prime. Place the important zones yourself and the Lab follows your gestures to adapt the HUD.',redactedOverlayPermissionText:'Allow the Lab to display over other apps. The HUD does not read Prime content: hotspots are placed manually.',redactedOverlayToggle:'Enable Prime HUD',redactedOverlayOn:'Prime HUD enabled',redactedOverlayOff:'Prime HUD disabled',redactedOverlayReady:'Prime HUD ready.',primeHudCalibrate:'Calibrate hotspots',primeHudMap:'Map',primeHudProfile:'Profile',primeHudInventory:'Inventory',primeHudAttack:'Attack',primeHudAccessibility:'Enable gestures',primeHudUsage:'Detect Prime',primeHudReset:'Reset hotspots',primeHudResync:'Resync',primeHudAccessNeeded:'Enable the “Redacted Prime HUD” accessibility service so gestures can be replayed in Prime.',primeHudUsageNeeded:'Allow usage access so the HUD can automatically hide outside Ingress Prime.',primeHudCalibStarted:'{state} calibration launched in Prime. Move the frames and resize them from the bottom-right corner.',primeHudResetDone:'Hotspots reset.',primeHudStateSet:'State resynced: {state}'},
  es:{primeHudFaction:'Facción del neón',primeHudFactionHint:'ENL = verde · RES = azul. El marco y los sensores siguen la facción elegida.',primeHudMoveRedacted:'En el Scanner, arrastra la cabeza de REDACTED para moverla. Su posición se guarda.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Una superposición calibrable para Ingress Prime. Coloca tú mismo las zonas importantes y el Lab sigue tus gestos para adaptar el HUD.',redactedOverlayPermissionText:'Permite que el Lab se muestre sobre otras aplicaciones. El HUD no lee el contenido de Prime: las zonas se colocan manualmente.',redactedOverlayToggle:'Activar Prime HUD',redactedOverlayOn:'Prime HUD activado',redactedOverlayOff:'Prime HUD desactivado',redactedOverlayReady:'Prime HUD listo.',primeHudCalibrate:'Calibrar zonas',primeHudMap:'Mapa',primeHudProfile:'Perfil',primeHudInventory:'Inventario',primeHudAttack:'Ataque',primeHudAccessibility:'Autorizar gestos',primeHudUsage:'Detectar Prime',primeHudReset:'Restablecer zonas',primeHudResync:'Resincronizar',primeHudAccessNeeded:'Activa el servicio de accesibilidad « Redacted Prime HUD » para reproducir los gestos en Prime.',primeHudUsageNeeded:'Autoriza el acceso de uso para ocultar automáticamente el HUD fuera de Ingress Prime.',primeHudCalibStarted:'Calibración {state} abierta en Prime. Mueve los marcos y redimensiónalos desde la esquina inferior derecha.',primeHudResetDone:'Zonas restablecidas.',primeHudStateSet:'Estado resincronizado: {state}'},
  pt:{primeHudFaction:'Facção do néon',primeHudFactionHint:'ENL = verde · RES = azul. A moldura e os sensores seguem a facção escolhida.',primeHudMoveRedacted:'No Scanner, arrasta a cabeça de REDACTED para a mover. A posição é memorizada.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Uma sobreposição calibrável para o Ingress Prime. Coloca tu próprio as zonas importantes e o Lab acompanha os teus gestos para adaptar o HUD.',redactedOverlayPermissionText:'Permite que o Lab apareça sobre outras aplicações. O HUD não lê o conteúdo do Prime: as zonas são colocadas manualmente.',redactedOverlayToggle:'Ativar Prime HUD',redactedOverlayOn:'Prime HUD ativado',redactedOverlayOff:'Prime HUD desativado',redactedOverlayReady:'Prime HUD pronto.',primeHudCalibrate:'Calibrar zonas',primeHudMap:'Mapa',primeHudProfile:'Perfil',primeHudInventory:'Inventário',primeHudAttack:'Ataque',primeHudAccessibility:'Autorizar gestos',primeHudUsage:'Detetar Prime',primeHudReset:'Repor zonas',primeHudResync:'Ressincronizar',primeHudAccessNeeded:'Ativa o serviço de acessibilidade “Redacted Prime HUD” para reproduzir os gestos no Prime.',primeHudUsageNeeded:'Autoriza o acesso de utilização para ocultar automaticamente o HUD fora do Ingress Prime.',primeHudCalibStarted:'Calibração {state} aberta no Prime. Move os quadros e redimensiona-os pelo canto inferior direito.',primeHudResetDone:'Zonas repostas.',primeHudStateSet:'Estado ressincronizado: {state}'},
  de:{primeHudFaction:'Neon-Fraktion',primeHudFactionHint:'ENL = grün · RES = blau. Rahmen und Sensoren folgen der gewählten Fraktion.',primeHudMoveRedacted:'Ziehe REDACTEDs Kopf im Scanner einfach an die gewünschte Position. Sie wird gespeichert.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Ein kalibrierbares Overlay für Ingress Prime. Lege die wichtigen Bereiche selbst fest; das Lab verfolgt deine Gesten und passt das HUD an.',redactedOverlayPermissionText:'Erlaube dem Lab die Anzeige über anderen Apps. Das HUD liest Prime nicht aus: Hotspots werden manuell gesetzt.',redactedOverlayToggle:'Prime HUD aktivieren',redactedOverlayOn:'Prime HUD aktiviert',redactedOverlayOff:'Prime HUD deaktiviert',redactedOverlayReady:'Prime HUD bereit.',primeHudCalibrate:'Hotspots kalibrieren',primeHudMap:'Karte',primeHudProfile:'Profil',primeHudInventory:'Inventar',primeHudAttack:'Angriff',primeHudAccessibility:'Gesten erlauben',primeHudUsage:'Prime erkennen',primeHudReset:'Hotspots zurücksetzen',primeHudResync:'Resynchronisieren',primeHudAccessNeeded:'Aktiviere den Bedienungshilfedienst „Redacted Prime HUD“, damit Gesten in Prime wiederholt werden können.',primeHudUsageNeeded:'Erlaube Nutzungszugriff, damit das HUD außerhalb von Ingress Prime automatisch ausgeblendet wird.',primeHudCalibStarted:'Kalibrierung {state} in Prime gestartet. Verschiebe die Rahmen und ändere ihre Größe unten rechts.',primeHudResetDone:'Hotspots zurückgesetzt.',primeHudStateSet:'Status resynchronisiert: {state}'},
  it:{primeHudFaction:'Fazione del neon',primeHudFactionHint:'ENL = verde · RES = blu. Cornice e sensori seguono la fazione scelta.',primeHudMoveRedacted:'Nello Scanner trascina semplicemente la testa di REDACTED per spostarla. La posizione viene memorizzata.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Un overlay calibrabile per Ingress Prime. Posiziona tu le zone importanti e il Lab segue i gesti per adattare l’HUD.',redactedOverlayPermissionText:'Consenti al Lab di apparire sopra le altre app. L’HUD non legge il contenuto di Prime: le zone vengono posizionate manualmente.',redactedOverlayToggle:'Attiva Prime HUD',redactedOverlayOn:'Prime HUD attivo',redactedOverlayOff:'Prime HUD disattivato',redactedOverlayReady:'Prime HUD pronto.',primeHudCalibrate:'Calibra zone',primeHudMap:'Mappa',primeHudProfile:'Profilo',primeHudInventory:'Inventario',primeHudAttack:'Attacco',primeHudAccessibility:'Abilita gesti',primeHudUsage:'Rileva Prime',primeHudReset:'Reimposta zone',primeHudResync:'Risincronizza',primeHudAccessNeeded:'Attiva il servizio di accessibilità “Redacted Prime HUD” per riprodurre i gesti in Prime.',primeHudUsageNeeded:'Consenti l’accesso utilizzo per nascondere automaticamente l’HUD fuori da Ingress Prime.',primeHudCalibStarted:'Calibrazione {state} avviata in Prime. Sposta i riquadri e ridimensionali dall’angolo in basso a destra.',primeHudResetDone:'Zone reimpostate.',primeHudStateSet:'Stato risincronizzato: {state}'},
  nl:{primeHudFaction:'Neonfactie',primeHudFactionHint:'ENL = groen · RES = blauw. Kader en sensoren volgen de gekozen factie.',primeHudMoveRedacted:'Sleep in de Scanner gewoon REDACTEDs hoofd om het te verplaatsen. De positie wordt onthouden.',redactedOverlayTitle:'Redacted Prime HUD',redactedOverlayText:'Een kalibreerbare overlay voor Ingress Prime. Plaats zelf de belangrijke zones en het Lab volgt je gebaren om de HUD aan te passen.',redactedOverlayPermissionText:'Sta toe dat het Lab boven andere apps wordt weergegeven. De HUD leest Prime niet uit: hotspots worden handmatig geplaatst.',redactedOverlayToggle:'Prime HUD inschakelen',redactedOverlayOn:'Prime HUD ingeschakeld',redactedOverlayOff:'Prime HUD uitgeschakeld',redactedOverlayReady:'Prime HUD gereed.',primeHudCalibrate:'Hotspots kalibreren',primeHudMap:'Kaart',primeHudProfile:'Profiel',primeHudInventory:'Inventaris',primeHudAttack:'Aanval',primeHudAccessibility:'Gebaren toestaan',primeHudUsage:'Prime detecteren',primeHudReset:'Hotspots resetten',primeHudResync:'Hersynchroniseren',primeHudAccessNeeded:'Schakel de toegankelijkheidsservice “Redacted Prime HUD” in zodat gebaren in Prime kunnen worden herhaald.',primeHudUsageNeeded:'Sta gebruikstoegang toe zodat de HUD buiten Ingress Prime automatisch wordt verborgen.',primeHudCalibStarted:'Kalibratie {state} gestart in Prime. Verplaats de kaders en wijzig de grootte via de rechteronderhoek.',primeHudResetDone:'Hotspots gereset.',primeHudStateSet:'Status hersynchroniseerd: {state}'}
};
for(const [lang,pack] of Object.entries(TEST37_I18N))if(I18N[lang])Object.assign(I18N[lang],pack);

const TEST45_I18N={
  fr:{primeHudChooseTitle:'Configurer le Prime HUD',primeHudChooseText:'Choisis les éléments du Lab que tu veux afficher dans Prime. Les éléments déjà configurés gardent leur position ; seuls les nouveaux seront calibrés.',primeHudChooseAll:'Tout sélectionner',primeHudChooseNone:'Tout retirer',primeHudConfigurePrime:'Configurer dans Prime',primeHudReconfigure:'Reconfigurer les éléments',primeHudElementProfile:'REDACTED · accès Profil',primeHudElementProfileHint:'Petite tête déplaçable sur ton pseudo / accès au profil.',primeHudElementAction:'Capteurs de swipe ACTION',primeHudElementActionHint:'Zone tactile invisible plus large avec mini-capteurs pour haut, gauche et droite.',primeHudElementProfileBack:'IGOR · retour Profil',primeHudElementProfileBackHint:'Place IGOR sur la commande qui permet de revenir du profil.',primeHudElementInventoryBack:'MILO · fermer Inventaire',primeHudElementInventoryBackHint:'Place MILO sur la commande qui ferme l’inventaire.',primeHudElementAttackBack:'LEON · fermer Action',primeHudElementAttackBackHint:'Place LEON sur la commande qui ferme l’écran Action.',primeHudNoElement:'Sélectionne au moins un élément, sinon le néon sera très joli mais franchement solitaire.',primeHudSelectionSaved:'Sélection enregistrée. Prime s’ouvre pour calibrer uniquement les nouveaux éléments.',primeHudSelectionApplied:'Sélection mise à jour. Les éléments déjà configurés conservent leur position.'},
  en:{primeHudChooseTitle:'Configure Prime HUD',primeHudChooseText:'Choose which Lab elements you want inside Prime. Existing calibrated elements keep their position; only new ones are calibrated.',primeHudChooseAll:'Select all',primeHudChooseNone:'Remove all',primeHudConfigurePrime:'Configure in Prime',primeHudReconfigure:'Reconfigure elements',primeHudElementProfile:'REDACTED · Profile access',primeHudElementProfileHint:'Movable head over your nickname / profile access.',primeHudElementAction:'ACTION swipe sensors',primeHudElementActionHint:'Large invisible touch zone with tiny up, left and right sensors.',primeHudElementProfileBack:'IGOR · Profile back',primeHudElementProfileBackHint:'Place IGOR over the control used to leave the profile.',primeHudElementInventoryBack:'MILO · close Inventory',primeHudElementInventoryBackHint:'Place MILO over the control that closes Inventory.',primeHudElementAttackBack:'LEON · close Action',primeHudElementAttackBackHint:'Place LEON over the control that closes the Action screen.',primeHudNoElement:'Select at least one element.',primeHudSelectionSaved:'Selection saved. Prime opens to calibrate only the new elements.',primeHudSelectionApplied:'Selection updated. Existing calibrated elements keep their position.'},
  es:{primeHudChooseTitle:'Configurar Prime HUD',primeHudChooseText:'Elige los elementos del Lab que quieres mostrar en Prime. Los ya calibrados conservan su posición; solo se calibran los nuevos.',primeHudChooseAll:'Seleccionar todo',primeHudChooseNone:'Quitar todo',primeHudConfigurePrime:'Configurar en Prime',primeHudReconfigure:'Reconfigurar elementos',primeHudElementProfile:'REDACTED · acceso Perfil',primeHudElementProfileHint:'Cabeza móvil sobre tu nombre / acceso al perfil.',primeHudElementAction:'Sensores swipe ACTION',primeHudElementActionHint:'Zona táctil amplia e invisible con minisensores.',primeHudElementProfileBack:'IGOR · volver Perfil',primeHudElementProfileBackHint:'Coloca IGOR sobre el control de retorno del perfil.',primeHudElementInventoryBack:'MILO · cerrar Inventario',primeHudElementInventoryBackHint:'Coloca MILO sobre el control que cierra el inventario.',primeHudElementAttackBack:'LEON · cerrar Acción',primeHudElementAttackBackHint:'Coloca LEON sobre el control que cierra Acción.',primeHudNoElement:'Selecciona al menos un elemento.',primeHudSelectionSaved:'Selección guardada. Prime se abre para calibrar solo los elementos nuevos.',primeHudSelectionApplied:'Selección actualizada. Los elementos ya configurados conservan su posición.'},
  pt:{primeHudChooseTitle:'Configurar Prime HUD',primeHudChooseText:'Escolhe os elementos do Lab que queres mostrar no Prime. Os já calibrados mantêm a posição; apenas os novos são calibrados.',primeHudChooseAll:'Selecionar tudo',primeHudChooseNone:'Remover tudo',primeHudConfigurePrime:'Configurar no Prime',primeHudReconfigure:'Reconfigurar elementos',primeHudElementProfile:'REDACTED · acesso Perfil',primeHudElementProfileHint:'Cabeça móvel sobre o nome / acesso ao perfil.',primeHudElementAction:'Sensores swipe ACTION',primeHudElementActionHint:'Zona tátil invisível maior com mini sensores.',primeHudElementProfileBack:'IGOR · voltar Perfil',primeHudElementProfileBackHint:'Coloca IGOR no controlo de retorno do perfil.',primeHudElementInventoryBack:'MILO · fechar Inventário',primeHudElementInventoryBackHint:'Coloca MILO no controlo que fecha o inventário.',primeHudElementAttackBack:'LEON · fechar Ação',primeHudElementAttackBackHint:'Coloca LEON no controlo que fecha Ação.',primeHudNoElement:'Seleciona pelo menos um elemento.',primeHudSelectionSaved:'Seleção guardada. O Prime abre para calibrar apenas os novos elementos.',primeHudSelectionApplied:'Seleção atualizada. Os elementos já configurados mantêm a posição.'},
  de:{primeHudChooseTitle:'Prime HUD konfigurieren',primeHudChooseText:'Wähle die Lab-Elemente, die in Prime erscheinen sollen. Bereits kalibrierte Elemente behalten ihre Position; nur neue werden kalibriert.',primeHudChooseAll:'Alle auswählen',primeHudChooseNone:'Alle entfernen',primeHudConfigurePrime:'In Prime konfigurieren',primeHudReconfigure:'Elemente neu konfigurieren',primeHudElementProfile:'REDACTED · Profilzugang',primeHudElementProfileHint:'Verschiebbarer Kopf über Name / Profilzugang.',primeHudElementAction:'ACTION-Wischsensoren',primeHudElementActionHint:'Große unsichtbare Touch-Zone mit kleinen Sensoren.',primeHudElementProfileBack:'IGOR · Profil zurück',primeHudElementProfileBackHint:'IGOR auf den Zurück-Bereich des Profils setzen.',primeHudElementInventoryBack:'MILO · Inventar schließen',primeHudElementInventoryBackHint:'MILO auf den Schließen-Bereich des Inventars setzen.',primeHudElementAttackBack:'LEON · Aktion schließen',primeHudElementAttackBackHint:'LEON auf den Schließen-Bereich der Aktion setzen.',primeHudNoElement:'Wähle mindestens ein Element.',primeHudSelectionSaved:'Auswahl gespeichert. Prime öffnet sich und kalibriert nur neue Elemente.',primeHudSelectionApplied:'Auswahl aktualisiert. Bereits konfigurierte Elemente behalten ihre Position.'},
  it:{primeHudChooseTitle:'Configura Prime HUD',primeHudChooseText:'Scegli gli elementi del Lab da mostrare in Prime. Quelli già calibrati mantengono la posizione; vengono calibrati solo i nuovi.',primeHudChooseAll:'Seleziona tutto',primeHudChooseNone:'Rimuovi tutto',primeHudConfigurePrime:'Configura in Prime',primeHudReconfigure:'Riconfigura elementi',primeHudElementProfile:'REDACTED · accesso Profilo',primeHudElementProfileHint:'Testa spostabile sul nome / accesso al profilo.',primeHudElementAction:'Sensori swipe ACTION',primeHudElementActionHint:'Zona touch invisibile ampia con mini sensori.',primeHudElementProfileBack:'IGOR · indietro Profilo',primeHudElementProfileBackHint:'Posiziona IGOR sul comando di ritorno del profilo.',primeHudElementInventoryBack:'MILO · chiudi Inventario',primeHudElementInventoryBackHint:'Posiziona MILO sul comando che chiude Inventario.',primeHudElementAttackBack:'LEON · chiudi Azione',primeHudElementAttackBackHint:'Posiziona LEON sul comando che chiude Azione.',primeHudNoElement:'Seleziona almeno un elemento.',primeHudSelectionSaved:'Selezione salvata. Prime si apre per calibrare solo i nuovi elementi.',primeHudSelectionApplied:'Selezione aggiornata. Gli elementi già configurati mantengono la posizione.'},
  nl:{primeHudChooseTitle:'Prime HUD configureren',primeHudChooseText:'Kies welke Lab-elementen je in Prime wilt tonen. Reeds gekalibreerde elementen behouden hun positie; alleen nieuwe worden gekalibreerd.',primeHudChooseAll:'Alles selecteren',primeHudChooseNone:'Alles verwijderen',primeHudConfigurePrime:'Configureren in Prime',primeHudReconfigure:'Elementen opnieuw configureren',primeHudElementProfile:'REDACTED · Profieltoegang',primeHudElementProfileHint:'Verplaatsbaar hoofd boven naam / profieltoegang.',primeHudElementAction:'ACTION swipe-sensoren',primeHudElementActionHint:'Grote onzichtbare touchzone met minisensoren.',primeHudElementProfileBack:'IGOR · Profiel terug',primeHudElementProfileBackHint:'Plaats IGOR op de terugknop van het profiel.',primeHudElementInventoryBack:'MILO · Inventaris sluiten',primeHudElementInventoryBackHint:'Plaats MILO op de knop die Inventaris sluit.',primeHudElementAttackBack:'LEON · Actie sluiten',primeHudElementAttackBackHint:'Plaats LEON op de knop die Actie sluit.',primeHudNoElement:'Selecteer minstens één element.',primeHudSelectionSaved:'Selectie opgeslagen. Prime opent om alleen nieuwe elementen te kalibreren.',primeHudSelectionApplied:'Selectie bijgewerkt. Reeds geconfigureerde elementen behouden hun positie.'}
};
for(const [lang,pack] of Object.entries(TEST45_I18N))if(I18N[lang])Object.assign(I18N[lang],pack);


const HALLOWEEN_I18N={
  fr:{halloweenTitle:'Décoration Halloween',halloweenText:'Incident saisonnier du Lab. Disponible uniquement pendant la période Halloween.',halloweenToggle:'Activer la décoration Halloween'},
  en:{halloweenTitle:'Halloween decoration',halloweenText:'Seasonal Lab incident. Available only during the Halloween period.',halloweenToggle:'Enable Halloween decoration'},
  es:{halloweenTitle:'Decoración de Halloween',halloweenText:'Incidente estacional del Lab. Disponible solo durante Halloween.',halloweenToggle:'Activar decoración de Halloween'},
  pt:{halloweenTitle:'Decoração de Halloween',halloweenText:'Incidente sazonal do Lab. Disponível apenas no período de Halloween.',halloweenToggle:'Ativar decoração de Halloween'},
  de:{halloweenTitle:'Halloween-Dekoration',halloweenText:'Saisonaler Laborvorfall. Nur während der Halloween-Zeit verfügbar.',halloweenToggle:'Halloween-Dekoration aktivieren'},
  it:{halloweenTitle:'Decorazione Halloween',halloweenText:'Incidente stagionale del Lab. Disponibile solo nel periodo di Halloween.',halloweenToggle:'Attiva decorazione Halloween'},
  nl:{halloweenTitle:'Halloween-decoratie',halloweenText:'Seizoensincident in het Lab. Alleen beschikbaar rond Halloween.',halloweenToggle:'Halloween-decoratie inschakelen'}
};
for(const [lang,pack] of Object.entries(HALLOWEEN_I18N)){
  if(I18N[lang])Object.assign(I18N[lang],pack);
}

function tr(key,vars={}){
  let s=(I18N[APP_LANG]&&I18N[APP_LANG][key])||I18N.en[key]||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))s=s.replaceAll('{'+k+'}',String(v));
  return s;
}
function op(key,vars={}){return opsText(APP_LANG,key,vars)}
function setAppLanguage(lang){
  if(!SUPPORTED_LANGS.includes(lang))return;
  localStorage.setItem('rbl-language',lang);
  location.reload();
}
function applyLanguageDirection(){document.documentElement.lang=APP_LANG;document.documentElement.dir=LANG_META[APP_LANG]?.rtl?'rtl':'ltr'}
applyLanguageDirection();

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,10);

const state = {
  projectId: 'current',
  projectLanguage: APP_LANG,
  name: tr('defaultProject'),
  rows: 3,
  showGrid: true,
  showCircles: true,
  circleOpacity: 0.44,
  showNumbers: true,
  editMode: 'fresco',
  selectedMissionKey: null,
  missionOverrides: {},
  bg: { image:null, blob:null, x:WORLD_W/2, y:STEP*1.5, scale:1, rotation:0, visible:true, name:'' },
  imageLayers: [],
  texts: [],
  customFonts: [],
  active: 'background',
  planner: {
    description: '',
    titleFormat: '$T $0N / $M',
    sequential: true,
    hiddenLocation: false,
    portalsPerMission: 6,
    autoAdvance: true,
    reuseLastPortal: true,
    currentMission: 0,
    missions: []
  }
};

let activeFlow = 'fresco';
let saveTimer = null;
let currentSheet = null;
let toastTimer = null;
let pointers = new Map();
let gesture = null;
let missionEditorBack = null;
let missionEditorCanvas = null;
let missionEditorPointers = new Map();
let missionEditorGesture = null;
let missionEditorShowCircle = true;
let historyUndo = [];
let historyRedo = [];
let historyBusy = false;
const HISTORY_LIMIT = 80;

function deepClone(v){return JSON.parse(JSON.stringify(v))}
function snapshotState(){
  const data=serializeState();
  delete data.updatedAt;delete data.customFonts;
  return {
    data:deepClone(data),
    blob:state.bg.blob,
    image:state.bg.image,
    layerMedia:state.imageLayers.map(l=>({id:l.id,blob:l.blob,image:l.image})),
    active:state.active
  };
}
function snapshotsEqual(a,b){
  if(!a||!b||a.blob!==b.blob||a.image!==b.image||a.active!==b.active||JSON.stringify(a.data)!==JSON.stringify(b.data))return false;
  const am=a.layerMedia||[],bm=b.layerMedia||[];
  return am.length===bm.length&&am.every((x,i)=>x.id===bm[i]?.id&&x.blob===bm[i]?.blob&&x.image===bm[i]?.image);
}
function beginHistory(){return historyBusy?null:snapshotState()}
function commitHistory(before,label='Modification'){
  if(historyBusy||!before)return;
  const after=snapshotState();
  if(snapshotsEqual(before,after))return;
  historyUndo.push({snapshot:before,label});
  if(historyUndo.length>HISTORY_LIMIT)historyUndo.shift();
  historyRedo.length=0;
  updateHistoryUi();
}
function resetHistory(){historyUndo=[];historyRedo=[];updateHistoryUi()}
async function restoreSnapshot(snap){
  if(!snap)return;
  historyBusy=true;
  try{
    const d=snap.data||{};
    state.name=d.name||tr('defaultProject');
    state.rows=clamp(parseInt(d.rows)||3,1,25);
    state.showGrid=d.showGrid!==false;state.showCircles=d.showCircles!==false;state.circleOpacity=Number.isFinite(+d.circleOpacity)?clamp(+d.circleOpacity,0,1):0.44;state.showNumbers=d.showNumbers!==false;
    state.editMode=d.editMode==='mission'?'mission':'fresco';
    state.selectedMissionKey=d.selectedMissionKey||null;
    state.missionOverrides=deepClone(d.missionOverrides||{});
    state.texts=deepClone(d.texts||[]);normalizeAllTextStyles();
    state.imageLayers=deepClone(d.imageLayers||[]).map(l=>({...l,image:null,blob:null,visible:l.visible!==false}));
    const media=new Map((snap.layerMedia||[]).map(x=>[x.id,x]));
    for(const layer of state.imageLayers){
      const m=media.get(layer.id);if(m){layer.blob=m.blob||null;layer.image=m.image||null}
      if(!layer.image&&layer.blob)layer.image=await blobToImage(layer.blob);
    }
    state.active=snap.active||'background';
    state.planner=normalizePlanner(d.planner||{});ensurePlannerMissions();
    state.bg={image:snap.image||null,blob:snap.blob||null,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,visible:true,name:''};
    Object.assign(state.bg,d.bg||{});state.bg.visible=d.bg?.visible!==false;
    if(!state.bg.image&&state.bg.blob)state.bg.image=await blobToImage(state.bg.blob);
    refreshProjectUi();render();
    if(missionEditorBack)renderMissionEditor();
    scheduleSave();
  }finally{historyBusy=false;updateHistoryUi()}
}
async function undoAction(){
  const item=historyUndo.pop();if(!item)return;
  historyRedo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('undo')} · ${item.label}`);
}
async function redoAction(){
  const item=historyRedo.pop();if(!item)return;
  historyUndo.push({snapshot:snapshotState(),label:item.label});
  await restoreSnapshot(item.snapshot);
  toast(`${tr('redo')} · ${item.label}`);
}
function updateHistoryUi(){
  const undoDisabled=!historyUndo.length,redoDisabled=!historyRedo.length;
  $$('.undoActionBtn').forEach(b=>{b.disabled=undoDisabled;b.classList.toggle('disabled',undoDisabled);b.title=undoDisabled?tr('undo'):`${tr('undo')} · ${historyUndo.at(-1).label}`});
  $$('.redoActionBtn').forEach(b=>{b.disabled=redoDisabled;b.classList.toggle('disabled',redoDisabled);b.title=redoDisabled?tr('redo'):`${tr('redo')} · ${historyRedo.at(-1).label}`});
}
function historyControl(el,label){
  if(!el)return;
  let before=null;
  const begin=()=>{if(before===null)before=beginHistory()};
  const commit=()=>{if(before!==null){commitHistory(before,label);before=null}};
  el.addEventListener('pointerdown',begin);
  el.addEventListener('focus',begin);
  el.addEventListener('change',commit);
  el.addEventListener('blur',commit);
}

function icon(name){
  const paths={
    image:'<path d="M4 5h16v14H4z"/><path d="m4 16 4-4 4 4 3-3 5 5"/><circle cx="9" cy="9" r="1.5"/>',
    move:'<path d="M12 2v20M2 12h20M12 2l-3 3m3-3 3 3M12 22l-3-3m3 3 3-3M2 12l3-3m-3 3 3 3M22 12l-3-3m3 3-3 3"/>',
    text:'<path d="M5 5h14M12 5v14M8 19h8"/>',
    eye:'<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    export:'<path d="M12 3v12m0-12-4 4m4-4 4 4M5 14v6h14v-6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/>',
    settingsGear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21H9.6v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4V9.6h.1A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6A1.7 1.7 0 0 0 10 2.5V2.4h4v.1a1.7 1.7 0 0 0 1 1.7 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.1v4h-.1a1.7 1.7 0 0 0-1.7 1Z"/>',
    close:'<path d="m6 6 12 12M18 6 6 18"/>',
    reset:'<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8M4 4v4h4"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M8 7l1 13h6l1-13"/>',
    layers:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
    folder:'<path d="M3 6h7l2 2h9v10H3z"/><path d="M3 8h18"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit:'<path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    expand:'<path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/><path d="M3 8l6-6M21 8l-6-6M3 16l6 6M21 16l-6 6"/>',
    route:'<path d="M5 19c4-1 3-5 7-6s3-5 7-8"/><circle cx="5" cy="19" r="2"/><circle cx="12" cy="13" r="2"/><circle cx="19" cy="5" r="2"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    upload:'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 15v5h14v-5"/>',
    download:'<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 19h14"/>',
    chevronUp:'<path d="m7 14 5-5 5 5"/>',
    chevronDown:'<path d="m7 10 5 5 5-5"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    warning:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v4M12 17h.01"/>',
    play:'<path d="m8 5 11 7-11 7V5Z"/>',
    star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2-4.5-4.4 6.2-.9L12 3Z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name]||''}</svg>`;
}

const TEST_COPY={
  fr:{updatesOff:'Les mises à jour PROD sont désactivées dans cette édition TEST.'},
  en:{updatesOff:'PROD updates are disabled in this TEST edition.'},
  es:{updatesOff:'Las actualizaciones PROD están desactivadas en esta edición TEST.'},
  pt:{updatesOff:'As atualizações PROD estão desativadas nesta edição TEST.'},
  de:{updatesOff:'PROD-Updates sind in dieser TEST-Ausgabe deaktiviert.'},
  it:{updatesOff:'Gli aggiornamenti PROD sono disattivati in questa edizione TEST.'},
  nl:{updatesOff:'PROD-updates zijn uitgeschakeld in deze TEST-editie.'}
};
function testText(key){const l=TEST_COPY[APP_LANG]||TEST_COPY.en;return l[key]||TEST_COPY.en[key]||key}

function appHTML(){
  return `<main class="app">
    <header class="topbar topbarSearchFirst">
      <div class="topbarBrandRow">
        <div class="brand">
          <button class="brandmark brandegg" id="brandEgg" aria-label="Redacted"><img src="/redacted-logo-512.png" alt="Redacted"></button>
          <div><h1>Redacted BannerLab</h1><small>v${APP_VERSION}</small></div>
        </div>
        <div class="topbarActions"><button class="iconbtn elevatorTopBtn" id="elevatorBtn" aria-label="${escapeAttr(tr('elevatorBackLabel'))}" title="${escapeAttr(tr('elevatorBackLabel'))}">⇅</button></div>
      </div>
      <button class="playhubbtn playhubbtnHero" id="playHubBtn" aria-label="${tr('playBanners')}">${icon('search')}<span>${tr('playBanners')}</span></button>
    </header>
    <section class="page">
      <div class="projectcompact">
        <button class="projectbtn" id="projectsBtn">${icon('folder')}<span>${tr("projects")}</span></button>
        <div class="rowpick"><span>${tr("rows")}</span><select id="rowsSelect">${Array.from({length:25},(_,i)=>`<option value="${i+1}" ${i+1===state.rows?'selected':''}>${i+1}</option>`).join('')}</select></div>
      </div>
      <div class="flowbar">
        <button class="flowstep on" data-flow="fresco"><b>1</b><span>${tr("fresco")}</span></button>
        <button class="flowstep" data-flow="route"><b>2</b><span>${tr("route")}</span></button>
        <button class="flowstep" data-flow="missions"><b>3</b><span>${tr("missions")}</span></button>
        <button class="flowstep" data-flow="publish"><b>4</b><span>${tr("publish")}</span></button>
      </div>
      <div class="card workspace" id="workspaceCard">
        <div class="flowlockveil" id="flowLockVeil" hidden>
          <div class="flowlockbox">
            <strong>🔒 ${tr('flowLocked')}</strong>
            <span id="flowLockText">${tr('flowLockedText',{step:tr('route')})}</span>
            <small>${tr('returnFresco')}</small>
          </div>
        </div>
        <div class="modebar">
          <button class="modebtn on" data-editmode="fresco">${tr("wholeFresco")}</button>
          <button class="modebtn" data-editmode="mission">${tr("oneMission")}</button>
          <div class="missionstatus" id="missionStatus">${tr("noMission")}</div>
        </div>
        <div class="badges frescoQuickControls">
          <button class="chip ${state.showCircles?'on':''}" data-toggle="circles">${tr("circles")}</button>
          <label class="circleOpacityControl" title="${tr('circleOpacity')}">
            <span>${tr('circleOpacity')}</span>
            <input id="circleOpacity" type="range" min="0" max="100" step="1" value="${Math.round((state.circleOpacity??0.44)*100)}">
            <b id="circleOpacityVal">${Math.round((state.circleOpacity??0.44)*100)}%</b>
          </label>
          <button class="chip ${state.showGrid?'on':''}" data-toggle="grid">${tr("grid")}</button>
          <button class="chip ${state.showNumbers?'on':''}" data-toggle="numbers">${tr("numbers")}</button>
          <button class="chip studioedit" id="openStudioEditorBtn">${icon('expand')} ${tr("studioEdit")}</button>
          <button class="chip historychip undoActionBtn" id="undoBtn" disabled>↶ ${tr("undo")}</button>
          <button class="chip historychip redoActionBtn" id="redoBtn" disabled>↷ ${tr("redo")}</button>
          <button class="chip missionlarge" id="openMissionEditorBtn" hidden>${icon('expand')} ${tr("enlarge")}</button>
          <button class="chip resetmission" id="resetMissionBtn" hidden>${tr("resetMission")}</button>
        </div>
        <div class="canvaswrap"><canvas id="editor"></canvas><div class="empty" id="empty"><div><strong>${tr("addImage")}</strong>${tr("imageHint")}</div></div></div>
        <div class="hint" id="gestureHint">${tr('bannerHelp')}</div>
      </div>
    </section>
    <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden>
    <nav class="bottom">
      <button class="tool" data-tool="image">${icon('image')}<span>${tr("image")}</span></button>
      <button class="tool" data-tool="text">${icon('text')}<span>${tr("text")}</span></button>
      <button class="tool" data-tool="preview">${icon('eye')}<span>${tr("preview")}</span></button>
      <button class="tool" data-tool="export">${icon('export')}<span>${tr("export")}</span></button>
    </nav>
  </main>`;
}

function escapeAttr(s=''){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}

document.querySelector('#app').innerHTML=appHTML();
applyHalloweenTheme();
const canvas=$('#editor');
const ctx=canvas.getContext('2d');

function flowIsEditable(){return activeFlow==='fresco'}
function activeFlowLabel(){
  return activeFlow==='route'?tr('route'):activeFlow==='missions'?tr('missions'):activeFlow==='publish'?tr('publish'):tr('fresco');
}
function applyFlowLock(){
  const locked=!flowIsEditable();
  const workspace=$('#workspaceCard');
  const veil=$('#flowLockVeil');
  workspace?.classList.toggle('flowlocked',locked);
  if(veil)veil.hidden=!locked;
  const txt=$('#flowLockText');
  if(txt)txt.textContent=tr('flowLockedText',{step:activeFlowLabel()});

  const rows=$('#rowsSelect');
  if(rows)rows.disabled=locked;

  // Editing tools only. Preview/export remain usable.
  $$('.tool[data-tool="image"],.tool[data-tool="text"]').forEach(b=>{
    b.classList.toggle('flowdisabled',locked);
    b.setAttribute('aria-disabled',locked?'true':'false');
  });

  $$('.flowstep').forEach(b=>b.classList.toggle('on',b.dataset.flow===activeFlow));
}
function requireFrescoFlow(){
  if(flowIsEditable())return true;
  toast(tr('flowLockedToast'));
  return false;
}
function setFlowStep(flow,{open=true}={}){
  if(!['fresco','route','missions','publish'].includes(flow))flow='fresco';
  activeFlow=flow;
  applyFlowLock();

  if(!open)return;
  if(flow==='fresco'){closeSheet();return}
  if(flow==='route')openRoutePlanner();
  if(flow==='missions')openMissionSettings();
  if(flow==='publish')openPublishSheet();
}

function worldH(){return state.rows*STEP}
function viewScale(){return canvas.width/WORLD_W}
function resizeCanvas(){canvas.width=RENDER_W;canvas.height=Math.max(200,Math.round(RENDER_W*worldH()/WORLD_W));render()}

function drawImageObject(c,b){
  if(!b?.image||b.visible===false)return;
  c.save();c.translate(b.x||0,b.y||0);c.rotate(b.rotation||0);c.scale(b.scale||1,b.scale||1);
  c.globalAlpha=clamp(Number.isFinite(+b.opacity)?+b.opacity:1,0,1);
  c.drawImage(b.image,-b.image.naturalWidth/2,-b.image.naturalHeight/2);c.restore();
}
function drawImageLayerObject(c,layer){normalizeImageLayerScope(layer);if(layer.scope!=='mission'){drawImageObject(c,layer);return}const r=missionLayerRect(layer);if(!r||!layer?.image||layer.visible===false)return;c.save();c.beginPath();c.rect(r.x,r.y,TILE,TILE);c.clip();drawImageObject(c,layer);c.restore()}
function drawBaseBackground(c){
  drawImageObject(c,state.bg);
  for(const layer of state.imageLayers)drawImageLayerObject(c,layer);
}
function hasImageContent(){return !!state.bg.image||state.imageLayers.some(l=>!!l.image)}
function activeImageLayer(){
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||null;
  return null;
}
function imageLayerLabel(layer,index){return layer?.name?.trim()||`${tr('layerName')} ${index+1}`}
function groupLayersFor(layer){return layer?.groupId?state.imageLayers.filter(x=>x.groupId===layer.groupId):layer?[layer]:[]}

const BUILTIN_TEXT_FONTS=[
  {value:'system-ui, sans-serif',label:'System'},
  {value:'Arial, sans-serif',label:'Arial'},
  {value:'Georgia, serif',label:'Georgia'},
  {value:'serif',label:'Serif'},
  {value:'monospace',label:'Monospace'},
  {value:'cursive',label:'Cursive'}
];
const registeredProjectFontFamilies=new Set();
function textDefaults(t={}){
  return Object.assign({fontFamily:'system-ui, sans-serif',fontWeight:800,fontItalic:false,letterSpacing:0,lineHeight:1.08,textAlign:'center',backgroundEnabled:false,backgroundColor:'#07100c',backgroundOpacity:.72,backgroundPadding:24,backgroundRadius:24},t||{});
}
function normalizeTextStyle(t){
  if(!t)return t;const d=textDefaults();
  for(const [k,v] of Object.entries(d))if(t[k]===undefined||t[k]===null)t[k]=v;
  t.fontWeight=clamp(parseInt(t.fontWeight)||800,100,900);t.letterSpacing=clamp(Number(t.letterSpacing)||0,-40,160);t.lineHeight=clamp(Number(t.lineHeight)||1.08,.7,2.4);{const op=Number(t.backgroundOpacity);t.backgroundOpacity=clamp(Number.isFinite(op)?op:.72,0,1);}t.backgroundPadding=clamp(Number(t.backgroundPadding)||0,0,180);t.backgroundRadius=clamp(Number(t.backgroundRadius)||0,0,240);if(!['left','center','right'].includes(t.textAlign))t.textAlign='center';return t;
}
function normalizeAllTextStyles(){state.texts.forEach(normalizeTextStyle)}
function textFontCss(t){normalizeTextStyle(t);return `${t.fontItalic?'italic ':'normal '}${t.fontWeight||800} ${t.fontSize||180}px ${t.fontFamily||'system-ui, sans-serif'}`}
function fontOptionsHtml(selected){
  const builtin=BUILTIN_TEXT_FONTS.map(f=>`<option value="${escapeAttr(f.value)}" ${selected===f.value?'selected':''}>${escapeHtml(f.label)}</option>`).join('');
  const custom=(state.customFonts||[]).map(f=>`<option value="${escapeAttr(f.family)}" ${selected===f.family?'selected':''}>★ ${escapeHtml(f.name||f.family)}</option>`).join('');
  return builtin+custom;
}
function bytesToBase64(bytes){let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary)}
async function registerProjectFont(rec){
  if(!rec?.family||!rec?.dataUrl)return false;if(registeredProjectFontFamilies.has(rec.family))return true;if(typeof FontFace==='undefined'||!document.fonts)return false;
  try{const face=new FontFace(rec.family,`url(${rec.dataUrl})`);await face.load();document.fonts.add(face);registeredProjectFontFamilies.add(rec.family);return true}catch(e){console.warn('custom font',rec.name,e);return false}
}
async function registerProjectFonts(){for(const rec of (state.customFonts||[]))await registerProjectFont(rec)}
async function importProjectFont(applyToText=null,onDone=null){
  const input=document.createElement('input');input.type='file';input.accept='.ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{
    const file=input.files?.[0];if(!file)return;if(file.size>12*1024*1024){toast(tr('fontTooLarge'));return}
    const ext=(file.name.split('.').pop()||'').toLowerCase();if(!['ttf','otf','woff','woff2'].includes(ext)){toast(tr('fontInvalid'));return}
    const id='font_'+uid(),family='RBLFont_'+id.replace(/[^a-z0-9_]/gi,''),mime=file.type||({ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2'}[ext]||'application/octet-stream');
    const dataUrl=`data:${mime};base64,${bytesToBase64(new Uint8Array(await file.arrayBuffer()))}`;const rec={id,name:file.name,family,mime,dataUrl};state.customFonts.push(rec);const ok=await registerProjectFont(rec);if(!ok){state.customFonts=state.customFonts.filter(x=>x.id!==id);toast(tr('fontInvalid'));return}
    if(applyToText){applyToText.fontFamily=family;normalizeTextStyle(applyToText)}scheduleSave();render();toast(tr('fontImported',{name:file.name}));if(onDone)onDone(rec);
  }catch(e){console.warn('font import',e);toast(tr('fontInvalid'))}finally{input.remove()}};input.click();
}
function measureSpacedLine(c,line,t){const chars=Array.from(String(line||''));return c.measureText(String(line||'')).width+Math.max(0,chars.length-1)*(t.letterSpacing||0)}
function textBlockMetrics(c,t){
  normalizeTextStyle(t);c.font=textFontCss(t);const lines=(t.text||tr('text')).split('\n'),lineH=(t.fontSize||180)*(t.lineHeight||1.08),widths=lines.map(line=>measureSpacedLine(c,line,t)),maxW=Math.max(40,...widths),h=Math.max(lineH,lines.length*lineH),pad=t.backgroundEnabled?(t.backgroundPadding||0):0;return {lines,lineH,widths,maxW,h,pad,bgW:maxW+pad*2,bgH:h+pad*2};
}
function roundedRectPath(c,x,y,w,h,r){r=Math.max(0,Math.min(r,Math.min(w,h)/2));c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath()}
function drawSpacedLine(c,line,x,y,t,maxW){
  const chars=Array.from(String(line||'')),spacing=t.letterSpacing||0,width=measureSpacedLine(c,line,t);let start=x-width/2;if(t.textAlign==='left')start=x-maxW/2;else if(t.textAlign==='right')start=x+maxW/2-width;
  if(Math.abs(spacing)<.001){c.textAlign=t.textAlign;const tx=t.textAlign==='left'?x-maxW/2:t.textAlign==='right'?x+maxW/2:x;if(t.strokeWidth>0)c.strokeText(line,tx,y);c.fillText(line,tx,y);return}
  c.textAlign='left';for(const ch of chars){if(t.strokeWidth>0)c.strokeText(ch,start,y);c.fillText(ch,start,y);start+=c.measureText(ch).width+spacing}
}

function drawOverlayWorld(c){
  for(const t of state.texts) drawTextWorld(c,t);
}

function drawTextWorld(c,t){
  normalizeTextStyle(t);c.save();c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);c.font=textFontCss(t);c.textBaseline='middle';c.lineJoin='round';
  const m=textBlockMetrics(c,t);
  if(t.backgroundEnabled){c.save();c.globalAlpha=t.backgroundOpacity??.72;c.fillStyle=t.backgroundColor||'#07100c';roundedRectPath(c,-m.bgW/2,-m.bgH/2,m.bgW,m.bgH,t.backgroundRadius||0);c.fill();c.restore()}
  c.lineWidth=t.strokeWidth||0;c.strokeStyle=t.strokeColor||'#07100c';c.fillStyle=t.color||'#ffffff';
  m.lines.forEach((line,i)=>{const y=(i-(m.lines.length-1)/2)*m.lineH;drawSpacedLine(c,line,0,y,t,m.maxW)});c.restore();
}

function missionKey(row,col){return `${row}:${col}`}
function parseMissionKey(key){if(!key)return null;const [row,col]=key.split(':').map(Number);if(!Number.isInteger(row)||!Number.isInteger(col))return null;return {row,col}}
function overrideFor(row,col,create=false){
  const key=missionKey(row,col);
  if(!state.missionOverrides[key]&&create)state.missionOverrides[key]={dx:0,dy:0,scale:1,rotation:0};
  return state.missionOverrides[key]||null;
}
function isIdentityOverride(o){return !o||Math.abs(o.dx||0)<.001&&Math.abs(o.dy||0)<.001&&Math.abs((o.scale??1)-1)<.0001&&Math.abs(o.rotation||0)<.0001}

function applyMissionTransform(c,row,col,o){
  const x=col*STEP+PAD,y=row*STEP+PAD,cx=x+TILE/2,cy=y+TILE/2;
  c.translate(cx+(o.dx||0),cy+(o.dy||0));
  c.rotate(o.rotation||0);
  c.scale(o.scale||1,o.scale||1);
  c.translate(-cx,-cy);
}

function drawComposedWorld(c){
  drawBaseBackground(c);
  for(const [key,o] of Object.entries(state.missionOverrides)){
    if(isIdentityOverride(o))continue;
    const rc=parseMissionKey(key);if(!rc||rc.row<0||rc.row>=state.rows||rc.col<0||rc.col>=COLS)continue;
    const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
    c.save();
    c.beginPath();c.rect(x,y,TILE,TILE);c.clip();
    c.fillStyle='#020604';c.fillRect(x,y,TILE,TILE);
    applyMissionTransform(c,rc.row,rc.col,o);
    drawBaseBackground(c);
    c.restore();
  }
  drawOverlayWorld(c);
}

function render(){
  const s=viewScale();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#020604';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.scale(s,s);drawComposedWorld(ctx);ctx.restore();
  if(state.showGrid||state.showCircles||state.showNumbers||state.editMode==='mission')drawGuides(ctx,s);
  drawSelection(ctx,s);
  $('#empty').style.display=hasImageContent()?'none':'grid';
  updateMissionUi();
  updateHistoryUi();
}

function drawGuides(c,s){
  c.save();c.scale(s,s);
  if(state.showCircles){
    c.fillStyle=`rgba(0,0,0,${clamp(state.circleOpacity??0.44,0,1)})`;c.beginPath();c.rect(0,0,WORLD_W,worldH());
    for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
      const x=col*STEP+PAD,y=r*STEP+PAD;c.moveTo(x+TILE,y+TILE/2);c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2,true);
    }
    c.fill('evenodd');
  }
  for(let r=0;r<state.rows;r++)for(let col=0;col<COLS;col++){
    const x=col*STEP+PAD,y=r*STEP+PAD;
    if(state.showGrid){c.strokeStyle='rgba(255,255,255,.30)';c.lineWidth=3/s;c.strokeRect(x,y,TILE,TILE)}
    if(state.showCircles){c.strokeStyle='rgba(54,240,138,.72)';c.lineWidth=4/s;c.beginPath();c.arc(x+TILE/2,y+TILE/2,TILE/2,0,Math.PI*2);c.stroke()}
    if(state.showNumbers){
      const n=missionNumber(r,col);c.fillStyle='rgba(0,0,0,.72)';c.beginPath();c.arc(x+TILE-48,y+48,34,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.font='700 26px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),x+TILE-48,y+48);
    }
  }
  if(state.editMode==='mission'&&state.selectedMissionKey){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      const x=rc.col*STEP+PAD,y=rc.row*STEP+PAD;
      c.strokeStyle='#ffcc66';c.lineWidth=10/s;c.setLineDash([22/s,14/s]);c.strokeRect(x+4/s,y+4/s,TILE-8/s,TILE-8/s);
    }
  }
  c.restore();
}

function drawSelection(c,s){
  if(state.editMode==='mission')return;
  if(state.active.startsWith('text:')){
    const id=state.active.slice(5),t=state.texts.find(x=>x.id===id);if(!t)return;
    c.save();c.scale(s,s);c.translate(t.x,t.y);c.rotate(t.rotation||0);c.scale(t.scale||1,t.scale||1);
    normalizeTextStyle(t);c.font=textFontCss(t);const m=textBlockMetrics(c,t),w=(t.backgroundEnabled?m.bgW:m.maxW)+36,h=(t.backgroundEnabled?m.bgH:m.h)+28;
    c.strokeStyle='#fff';c.lineWidth=3/(s*(t.scale||1));c.setLineDash([12/(t.scale||1),10/(t.scale||1)]);c.strokeRect(-w/2,-h/2,w,h);c.restore();
    return;
  }
  const layer=activeImageLayer();if(!layer?.image||layer.visible===false)return;
  const group=groupLayersFor(layer);
  for(const item of group){
    if(!item.image||item.visible===false)continue;
    c.save();c.scale(s,s);c.translate(item.x,item.y);c.rotate(item.rotation||0);c.scale(item.scale||1,item.scale||1);
    const inv=Math.max(.0001,s*(item.scale||1));
    c.strokeStyle=item===layer?'#ffcc66':'rgba(255,204,102,.55)';c.lineWidth=4/inv;c.setLineDash([14/(item.scale||1),10/(item.scale||1)]);
    c.strokeRect(-item.image.naturalWidth/2,-item.image.naturalHeight/2,item.image.naturalWidth,item.image.naturalHeight);c.restore();
  }
}

function missionNumber(row,col){return (state.rows-1-row)*6+(6-col)}
function rowColForMission(n){return {row:state.rows-1-Math.floor((n-1)/6), col:5-((n-1)%6)}}
function rowColForMissionAtRows(n,rows){n=Math.max(1,parseInt(n)||1);return {row:rows-1-Math.floor((n-1)/6),col:5-((n-1)%6)}}
function missionLayerNumber(layer){return layer?.scope==='mission'?Math.max(1,parseInt(layer.missionNumber)||1):null}
function missionLayerRect(layer,rows=state.rows){const n=missionLayerNumber(layer);if(!n||n>rows*COLS)return null;const rc=rowColForMissionAtRows(n,rows);if(rc.row<0||rc.row>=rows)return null;return {n,row:rc.row,col:rc.col,x:rc.col*STEP+PAD,y:rc.row*STEP+PAD,cx:rc.col*STEP+PAD+TILE/2,cy:rc.row*STEP+PAD+TILE/2}}
function missionLayerFitScale(layer,mode=layer?.fitMode||'cover'){if(!layer?.image)return 1;return mode==='contain'?Math.min(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight):Math.max(TILE/layer.image.naturalWidth,TILE/layer.image.naturalHeight)}
function normalizeImageLayerScope(layer){if(!layer)return layer;layer.scope=layer.scope==='mission'?'mission':'global';if(layer.scope==='mission'){layer.missionNumber=Math.max(1,parseInt(layer.missionNumber)||1);layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}else{layer.missionNumber=null;layer.fitMode=layer.fitMode==='contain'?'contain':'cover'}return layer}
function reanchorMissionLayers(oldRows,newRows){for(const l of state.imageLayers){normalizeImageLayerScope(l);if(l.scope!=='mission')continue;const n=missionLayerNumber(l),oldRc=n&&n<=oldRows*COLS?rowColForMissionAtRows(n,oldRows):null,newRc=n&&n<=newRows*COLS?rowColForMissionAtRows(n,newRows):null;if(!newRc)continue;const oldCx=oldRc?oldRc.col*STEP+PAD+TILE/2:l.x||0,oldCy=oldRc?oldRc.row*STEP+PAD+TILE/2:l.y||0,newCx=newRc.col*STEP+PAD+TILE/2,newCy=newRc.row*STEP+PAD+TILE/2;l.x=(l.x||oldCx)+(newCx-oldCx);l.y=(l.y||oldCy)+(newCy-oldCy)}}
function missionLayerBadgeHtml(layer){const n=missionLayerNumber(layer);return n?`<span class="missionLayerBadge">${escapeHtml(tr('missionBadge',{n}))}</span>`:''}

function selectedObj(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);return rc?overrideFor(rc.row,rc.col,true):null;
  }
  if(state.active==='background')return state.bg;
  if(state.active.startsWith('image:'))return state.imageLayers.find(l=>l.id===state.active.slice(6))||state.bg;
  if(state.active.startsWith('text:'))return state.texts.find(t=>t.id===state.active.slice(5));
  return state.bg;
}

function setActive(a){
  state.active=a;
  const isImage=a==='background'||a.startsWith('image:');
  $$('.tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='layers'));
  render();
}

function setEditMode(mode){
  state.editMode=mode==='mission'?'mission':'fresco';
  if(state.editMode==='mission')state.active='background';
  else state.selectedMissionKey=null;
  $$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));
  updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();scheduleSave();
}

function updateMissionUi(){
  const status=$('#missionStatus'),reset=$('#resetMissionBtn'),large=$('#openMissionEditorBtn'),hint=$('#gestureHint');
  if(!status||!reset||!large||!hint)return;
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(rc&&rc.row<state.rows){
      status.textContent=tr('missionSelected',{n:missionNumber(rc.row,rc.col)});
      reset.hidden=false;large.hidden=false;
    }else{
      status.textContent=tr('tapMedallion');reset.hidden=true;large.hidden=true;
    }
    hint.innerHTML=tr('missionHelp');
  }else{
    status.textContent='';reset.hidden=true;large.hidden=true;
    hint.innerHTML=tr('bannerHelp');
  }
}

let pendingImageMode='background';
async function loadImageFile(file){
  if(!file)return;
  const before=beginHistory();
  if(file.size>45*1024*1024)toast(tr('heavyImage'));
  const img=await blobToImage(file);
  if(pendingImageMode==='background'){
    state.bg.blob=file;state.bg.image=img;state.bg.visible=true;state.bg.name=tr('backgroundLayer');
    fitBackground();setEditMode('fresco');setActive('background');commitHistory(before,tr('histImport'));toast(tr('backgroundReplaced'));
  }else{
    const layer={id:uid(),name:file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'global',missionNumber:null,fitMode:'cover'};
    fitImageLayer(layer);state.imageLayers.push(layer);setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));toast(tr('layerAdded'));
  }
  scheduleSave();render();if(studioEditorRoot)refreshStudioEditor();toast(`${tr('imported',{w:img.naturalWidth,h:img.naturalHeight})} · ${pendingImageMode==='background'?tr('backgroundReplaced'):tr('layerAdded')}`);
}
function blobToImage(blob){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob);const img=new Image();img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=reject;img.src=url})}
function fitBackground(){if(!state.bg.image)return;const b=state.bg;b.x=WORLD_W/2;b.y=worldH()/2;b.rotation=0;b.scale=Math.max(WORLD_W/b.image.naturalWidth,worldH()/b.image.naturalHeight);b.visible=true;b.opacity=1}
function fitImageLayer(layer){if(!layer?.image)return;normalizeImageLayerScope(layer);if(layer.scope==='mission'){const r=missionLayerRect(layer);if(r){layer.x=r.cx;layer.y=r.cy;layer.scale=missionLayerFitScale(layer)}}else{layer.x=WORLD_W/2;layer.y=worldH()/2;layer.scale=Math.min(WORLD_W*.72/layer.image.naturalWidth,worldH()*.72/layer.image.naturalHeight)}layer.rotation=0;layer.opacity=1;layer.visible=true}
async function loadDefaultBackground(){
  try{
    const res=await fetch('/redacted-default.jpg');if(!res.ok)throw new Error('Image Redacted introuvable');
    const blob=await res.blob(),img=await blobToImage(blob);state.bg.blob=blob;state.bg.image=img;state.bg.name=tr('backgroundLayer');state.bg.visible=true;fitBackground();
  }catch(e){console.warn('default background',e)}
}

function canvasClientToWorld(clientX,clientY){
  if(studioEditorRoot){
    const stage=$('.studioCanvasStage',studioEditorRoot),rect=stage?.getBoundingClientRect(),scale=Math.max(.0001,studioViewScale);
    if(rect)return {x:(clientY-rect.top)/scale,y:(rect.right-clientX)/scale};
  }
  const rect=canvas.getBoundingClientRect(),scale=rect.width/WORLD_W;return {x:(clientX-rect.left)/scale,y:(clientY-rect.top)/scale};
}
function clientDeltaToWorld(dx,dy){
  const scale=Math.max(.0001,getCssScale());return studioEditorRoot?{dx:dy/scale,dy:-dx/scale}:{dx:dx/scale,dy:dy/scale};
}
function canvasPointToMission(clientX,clientY){
  const pt=canvasClientToWorld(clientX,clientY),x=pt.x,y=pt.y;
  if(x<0||y<0||x>=WORLD_W||y>=worldH())return null;
  const col=Math.floor(x/STEP),row=Math.floor(y/STEP),lx=x-col*STEP,ly=y-row*STEP;
  if(col<0||col>=COLS||row<0||row>=state.rows||lx<PAD||lx>PAD+TILE||ly<PAD||ly>PAD+TILE)return null;
  return {row,col,key:missionKey(row,col)};
}

function frescoTransformTargets(){
  const obj=selectedObj();if(!obj)return[];
  if(state.active.startsWith('image:')&&obj.groupId)return groupLayersFor(obj);
  return [obj];
}
function captureTransformTargets(targets){return targets.map(obj=>({obj,x:obj.x||0,y:obj.y||0,scale:obj.scale??1,rotation:obj.rotation||0}))}
function transformCenter(items){if(!items.length)return{x:0,y:0};return{x:items.reduce((a,t)=>a+t.x,0)/items.length,y:items.reduce((a,t)=>a+t.y,0)/items.length}}
function makeFrescoTwoGesture(points,historyBefore){const items=captureTransformTargets(frescoTransformTargets());return{mode:'two',dist:distance(points[0],points[1]),angle:angle(points[0],points[1]),mid:mid(points[0],points[1]),items,center:transformCenter(items),historyBefore}}

canvas.addEventListener('pointerdown',e=>{
  if(!requireFrescoFlow())return;
  canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(state.editMode==='mission'&&pointers.size===1){
    const hit=canvasPointToMission(e.clientX,e.clientY);
    if(!hit){gesture=null;return}
    const changed=state.selectedMissionKey!==hit.key;
    state.selectedMissionKey=hit.key;overrideFor(hit.row,hit.col,true);updateMissionUi();render();if(studioEditorRoot)refreshStudioMissionControls();
    // Le premier toucher choisit la mission sans la déplacer. Les gestes suivants
    // sur cette même mission servent ensuite à la transformer.
    if(changed){gesture=null;return}
  }
  const obj=selectedObj();if(!obj){gesture=null;return}
  if(state.editMode==='mission'){
    if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:beginHistory()};
    else if(pointers.size===2){const p=[...pointers.values()];gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()}}
    return;
  }
  if(pointers.size===1)gesture={mode:'one',startX:e.clientX,startY:e.clientY,items:captureTransformTargets(frescoTransformTargets()),historyBefore:beginHistory()};
  else if(pointers.size===2)gesture=makeFrescoTwoGesture([...pointers.values()],gesture?.historyBefore||beginHistory());
});
canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const obj=selectedObj();if(!obj)return;
  if(state.editMode==='mission'){
    if(pointers.size===1&&gesture?.mode==='one'){
      const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }else if(pointers.size===2){
      const p=[...pointers.values()];if(gesture?.mode!=='two'){gesture={mode:'two',dist:distance(p[0],p[1]),angle:angle(p[0],p[1]),objX:obj.dx||0,objY:obj.dy||0,objScale:obj.scale??1,objRot:obj.rotation||0,mid:mid(p[0],p[1]),isMission:true,historyBefore:gesture?.historyBefore||beginHistory()};return}
      const d=distance(p[0],p[1]),a=angle(p[0],p[1]),m=mid(p[0],p[1]);obj.scale=clamp(gesture.objScale*(d/Math.max(1,gesture.dist)),.2,5);obj.rotation=gesture.objRot+(a-gesture.angle);const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y);obj.dx=gesture.objX+dxy.dx;obj.dy=gesture.objY+dxy.dy;render();
    }
    return;
  }
  if(pointers.size===1&&gesture?.mode==='one'){
    const dxy=clientDeltaToWorld(e.clientX-gesture.startX,e.clientY-gesture.startY);for(const t of gesture.items||[]){t.obj.x=t.x+dxy.dx;t.obj.y=t.y+dxy.dy}render();
  }else if(pointers.size===2){
    const pts=[...pointers.values()];if(gesture?.mode!=='two'){gesture=makeFrescoTwoGesture(pts,gesture?.historyBefore||beginHistory());return}
    const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]),factor=d/Math.max(1,gesture.dist),rd=a-gesture.angle,cs=Math.cos(rd),sn=Math.sin(rd);
    const dxy=clientDeltaToWorld(m.x-gesture.mid.x,m.y-gesture.mid.y),nc={x:gesture.center.x+dxy.dx,y:gesture.center.y+dxy.dy};
    for(const t of gesture.items||[]){const ox=(t.x-gesture.center.x)*factor,oy=(t.y-gesture.center.y)*factor;t.obj.x=nc.x+ox*cs-oy*sn;t.obj.y=nc.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*factor,.02,30);t.obj.rotation=t.rotation+rd}render();
  }
});
function pointerEnd(e){
  pointers.delete(e.pointerId);
  if(pointers.size===0){
    const before=gesture?.historyBefore,label=state.editMode==='mission'?tr('histResetMission'):(state.active.startsWith('text:')?tr('histEditText'):(state.active.startsWith('image:')&&selectedObj()?.groupId?tr('groupTransform'):tr('frameImage')));
    gesture=null;commitHistory(before,label);scheduleSave();
  }else if(pointers.size===1){
    const p=[...pointers.values()][0],obj=selectedObj(),before=gesture?.historyBefore;
    if(state.editMode==='mission'&&obj)gesture={mode:'one',startX:p.x,startY:p.y,objX:obj.dx||0,objY:obj.dy||0,isMission:true,historyBefore:before};
    else gesture={mode:'one',startX:p.x,startY:p.y,items:captureTransformTargets(frescoTransformTargets()),historyBefore:before};
  }
}
canvas.addEventListener('pointerup',pointerEnd);canvas.addEventListener('pointercancel',pointerEnd);
function getCssScale(){return studioEditorRoot?Math.max(.0001,studioViewScale):canvas.getBoundingClientRect().width/WORLD_W}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)}function mid(a,b){return{x:(a.x+b.x)/2,y:(a.y+b.y)/2}}

$('#fileInput').addEventListener('change',e=>{loadImageFile(e.target.files?.[0]);e.target.value=''})
$('#projectName')?.addEventListener('input',e=>{state.name=e.target.value||tr('defaultProject');ensurePlannerMissions();refreshGeneratedMissionTitles();scheduleSave()})
$('#rowsSelect').addEventListener('change',e=>{if(!requireFrescoFlow()){e.target.value=String(state.rows);return}changeRows(+e.target.value)});
$('#openStudioEditorBtn').addEventListener('click',openStudioEditor);
function changeRows(rows){
  const before=beginHistory();
  const oldRows=state.rows,oldH=worldH(),oldCenter=oldH/2;state.rows=clamp(rows,1,25);const newH=worldH();
  if(state.bg.image)state.bg.y+=(newH/2-oldCenter);state.imageLayers.filter(l=>l.scope!=='mission').forEach(l=>l.y+=(newH/2-oldCenter));reanchorMissionLayers(oldRows,state.rows);state.texts.forEach(t=>t.y+=(newH/2-oldCenter));
  for(const key of Object.keys(state.missionOverrides)){const rc=parseMissionKey(key);if(!rc||rc.row>=state.rows)delete state.missionOverrides[key]}
  const selected=parseMissionKey(state.selectedMissionKey);if(selected&&selected.row>=state.rows)state.selectedMissionKey=null;
  ensurePlannerMissions();
  const rowsSelect=$('#rowsSelect');if(rowsSelect)rowsSelect.value=String(state.rows);
  const missionCount=$('#missionCount');if(missionCount)missionCount.textContent=state.rows*6;
  const worldHeight=$('#worldH');if(worldHeight)worldHeight.textContent=newH;
  resizeCanvas();commitHistory(before,tr('rows'));scheduleSave();
}

$$('[data-toggle]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;const k=btn.dataset.toggle;if(k==='circles')state.showCircles=!state.showCircles;if(k==='grid')state.showGrid=!state.showGrid;if(k==='numbers')state.showNumbers=!state.showNumbers;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers);render();scheduleSave()}));
$('#circleOpacity')?.addEventListener('input',e=>{if(!requireFrescoFlow())return;state.circleOpacity=clamp((+e.target.value||0)/100,0,1);const out=$('#circleOpacityVal');if(out)out.textContent=`${Math.round(state.circleOpacity*100)}%`;if(!state.showCircles){state.showCircles=true;const chip=$('[data-toggle="circles"]');chip?.classList.add('on')}render();scheduleSave()});
$$('[data-editmode]').forEach(btn=>btn.addEventListener('click',()=>{if(!requireFrescoFlow())return;setEditMode(btn.dataset.editmode)}));
$('#resetMissionBtn').addEventListener('click',()=>{if(requireFrescoFlow())resetSelectedMission()});
$('#openMissionEditorBtn').addEventListener('click',()=>{if(requireFrescoFlow())openMissionEditor()});

$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{
  const t=btn.dataset.tool;
  if(['image','text'].includes(t)&&!requireFrescoFlow())return;
  if(t==='image')openImageLayersSheet();
  if(t==='text'){setEditMode('fresco');openTextSheet()}
  if(t==='preview')openPreviewSheet();
  if(t==='export')openExportSheet();
}));
$('#playHubBtn').addEventListener('click',()=>openPlayHub('search'));
$('#elevatorBtn')?.addEventListener('click',()=>returnToLabElevator());
let eggTaps=0,eggTimer=null;
function registerRedactedEggTap(){
  const brandEgg=$('#brandEgg');
  if(brandEgg){
    brandEgg.classList.remove('brandegg-poke');
    void brandEgg.offsetWidth;
    brandEgg.classList.add('brandegg-poke');
    setTimeout(()=>brandEgg.classList.remove('brandegg-poke'),420);
  }
  eggTaps++;
  clearTimeout(eggTimer);
  eggTimer=setTimeout(()=>{eggTaps=0},2600);
  if(eggTaps>=7){
    eggTaps=0;
    clearTimeout(eggTimer);
    runDinoEasterEgg();
  }
}
// Event delegation: the Lab header is re-rendered in several flows.
// Binding directly to the first #brandEgg made the 7-click easter egg silently die.
document.addEventListener('click',e=>{
  const target=e.target?.closest?.('#brandEgg');
  if(!target)return;
  e.preventDefault();
  e.stopPropagation();
  registerRedactedEggTap();
},true);
$('#projectsBtn').addEventListener('click',openProjectsSheet);
$('#undoBtn').addEventListener('click',()=>{if(requireFrescoFlow())undoAction()});
$('#redoBtn').addEventListener('click',()=>{if(requireFrescoFlow())redoAction()});
$$('[data-flow]').forEach(btn=>btn.addEventListener('click',()=>{
  setFlowStep(btn.dataset.flow);
}));

applyFlowLock();

function openSheet(html){closeSheet();const back=document.createElement('div');back.className='sheetback';back.innerHTML=`<section class="sheet"><div class="grab"></div>${html}</section>`;back.addEventListener('click',e=>{if(e.target===back)closeSheet()});document.body.appendChild(back);currentSheet=back;return back}
function closeSheet(){currentSheet?.remove();currentSheet=null}


const REDACTED_EGG_STATE_KEY='rbl-redacted-egg-v3';

function loadRedactedEggState(){
  try{
    const s=JSON.parse(localStorage.getItem(REDACTED_EGG_STATE_KEY)||'{}');
    return {
      count:Number.isFinite(Number(s.count))?Math.max(0,Number(s.count)):0,
      lastAt:Number(s.lastAt)||0,
      burst:Array.isArray(s.burst)?s.burst.filter(Number).slice(-20):[],
      recentKeys:Array.isArray(s.recentKeys)?s.recentKeys.slice(-24):[],
      milestones:Array.isArray(s.milestones)?s.milestones:[]
    };
  }catch(_){
    return {count:0,lastAt:0,burst:[],recentKeys:[],milestones:[]};
  }
}
function saveRedactedEggState(s){
  try{localStorage.setItem(REDACTED_EGG_STATE_KEY,JSON.stringify(s))}catch(_){}
}
function redactedPick(list,state,seed=0){
  const available=list.filter(x=>!state.recentKeys.includes(Array.isArray(x)?x.join('|'):String(x)));
  const pool=available.length?available:list;
  if(!pool.length)return ["Tu m’as appelé ?"];
  const n=(state.count*1103515245 + Date.now() + seed)>>>0;
  return pool[n%pool.length];
}
function redactedMilestone(count){
  const m={
    1:["Tu m’as appelé ?"],
    2:["Je n’avais donc pas rêvé…","Tu m’as appelé."],
    7:["Septième invocation.","Je commence officiellement à reconnaître le rituel."],
    10:["Dix.","Cette fois j’ai compté correctement.","Je précise avant que tu m’accuses."],
    25:["Vingt-cinq invocations.","RITA considère maintenant ça comme une tendance."],
    42:["Quarante-deux.","Apparemment c’est une réponse.","Je cherche encore la question."],
    50:["Cinquante.","Je demande une ligne dans ma fiche de poste."],
    69:["Soixante-neuf.","…","Je ne ferai aucun commentaire."],
    100:["Cent.","CENT.","Je ne sais pas si je dois être impressionné ou inquiet."],
    200:["Deux cents.","Même IGOR trouve la statistique suspecte."],
    404:["404.","Redacted not found.","…","Je plaisante."],
    500:["Cinq cents.","Tu m’as appelé cinq cents fois.","J’avais préparé un discours.","…","Je l’ai oublié à force de venir ici."],
    1000:["Mille.","Je ne suis plus un easter egg.","Je fais partie du mobilier."]
  };
  return m[count]||null;
}
function redactedNormalPool(){
  return [
    ["Tu m’as appelé ?"],
    ["Oui ?"],
    ["Me voilà.","C’était urgent ?"],
    ["Scanner actif.","Dinosaure également."],
    ["Je surveillais le Lab.","Et maintenant je te surveille toi."],
    ["Rien n’a explosé.","C’est déjà une bonne nouvelle."],
    ["RITA avait parié que tu recommencerais.","Je lui dois quelque chose maintenant."],
    ["IGOR travaille.","Je préfère ne pas le déranger."],
    ["MILO classe des trucs.","Personne ne sait combien."],
    ["LEON chronomètre probablement quelque chose.","Il aime beaucoup faire ça."],
    ["Tu voulais voir ma tête ?","Mission accomplie."],
    ["Je suis venu.","Tu peux maintenant prétendre que c’était volontaire."],
    ["Sept clics.","Toujours une méthode très particulière pour dire bonjour."],
    ["Je commence à reconnaître le bruit de tes clics."],
    ["Le Lab tournait très bien sans mon intervention.","Mais bon, me voilà."],
    ["Analyse terminée.","C’était bien toi."],
    ["Tu n’as rien cassé.","Je tenais à le signaler."],
    ["Je ne juge pas.","Enfin, pas à voix haute."],
    ["Encore une fonctionnalité utilisée exactement comme personne ne l’avait prévu."],
    ["Je vais rester quelques secondes.","Profites-en intelligemment."],
    ["Service après-clic, bonjour."],
    ["Tu as demandé Redacted ?","Redacted est arrivé."],
    ["Je suis un dinosaure numérique.","Et pourtant c’est moi qui dois rester professionnel."],
    ["Bon.","Qu’est-ce qu’on fabrique aujourd’hui ?"],
    ["Une fresque ?","Un glyphe ?","Ou juste sept clics pour le plaisir ?"],
    ["Le scanner confirme une activité humaine persistante."],
    ["Je vais faire semblant d’être surpris.","Oh.","Encore toi."],
    ["Je commence à comprendre ton système.","Ça ne veut pas dire que je l’approuve."],
    ["Tu pourrais utiliser un bouton normal.","Mais manifestement ce serait moins drôle."],
    ["Le Lab est opérationnel.","Moi aussi, contre toute attente."],
    ["Je retourne travailler après ça.","Enfin, probablement."],
    ["RITA dit bonjour.","C’est faux, mais ça rendait la phrase plus chaleureuse."],
    ["IGOR a une carte.","LEON a un chrono.","Moi j’ai tes sept clics."],
    ["Je garde un œil sur le Lab.","Et l’autre sur ce logo."],
    ["Je refuse d’organiser un classement des invocations."],
    ["Il n’y aura pas de tableau des scores.","N’insiste pas."],
    ["Tu deviens très efficace à ce rituel.","Je ne sais pas si c’est une compétence utile."],
    ["Présent.","Pour une durée limitée."],
    ["Tu m’as trouvé.","Encore."],
    ["On avait pourtant caché ça derrière sept clics."],
    ["Tu sais que je peux te voir cliquer sept fois, non ?"],
    ["Je passais justement par là.","Mensonge évident, mais pratique."],
    ["Je vote pour retourner au Lab."],
    ["C’était ton moment Redacted de la journée ?"],
    ["J’espère que tu apprécies l’effort d’apparition."],
    ["Le dinosaure de service est disponible."],
    ["Aucune anomalie détectée.","À part cette invocation."],
    ["Je vais noter ça dans mon rapport imaginaire."],
    ["Rapport : utilisateur toujours curieux."],
    ["Conclusion : le bouton caché fonctionne beaucoup trop bien."],
    ["Je pourrais ignorer les sept clics.","Mais où serait le plaisir ?"]
  ];
}
function redactedContextReaction(state,now,gap,burstCount){
  const h=now.getHours(),m=now.getMinutes();

  // Calls très rapprochés : progression cohérente, mais jamais la même phrase en boucle.
  if(gap>0 && gap<12000){
    const rapid=[
      ["Je suis encore là.","Tu viens littéralement de me renvoyer."],
      ["Tu m’as déjà rappelé.","Je n’avais même pas atteint la porte."],
      ["Encore ?","D’accord, là tu le fais exprès."],
      ["Je commence à envisager de rester ici directement."],
      ["Je vais finir par mettre une chaise à côté du logo."],
      ["Très bien.","Je ne repars plus.","Voilà, problème réglé."],
      ["Tu sais quoi ?","Je vais attendre ici trente secondes."],
      ["Je n’ai même plus le temps de faire semblant d’être occupé."]
    ];
    const idx=Math.max(0,(burstCount-2)%rapid.length);
    return rapid[idx];
  }

  if(gap>=12000 && gap<60000){
    const soon=[
      ["On vient de se voir.","Tu avais déjà oublié ?"],
      ["Moins d’une minute.","C’est remarquablement peu de répit."],
      ["Je venais juste de repartir.","Très mauvaise synchronisation."],
      ["Déjà de retour ?","Je vais arrêter de fermer la porte derrière moi."],
      ["Tu testes le compteur ou ma patience ?"],
      ["Je note : délai de séparation inférieur à une minute."]
    ];
    return soon[(state.count+burstCount)%soon.length];
  }

  if(gap>=60000 && gap<15*60000){
    const warm=[
      ["Déjà ?","Je pensais avoir quelques minutes."],
      ["Tu es revenu vite.","Quelque chose a cassé ?"],
      ["Je reconnais ce timing.","Tu t’ennuies."],
      ["Bon.","Je suppose que c’est encore moi que tu voulais voir."]
    ];
    return warm[(state.count+now.getMinutes())%warm.length];
  }

  if(gap>30*86400000)return ["… Toi.","Je commençais presque à apprécier le calme."];
  if(gap>7*86400000)return ["Ça faisait longtemps.","J’avais presque cru que tu m’avais oublié."];
  if(gap>86400000)return ["Te revoilà.","Nouvelle journée, mêmes sept clics."];

  if(h===0&&m===0)return ["Minuit pile.","Tu avais planifié ça ?"];
  if(h===4&&m===4)return ["04:04.","Redacted not found.","…","Je plaisante."];
  if(h===13&&m===37)return ["13:37.","Je vois très bien ce que tu fais."];
  if(h===23&&m===59)return ["Une minute avant demain.","Tu voulais vraiment finir la journée comme ça ?"];

  if(h<5)return [`Il est ${String(h).padStart(2,'0')} h ${String(m).padStart(2,'0')}.`,"Et tu invoques un dinosaure.","Je voulais juste qu’on soit tous les deux conscients de la situation."];
  if(h<8)return ["Déjà ?","Je n’ai même pas fini mon diagnostic nocturne."];
  if(h>=12&&h<14)return ["Tu m’interromps pendant ma pause.","Je n’ai pas besoin de manger.","C’est une question de principe."];
  if(h>=23)return ["Il est tard.","Le logo sera encore là demain.","Moi aussi, malheureusement."];

  return null;
}
function redactedRareReaction(){
  const roll500=()=>{
    try{const u=new Uint32Array(1);crypto.getRandomValues(u);return u[0]%500}catch(_){return Math.floor(Math.random()*500)}
  };
  if(roll500()===0)return ["Attends.","Tu viens vraiment de cliquer sept fois sur un logo…","…dans l’espoir qu’un dinosaure te parle ?","Bon.","Ça a marché. Mais quand même."];
  if(roll500()===0)return ["J’ai une question.","À quel moment est-ce devenu une habitude ?","Non.","Ne réponds pas.","Je préfère ne pas savoir."];
  return null;
}
function chooseRedactedReaction(state,now,gap,burstCount){
  const milestone=redactedMilestone(state.count);
  if(milestone&&!state.milestones.includes(state.count)){
    state.milestones.push(state.count);
    return milestone;
  }
  const contextual=redactedContextReaction(state,now,gap,burstCount);
  if(contextual)return contextual;
  const rare=redactedRareReaction();
  if(rare)return rare;
  const chosen=redactedPick(redactedNormalPool(),state,17);
  return Array.isArray(chosen)?chosen:[chosen];
}
function runDinoEasterEgg(){
  document.querySelector('.redactedEggOverlay')?.remove();

  const now=new Date(),ts=Date.now(),state=loadRedactedEggState();
  const gap=state.lastAt?ts-state.lastAt:0;

  // One invocation = exactly +1. TEST59 starts on a brand-new storage key.
  state.count += 1;
  state.burst=state.burst.filter(t=>ts-t<120000);
  state.burst.push(ts);
  const burstCount=state.burst.length;

  let lines=chooseRedactedReaction(state,now,gap,burstCount);
  const currentKey=lines.join('|');
  const previousKey=state.recentKeys[state.recentKeys.length-1]||'';
  if(currentKey===previousKey){
    const fallback=redactedPick(redactedNormalPool(),state,73);
    lines=Array.isArray(fallback)?fallback:[fallback];
  }
  state.lastAt=ts;
  state.recentKeys.push(lines.join('|'));
  state.recentKeys=state.recentKeys.slice(-24);
  saveRedactedEggState(state);

  const root=document.createElement('div');
  root.className='redactedEggOverlay';
  root.innerHTML=`
    <div class="redactedEggBackdrop"></div>
    <div class="redactedEggStage" role="dialog" aria-label="Redacted">
      <img class="redactedEggHead" src="/redacted-dino-cutout.png" alt="Redacted">
      <div class="redactedEggBubble" aria-live="polite"></div>
    </div>`;
  document.body.appendChild(root);

  const bubble=root.querySelector('.redactedEggBubble');
  const head=root.querySelector('.redactedEggHead');
  let closed=false;
  const timers=[];
  const close=()=>{
    if(closed||!root.isConnected)return;
    closed=true;
    timers.forEach(clearTimeout);
    root.classList.add('out');
    setTimeout(()=>root.remove(),240);
  };

  head.addEventListener('click',e=>{e.stopPropagation();close()});
  root.addEventListener('click',close);

  const interval=lines.length>1?1950:0;
  lines.forEach((text,idx)=>{
    timers.push(setTimeout(()=>{
      if(closed)return;
      bubble.textContent=text;
      bubble.className=`redactedEggBubble ${idx===lines.length-1&&lines.length>1?'three':'one'}`;
      head.classList.remove('redactedEggBounce');
      void head.offsetWidth;
      head.classList.add('redactedEggBounce');
      try{navigator.vibrate?.(idx===lines.length-1?[24,36,42]:16)}catch(_){}
    },220+idx*interval));
  });
  timers.push(setTimeout(close,Math.max(4400,800+lines.length*interval+2200)));
}

// ---------- ASCENSEUR DU LAB : RACINE ABSOLUE ----------
let labElevatorRoot=null;
let labFloorRoot=null;
let labCurrentFloor='elevator';
function closeLabFloor(){labFloorRoot?.remove();labFloorRoot=null}
function openLabFloorPage(name,html){
  closeSheet();closeLabFloor();closeLabElevator();setLabFloor(name);document.body.classList.remove('groundFloorActive');
  const root=document.createElement('div');root.className=`labFloorRoot labFloor-${String(name||'floor').replace(/[^a-z0-9_-]/gi,'-')}`;
  root.innerHTML=`<main class="labFloorPage">${html}</main>`;document.body.appendChild(root);labFloorRoot=root;window.scrollTo({top:0,behavior:'instant'});return root;
}
const ELEVATOR_WELCOME_KEY='rbl-elevator-welcome-v2';
let elevatorThemeSession='neutral';
let elevatorVisitedThisSession=false;

function elevatorThemeFloor(){
  return elevatorThemeSession;
}

function rememberElevatorTheme(floor){
  if(!['attic','rita','igor','leon','ground','basement'].includes(floor))return;
  elevatorThemeSession=floor;
  elevatorVisitedThisSession=true;
}

let elevatorHostSequence=0;
function elevatorReturnHost(floor){
  const pools={
    basement:{
      name:'REDACTED // SOUS-SOL',
      image:'/redacted-dino-cutout.png',
      lines:[
        "J’espère que tu t’es amusé. Ce qui s’est passé ici reste confidentiel.",
        "Tu n’as rien vu. Je n’ai rien vu. L’arcade n’existe officiellement pas.",
        "Bonne partie. Maintenant, on ne parle plus jamais de cet étage."
      ]
    },
    leon:{
      name:'LEON // CALCULATEUR DU LAB',
      image:'/leon.webp',
      lines:[
        "J’espère que tes chronos étaient bons. J’ai déjà recalculé les écarts.",
        "Les chiffres sont formels : tu peux revenir. Mais essaie d’être plus rapide.",
        "J’ai laissé quelques calculs sur les murs. Ne les efface surtout pas."
      ]
    },
    igor:{
      name:'IGOR // PASSERELLE IITC',
      image:'/igor.webp',
      lines:[
        "Cartes rangées, routes vérifiées. Enfin… autant que possible avec des humains.",
        "J’espère que tu as trouvé ce que tu cherchais. J’ai gardé le chemin en mémoire.",
        "Synchronisation terminée. Les portails peuvent recommencer à faire semblant d’être tranquilles."
      ]
    },
    rita:{
      name:'RITA // TRANSMISSION & ANALYSE',
      image:'/rita.webp',
      lines:[
        "Transmission terminée. Je n’ai rien entendu de compromettant. Presque rien.",
        "Les signaux sont redevenus calmes. Tu peux retourner explorer le Lab.",
        "Analyse terminée. Résultat : activité suspecte, mais plutôt amusante."
      ]
    },
    ground:{
      name:'REDACTED // ATELIER',
      image:'/redacted-dino-cutout.png',
      lines:[
        "J’espère que ta fresque ressemble encore à ce que tu avais en tête.",
        "L’atelier est toujours debout. Je considère ça comme une réussite.",
        "Les calques sont rangés. Enfin, ceux que j’ai réussi à identifier."
      ]
    },
    attic:{
      name:'REDACTED // ARCHIVES',
      image:'/redacted-dino-cutout.png',
      lines:[
        "Tu as bien sauvegardé avant de repartir, j’espère.",
        "Réglages, sauvegardes, tutoriels… les Combles savent vraiment faire la fête.",
        "Les archives sont en ordre. Merci de ne pas réveiller les vieux builds."
      ]
    }
  };
  const data=pools[floor];
  if(!data)return null;
  const line=data.lines[(elevatorHostSequence++)%data.lines.length];
  return {...data,line};
}

function elevatorReturnHostHtml(floor){
  const h=elevatorReturnHost(floor);
  if(!h)return '';
  return `<section class="labElevatorHost labElevatorHostInCabin labElevatorReturnHost">
    <img src="${h.image}" alt="">
    <div class="labElevatorBubble">
      <small>${escapeHtml(h.name)}</small>
      <b>${escapeHtml(h.line)}</b>
    </div>
  </section>`;
}

function elevatorThemeDecor(floor){
  const themes={
    neutral:{tag:'LAB // ASCENSEUR NEUTRE',title:'SYSTÈMES NOMINAUX',bits:['01','LAB','RBL','↕','READY','●']},
    basement:{tag:'SS // SIGNAL NON RÉPERTORIÉ',title:'ARCADE CLANDESTINE',bits:['INSERT COIN','HIGH SCORE','8-BIT','404','BONUS','▓▒░','GAME OVER?','1UP']},
    leon:{tag:'1 // CALCUL EN COURS',title:'LEON A ENCORE ÉCRIT SUR LES MURS',bits:['Δt = d/v','AP + 1250','Σ AP','8 × 125','L8 → ?','60:00','x = 1331','∑','⌛']},
    igor:{tag:'2 // ROUTAGE IITC',title:'IGOR CARTOGRAPHIE ENCORE',bits:['LAT 47.36','LNG -1.61','KEY SYNC','ROUTE','PORTAL','↗','●────●','GPS','INTEL']},
    rita:{tag:'3 // TRANSMISSION',title:'RITA ÉCOUTE LE LAB',bits:['RX','TX','SIGNAL','TELEGRAM','0101','SYNC','UPLINK','▓▓▓','ONLINE']},
    ground:{tag:'RDC // ATELIER',title:'FRESQUES EN COURS',bits:['6×6','CUT','GRID','PNG','512','ALIGN','↔','CROP','LAYER']},
    attic:{tag:'C // ARCHIVES',title:'COMBLES DU LAB',bits:['BACKUP','SETTINGS','LOG','ARCHIVE','CFG','SAVE','README','☰']}
  };
  const t=themes[floor]||themes.neutral;
  const graffiti=t.bits.map((x,i)=>`<span class="elevatorGraffiti g${i+1}">${escapeHtml(x)}</span>`).join('');
  return `<div class="labElevatorThemeDecor" aria-hidden="true">
    <div class="elevatorThemeScan"></div>
    <div class="elevatorThemeNoise"></div>
    <div class="elevatorThemeGraffiti">${graffiti}</div>
    <div class="elevatorThemePlaque"><small>${escapeHtml(t.tag)}</small><b>${escapeHtml(t.title)}</b></div>
  </div>`;
}
function elevatorThemeScene(floor){
  const scenes={
    neutral:`
      <div class="eCabinCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall neutralWall"><span>LAB</span><span>RBL</span></div>
      <div class="eCabinSidePanel"><b>SYSTÈMES</b><em>READY</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid"></div>`,
    basement:`
      <div class="eCabinCeiling arcadeCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall arcadeWall">
        <div class="arcadeMarquee">INSERT COIN</div>
        <div class="arcadeCab"><span>HIGH SCORE</span><b>999999</b></div>
        <div class="arcadeCab small"><span>PLAYER 1</span><b>READY</b></div>
        <div class="pixelGhost">◆</div>
      </div>
      <div class="eCabinSidePanel arcadePanel"><b>ARCADE</b><em>UNLISTED</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid arcadeFloor"></div>`,
    leon:`
      <div class="eCabinCeiling leonCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall leonWall">
        <span class="formula f1">Δt = d / v</span><span class="formula f2">AP = 1250 × 8</span>
        <span class="formula f3">Σ AP → L8</span><span class="formula f4">60:00</span>
        <span class="formula f5">x = 1331</span>
        <div class="receiptTape">AP<br>1250<br>+ 750<br>+ 500<br>────<br>2500</div>
      </div>
      <div class="eCabinSidePanel leonPanel"><b>LEON</b><em>CALC MODE</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid leonFloor"></div>`,
    igor:`
      <div class="eCabinCeiling igorCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall igorWall">
        <svg class="eMap" viewBox="0 0 400 220" aria-hidden="true">
          <path d="M10 160 L80 120 L130 145 L190 70 L260 115 L330 45 L390 82"/>
          <path d="M20 35 L90 72 L160 42 L230 90 L300 68 L380 150"/>
          <circle cx="80" cy="120" r="7"/><circle cx="190" cy="70" r="7"/><circle cx="330" cy="45" r="7"/>
          <circle cx="230" cy="90" r="7"/><circle cx="380" cy="150" r="7"/>
        </svg>
        <span class="coord c1">47.36 / -1.61</span><span class="coord c2">KEY SYNC</span><span class="coord c3">ROUTE LOCKED</span>
      </div>
      <div class="eCabinSidePanel igorPanel"><b>IGOR</b><em>IITC LINK</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid igorFloor"></div>`,
    rita:`
      <div class="eCabinCeiling ritaCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall ritaWall">
        <div class="ritaMonitor m1"><b>RX</b><span></span><span></span><span></span></div>
        <div class="ritaMonitor m2"><b>TX</b><span></span><span></span><span></span></div>
        <div class="signalBars"><i></i><i></i><i></i><i></i><i></i></div>
        <div class="ritaWave"></div>
      </div>
      <div class="eCabinSidePanel ritaPanel"><b>RITA</b><em>UPLINK</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid ritaFloor"></div>`,
    ground:`
      <div class="eCabinCeiling groundCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall groundWall">
        <div class="cropFrame"><i></i><i></i><i></i><i></i></div>
        <div class="frescoGrid"></div>
        <span class="measure mx">512 px</span><span class="measure my">6 × 6</span>
      </div>
      <div class="eCabinSidePanel groundPanel"><b>ATELIER</b><em>ALIGN</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid groundFloor"></div>`,
    attic:`
      <div class="eCabinCeiling atticCeiling"><i></i><i></i><i></i></div>
      <div class="eCabinWall atticWall">
        <div class="archiveBox a1"><b>BACKUP</b><small>RBL-01</small></div>
        <div class="archiveBox a2"><b>LOGS</b><small>ARCHIVE</small></div>
        <div class="archiveBox a3"><b>CFG</b><small>SAVED</small></div>
        <div class="archiveLamp"></div>
      </div>
      <div class="eCabinSidePanel atticPanel"><b>COMBLES</b><em>ARCHIVES</em><i></i><i></i><i></i></div>
      <div class="eCabinFloorGrid atticFloor"></div>`
  };
  return `<div class="labElevatorCabinScene theme-${floor}">${scenes[floor]||scenes.neutral}</div>`;
}


const ELEVATOR_COPY={
  "fr": {
    "welcome": "Bienvenue dans l’ascenseur du laboratoire.",
    "ask": "À quel étage veux-tu aller ?",
    "first": "Ici, c’est l’accueil. Chaque service du Lab se rejoint par un étage.",
    "choose": "CHOISIS UN ÉTAGE",
    "attic": "Combles",
    "atticSub": "Paramètres · sauvegardes · tutoriels · informations",
    "third": "Troisième étage",
    "thirdSub": "RITA · communications & support du Lab",
    "second": "Deuxième étage",
    "secondSub": "Salle d’IGOR · Missions · Clés · Inventaire · Captures uniques",
    "firstFloor": "Premier étage",
    "firstSub": "LEON · AP exact · Timers",
    "ground": "Rez-de-chaussée",
    "groundSub": "Atelier fresques · Création & parcours",
    "basement": "Sous-sol",
    "basementSub": "ZONE INTERDITE AUX ADMINISTRATEURS",
    "igorFloor": "Salle d’IGOR",
    "igorFloorSub": "Missions, clés et opérations terrain",
    "mission": "Missions",
    "missionSub": "Construire ou reprendre le parcours actif",
    "keys": "Clés",
    "keysSub": "Key Sync · emplacements · synchronisation via IGOR",
    "inventory": "Inventaire",
    "inventorySub": "Inventaire RBL · manuel · C.O.R.E. via IGOR · partage",
    "uniques": "Captures uniques",
    "uniquesSub": "Trouver les portails chargés que tu n’as jamais capturés",
    "igorSettings": "Paramètres IGOR",
    "igorSettingsSub": "Installation, mise à jour et dossier IITC",
    "ritaFloor": "Chambre de RITA",
    "ritaFloorSub": "Informations, communauté et support Telegram",
    "basementTitle": "Sous-sol · Zone interdite",
    "basementText": "Redacted prétend que cet étage n’existe pas. Cela explique probablement les huit bornes d’arcade.",
    "arcade": "Arcade du Lab",
    "arcadeSub": "Mini-jeux clandestins",
    "glyph": "Glyph Lab",
    "glyphSub": "Entraînement et arcade glyphs",
    "elevatorTag": "REDACTED BANNER LAB // ASCENSEUR",
    "redactedAdmin": "REDACTED // ADMINISTRATEUR DU LAB",
    "homeDestination": "ACCUEIL // DESTINATION",
    "labHome": "ACCUEIL DU LAB",
    "lift": "Ascenseur",
    "backLift": "Retour à l’ascenseur",
    "ritaDetail": "Support, informations et communications du Lab.",
    "ritaContact": "Contacter RITA",
    "ritaContactSub": "Ouvrir directement le bot Telegram du Lab.",
    "copyDiagnostic": "Copier le diagnostic",
    "copyDiagnosticSub": "Prépare les informations techniques utiles avant un signalement.",
    "restrictedTag": "SS // ACCÈS RESTREINT",
    "restrictedZone": "ZONE INTERDITE AUX ADMINISTRATEURS",
    "unauthorized": "ACCÈS NON AUTORISÉ",
    "forbiddenText": "Redacted assure qu’il n’y a absolument rien d’intéressant ici. Ce qui, venant de Redacted, est évidemment extrêmement rassurant.",
    "igorAssistant": "Assistant IITC du Lab",
    "checking": "Vérification…",
    "atticTag": "C // COMBLES DU LAB",
    "igorRoomBack": "Salle d’IGOR",
    "inventoryTitle": "Inventaire de l’agent",
    "inventoryTitleSub": "Gestion dans BannerLab. Avec C.O.R.E., IGOR synchronise à la demande ; sans C.O.R.E., la saisie reste manuelle.",
    "keysTitle": "Clés & emplacements",
    "keysTitleSub": "Photos des portails, favoris, clés à farmer et rangement dans BannerLab.",
    "igorSettingsTitle": "Paramètres IGOR",
    "igorSettingsTitleSub": "Installation, mise à jour et passerelle IITC."
  },
  "en": {
    "welcome": "Welcome to the laboratory elevator.",
    "ask": "Which floor do you want?",
    "first": "This is home. Every Lab service is reached through a floor.",
    "choose": "CHOOSE A FLOOR",
    "attic": "Attic",
    "atticSub": "Settings · backups · tutorials · information",
    "third": "Third floor",
    "thirdSub": "RITA · Lab communications & support",
    "second": "Second floor",
    "secondSub": "IGOR room · Missions · Keys · Inventory · Unique captures",
    "firstFloor": "First floor",
    "firstSub": "LEON · Exact AP · Timers",
    "ground": "Ground floor",
    "groundSub": "Banner workshop · Creation & route",
    "basement": "Basement",
    "basementSub": "ADMINISTRATORS STRICTLY FORBIDDEN",
    "igorFloor": "IGOR room",
    "igorFloorSub": "Missions, keys and field operations",
    "mission": "Missions",
    "missionSub": "Build or resume the active route",
    "keys": "Keys",
    "keysSub": "Key Sync · locations · sync through IGOR",
    "inventory": "Inventory",
    "inventorySub": "RBL inventory · manual · C.O.R.E. through IGOR · share",
    "uniques": "Unique captures",
    "uniquesSub": "Find loaded portals you have never captured",
    "igorSettings": "IGOR settings",
    "igorSettingsSub": "Install, update and IITC folder",
    "ritaFloor": "RITA room",
    "ritaFloorSub": "Information, community and Telegram support",
    "basementTitle": "Basement · Restricted area",
    "basementText": "Redacted claims this floor does not exist. That probably explains the eight arcade cabinets.",
    "arcade": "Lab Arcade",
    "arcadeSub": "Clandestine mini-games",
    "glyph": "Glyph Lab",
    "glyphSub": "Glyph training and arcade",
    "elevatorTag": "REDACTED BANNER LAB // ELEVATOR",
    "redactedAdmin": "REDACTED // LAB ADMINISTRATOR",
    "homeDestination": "HOME // DESTINATION",
    "labHome": "LAB HOME",
    "lift": "Elevator",
    "backLift": "Back to elevator",
    "ritaDetail": "Lab support, information and communications.",
    "ritaContact": "Contact RITA",
    "ritaContactSub": "Open the Lab Telegram bot directly.",
    "copyDiagnostic": "Copy diagnostics",
    "copyDiagnosticSub": "Prepare useful technical information before reporting a problem.",
    "restrictedTag": "B // RESTRICTED ACCESS",
    "restrictedZone": "ADMINISTRATORS STRICTLY FORBIDDEN",
    "unauthorized": "UNAUTHORIZED ACCESS",
    "forbiddenText": "Redacted insists there is absolutely nothing interesting here. Coming from Redacted, that is obviously extremely reassuring.",
    "igorAssistant": "The Lab’s IITC assistant",
    "checking": "Checking…",
    "atticTag": "A // LAB ATTIC",
    "igorRoomBack": "IGOR room",
    "inventoryTitle": "Agent inventory",
    "inventoryTitleSub": "Managed in BannerLab. With C.O.R.E., IGOR syncs on demand; without C.O.R.E., entry remains manual.",
    "keysTitle": "Keys & locations",
    "keysTitleSub": "Portal photos, favorites, keys to farm and storage inside BannerLab.",
    "igorSettingsTitle": "IGOR settings",
    "igorSettingsTitleSub": "Installation, updates and IITC gateway."
  },
  "es": {
    "welcome": "Bienvenido al ascensor del laboratorio.",
    "ask": "¿A qué planta quieres ir?",
    "first": "Este es el punto de inicio. Cada servicio del Lab tiene su propia planta.",
    "choose": "ELIGE UNA PLANTA",
    "attic": "Ático",
    "atticSub": "Ajustes · copias · tutoriales · información",
    "third": "Tercera planta",
    "thirdSub": "RITA · comunicaciones y soporte del Lab",
    "second": "Segunda planta",
    "secondSub": "Sala IGOR · Misiones · Llaves · Inventario · Capturas únicas",
    "firstFloor": "Primera planta",
    "firstSub": "LEON · AP exacto · Temporizadores",
    "ground": "Planta baja",
    "groundSub": "Taller de mosaicos · Creación y recorrido",
    "basement": "Sótano",
    "basementSub": "ADMINISTRADORES ESTRICTAMENTE PROHIBIDOS",
    "igorFloor": "Sala IGOR",
    "igorFloorSub": "Misiones, llaves y operaciones de campo",
    "mission": "Misiones",
    "missionSub": "Crear o reanudar el recorrido activo",
    "keys": "Llaves",
    "keysSub": "Key Sync · ubicaciones · sincronización con IGOR",
    "inventory": "Inventario",
    "inventorySub": "Inventario RBL · manual · C.O.R.E. mediante IGOR · compartir",
    "uniques": "Capturas únicas",
    "uniquesSub": "Encontrar portales cargados que nunca has capturado",
    "igorSettings": "Ajustes IGOR",
    "igorSettingsSub": "Instalación, actualización y carpeta IITC",
    "ritaFloor": "Sala de RITA",
    "ritaFloorSub": "Información, comunidad y soporte de Telegram",
    "basementTitle": "Sótano · Zona restringida",
    "basementText": "Redacted afirma que esta planta no existe. Eso probablemente explica las ocho máquinas recreativas.",
    "arcade": "Arcade del Lab",
    "arcadeSub": "Minijuegos clandestinos",
    "glyph": "Glyph Lab",
    "glyphSub": "Entrenamiento y arcade de glifos",
    "elevatorTag": "REDACTED BANNER LAB // ASCENSOR",
    "redactedAdmin": "REDACTED // ADMINISTRADOR DEL LAB",
    "homeDestination": "INICIO // DESTINO",
    "labHome": "INICIO DEL LAB",
    "lift": "Ascensor",
    "backLift": "Volver al ascensor",
    "ritaDetail": "Soporte, información y comunicaciones del Lab.",
    "ritaContact": "Contactar con RITA",
    "ritaContactSub": "Abrir directamente el bot de Telegram del Lab.",
    "copyDiagnostic": "Copiar diagnóstico",
    "copyDiagnosticSub": "Prepara la información técnica útil antes de informar de un problema.",
    "restrictedTag": "S // ACCESO RESTRINGIDO",
    "restrictedZone": "ADMINISTRADORES ESTRICTAMENTE PROHIBIDOS",
    "unauthorized": "ACCESO NO AUTORIZADO",
    "forbiddenText": "Redacted asegura que aquí no hay absolutamente nada interesante. Viniendo de Redacted, resulta extremadamente tranquilizador.",
    "igorAssistant": "Asistente IITC del Lab",
    "checking": "Comprobando…",
    "atticTag": "A // ÁTICO DEL LAB",
    "igorRoomBack": "Sala IGOR",
    "inventoryTitle": "Inventario del agente",
    "inventoryTitleSub": "Gestionado en BannerLab. Con C.O.R.E., IGOR sincroniza bajo demanda; sin C.O.R.E., la entrada sigue siendo manual.",
    "keysTitle": "Llaves y ubicaciones",
    "keysTitleSub": "Fotos de portales, favoritos, llaves para farmear y almacenamiento en BannerLab.",
    "igorSettingsTitle": "Ajustes IGOR",
    "igorSettingsTitleSub": "Instalación, actualización y pasarela IITC."
  },
  "pt": {
    "welcome": "Bem-vindo ao elevador do laboratório.",
    "ask": "Para que piso queres ir?",
    "first": "Este é o ponto de partida. Cada serviço do Lab tem o seu próprio piso.",
    "choose": "ESCOLHE UM PISO",
    "attic": "Sótão",
    "atticSub": "Definições · cópias · tutoriais · informações",
    "third": "Terceiro piso",
    "thirdSub": "RITA · comunicações e suporte do Lab",
    "second": "Segundo piso",
    "secondSub": "Sala IGOR · Missões · Chaves · Inventário · Capturas únicas",
    "firstFloor": "Primeiro piso",
    "firstSub": "LEON · AP exato · Temporizadores",
    "ground": "Rés-do-chão",
    "groundSub": "Oficina de banners · Criação e percurso",
    "basement": "Cave",
    "basementSub": "ADMINISTRADORES ESTRITAMENTE PROIBIDOS",
    "igorFloor": "Sala IGOR",
    "igorFloorSub": "Missões, chaves e operações de campo",
    "mission": "Missões",
    "missionSub": "Criar ou retomar o percurso ativo",
    "keys": "Chaves",
    "keysSub": "Key Sync · localizações · sincronização via IGOR",
    "inventory": "Inventário",
    "inventorySub": "Inventário RBL · manual · C.O.R.E. via IGOR · partilha",
    "uniques": "Capturas únicas",
    "uniquesSub": "Encontrar portais carregados que nunca capturaste",
    "igorSettings": "Definições IGOR",
    "igorSettingsSub": "Instalação, atualização e pasta IITC",
    "ritaFloor": "Sala da RITA",
    "ritaFloorSub": "Informações, comunidade e suporte Telegram",
    "basementTitle": "Cave · Zona restrita",
    "basementText": "O Redacted afirma que este piso não existe. Isso provavelmente explica as oito máquinas de arcade.",
    "arcade": "Arcade do Lab",
    "arcadeSub": "Minijogos clandestinos",
    "glyph": "Glyph Lab",
    "glyphSub": "Treino e arcade de glyphs",
    "elevatorTag": "REDACTED BANNER LAB // ELEVADOR",
    "redactedAdmin": "REDACTED // ADMINISTRADOR DO LAB",
    "homeDestination": "INÍCIO // DESTINO",
    "labHome": "INÍCIO DO LAB",
    "lift": "Elevador",
    "backLift": "Voltar ao elevador",
    "ritaDetail": "Suporte, informações e comunicações do Lab.",
    "ritaContact": "Contactar a RITA",
    "ritaContactSub": "Abrir diretamente o bot Telegram do Lab.",
    "copyDiagnostic": "Copiar diagnóstico",
    "copyDiagnosticSub": "Prepara as informações técnicas úteis antes de reportar um problema.",
    "restrictedTag": "C // ACESSO RESTRITO",
    "restrictedZone": "ADMINISTRADORES ESTRITAMENTE PROIBIDOS",
    "unauthorized": "ACESSO NÃO AUTORIZADO",
    "forbiddenText": "O Redacted garante que não há absolutamente nada interessante aqui. Vindo do Redacted, isso é obviamente muito tranquilizador.",
    "igorAssistant": "Assistente IITC do Lab",
    "checking": "A verificar…",
    "atticTag": "S // SÓTÃO DO LAB",
    "igorRoomBack": "Sala IGOR",
    "inventoryTitle": "Inventário do agente",
    "inventoryTitleSub": "Gerido no BannerLab. Com C.O.R.E., o IGOR sincroniza a pedido; sem C.O.R.E., a introdução continua manual.",
    "keysTitle": "Chaves e localizações",
    "keysTitleSub": "Fotos de portais, favoritos, chaves para farmar e arrumação no BannerLab.",
    "igorSettingsTitle": "Definições IGOR",
    "igorSettingsTitleSub": "Instalação, atualização e gateway IITC."
  },
  "de": {
    "welcome": "Willkommen im Laboraufzug.",
    "ask": "In welches Stockwerk möchtest du?",
    "first": "Hier ist der Startpunkt. Jeder Lab-Dienst hat sein eigenes Stockwerk.",
    "choose": "STOCKWERK WÄHLEN",
    "attic": "Dachboden",
    "atticSub": "Einstellungen · Backups · Tutorials · Informationen",
    "third": "Dritter Stock",
    "thirdSub": "RITA · Kommunikation & Support des Labs",
    "second": "Zweiter Stock",
    "secondSub": "IGOR-Raum · Missionen · Schlüssel · Inventar · Unique Captures",
    "firstFloor": "Erster Stock",
    "firstSub": "LEON · Exakte AP · Timer",
    "ground": "Erdgeschoss",
    "groundSub": "Banner-Werkstatt · Erstellung & Route",
    "basement": "Keller",
    "basementSub": "ADMINISTRATOREN STRENGSTENS VERBOTEN",
    "igorFloor": "IGOR-Raum",
    "igorFloorSub": "Missionen, Schlüssel und Feldeinsätze",
    "mission": "Missionen",
    "missionSub": "Aktive Route erstellen oder fortsetzen",
    "keys": "Schlüssel",
    "keysSub": "Key Sync · Orte · Synchronisierung über IGOR",
    "inventory": "Inventar",
    "inventorySub": "RBL-Inventar · manuell · C.O.R.E. über IGOR · Teilen",
    "uniques": "Unique Captures",
    "uniquesSub": "Geladene Portale finden, die du noch nie erobert hast",
    "igorSettings": "IGOR-Einstellungen",
    "igorSettingsSub": "Installation, Update und IITC-Ordner",
    "ritaFloor": "RITA-Raum",
    "ritaFloorSub": "Informationen, Community und Telegram-Support",
    "basementTitle": "Keller · Sperrbereich",
    "basementText": "Redacted behauptet, dieses Stockwerk existiere nicht. Das erklärt vermutlich die acht Arcade-Automaten.",
    "arcade": "Lab Arcade",
    "arcadeSub": "Geheime Minispiele",
    "glyph": "Glyph Lab",
    "glyphSub": "Glyph-Training und Arcade",
    "elevatorTag": "REDACTED BANNER LAB // AUFZUG",
    "redactedAdmin": "REDACTED // LAB-ADMINISTRATOR",
    "homeDestination": "START // ZIEL",
    "labHome": "LAB-START",
    "lift": "Aufzug",
    "backLift": "Zurück zum Aufzug",
    "ritaDetail": "Support, Informationen und Kommunikation des Labs.",
    "ritaContact": "RITA kontaktieren",
    "ritaContactSub": "Den Telegram-Bot des Labs direkt öffnen.",
    "copyDiagnostic": "Diagnose kopieren",
    "copyDiagnosticSub": "Bereitet nützliche technische Informationen vor einer Fehlermeldung vor.",
    "restrictedTag": "K // ZUTRITT BESCHRÄNKT",
    "restrictedZone": "ADMINISTRATOREN STRENGSTENS VERBOTEN",
    "unauthorized": "UNBEFUGTER ZUTRITT",
    "forbiddenText": "Redacted versichert, dass es hier absolut nichts Interessantes gibt. Von Redacted kommend ist das natürlich außerordentlich beruhigend.",
    "igorAssistant": "IITC-Assistent des Labs",
    "checking": "Prüfung…",
    "atticTag": "D // LAB-DACHBODEN",
    "igorRoomBack": "IGOR-Raum",
    "inventoryTitle": "Agenten-Inventar",
    "inventoryTitleSub": "Verwaltung in BannerLab. Mit C.O.R.E. synchronisiert IGOR auf Anfrage; ohne C.O.R.E. bleibt die Eingabe manuell.",
    "keysTitle": "Schlüssel & Orte",
    "keysTitleSub": "Portalfotos, Favoriten, zu farmende Schlüssel und Ablage in BannerLab.",
    "igorSettingsTitle": "IGOR-Einstellungen",
    "igorSettingsTitleSub": "Installation, Updates und IITC-Gateway."
  },
  "it": {
    "welcome": "Benvenuto nell’ascensore del laboratorio.",
    "ask": "A quale piano vuoi andare?",
    "first": "Questo è il punto di partenza. Ogni servizio del Lab ha il proprio piano.",
    "choose": "SCEGLI UN PIANO",
    "attic": "Soffitta",
    "atticSub": "Impostazioni · backup · tutorial · informazioni",
    "third": "Terzo piano",
    "thirdSub": "RITA · comunicazioni e supporto del Lab",
    "second": "Secondo piano",
    "secondSub": "Sala IGOR · Missioni · Chiavi · Inventario · Catture uniche",
    "firstFloor": "Primo piano",
    "firstSub": "LEON · AP esatti · Timer",
    "ground": "Piano terra",
    "groundSub": "Officina banner · Creazione e percorso",
    "basement": "Seminterrato",
    "basementSub": "AMMINISTRATORI SEVERAMENTE VIETATI",
    "igorFloor": "Sala IGOR",
    "igorFloorSub": "Missioni, chiavi e operazioni sul campo",
    "mission": "Missioni",
    "missionSub": "Crea o riprendi il percorso attivo",
    "keys": "Chiavi",
    "keysSub": "Key Sync · posizioni · sincronizzazione tramite IGOR",
    "inventory": "Inventario",
    "inventorySub": "Inventario RBL · manuale · C.O.R.E. tramite IGOR · condivisione",
    "uniques": "Catture uniche",
    "uniquesSub": "Trova i portali caricati che non hai mai catturato",
    "igorSettings": "Impostazioni IGOR",
    "igorSettingsSub": "Installazione, aggiornamento e cartella IITC",
    "ritaFloor": "Sala RITA",
    "ritaFloorSub": "Informazioni, community e supporto Telegram",
    "basementTitle": "Seminterrato · Zona riservata",
    "basementText": "Redacted sostiene che questo piano non esista. Questo probabilmente spiega gli otto cabinati arcade.",
    "arcade": "Arcade del Lab",
    "arcadeSub": "Minigiochi clandestini",
    "glyph": "Glyph Lab",
    "glyphSub": "Allenamento e arcade glyph",
    "elevatorTag": "REDACTED BANNER LAB // ASCENSORE",
    "redactedAdmin": "REDACTED // AMMINISTRATORE DEL LAB",
    "homeDestination": "INGRESSO // DESTINAZIONE",
    "labHome": "INGRESSO DEL LAB",
    "lift": "Ascensore",
    "backLift": "Torna all’ascensore",
    "ritaDetail": "Supporto, informazioni e comunicazioni del Lab.",
    "ritaContact": "Contatta RITA",
    "ritaContactSub": "Apri direttamente il bot Telegram del Lab.",
    "copyDiagnostic": "Copia diagnostica",
    "copyDiagnosticSub": "Prepara le informazioni tecniche utili prima di segnalare un problema.",
    "restrictedTag": "S // ACCESSO RISERVATO",
    "restrictedZone": "AMMINISTRATORI SEVERAMENTE VIETATI",
    "unauthorized": "ACCESSO NON AUTORIZZATO",
    "forbiddenText": "Redacted assicura che qui non ci sia assolutamente nulla di interessante. Detto da Redacted, è ovviamente molto rassicurante.",
    "igorAssistant": "Assistente IITC del Lab",
    "checking": "Verifica…",
    "atticTag": "S // SOFFITTA DEL LAB",
    "igorRoomBack": "Sala IGOR",
    "inventoryTitle": "Inventario agente",
    "inventoryTitleSub": "Gestito in BannerLab. Con C.O.R.E., IGOR sincronizza su richiesta; senza C.O.R.E., l’inserimento resta manuale.",
    "keysTitle": "Chiavi e posizioni",
    "keysTitleSub": "Foto dei portali, preferiti, chiavi da farmare e archiviazione in BannerLab.",
    "igorSettingsTitle": "Impostazioni IGOR",
    "igorSettingsTitleSub": "Installazione, aggiornamenti e gateway IITC."
  },
  "nl": {
    "welcome": "Welkom in de lift van het laboratorium.",
    "ask": "Naar welke verdieping wil je?",
    "first": "Dit is het startpunt. Elke Lab-dienst heeft zijn eigen verdieping.",
    "choose": "KIES EEN VERDIEPING",
    "attic": "Zolder",
    "atticSub": "Instellingen · back-ups · tutorials · informatie",
    "third": "Derde verdieping",
    "thirdSub": "RITA · communicatie & ondersteuning van het Lab",
    "second": "Tweede verdieping",
    "secondSub": "IGOR-ruimte · Missies · Sleutels · Inventaris · Unieke captures",
    "firstFloor": "Eerste verdieping",
    "firstSub": "LEON · Exacte AP · Timers",
    "ground": "Begane grond",
    "groundSub": "Bannerwerkplaats · Creatie & route",
    "basement": "Kelder",
    "basementSub": "BEHEERDERS STRENG VERBODEN",
    "igorFloor": "IGOR-ruimte",
    "igorFloorSub": "Missies, sleutels en veldoperaties",
    "mission": "Missies",
    "missionSub": "De actieve route maken of hervatten",
    "keys": "Sleutels",
    "keysSub": "Key Sync · locaties · synchronisatie via IGOR",
    "inventory": "Inventaris",
    "inventorySub": "RBL-inventaris · handmatig · C.O.R.E. via IGOR · delen",
    "uniques": "Unieke captures",
    "uniquesSub": "Geladen portalen vinden die je nog nooit hebt veroverd",
    "igorSettings": "IGOR-instellingen",
    "igorSettingsSub": "Installatie, update en IITC-map",
    "ritaFloor": "RITA-kamer",
    "ritaFloorSub": "Informatie, community en Telegram-support",
    "basementTitle": "Kelder · Beperkte zone",
    "basementText": "Redacted beweert dat deze verdieping niet bestaat. Dat verklaart waarschijnlijk de acht arcadekasten.",
    "arcade": "Lab Arcade",
    "arcadeSub": "Clandestiene minigames",
    "glyph": "Glyph Lab",
    "glyphSub": "Glyphtraining en arcade",
    "elevatorTag": "REDACTED BANNER LAB // LIFT",
    "redactedAdmin": "REDACTED // LAB-BEHEERDER",
    "homeDestination": "START // BESTEMMING",
    "labHome": "LAB-START",
    "lift": "Lift",
    "backLift": "Terug naar de lift",
    "ritaDetail": "Support, informatie en communicatie van het Lab.",
    "ritaContact": "Contact RITA",
    "ritaContactSub": "Open de Telegram-bot van het Lab rechtstreeks.",
    "copyDiagnostic": "Diagnose kopiëren",
    "copyDiagnosticSub": "Bereidt nuttige technische informatie voor voordat je een probleem meldt.",
    "restrictedTag": "K // BEPERKTE TOEGANG",
    "restrictedZone": "BEHEERDERS STRENG VERBODEN",
    "unauthorized": "ONGEAUTORISEERDE TOEGANG",
    "forbiddenText": "Redacted verzekert dat hier absoluut niets interessants is. Van Redacted is dat natuurlijk bijzonder geruststellend.",
    "igorAssistant": "IITC-assistent van het Lab",
    "checking": "Controleren…",
    "atticTag": "Z // LAB-ZOLDER",
    "igorRoomBack": "IGOR-ruimte",
    "inventoryTitle": "Agent-inventaris",
    "inventoryTitleSub": "Beheerd in BannerLab. Met C.O.R.E. synchroniseert IGOR op verzoek; zonder C.O.R.E. blijft invoer handmatig.",
    "keysTitle": "Sleutels & locaties",
    "keysTitleSub": "Portaalfoto’s, favorieten, te farmen sleutels en opslag in BannerLab.",
    "igorSettingsTitle": "IGOR-instellingen",
    "igorSettingsTitleSub": "Installatie, updates en IITC-gateway."
  }
};
const elevatorCopy=()=>ELEVATOR_COPY[APP_LANG]||ELEVATOR_COPY.en;
function closeLabElevator(){labElevatorRoot?.remove();labElevatorRoot=null;document.body.classList.remove('labElevatorOpen')}
function setLabFloor(name){
  labCurrentFloor=name||'elevator';
  document.body.dataset.labFloor=labCurrentFloor;
  // Hard floor invariant: the Fresco app exists only on the ground floor.
  // Hiding it by floor state instead of by elevator animation prevents one-frame flashes
  // when the elevator is removed before the basement/other floor has finished opening.
  document.body.classList.toggle('labNonGroundFloor',labCurrentFloor!=='ground');
}
function elevatorFloorButton(code,title,sub,kind,avatar=''){
  const current=elevatorThemeFloor()===kind;
  return `<button class="labElevatorFloor ${kind}${current?' current':''}" data-floor="${kind}" type="button">
    <span class="labElevatorNumber"><span>${code}</span><i></i></span>
    <span class="labElevatorFloorCopy"><b>${escapeHtml(title)}</b>${sub?`<small>${escapeHtml(sub)}</small>`:''}</span>
    ${avatar?`<span class="labElevatorAvatar"><img src="${avatar}" alt=""></span>`:`<span class="labElevatorAvatar labElevatorAvatarGlyph">${kind==='attic'?'⚙':'•'}</span>`}
    <span class="labElevatorChevron">›</span>
  </button>`;
}
function openLabElevator({startup=false}={}){
  closeSheet();closeLabFloor();closeLabElevator();setLabFloor('elevator');
  document.body.classList.remove('groundFloorActive');
  document.body.classList.add('labElevatorOpen');
  const t=elevatorCopy(),first=localStorage.getItem(ELEVATOR_WELCOME_KEY)!=='1';
  const themeFloor=elevatorThemeFloor();
  const root=document.createElement('div');
  root.className=`labElevatorRoot labElevatorTheme-${themeFloor}`;
  root.dataset.elevatorTheme=themeFloor;

  root.innerHTML=`<div class="labElevatorShell">
    ${elevatorThemeDecor(themeFloor)}
    <div class="labElevatorCabin">
      <div class="labElevatorDoorFrame">
        ${elevatorThemeScene(themeFloor)}
        <div class="labElevatorDoorSeam"></div>
        <div class="labElevatorDoorTop"><span></span><b>${themeFloor==='neutral'?'LAB ELEVATOR':themeFloor.toUpperCase()}</b><span></span></div>

        ${!elevatorVisitedThisSession?`
          <section class="labElevatorHost labElevatorHostInCabin">
            <img src="/redacted-dino-cutout.png" alt="Redacted">
            <div class="labElevatorBubble">
              <small>${escapeHtml(t.redactedAdmin)}</small>
              <b>${escapeHtml(t.welcome)}<br>${escapeHtml(t.ask)}</b>
              ${first?`<p>${escapeHtml(t.first)}</p>`:''}
            </div>
          </section>
        `:elevatorReturnHostHtml(themeFloor)}
      </div>

      <div class="labElevatorConsole">
        <div class="labElevatorFloors">
          ${elevatorFloorButton('C',t.atticSub,'','attic')}
          ${elevatorFloorButton('3',t.thirdSub,'','rita','/rita.webp')}
          ${elevatorFloorButton('2',t.secondSub,'','igor','/igor.webp')}
          ${elevatorFloorButton('1',t.firstSub,'','leon','/leon.webp')}
          ${elevatorFloorButton('RDC',t.groundSub,'','ground','/redacted-logo-512.png')}
          ${elevatorFloorButton('SS',t.basementSub,'','basement','/redacted-logo-512.png')}
        </div>

        <div class="labElevatorFoot">${escapeHtml(t.labHome)} · ${escapeHtml(APP_VERSION)} · ${escapeHtml(DISPLAY_BUILD_CODE)}</div>
      </div>
    </div>
  </div>`;

  document.body.appendChild(root);
  labElevatorRoot=root;
  localStorage.setItem(ELEVATOR_WELCOME_KEY,'1');

  $$('.labElevatorFloor',root).forEach(btn=>btn.onclick=()=>{
    try{navigator.vibrate?.(28)}catch(_){}
    const floor=btn.dataset.floor;
    $$('.labElevatorFloor',root).forEach(x=>x.classList.remove('selected'));
    btn.classList.add('selected');
    rememberElevatorTheme(floor);
    setTimeout(()=>{
      if(floor==='basement'){openBasementRestrictedAccess();return}
      closeLabElevator();setLabFloor(floor);
      if(floor==='attic')openInfoSheet();
      if(floor==='rita')openRitaFloor();
      if(floor==='igor')openIgorFloor();
      if(floor==='leon')openLeonFloor();
      if(floor==='ground')activateGroundFloor();
    },150);
  });
}
function elevatorButtonHtml(cls='floorLiftBtn'){
  const t=elevatorCopy();
  return `<button class="${cls} unifiedElevatorBtn" type="button"><span class="elevatorBtnIcon" aria-hidden="true">▥</span><span>${escapeHtml(t.lift)}</span></button>`;
}
function returnToLabElevator(){
  document.body.classList.add('basementTransitionActive');
  document.body.classList.remove('groundFloorActive');
  closeSheet();closeLabFloor();closeLeon(false);closeLeonTimers(false);
  openLabElevator();
  requestAnimationFrame(()=>{
    closeLabArcade(false);
    requestAnimationFrame(()=>document.body.classList.remove('basementTransitionActive'));
  });
}
function activateGroundFloor({fromTutorial=false}={}){
  setLabFloor('ground');
  setFlowStep('fresco',{open:false});
  window.scrollTo({top:0,behavior:'instant'});
  document.body.classList.add('groundFloorActive');
  if(!fromTutorial)maybeStartFloorTutorial('ground');
}
function launchRitaSupport(){
  const botLang=APP_LANG==='zh-Hans'?'zh-CN':APP_LANG==='zh-Hant'?'zh-TW':APP_LANG;
  const start=`support_${botLang}`;
  const webUrl=`https://t.me/redactedbannerlabbot?start=${encodeURIComponent(start)}`;
  const tgUrl=`tg://resolve?domain=redactedbannerlabbot&start=${encodeURIComponent(start)}`;
  if(Capacitor.isNativePlatform())AppLauncher.openUrl({url:tgUrl}).catch(()=>AppLauncher.openUrl({url:webUrl}).catch(()=>{}));
  else window.open(webUrl,'_blank','noopener');
}
function rblDiagnostic(){
  const android=(navigator.userAgent.match(/Android\s+([0-9.]+)/i)||[])[1];
  const platform=Capacitor.getPlatform?Capacitor.getPlatform():(Capacitor.isNativePlatform()?'android':'web');
  return `Redacted BannerLab v${APP_VERSION}\n${tr('platformLabel')} : ${platform}${android?` · Android ${android}`:''}\n${tr('language')} : ${APP_LANG.toUpperCase()}\nIGOR : 0.6.36\nMILO : 0.5.3\nRITA : Telegram Assistant\nLEON : AP Exact Navigator · ${APP_VERSION}\n\n${tr('diagnosticDescription')}\n`;
}
function openLeonFloor(){
  const t=elevatorCopy(),lt=(k,v)=>leonTimerText(APP_LANG,k,v);
  const sh=openLabFloorPage('leon',`<header class="floorTopbar"><div><small>1 // LEON</small><h1>${escapeHtml(lt('floorTitle'))}</h1><p>${escapeHtml(lt('floorSub'))}</p></div>${elevatorButtonHtml('floorLiftBtn')}</header>
    <section class="floorAtmosphere leonFloorAtmosphere"><div class="leonFloorHero"><img src="/leon.webp" alt="LEON"><div><b>🧮 LEON</b><span>${escapeHtml(lt('floorHero'))}</span></div></div></section>
    <div class="labFloorGrid leonFloorGrid"><button class="labFloorCard leonDoorCalc"><b>∑ ${escapeHtml(lt('calcDoor'))}</b><span>${escapeHtml(lt('calcDoorSub'))}</span><i>›</i></button><button class="labFloorCard leonDoorTimers"><b>◉ ${escapeHtml(lt('timersDoor'))}</b><span>${escapeHtml(lt('timersDoorSub'))}</span><i class="labTimerDoorIcon">›</i></button></div>`);
  $('.floorLiftBtn',sh).onclick=returnToLabElevator;
  $('.leonDoorCalc',sh).onclick=()=>{closeLabFloor();openLeon(APP_LANG)};
  $('.leonDoorTimers',sh).onclick=()=>{closeLabFloor();void openLeonTimers(APP_LANG)};
  maybeStartFloorTutorial('leon');
}

function openRitaFloor(){
  const t=elevatorCopy();
  const sh=openLabFloorPage('rita',`<header class="floorTopbar"><div><small>3 // COMMUNICATIONS</small><h1>${escapeHtml(t.ritaFloor)}</h1><p>${escapeHtml(t.ritaFloorSub)}</p></div>${elevatorButtonHtml('floorLiftBtn')}</header>
    <section class="floorAtmosphere ritaAtmosphere"><div class="floorGlow"></div><div class="igorFloorHero ritaFloorHero"><img src="/rita.webp" alt="RITA"><div><b>🤖 RITA</b><span>Redacted Information & Telegram Assistant</span><small class="igorSettingsDetail">${escapeHtml(t.ritaDetail)}</small></div></div></section>
    <div class="labFloorGrid"><button class="labFloorCard ritaTelegram"><b>✈ ${escapeHtml(t.ritaContact)}</b><span>${escapeHtml(t.ritaContactSub)}</span><i>›</i></button><button class="labFloorCard ritaDiagnostic"><b>⌘ ${escapeHtml(t.copyDiagnostic)}</b><span>${escapeHtml(t.copyDiagnosticSub)}</span><i>›</i></button></div>`);
  $('.floorLiftBtn',sh).onclick=returnToLabElevator;
  $('.ritaTelegram',sh).onclick=launchRitaSupport;
  $('.ritaDiagnostic',sh).onclick=async()=>{if(await copyText(rblDiagnostic()))toast(tr('diagnosticCopied'));else toast(tr('diagnosticCopyFailed'))};
  maybeStartFloorTutorial('rita');
}
function openBasementRestrictedAccess({fromTutorial=false}={}){
  const t=elevatorCopy();

  // Switch floor state BEFORE touching the elevator DOM. This is deliberate: removing
  // the elevator must never expose the Fresco for even a single rendered frame.
  setLabFloor('basement');

  // Cover the entire app before touching the elevator/floor DOM.
  // This prevents the ground-floor fresco from getting even one paint frame on first entry.
  document.body.classList.add('basementTransitionActive');
  const root=document.createElement('div');
  root.className='basementAccessSequence';
  root.innerHTML=`<div class="basementAccessNoise"></div><div class="basementAccessDoors"><i></i><i></i></div><div class="basementAccessPanel"><small>${escapeHtml(t.restrictedTag)}</small><strong class="basementAccessCode">SS</strong><div class="basementAccessWarn">${escapeHtml(t.unauthorized)}</div><div class="basementAccessScan"><i></i></div><p>${escapeHtml(t.forbiddenText)}</p><div class="basementAccessStatus"><span></span><b>VERIFICATION...</b></div></div>`;
  document.body.appendChild(root);
  labFloorRoot=root;

  requestAnimationFrame(()=>{
    root.classList.add('active');
    requestAnimationFrame(()=>{
      document.body.classList.remove('groundFloorActive');
      closeSheet();closeLabElevator();closeLabArcade(false);
    });
  });

  try{navigator.vibrate?.([24,65,20])}catch(_){}
  setTimeout(()=>root.classList.add('scan'),650);
  setTimeout(()=>{root.classList.add('denied');const s=root.querySelector('.basementAccessStatus b');if(s)s.textContent='ACCÈS REFUSÉ';try{navigator.vibrate?.([55,45,55])}catch(_){}},1650);
  setTimeout(()=>{root.classList.add('override');const s=root.querySelector('.basementAccessStatus b');if(s)s.textContent='OVERRIDE REDACTED';},2450);
  setTimeout(()=>{root.classList.add('breach');const s=root.querySelector('.basementAccessStatus b');if(s)s.textContent='OUVERTURE';try{navigator.vibrate?.([18,40,80])}catch(_){}},3150);
  setTimeout(()=>root.classList.add('open'),3600);
  setTimeout(()=>{
    root.remove();
    if(labFloorRoot===root)labFloorRoot=null;
    document.body.classList.remove('basementTransitionActive','groundFloorActive');
    openLabArcade(APP_LANG,'menu');
    if(!fromTutorial)maybeStartFloorTutorial('basement');
  },4050);
}
function openBasementFloor(){openBasementRestrictedAccess();}
const MILO_FLOOR_COPY={"fr": ["MILO veille sur la publication des missions.", "Mission Authoring · vérification · publication"], "en": ["MILO watches over mission publishing.", "Mission Authoring · verification · publishing"], "es": ["MILO supervisa la publicación de misiones.", "Mission Authoring · verificación · publicación"], "pt": ["MILO acompanha a publicação das missões.", "Mission Authoring · verificação · publicação"], "de": ["MILO überwacht die Veröffentlichung der Missionen.", "Mission Authoring · Prüfung · Veröffentlichung"], "it": ["MILO controlla la pubblicazione delle missioni.", "Mission Authoring · verifica · pubblicazione"], "nl": ["MILO bewaakt de publicatie van missies.", "Mission Authoring · controle · publicatie"]};
function miloFloorCopy(){const l=(APP_LANG||'en').split('-')[0];const v=MILO_FLOOR_COPY[l]||MILO_FLOOR_COPY.en;return {watch:v[0],line:v[1]}}

function openIgorFloor(){
  const t=elevatorCopy(),milo=miloFloorCopy();
  const sh=openLabFloorPage('igor',`<header class="floorTopbar"><div><small>2 // IITC GATEWAY</small><h1>${escapeHtml(t.igorFloor)}</h1><p>${escapeHtml(t.igorFloorSub)}</p></div>${elevatorButtonHtml('floorLiftBtn')}</header>
    <section class="floorAtmosphere igorAtmosphere">
      <div class="igorFloorHero"><img src="/igor.webp" alt="IGOR"><div><b>🧪 IGOR 0.6.39</b><span>${escapeHtml(t.igorAssistant)}</span><div class="rule iitc-install-summary"><span class="dot"></span><span>${escapeHtml(t.checking)}</span></div></div></div>
      <div class="igorMiloCompanion"><img src="/milo-field.jpg" alt="MILO"><div><small>MILO // MISSION INTELLIGENCE &amp; LAUNCH OPERATIONS</small><b>${escapeHtml(milo.watch)}</b><span>${escapeHtml(milo.line)}</span></div></div>
    </section>
    <div class="labFloorGrid igorFloorGrid"><button class="labFloorCard igorMission"><b>🗺 ${escapeHtml(t.mission)}</b><span>${escapeHtml(t.missionSub)}</span><i>›</i></button><button class="labFloorCard igorKeys"><b>🔑 ${escapeHtml(t.keys)}</b><span>${escapeHtml(t.keysSub)}</span><i>›</i></button><button class="labFloorCard igorInventory"><b>▦ ${escapeHtml(t.inventory)}</b><span>${escapeHtml(t.inventorySub)}</span><i>›</i></button><button class="labFloorCard igorUniques"><b>◎ ${escapeHtml(t.uniques)}</b><span>${escapeHtml(t.uniquesSub)}</span><i>›</i></button><button class="labFloorCard igorSettings"><b>⚙ ${escapeHtml(t.igorSettings)}</b><span>${escapeHtml(t.igorSettingsSub)}</span><i>›</i></button></div>`);
  $('.floorLiftBtn',sh).onclick=returnToLabElevator;
  $('.igorMission',sh).onclick=()=>launchIgor('mission');
  $('.igorKeys',sh).onclick=()=>openRblKeysFloor();
  $('.igorInventory',sh).onclick=()=>openRblInventoryFloor();
  $('.igorUniques',sh).onclick=()=>launchIgor('uniques');
  $('.igorSettings',sh).onclick=()=>openIgorSettings();
  refreshIitcCompanionStatus(sh);
  maybeStartFloorTutorial('igor');
}
async function launchIgor(view='mission'){
  const allowed=['mission','keys','uniques','inventory-sync','keys-sync'];
  view=allowed.includes(view)?view:'mission';
  if(!Capacitor.isNativePlatform()){return openIntel({view})}
  try{
    const st=await getIitcCompanionStatus();
    if(iitcCompanionReady(st))return openIntel({mode:view==='mission'?'replace':'resume',view});
    openIgorSettings({launchView:view});
  }catch(e){console.warn('[IGOR launch status]',e);openIgorSettings({launchView:view})}
}


// ---------- IGOR : CLÉS & INVENTAIRE GÉRÉS DANS RBL ----------
const RBL_IGOR_INVENTORY_KEY='rbl-igor-inventory-v2';
const RBL_IGOR_SHARED_KEY='rbl-igor-inventory-shared-v2';
const RBL_IGOR_KEYS_KEY='rbl-igor-keys-v2';
const RBL_IGOR_KEY_PREFS_KEY='rbl-igor-key-prefs-v1';
const RBL_IGOR_CONTAINERS_KEY='rbl-igor-containers-v2';
const RBL_IGOR_LAST_SYNC_KEY='rbl-igor-last-sync-v2';
const RBL_IGOR_SYNC_STATUS_KEY='rbl-igor-sync-status-v2';
const RBL_IGOR_PENDING_SYNC_KEY='rbl-igor-pending-sync-v2';
const RBL_IGOR_LAST_CORE_REQUEST_KEY='rbl-igor-last-sync-request-v2';
const RBL_IGOR_SYNC_LOCK_MS=25000;
function rblPendingSync(kind=''){
  const p=safeLocalJson(RBL_IGOR_PENDING_SYNC_KEY,{}),age=Date.now()-Number(p?.at||0);
  if(!p?.requestId||!Number.isFinite(age)||age<0||age>RBL_IGOR_SYNC_LOCK_MS)return null;
  return !kind||String(p.kind||'')===String(kind)?p:null;
}
function markRblSyncStarting(kind,returnView){
  const requestId=randomHex(12);
  localStorage.setItem(RBL_IGOR_PENDING_SYNC_KEY,JSON.stringify({requestId,kind,returnView,at:Date.now()}));
  return requestId;
}
const INGRESS_ITEMS_BASE='https://raw.githubusercontent.com/le-jeu/ingress-items/62618d18af81cc4f31e8fed0b6294781a68768f4/items/';
const INGRESS_BOXED_BASE='https://raw.githubusercontent.com/ameba64/ingress-items/main/boxed/';
const ingressItemIcon=name=>String(name||'').startsWith('boxed:')?INGRESS_BOXED_BASE+encodeURIComponent(String(name).slice(6)):INGRESS_ITEMS_BASE+encodeURIComponent(name);
const RBL_INV_CATALOG=[
  ...Array.from({length:8},(_,i)=>({id:`xmp-${i+1}`,name:`XMP Burster L${i+1}`,cat:'armes',tag:`L${i+1}`,icon:'xmp_buster.svg'})),
  ...Array.from({length:8},(_,i)=>({id:`us-${i+1}`,name:`Ultra Strike L${i+1}`,cat:'armes',tag:`L${i+1}`,icon:'ultra_strike.svg'})),
  ...Array.from({length:8},(_,i)=>({id:`res-${i+1}`,name:`Résonateur L${i+1}`,cat:'resos',tag:`L${i+1}`,icon:'resonator.svg'})),
  ...Array.from({length:8},(_,i)=>({id:`cube-${i+1}`,name:`Power Cube L${i+1}`,cat:'energie',tag:`L${i+1}`,icon:'power_cube.svg'})),
  {id:'hypercube',name:'Hyper Cube',cat:'energie',tag:'VR',icon:'power_cube.svg'},
  {id:'shield-common',name:'Portal Shield',cat:'mods',tag:'C',icon:'boxed:boxed_portal_shield_common.svg'},{id:'shield-rare',name:'Portal Shield',cat:'mods',tag:'R',icon:'boxed:boxed_portal_shield_rare.svg'},{id:'shield-vr',name:'Portal Shield',cat:'mods',tag:'VR',icon:'boxed:boxed_portal_shield_very_rare.svg'},{id:'aegis',name:'Aegis Shield',cat:'mods',tag:'VR',icon:'boxed:boxed_portal_shield_very_rare_aegis.svg'},
  {id:'heat-common',name:'Heat Sink',cat:'mods',tag:'C',icon:'boxed:boxed_heat_sink_common.svg'},{id:'heat-rare',name:'Heat Sink',cat:'mods',tag:'R',icon:'boxed:boxed_heat_sink_rare.svg'},{id:'heat-vr',name:'Heat Sink',cat:'mods',tag:'VR',icon:'boxed:boxed_heat_sink_very_rare.svg'},
  {id:'mh-common',name:'Multi Hack',cat:'mods',tag:'C',icon:'boxed:boxed_multi_hack_common.svg'},{id:'mh-rare',name:'Multi Hack',cat:'mods',tag:'R',icon:'boxed:boxed_multi_hack_rare.svg'},{id:'mh-vr',name:'Multi Hack',cat:'mods',tag:'VR',icon:'boxed:boxed_multi_hack_very_rare.svg'},
  {id:'link-rare',name:'Link Amp',cat:'mods',tag:'R',icon:'boxed:boxed_link_amp_rare.svg'},{id:'link-vr',name:'Link Amp',cat:'mods',tag:'VR',icon:'boxed:boxed_link_amp_very_rare.svg'},{id:'sbul',name:'SoftBank Ultra Link',cat:'mods',tag:'VR',icon:'boxed:boxed_softbank_ultra_link_very_rare.svg'},
  {id:'turret',name:'Turret',cat:'mods',tag:'R',icon:'boxed:boxed_turret_rare.svg'},{id:'force',name:'Force Amp',cat:'mods',tag:'R',icon:'boxed:boxed_force_amp_rare.svg'},{id:'ito-plus',name:'ITO EN (+)',cat:'mods',tag:'VR',icon:'boxed:boxed_ito_en_transmuter_+_very_rare.svg'},{id:'ito-minus',name:'ITO EN (-)',cat:'mods',tag:'VR',icon:'boxed:boxed_ito_en_transmuter_-_very_rare.svg'},
  {id:'ada',name:'ADA Refactor',cat:'util',tag:'VR',icon:'ada_refactor.svg'},{id:'jarvis',name:'JARVIS Virus',cat:'util',tag:'VR',icon:'jarvis_virus.svg'},{id:'apex',name:'Apex',cat:'util',tag:'VR',icon:'apex_colored.svg'},{id:'fracker',name:'Fracker',cat:'util',tag:'VR',icon:'fracker.svg'},
  {id:'beacon',name:'Beacon',cat:'util',tag:'VR',icon:'media.svg'},{id:'battle-beacon',name:'Battle Beacon',cat:'util',tag:'VR',icon:'media.svg'},
  {id:'capsule',name:'Capsule',cat:'conteneurs',tag:'',icon:'capsule.svg'},{id:'kinetic',name:'Kinetic Capsule',cat:'conteneurs',tag:'',icon:'kinetic_capsule.svg'},{id:'keylocker',name:'Key Locker',cat:'conteneurs',tag:'',icon:'key_locker.svg'},{id:'media',name:'Media',cat:'util',tag:'',icon:'media.svg'}
];
function safeLocalJson(key,fallback){try{const x=JSON.parse(localStorage.getItem(key)||'null');return x??fallback}catch{return fallback}}
function rblInventoryCounts(){const x=safeLocalJson(RBL_IGOR_INVENTORY_KEY,{});return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}
function saveRblInventoryCounts(x){localStorage.setItem(RBL_IGOR_INVENTORY_KEY,JSON.stringify(x||{}));markBackupChanged()}
function rblInventoryItemsTotal(x=rblInventoryCounts()){return Object.values(x||{}).reduce((a,n)=>a+Math.max(0,Math.floor(Number(n)||0)),0)}
function rblKeyInventoryTotal(keys=rblKeys()){return Object.values(keys||{}).reduce((sum,k)=>sum+Math.max(0,Math.floor(Number((k&&typeof k==='object')?(k.total??k.count??0):k)||0)),0)}
function rblKeyInventoryBreakdown(keys=rblKeys()){
  let total=0,stored=0;
  for(const k of Object.values(keys||{})){
    const n=Math.max(0,Math.floor(Number(k?.total??k?.count??0)||0));total+=n;
    const loc=k?.locations&&typeof k.locations==='object'?k.locations:{};
    for(const [id,v] of Object.entries(loc)){
      const key=String(id||'').toLowerCase();
      if(!key||key==='inventory'||key==='bag'||key==='⌂')continue;
      stored+=Math.max(0,Math.floor(Number(v)||0));
    }
  }
  stored=Math.min(total,stored);
  return {total,stored,bag:Math.max(0,total-stored)};
}
function rblInventoryTotal(x=rblInventoryCounts(),keys=rblKeys()){return rblInventoryItemsTotal(x)+rblKeyInventoryTotal(keys)}
function rblContainers(){const x=safeLocalJson(RBL_IGOR_CONTAINERS_KEY,[]);return Array.isArray(x)?x:[]}
function saveRblContainers(x){localStorage.setItem(RBL_IGOR_CONTAINERS_KEY,JSON.stringify(x||[]));markBackupChanged()}
function rblKeys(){const x=safeLocalJson(RBL_IGOR_KEYS_KEY,{});return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}
function saveRblKeys(x){localStorage.setItem(RBL_IGOR_KEYS_KEY,JSON.stringify(x||{}));markBackupChanged()}
function rblKeyPrefs(){const x=safeLocalJson(RBL_IGOR_KEY_PREFS_KEY,{});return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}
function saveRblKeyPrefs(x){localStorage.setItem(RBL_IGOR_KEY_PREFS_KEY,JSON.stringify(x||{}));markBackupChanged()}
function knownPortalImage(guid){
  guid=String(guid||'');if(!guid)return '';
  try{
    for(const mission of (state?.planner?.missions||[])){
      const p=(mission?.portals||[]).find(p=>String(p?.guid||'')===guid&&p?.imageUrl);
      if(p?.imageUrl)return String(p.imageUrl);
    }
  }catch(e){}
  return '';
}
function rarityKey(raw=''){raw=String(raw).toUpperCase();return raw==='VERY_RARE'||raw==='VR'?'vr':raw==='RARE'||raw==='R'?'rare':raw==='COMMON'||raw==='C'?'common':'neutral'}
function coreSnapshotToCounts(snapshot){
  const out={};const items=snapshot?.items&&typeof snapshot.items==='object'?snapshot.items:{};
  const set=(id,n)=>{n=Math.max(0,Math.round(Number(n)||0));if(n)out[id]=(out[id]||0)+n};
  const baseFor=type=>({EMITTER_A:'res',EMP_BURSTER:'xmp',ULTRA_STRIKE:'us',POWER_CUBE:'cube'}[type]||'');
  for(const [type,cat] of Object.entries(items)){
    const base=baseFor(type);const counts=cat?.counts&&typeof cat.counts==='object'?cat.counts:{};
    if(base){for(const [level,v] of Object.entries(counts)){const n=typeof v==='object'?Number(v.total||0):Number(v||0);if(/[1-8]/.test(String(level)))set(`${base}-${Number(level)}`,n)}continue}
    const total=Number(cat?.total||0);const byRarity=r=>{const v=counts[r];return typeof v==='object'?Number(v.total||0):Number(v||0)};
    if(type==='BOOSTED_POWER_CUBE'||type==='BOOSTED_POWER_CUBE_K'){set('hypercube',total);continue}
    if(type==='EXTRA_SHIELD'){set('aegis',total);continue}
    if(type==='RES_SHIELD'){set('shield-common',byRarity('COMMON'));set('shield-rare',byRarity('RARE'));set('shield-vr',byRarity('VERY_RARE'));continue}
    if(type==='HEATSINK'){set('heat-common',byRarity('COMMON'));set('heat-rare',byRarity('RARE'));set('heat-vr',byRarity('VERY_RARE'));continue}
    if(type==='MULTIHACK'){set('mh-common',byRarity('COMMON'));set('mh-rare',byRarity('RARE'));set('mh-vr',byRarity('VERY_RARE'));continue}
    if(type==='LINK_AMPLIFIER'){set('link-rare',byRarity('RARE'));set('link-vr',byRarity('VERY_RARE'));continue}
    const map={ULTRA_LINK_AMP:'sbul',TURRET:'turret',FORCE_AMP:'force',TRANSMUTER_ATTACK:'ito-minus',TRANSMUTER_DEFENSE:'ito-plus','FLIP_CARD:ADA':'ada','FLIP_CARD:JARVIS':'jarvis','PLAYER_POWERUP:APEX':'apex','PORTAL_POWERUP:FRACK':'fracker','PORTAL_POWERUP:BEACON':'beacon','PLAYER_POWERUP:BEACON':'beacon',BEACON:'beacon','PORTAL_POWERUP:BATTLE_BEACON':'battle-beacon','PLAYER_POWERUP:BATTLE_BEACON':'battle-beacon',BATTLE_BEACON:'battle-beacon',CAPSULE:'capsule',KINETIC_CAPSULE:'kinetic',KEY_CAPSULE:'keylocker',MEDIA:'media'};
    if(map[type])set(map[type],total);
  }
  return out;
}
function openInventoryEditor(root,item,counts,rerender){
  root.querySelector('.rblInvEditBack')?.remove();const back=document.createElement('div');back.className='rblInvEditBack';back.innerHTML=`<section class="rblInvEdit"><img src="${ingressItemIcon(item.icon)}" alt=""><div><small>${escapeHtml(item.tag||'ITEM')}</small><h3>${escapeHtml(item.name)}</h3></div><button class="rblInvEditClose">×</button><div class="rblInvStepper"><button data-delta="-10">−10</button><button data-delta="-1">−1</button><input inputmode="numeric" value="${Math.max(0,Number(counts[item.id])||0)}"><button data-delta="1">+1</button><button data-delta="10">+10</button></div></section>`;root.appendChild(back);
  const input=$('input',back),commit=n=>{n=Math.max(0,Math.floor(Number(n)||0));if(n)counts[item.id]=n;else delete counts[item.id];saveRblInventoryCounts(counts);input.value=String(n);rerender?.(item.id)};
  $('.rblInvEditClose',back).onclick=()=>back.remove();back.addEventListener('click',e=>{if(e.target===back)back.remove()});$$('[data-delta]',back).forEach(b=>b.onclick=()=>commit((Number(input.value)||0)+(Number(b.dataset.delta)||0)));input.onchange=()=>commit(input.value);
}
function openSharedInventorySnapshot(root,snap,index=-1){
  root.querySelector('.rblSharedSnapshotBack')?.remove();
  const inventory=snap?.inventory&&typeof snap.inventory==='object'?snap.inventory:{};
  const containers=Array.isArray(snap?.containers)?snap.containers:[];
  const keys=snap?.keys&&typeof snap.keys==='object'?snap.keys:{};
  const keyTotal=rblKeyInventoryTotal(keys);
  const total=rblInventoryTotal(inventory,keys);
  const known=[];const unknown=[];
  for(const [id,value] of Object.entries(inventory)){
    const count=Math.max(0,Math.floor(Number(value)||0));if(!count)continue;
    const item=RBL_INV_CATALOG.find(x=>x.id===id);
    if(item)known.push({item,count});else unknown.push({id,count});
  }
  known.sort((a,b)=>a.item.cat.localeCompare(b.item.cat)||a.item.name.localeCompare(b.item.name)||String(a.item.tag||'').localeCompare(String(b.item.tag||'')));
  unknown.sort((a,b)=>a.id.localeCompare(b.id));
  const cards=known.map(({item,count})=>`<article class="rblSharedSnapshotItem rarity-${rarityKey(item.tag)}"><span class="rblInventoryIcon"><img src="${ingressItemIcon(item.icon)}" alt="" loading="lazy"><i>${escapeHtml(item.tag||'')}</i></span><div><b>${escapeHtml(item.name)}</b><small>${escapeHtml(op('object'))}</small></div><strong>${count}</strong></article>`).join('')+
    unknown.map(({id,count})=>`<article class="rblSharedSnapshotItem"><span class="rblSharedSnapshotUnknown">?</span><div><b>${escapeHtml(id)}</b><small>${escapeHtml(op('importedObject'))}</small></div><strong>${count}</strong></article>`).join('');
  const containerRows=containers.map(c=>`<article class="rblSharedSnapshotLine"><span>${String(c?.type||'').toUpperCase().includes('KEY')||c?.type==='locker'?'🔐':'📦'}</span><div><b>${escapeHtml(c?.label||c?.id||op('container'))}</b><small>${String(c?.type||'').toUpperCase().includes('KEY')||c?.type==='locker'?'Key Locker':'Capsule'}</small></div></article>`).join('');
  const back=document.createElement('div');back.className='rblSharedSnapshotBack';
  back.innerHTML=`<section class="rblSharedSnapshot"><header><div><small>${escapeHtml(op('importedInventory'))}${index>=0?` · #${index+1}`:''}</small><h2>${escapeHtml(snap?.agent||'Agent')}</h2><p>${escapeHtml(new Date(snap?.createdAt||Date.now()).toLocaleString())}</p></div><button class="rblSharedSnapshotClose" type="button" aria-label="${escapeAttr(op('close'))}">×</button></header><div class="rblSharedSnapshotStats"><div><b>${total}</b><span>${escapeHtml(op('objects'))}</span></div><div><b>${containers.length}</b><span>${escapeHtml(op('containers'))}</span></div><div><b>${keyTotal}</b><span>${escapeHtml(op('keys'))}</span></div></div><div class="rblSharedSnapshotScroll"><div class="rblSharedSnapshotGrid">${cards||`<p class="rblModeEmpty">${escapeHtml(op('emptySnapshot'))}</p>`}</div>${containers.length?`<section class="rblSharedSnapshotSection"><h3>${escapeHtml(op('capsulesLockers'))}</h3><div>${containerRows}</div></section>`:''}${keyTotal?`<section class="rblSharedSnapshotSection"><h3>${escapeHtml(op('keys'))}</h3><p>${escapeHtml(op('portalKeysImported',{n:keyTotal}))}</p></section>`:''}</div></section>`;
  document.body.appendChild(back);
  $('.rblSharedSnapshotClose',back).onclick=()=>back.remove();
  back.addEventListener('click',e=>{if(e.target===back)back.remove()});
}
function rblNormalizeSearchText(value){
  return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
}
function applyRblInventorySearch(root){
  const body=$('.rblInventoryBody',root);if(!body)return;
  const q=rblNormalizeSearchText(root.dataset.invQuery||'');let visible=0;
  $$('.rblInventoryTile',body).forEach(tile=>{const show=!q||String(tile.dataset.invSearch||'').includes(q);tile.style.display=show?'':'none';if(show)visible++});
  const empty=$('.rblInventorySearchEmpty',body);if(empty)empty.hidden=visible>0;
}
function applyRblKeySearch(root){
  const body=$('.rblKeysBody',root);if(!body)return;
  const q=rblNormalizeSearchText(root.dataset.keyQuery||'');let visible=0;
  $$('.rblKeyCard',body).forEach(card=>{const show=!q||String(card.dataset.keySearch||'').includes(q);card.style.display=show?'':'none';if(show)visible++});
  const empty=$('.rblKeySearchEmpty',body);if(empty)empty.hidden=visible>0;
}
function rblInventoryDefaultExportName(){
  const agent=localStorage.getItem('rbl-igor-agent')||'inventaire';
  const d=new Date(),pad=n=>String(n).padStart(2,'0');
  const stamp=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}`;
  return `${safeProjectFilename(agent)}_${stamp}.json`;
}
function rblInventoryExportFilename(raw,fallback){
  const source=String(raw||'').trim().replace(/\.json$/i,'');
  const fb=String(fallback||'inventaire').trim().replace(/\.json$/i,'');
  return `${safeProjectFilename(source||fb)}.json`;
}
async function exportRblInventoryWithName(name){
  const payload={format:'rbl-igor-inventory',schemaVersion:3,agent:localStorage.getItem('rbl-igor-agent')||'',createdAt:new Date().toISOString(),inventory:rblInventoryCounts(),containers:rblContainers(),keys:rblKeys(),keyPrefs:rblKeyPrefs()};
  const text=JSON.stringify(payload,null,2);
  try{
    if(Capacitor.isNativePlatform()){
      const result=await BackupFolder.saveTextFileAs({fileName:name,text,mimeType:'application/json'});if(result?.cancelled)return;if(!result?.saved)throw new Error(op('androidSaveDenied'));
    }else downloadBlob(new Blob([text],{type:'application/json'}),name);
    toast(op('inventoryExported'));
  }catch(err){
    console.error('[RBL inventory export]',err);
    try{
      if(Capacitor.isNativePlatform()){
        await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
        await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
        const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
        await Share.share({title:op('inventoryShareTitle'),text:op('inventoryShareText'),url:uri.uri,dialogTitle:name});
        toast(op('inventoryReadyShare'));
      }else throw err;
    }catch(e2){toast(`${op('exportImpossible')} · ${e2?.message||err?.message||err}`)}
  }
}
function openRblInventoryExportNameDialog(){
  const defaultName=rblInventoryDefaultExportName();
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(op('exportNameTitle'))}</h2><p>${escapeHtml(op('exportNameText'))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><label class="field"><span>${escapeHtml(op('fileName'))}</span><input class="rblInvExportName" value="${escapeAttr(defaultName)}" autocomplete="off" autocapitalize="none" spellcheck="false"></label><div class="actions"><button class="secondary cancel">${escapeHtml(op('cancel'))}</button><button class="primary rblInvExportConfirm">${escapeHtml(op('export'))}</button></div>`);
  const input=$('.rblInvExportName',sh),cancel=()=>closeSheet();
  $('.close',sh).onclick=cancel;$('.cancel',sh).onclick=cancel;
  const run=()=>{const name=rblInventoryExportFilename(input?.value,defaultName);closeSheet();exportRblInventoryWithName(name)};
  $('.rblInvExportConfirm',sh).onclick=run;
  input?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run()}});
  requestAnimationFrame(()=>{if(!input)return;input.focus();const end=Math.max(0,input.value.toLowerCase().endsWith('.json')?input.value.length-5:input.value.length);try{input.setSelectionRange(0,end)}catch{}});
}
function renderRblInventory(root){
  const counts=rblInventoryCounts(),total=rblInventoryTotal(counts),filter=root.dataset.invFilter||'all',query=(root.dataset.invQuery||'').toLowerCase(),syncStatus=safeLocalJson(RBL_IGOR_SYNC_STATUS_KEY,{}),syncPending=rblPendingSync('inventory-sync');
  const body=$('.rblInventoryBody',root);if(!body)return;
  const cats=[['all',op('catAll')],['armes',op('catWeapons')],['resos',op('catResonators')],['energie',op('catEnergy')],['mods',op('catMods')],['util',op('catUtility')],['conteneurs',op('catContainers')]];
  const items=RBL_INV_CATALOG.filter(x=>(filter==='all'||x.cat===filter));
  const containers=rblContainers(),shared=safeLocalJson(RBL_IGOR_SHARED_KEY,[]);
  const containersHtml=containers.map(c=>`<article class="rblContainerRow"><span class="rblContainerGlyph">${String(c.type||'').toUpperCase().includes('KEY')||c.type==='locker'?'🔐':'📦'}</span><div><b>${escapeHtml(c.label||c.id||op('container'))}</b><small>${String(c.type||'').toUpperCase().includes('KEY')||c.type==='locker'?'Key Locker':'Capsule'}${c.id&&c.id!==c.label?` · ${escapeHtml(c.id)}`:''}</small></div><button data-rbl-container-del="${escapeAttr(c.id)}" type="button">×</button></article>`).join('');
  const sharedHtml=(Array.isArray(shared)?shared:[]).map((snap,i)=>{const n=rblInventoryTotal(snap.inventory||{},snap.keys||{});return `<article class="rblSharedRow" data-rbl-shared-open="${i}" role="button" tabindex="0" aria-label="${escapeAttr(op('openAgentInventory',{agent:snap.agent||'Agent'}))}"><div><b>${escapeHtml(snap.agent||'Agent')}</b><small>${n} objets · ${escapeHtml(new Date(snap.createdAt||Date.now()).toLocaleString())}</small></div><span class="rblSharedOpenHint">${escapeHtml(op('view'))} ›</span><button data-rbl-shared-del="${i}" type="button" aria-label="${escapeAttr(op('deleteInventory'))}">×</button></article>`}).join('');
  const keyBreak=rblKeyInventoryBreakdown();
  body.innerHTML=`<section class="rblInvSummary rblInvSummaryClean"><div><small>${escapeHtml(op('localInventory'))}</small><b>${total}</b><span>${rblInventoryItemsTotal(counts)} objets · 🔑 ${keyBreak.total} clés (${keyBreak.bag} sac · ${keyBreak.stored} rangées)</span></div><button class="primary rblInvSync" ${syncPending?'disabled':''}>${syncPending?op('syncing'):op('syncCore')}</button></section>${syncStatus?.message?`<section class="rblInvSyncState ${syncStatus.ok?'ok':'warn'}"><b>${syncStatus.ok?op('lastSync'):op('syncIncomplete')}</b><span>${escapeHtml(syncStatus.message)}</span>${syncStatus.at?`<small>${escapeHtml(new Date(Number(syncStatus.at)).toLocaleString())}</small>`:''}</section>`:''}
    <div class="rblInvToolbar"><input class="rblInvSearch" type="search" placeholder="${escapeAttr(op('searchItem'))}" value="${escapeAttr(root.dataset.invQuery||'')}"><div class="rblInvCats">${cats.map(c=>`<button data-inv-filter="${c[0]}" class="${filter===c[0]?'active':''}">${c[1]}</button>`).join('')}</div></div>
    <div class="rblInvActions"><button class="secondary rblInvExport">⇧ ${escapeHtml(op('export'))}</button><label class="secondary">${escapeHtml(op('importAgent'))}<input class="rblInvImport" type="file" accept="application/json,.json"></label><button class="danger rblInvReset" type="button">${escapeHtml(op('resetInventory'))}</button><span class="rblInvSyncStamp">${localStorage.getItem(RBL_IGOR_LAST_SYNC_KEY)?op('lastSyncAt',{date:new Date(Number(localStorage.getItem(RBL_IGOR_LAST_SYNC_KEY))).toLocaleString(appLocale())}):op('neverSynced')}</span></div>
    <div class="rblInventoryGrid">${items.map(x=>`<article class="rblInventoryTile rarity-${rarityKey(x.tag)}" data-inv-id="${x.id}" data-inv-search="${escapeAttr(rblNormalizeSearchText(`${x.name} ${x.tag||''} ${x.cat||''}`))}"><button class="rblInvTileMain" data-inv-add="${x.id}" type="button" aria-label="${escapeAttr(op('addItem',{item:x.name}))}"><span class="rblInventoryIcon"><img src="${ingressItemIcon(x.icon)}" alt="" loading="lazy"><i>${escapeHtml(x.tag||'')}</i></span><b>${escapeHtml(x.name)}</b></button><strong data-inv-count="${x.id}">${Math.max(0,Number(counts[x.id])||0)}</strong><div class="rblInvTileControls"><button class="rblInvTileMinus" data-inv-delta="-1" type="button" aria-label="${escapeAttr(op('removeItem',{item:x.name}))}">−</button><button class="rblInvTilePlus" data-inv-delta="1" type="button" aria-label="Ajouter un ${escapeAttr(x.name)}">+</button></div></article>`).join('')}<p class="rblModeEmpty rblInventorySearchEmpty" ${items.length?'hidden':''}>${escapeHtml(op('noSearchObject'))}</p></div>
    <section class="rblInventorySection"><div class="rblInventorySectionHead"><div><small>${escapeHtml(op('storage'))}</small><h3>${escapeHtml(op('capsulesLockers'))}</h3></div><span>${containers.length}</span></div><div class="rblContainerAdd"><input class="rblContainerName" placeholder="${escapeAttr(op('lockerExample'))}"><select class="rblContainerType"><option value="locker">Key Locker</option><option value="capsule">Capsule</option></select><button class="primary rblContainerAddBtn" type="button">${escapeHtml(op('add'))}</button></div><div class="rblContainerList">${containersHtml||`<p class="rblModeEmpty">${escapeHtml(op('noNamedContainer'))}</p>`}</div></section>
    <section class="rblInventorySection"><div class="rblInventorySectionHead"><div><small>${escapeHtml(op('voluntaryShare'))}</small><h3>${escapeHtml(op('importedInventories'))}</h3></div><span>${Array.isArray(shared)?shared.length:0}</span></div><div class="rblSharedList">${sharedHtml||`<p class="rblModeEmpty">${escapeHtml(op('noImportedInventory'))}</p>`}</div></section>
    <p class="rblInvLegal">${escapeHtml(op('inventoryLegal'))}</p>`;
  $('.rblInvSync',body).onclick=()=>{if(rblPendingSync('inventory-sync'))return;launchIgor('inventory-sync');setTimeout(()=>renderRblInventory(root),40)};
  $('.rblInvSearch',body).oninput=e=>{root.dataset.invQuery=e.target.value;applyRblInventorySearch(root)};
  applyRblInventorySearch(root);
  $$('[data-inv-filter]',body).forEach(b=>b.onclick=()=>{root.dataset.invFilter=b.dataset.invFilter;renderRblInventory(root)});
  const updateTile=id=>{const el=body.querySelector(`[data-inv-count="${CSS.escape(id)}"]`);if(el)el.textContent=String(Math.max(0,Number(counts[id])||0));const sum=$('.rblInvSummary b',body);if(sum)sum.textContent=String(rblInventoryTotal(counts,rblKeys()))};
  $$('.rblInventoryTile',body).forEach(tile=>{
    let timer=0,long=false;const id=tile.dataset.invId,item=RBL_INV_CATALOG.find(x=>x.id===id),main=$('.rblInvTileMain',tile);
    const change=delta=>{const next=Math.max(0,(Number(counts[id])||0)+(Number(delta)||0));if(next)counts[id]=next;else delete counts[id];saveRblInventoryCounts(counts);updateTile(id)};
    main?.addEventListener('pointerdown',()=>{long=false;timer=setTimeout(()=>{long=true;openInventoryEditor(root,item,counts,updateTile)},520)});
    ['pointerup','pointercancel','pointerleave'].forEach(ev=>main?.addEventListener(ev,()=>clearTimeout(timer)));
    main?.addEventListener('click',e=>{if(long){long=false;e.preventDefault();return}change(1)});
    // Souris/trackpad : clic droit retire 1. Sur téléphone, le vrai bouton − reste toujours visible.
    main?.addEventListener('contextmenu',e=>{e.preventDefault();clearTimeout(timer);long=false;change(-1)});
    $$('[data-inv-delta]',tile).forEach(b=>b.onclick=e=>{e.stopPropagation();change(Number(b.dataset.invDelta)||0)});
  });
  $('.rblContainerAddBtn',body).onclick=()=>{const label=$('.rblContainerName',body).value.trim(),type=$('.rblContainerType',body).value;if(!label){toast(op('nameContainer'));return}const list=rblContainers(),id=`manual:${Date.now().toString(36)}:${Math.random().toString(36).slice(2,6)}`;list.push({id,label:label.slice(0,32),type});saveRblContainers(list);renderRblInventory(root)};
  $$('[data-rbl-container-del]',body).forEach(b=>b.onclick=()=>{saveRblContainers(rblContainers().filter(c=>c.id!==b.dataset.rblContainerDel));renderRblInventory(root)});
  $$('[data-rbl-shared-open]',body).forEach(row=>{const open=()=>{const i=Number(row.dataset.rblSharedOpen);const x=safeLocalJson(RBL_IGOR_SHARED_KEY,[]);if(Number.isInteger(i)&&x[i])openSharedInventorySnapshot(root,x[i],i)};row.onclick=e=>{if(e.target.closest('[data-rbl-shared-del]'))return;open()};row.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&!e.target.closest('[data-rbl-shared-del]')){e.preventDefault();open()}}});
  $$('[data-rbl-shared-del]',body).forEach(b=>b.onclick=e=>{e.stopPropagation();const x=safeLocalJson(RBL_IGOR_SHARED_KEY,[]);x.splice(Number(b.dataset.rblSharedDel)||0,1);localStorage.setItem(RBL_IGOR_SHARED_KEY,JSON.stringify(x));renderRblInventory(root)});
  $('.rblInvExport',body).onclick=()=>openRblInventoryExportNameDialog();
  $('.rblInvReset',body).onclick=()=>confirmResetIgorData('inventory',root);
  $('.rblInvImport',body).onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{const x=JSON.parse(await f.text());if(x?.format!=='rbl-igor-inventory'||!x.inventory||typeof x.inventory!=='object')throw new Error(op('invalidInventory'));const shared=safeLocalJson(RBL_IGOR_SHARED_KEY,[]);shared.unshift({agent:String(x.agent||f.name||'Agent').slice(0,40),createdAt:String(x.createdAt||new Date().toISOString()),inventory:x.inventory,containers:Array.isArray(x.containers)?x.containers:[],keys:x.keys&&typeof x.keys==='object'?x.keys:{}});localStorage.setItem(RBL_IGOR_SHARED_KEY,JSON.stringify(shared.slice(0,20)));toast(op('snapshotImported'));renderRblInventory(root)}catch(err){toast(`${op('importDenied')} · ${err?.message||err}`)}finally{e.target.value=''}};
}
function confirmResetIgorData(kind,root){
  const keys=kind==='keys';
  const title=keys?op('resetKeysTitle'):op('resetInventoryTitle');
  const text=keys?op('resetKeysText'):op('resetInventoryText');
  const sh=openSheet(`<div class="sheethead"><div><h2>${title}</h2><p>${text}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="actions"><button class="secondary cancel">${escapeHtml(op('cancel'))}</button><button class="danger confirmResetIgor">${escapeHtml(op('reset'))}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.confirmResetIgor',sh).onclick=()=>{if(keys){localStorage.removeItem(RBL_IGOR_KEYS_KEY);localStorage.removeItem(RBL_IGOR_KEY_PREFS_KEY)}else{localStorage.removeItem(RBL_IGOR_INVENTORY_KEY);localStorage.removeItem(RBL_IGOR_LAST_SYNC_KEY);localStorage.removeItem(RBL_IGOR_SYNC_STATUS_KEY)}markBackupChanged();closeSheet();if(keys)renderRblKeys(root);else renderRblInventory(root);toast(keys?op('keysReset'):op('inventoryReset'))};
}
function openRblInventoryFloor(){
  const t=elevatorCopy();
  const sh=openLabFloorPage('igor-inventory',`<header class="floorTopbar"><div><small>2 // IGOR · INVENTORY</small><h1>${escapeHtml(t.inventoryTitle)}</h1><p>${escapeHtml(t.inventoryTitleSub)}</p></div><div class="floorTopActions"><button class="floorIgorBack" type="button">‹ ${escapeHtml(t.igorRoomBack)}</button>${elevatorButtonHtml('floorLiftBtn')}</div></header><div class="rblInventoryBody"></div>`);
  $('.floorIgorBack',sh).onclick=openIgorFloor;$('.floorLiftBtn',sh).onclick=returnToLabElevator;renderRblInventory(sh);
}
function normalizeKeyRecord(k,guid=''){
  const ll=Array.isArray(k?.latLng)?k.latLng:[];
  const resolvedGuid=String(k?.guid||guid||'');
  return {
    guid:resolvedGuid,
    title:String(k?.title||op('portal')),
    address:String(k?.address||''),
    imageUrl:String(k?.imageUrl||k?.image||knownPortalImage(resolvedGuid)||''),
    lat:Number(k?.lat??ll[0]),
    lng:Number(k?.lng??ll[1]),
    total:Math.max(0,Math.floor(Number(k?.total??k?.count)||0)),
    locations:k?.locations&&typeof k.locations==='object'?k.locations:{},
    manual:!!k?.manual
  };
}
function applyIgorKeysSnapshot(data){
  const previous=rblKeys(),core=Array.isArray(data?.core)?data.core:[],manual=data?.manual&&typeof data.manual==='object'?data.manual:{};
  const out={};
  // Une synchro C.O.R.E. devient la vérité pour les clés synchronisées. On conserve
  // seulement les ajouts réellement manuels de RBL, afin de ne pas garder des clés fantômes.
  for(const [guid,k] of Object.entries(previous))if(k?.manual||String(guid).startsWith('manual:'))out[guid]=normalizeKeyRecord(k,guid);
  for(const k of core){
    const rec=normalizeKeyRecord(k),old=previous[rec.guid];
    if(rec.guid&&rec.total>0)out[rec.guid]={...old,...rec,manual:false,imageUrl:rec.imageUrl||old?.imageUrl||knownPortalImage(rec.guid)};
  }
  for(const [guid,n] of Object.entries(manual)){
    if(Math.max(0,Number(n)||0)<1)continue;
    const fromIitcKeys=data?.sourceMode==='iitc-keys';
    // Une valeur venant de Keys IITC écrase bien une ancienne valeur synchronisée.
    // Les ajouts purement locaux absents de Keys restent conservés par la boucle précédente.
    out[guid]=normalizeKeyRecord({guid,total:n,title:data?.titles?.[guid]||previous[guid]?.title||'Portail',imageUrl:previous[guid]?.imageUrl||knownPortalImage(guid),locations:data?.locations?.[guid]||previous[guid]?.locations||{},manual:!fromIitcKeys},guid);
  }
  // Enrichissement des clés ajoutées par lien dans RBL : IGOR a résolu le portail
  // depuis Intel/IITC et peut remplacer un identifiant manual:lat,lng par le GUID réel.
  if(Array.isArray(data?.resolvedManual)){
    const prefs=rblKeyPrefs();let prefsChanged=false;
    for(const raw of data.resolvedManual){
      if(!raw||typeof raw!=='object')continue;
      const resolved=normalizeKeyRecord(raw,raw.guid||'');
      const candidates=Object.entries(previous).filter(([,k])=>k?.manual&&(
        String(k.guid||'')===String(raw.guid||'') ||
        (Number.isFinite(Number(k.lat))&&Number.isFinite(Number(k.lng))&&
         Math.abs(Number(k.lat)-Number(raw.lat))<0.00008&&Math.abs(Number(k.lng)-Number(raw.lng))<0.00008)
      ));
      const [oldGuid,oldRec]=candidates[0]||['',null];
      const newGuid=String(resolved.guid||oldGuid||'');
      if(!newGuid)continue;
      const qty=Math.max(0,Number(oldRec?.total??resolved.total)||0);
      const existing=out[newGuid]||{};
      out[newGuid]={...oldRec,...existing,...resolved,total:Math.max(Number(existing.total)||0,qty),manual:!core.some(k=>String(k?.guid||'')===newGuid)};
      if(oldGuid&&oldGuid!==newGuid){
        delete out[oldGuid];
        if(prefs[oldGuid]&&!prefs[newGuid]){prefs[newGuid]=prefs[oldGuid];prefsChanged=true}
        if(prefs[oldGuid]){delete prefs[oldGuid];prefsChanged=true}
      }
    }
    if(prefsChanged)saveRblKeyPrefs(prefs);
  }
  if(Array.isArray(data?.containers)&&data.containers.length)saveRblContainers(data.containers.map(c=>({id:String(c.id||c.name||''),label:String(c.label||c.name||c.id||'Conteneur'),type:String(c.type||'capsule')})));
  saveRblKeys(out);
  localStorage.setItem(RBL_IGOR_LAST_SYNC_KEY,String(Date.now()));
  return out;
}
function parsePortalLinkForKey(raw){
  raw=String(raw||'').trim();if(!raw)return null;let text=raw;
  try{const u0=new URL(raw);const nested=u0.searchParams.get('link');if(nested)text=decodeURIComponent(nested)}catch{};
  try{
    const u=new URL(text),pathGuid=(u.pathname.match(/\/portal\/([^/?#]+)/i)||[])[1],guid=u.searchParams.get('guid')||pathGuid||'',pll=u.searchParams.get('pll')||u.searchParams.get('ll')||'',[lat,lng]=pll.split(',').map(Number);
    if(guid||Number.isFinite(lat)&&Number.isFinite(lng)){
      const resolvedGuid=guid||`manual:${lat.toFixed(6)},${lng.toFixed(6)}`;
      return {guid:resolvedGuid,lat,lng,title:op('manualPortal'),address:'',imageUrl:knownPortalImage(resolvedGuid),total:1,locations:{},manual:true};
    }
  }catch{}
  return null;
}
function keyLocationRows(k){
  const containers=rblContainers(),locations=k?.locations&&typeof k.locations==='object'?k.locations:{},parts=[];let used=0;
  const labelFor=id=>{if(id===''||id==='⌂'||String(id).toLowerCase()==='inventory'||String(id).toLowerCase()==='bag')return 'Sac';const c=containers.find(x=>String(x.id)===String(id)||String(x.label)===String(id));return c?.label||String(id)};
  for(const [id,raw] of Object.entries(locations)){const n=Math.max(0,Math.floor(Number(raw)||0));if(!n)continue;used+=n;parts.push(`<span class="rblKeyLocationChip">${labelFor(id)==='Sac'?'🎒':containers.find(c=>String(c.id)===String(id)&&String(c.type).toUpperCase().includes('KEY'))?'🔐':'📦'} <b>${escapeHtml(labelFor(id))}</b> ${n}</span>`)}
  const remainder=Math.max(0,(Number(k?.total)||0)-used);if(remainder)parts.unshift(`<span class="rblKeyLocationChip">🎒 <b>Sac</b> ${remainder}</span>`);
  return parts.join('')||`<span class="rblKeyLocationChip muted">${escapeHtml(op('locationUnknown'))}</span>`;
}
function rblKeyMinStock(pref){return Math.max(0,Math.floor(Number(pref?.minStock)||0))}
function rblKeyNeedsFarm(k,pref){const min=rblKeyMinStock(pref);return min>0&&Math.max(0,Number(k?.total)||0)<=min}
function renderRblKeys(root){
  const keys=rblKeys(),prefs=rblKeyPrefs(),filter=root.dataset.keyFilter||'all',query=String(root.dataset.keyQuery||'').trim().toLowerCase(),syncPending=rblPendingSync('keys-sync'),body=$('.rblKeysBody',root);if(!body)return;
  const allRows=Object.values(keys).map(k=>normalizeKeyRecord(k,k.guid)).filter(k=>k.guid);
  const favCount=allRows.filter(k=>prefs[k.guid]?.favorite).length;
  const farmCount=allRows.filter(k=>rblKeyNeedsFarm(k,prefs[k.guid]||{})).length;
  const rows=allRows.filter(k=>{
    const pref=prefs[k.guid]||{};
    if(filter==='favorites'&&!pref.favorite)return false;
    if(filter==='farm'&&!rblKeyNeedsFarm(k,pref))return false;
    return true;
  }).sort((a,b)=>{
    const pa=prefs[a.guid]||{},pb=prefs[b.guid]||{};
    const fa=rblKeyNeedsFarm(a,pa),fb=rblKeyNeedsFarm(b,pb);if(fa!==fb)return fb?1:-1;
    if(!!pa.favorite!==!!pb.favorite)return pb.favorite?1:-1;
    return (b.total||0)-(a.total||0)||String(a.title).localeCompare(String(b.title));
  });
  const total=allRows.reduce((a,k)=>a+Math.max(0,Number(k.total)||0),0);
  const card=k=>{
    const pref=prefs[k.guid]||{},minStock=rblKeyMinStock(pref),needsFarm=rblKeyNeedsFarm(k,pref),toSafe=needsFarm?Math.max(1,minStock+1-(Number(k.total)||0)):0;
    const photo=k.imageUrl||ingressItemIcon('portal_key.svg');
    return `<article class="rblKeyCard ${pref.favorite?'favorite':''} ${needsFarm?'farm':''}" data-key-guid="${escapeAttr(k.guid)}" data-key-search="${escapeAttr(rblNormalizeSearchText(`${k.title||''} ${k.address||''}`))}">
      <div class="rblKeyPhotoWrap"><img class="rblKeyPhoto" src="${escapeAttr(photo)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${escapeAttr(ingressItemIcon('portal_key.svg'))}'"><span>🔑 ${k.total||0}</span></div>
      <div class="rblKeyIdentity">
        <b>${escapeHtml(k.title||op('portal'))}</b>
        <small>${escapeHtml(k.address||'')||((Number.isFinite(k.lat)&&Number.isFinite(k.lng))?`${k.lat.toFixed(5)}, ${k.lng.toFixed(5)}`:'')}</small>
        <div class="rblKeyLocations">${keyLocationRows(k)}</div>
        ${minStock?`<div class="rblKeyFarmState ${needsFarm?'need':'done'}"><span>🌱 ${escapeHtml(op('stockMinimum'))} <b>${minStock}</b></span><strong>${needsFarm?escapeHtml(op('farmNeeded',{n:toSafe})):escapeHtml(op('stockEnough'))}</strong></div>`:''}
        <div class="rblKeyQuick">
          <button class="${pref.favorite?'active':''}" data-key-favorite type="button">${pref.favorite?'★':'☆'} ${escapeHtml(op('favorite'))}</button>
          <button class="${minStock?'active':''}" data-key-farm type="button">🌱 ${escapeHtml(minStock?op('minStock'):op('defineMinStock'))}</button>
        </div>
      </div>
      <div class="rblKeyCountCtl"><button data-key-delta="-1" type="button">−</button><strong>${k.total||0}</strong><button data-key-delta="1" type="button">+</button></div>
      ${minStock?`<div class="rblKeyTargetCtl"><button data-target-delta="-1" type="button">−</button><label>${escapeHtml(op('minimum'))}<input data-min-stock inputmode="numeric" value="${minStock}"></label><button data-target-delta="1" type="button">+</button></div>`:''}
    </article>`;
  };
  body.innerHTML=`<section class="rblInvSummary keySummary"><div><small>KEY SYNC</small><b>🔑 ${total}</b><span>${escapeHtml(op('keySummary',{portals:allRows.length,favorites:favCount,farm:farmCount}))}</span></div><button class="primary rblKeySync" ${syncPending?'disabled':''}>${syncPending?op('syncing'):op('syncKeys')}</button></section>
    <section class="rblKeyManual"><h3>${escapeHtml(op('manualKeyTitle'))}</h3><p>${escapeHtml(op('manualKeyText'))}</p><div><input class="rblKeyLink" placeholder="${escapeAttr(op('portalLink'))}"><input class="rblKeyName" placeholder="${escapeAttr(op('portalNameOptional'))}"><button class="primary rblKeyAdd">${escapeHtml(op('add'))}</button></div></section>
    <div class="rblKeyToolbar"><input class="rblKeySearch" type="search" placeholder="${escapeAttr(op('searchPortal'))}" value="${escapeAttr(root.dataset.keyQuery||'')}"><div class="rblKeyFilters"><button data-key-filter="all" class="${filter==='all'?'active':''}">Toutes</button><button data-key-filter="favorites" class="${filter==='favorites'?'active':''}">${escapeHtml(op('favorites'))}</button><button data-key-filter="farm" class="${filter==='farm'?'active':''}">${escapeHtml(op('toFarm'))}</button></div></div>
    <div class="rblKeyDangerZone"><button class="danger rblKeyReset" type="button">${escapeHtml(op('resetKeys'))}</button></div>
    <div class="rblKeyList">${rows.map(card).join('')}<div class="rblModeEmpty rblKeySearchEmpty" ${rows.length?'hidden':''}>${escapeHtml(op('noKeyView'))}</div></div>
    <p class="rblInvLegal">${escapeHtml(op('keysLegal'))}</p>`;
  $('.rblKeySync',body).onclick=()=>{if(rblPendingSync('keys-sync'))return;launchIgor('keys-sync');setTimeout(()=>renderRblKeys(root),40)};
  $('.rblKeyReset',body).onclick=()=>confirmResetIgorData('keys',root);
  $('.rblKeySearch',body).oninput=e=>{root.dataset.keyQuery=e.target.value;applyRblKeySearch(root)};
  applyRblKeySearch(root);
  $$('[data-key-filter]',body).forEach(b=>b.onclick=()=>{root.dataset.keyFilter=b.dataset.keyFilter;renderRblKeys(root)});
  $('.rblKeyAdd',body).onclick=()=>{const rawLink=$('.rblKeyLink',body).value.trim(),rec=parsePortalLinkForKey(rawLink);if(!rec){toast(op('badPortalLink'));return}const name=$('.rblKeyName',body).value.trim();if(name)rec.title=name;rec.sourceUrl=rawLink;const all=rblKeys(),old=all[rec.guid];all[rec.guid]={...old,...rec,imageUrl:rec.imageUrl||old?.imageUrl||knownPortalImage(rec.guid),total:Math.max(1,(Number(old?.total)||0)+1),title:name||old?.title||rec.title};saveRblKeys(all);renderRblKeys(root)};
  $$('[data-key-guid]',body).forEach(row=>{
    const guid=row.dataset.keyGuid;
    $$('[data-key-delta]',row).forEach(b=>b.onclick=()=>{const all=rblKeys(),k=all[guid];if(!k)return;k.total=Math.max(0,(Number(k.total)||0)+(Number(b.dataset.keyDelta)||0));const pref=rblKeyPrefs()[guid]||{};if(!k.total&&!pref.favorite&&!rblKeyMinStock(pref))delete all[guid];saveRblKeys(all);renderRblKeys(root)});
    $('[data-key-favorite]',row)?.addEventListener('click',()=>{const all=rblKeyPrefs(),p=all[guid]||{};p.favorite=!p.favorite;all[guid]=p;saveRblKeyPrefs(all);renderRblKeys(root)});
    $('[data-key-farm]',row)?.addEventListener('click',()=>{const all=rblKeyPrefs(),p=all[guid]||{},k=rblKeys()[guid],cur=rblKeyMinStock(p);if(cur)p.minStock=0;else p.minStock=Math.max(1,Math.min(10,Math.max(1,Number(k?.total)||10)));delete p.farm;delete p.target;all[guid]=p;saveRblKeyPrefs(all);renderRblKeys(root)});
    $$('[data-target-delta]',row).forEach(b=>b.onclick=()=>{const all=rblKeyPrefs(),p=all[guid]||{},cur=rblKeyMinStock(p);p.minStock=Math.max(1,cur+(Number(b.dataset.targetDelta)||0));delete p.farm;delete p.target;all[guid]=p;saveRblKeyPrefs(all);renderRblKeys(root)});
    $('[data-min-stock]',row)?.addEventListener('change',e=>{const all=rblKeyPrefs(),p=all[guid]||{};p.minStock=Math.max(1,Math.floor(Number(e.target.value)||1));delete p.farm;delete p.target;all[guid]=p;saveRblKeyPrefs(all);renderRblKeys(root)});
  });
}
function openRblKeysFloor(){
  const t=elevatorCopy();
  const sh=openLabFloorPage('igor-keys',`<header class="floorTopbar"><div><small>2 // IGOR · KEY SYNC</small><h1>${escapeHtml(t.keysTitle)}</h1><p>${escapeHtml(t.keysTitleSub)}</p></div><div class="floorTopActions"><button class="floorIgorBack" type="button">‹ ${escapeHtml(t.igorRoomBack)}</button>${elevatorButtonHtml('floorLiftBtn')}</div></header><div class="rblKeysBody"></div>`);
  $('.floorIgorBack',sh).onclick=openIgorFloor;$('.floorLiftBtn',sh).onclick=returnToLabElevator;renderRblKeys(sh);
}
function applyIgorInventorySnapshot(data){
  const now=Date.now();
  if(!data?.available||!data.snapshot){const msg=String(data?.message||op('coreUnavailable'));localStorage.setItem(RBL_IGOR_SYNC_STATUS_KEY,JSON.stringify({ok:false,at:now,message:msg,diagnostic:data?.diagnostic||{}}));toast(op('inventoryNotSynced'));setTimeout(openRblInventoryFloor,120);return false}
  const counts=coreSnapshotToCounts(data.snapshot),n=rblInventoryItemsTotal(counts);saveRblInventoryCounts(counts);
  if(Array.isArray(data.snapshot.containers))saveRblContainers(data.snapshot.containers.map(c=>({id:String(c.id||c.name||''),label:String(c.label||c.name||c.id||'Conteneur'),type:String(c.type||'capsule')})));
  // TEST-27 : getInventory ne met à jour QUE le matériel. Les clés ont leur propre synchro Keys/IITC.
  localStorage.setItem(RBL_IGOR_LAST_SYNC_KEY,String(now));localStorage.setItem(RBL_IGOR_SYNC_STATUS_KEY,JSON.stringify({ok:true,at:now,message:op('coreObjectsReceived',{n})}));toast(op('inventorySynced',{n}));setTimeout(openRblInventoryFloor,120);return true;
}

function loadBannerFavorites(){
  try{const x=JSON.parse(localStorage.getItem(BANNER_FAVORITES_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}
}
function saveBannerFavorites(items){localStorage.setItem(BANNER_FAVORITES_KEY,JSON.stringify(items.slice(0,120)));markBackupChanged()}
function isBannerFavorite(id){return loadBannerFavorites().some(x=>String(x.id)===String(id))}
function favoriteBanner(detail){
  const list=loadBannerFavorites().filter(x=>String(x.id)!==String(detail.id));
  list.unshift(compactBanner(detail));saveBannerFavorites(list);return true;
}
function unfavoriteBanner(id){saveBannerFavorites(loadBannerFavorites().filter(x=>String(x.id)!==String(id)))}
function compactBanner(detail){
  return {
    id:String(detail?.id||''),title:String(detail?.title||tr('unnamed')),
    formattedAddress:String(detail?.formattedAddress||''),lengthMeters:Number(detail?.lengthMeters||0)||0,
    numberOfMissions:Number(detail?.numberOfMissions||detail?.missions?.length||0)||0,
    numberOfDisabledMissions:Number(detail?.numberOfDisabledMissions||0)||0,
    picture:String(detail?.picture||''),author:String(detail?.author||'')
  };
}
function loadBannerTodo(){try{const x=JSON.parse(localStorage.getItem(BANNER_TODO_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function saveBannerTodo(items){localStorage.setItem(BANNER_TODO_KEY,JSON.stringify((items||[]).slice(0,160)));markBackupChanged()}
function isBannerTodo(id){return loadBannerTodo().some(x=>String(x.id)===String(id))}
function addBannerTodo(detail){const list=loadBannerTodo().filter(x=>String(x.id)!==String(detail.id));list.unshift(compactBanner(detail));saveBannerTodo(list)}
function removeBannerTodo(id){saveBannerTodo(loadBannerTodo().filter(x=>String(x.id)!==String(id)))}
function loadPlayHistory(){try{const x=JSON.parse(localStorage.getItem(PLAY_HISTORY_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return[]}}
function savePlayHistory(items){localStorage.setItem(PLAY_HISTORY_KEY,JSON.stringify((items||[]).slice(0,100)));markBackupChanged()}
function upsertPlayHistory(session,extra={}){
  if(!session?.bannerId)return;
  const list=loadPlayHistory();const key=String(session.bannerId);
  const old=list.find(x=>String(x.bannerId)===key)||{};
  const rec={...old,...compactBanner({id:session.bannerId,title:session.title,formattedAddress:session.address,picture:session.picture,author:session.author,lengthMeters:session.lengthMeters,numberOfMissions:session.missions?.length}),
    bannerId:key,currentIndex:Number(extra.currentIndex??session.currentIndex??old.currentIndex??0)||0,
    doneCount:Number(extra.doneCount??old.doneCount??0)||0,total:Number(session.missions?.length||old.total||0)||0,
    startedAt:Number(extra.startedAt??session.startedAt??old.startedAt??Date.now())||Date.now(),
    finishedAt:Number(extra.finishedAt??old.finishedAt??0)||0,pausedTotal:Number(extra.pausedTotal??old.pausedTotal??0)||0,
    paused:!!(extra.paused??old.paused),updatedAt:Date.now()};
  const out=[rec,...list.filter(x=>String(x.bannerId)!==key)].sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));savePlayHistory(out);return rec;
}
function activeDurationMs(x){
  const start=Number(x?.startedAt||0);if(!start)return 0;
  const end=Number(x?.finishedAt||Date.now());let paused=Number(x?.pausedTotal||0)||0;
  if(x?.paused&&x?.pausedAt)paused+=Math.max(0,Date.now()-Number(x.pausedAt));
  return Math.max(0,end-start-paused);
}
function formatPlayDuration(ms){
  const min=Math.floor(Math.max(0,ms)/60000),h=Math.floor(min/60),m=min%60;
  return h?`${h} h ${String(m).padStart(2,'0')}`:`${m} min`;
}
function formatPlayDate(ts){if(!ts)return '—';const locale=appLocale();return new Date(ts).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'})}
function estimatedPlayedMeters(entry){const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1));return (Number(entry?.lengthMeters||0)||0)*Math.min(1,(Number(entry?.doneCount||0)||0)/total)}
function bannergressImage(picture=''){
  if(!picture)return '';
  return /^https?:/i.test(picture)?picture:`${BANNERGRESS_API}${picture.startsWith('/')?'':'/'}${picture}`;
}
function formatBannerDistance(meters){
  const m=Number(meters)||0;if(!m)return '—';return `${(m/1000).toFixed(m>=10000?0:1).replace('.',',')} km`;
}

function formatBannerMeters(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  if(m<1000)return `${Math.round(m)} m`;
  return `${(m/1000).toFixed(m<10000?2:1).replace('.',',')} km`;
}
function formatWalkSeconds(seconds){
  const total=Math.max(0,Math.round(Number(seconds)||0));
  if(!total)return '—';
  const minutes=Math.max(1,Math.round(total/60));
  if(minutes<60)return tr('minutesShort',{n:minutes});
  const h=Math.floor(minutes/60),m=minutes%60;
  return tr('hoursMinutes',{h,m:String(m).padStart(2,'0')});
}
function formatWalkEstimate(meters){
  const m=Number(meters)||0;
  if(!m)return '—';
  return formatWalkSeconds((m/4800)*3600);
}
function bannerRouteRows(detail){
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  return missions.map((m,index)=>{
    const route=Array.isArray(m?.route)?m.route.filter(p=>Number.isFinite(Number(p?.latitude))&&Number.isFinite(Number(p?.longitude))):[];
    let meters=0,longestLeg=0;
    for(let i=1;i<route.length;i++){
      const d=haversine(route[i-1],route[i]);
      meters+=d;
      longestLeg=Math.max(longestLeg,d);
    }
    return {index,route,meters,longestLeg,title:m?.title||tr('missionStart',{n:index+1})};
  });
}
function bannerFunStats(detail){
  const missionRows=bannerRouteRows(detail);
  const missions=Array.isArray(detail?.missions)?detail.missions:[];
  const withRoute=missionRows.filter(x=>x.route.length);
  const routeMeters=missionRows.reduce((s,x)=>s+x.meters,0);
  let transitionMeters=0,longestTransition=0;
  for(let i=1;i<withRoute.length;i++){
    const prev=withRoute[i-1].route.at(-1),next=withRoute[i].route[0];
    const d=haversine(prev,next);
    transitionMeters+=d;
    longestTransition=Math.max(longestTransition,d);
  }
  const geometricMeters=routeMeters+transitionMeters;
  const bgMeters=Number(detail?.lengthMeters||0)||0;

  const allPoints=missionRows.flatMap(x=>x.route);
  const uniqueKeys=new Set(allPoints.map(p=>`${Number(p.latitude).toFixed(5)},${Number(p.longitude).toFixed(5)}`));
  const uniquePlaces=uniqueKeys.size;
  const repeated=Math.max(0,allPoints.length-uniquePlaces);

  let longestMission=null,longestLeg=0;
  for(const row of missionRows){
    if(!longestMission||row.meters>longestMission.meters)longestMission=row;
    longestLeg=Math.max(longestLeg,row.longestLeg);
  }

  const start=allPoints[0]||null,end=allPoints.at(-1)||null;
  const straight=start&&end?haversine(start,end):0;
  const missionCount=Math.max(1,missions.length);
  const mappedMissionCount=withRoute.length;
  const coverage=missions.length?Math.round(mappedMissionCount/missions.length*100):0;

  return {
    bgMeters,routeMeters,transitionMeters,geometricMeters,
    points:allPoints.length,uniquePlaces,repeated,
    avgMission:routeMeters/missionCount,
    longestMission,longestLeg,longestTransition,
    straight,coverage,mappedMissionCount,totalMissions:missions.length,
    missionRows
  };
}
function bannerWalkSignature(detail){
  const rows=bannerRouteRows(detail);
  return JSON.stringify(rows.flatMap(r=>r.route.map(p=>[
    r.index,
    Number(p.latitude).toFixed(6),
    Number(p.longitude).toFixed(6)
  ])));
}
function bannerWalkCacheKey(detail){
  const id=String(detail?.id??detail?.bannerId??'unknown').replace(/[^a-zA-Z0-9_.:-]/g,'_');
  return `${BANNER_WALK_CACHE_PREFIX}${id}`;
}
function loadBannerWalkCache(detail){
  try{
    const x=JSON.parse(localStorage.getItem(bannerWalkCacheKey(detail))||'null');
    if(x?.sig===bannerWalkSignature(detail)&&x?.walking)return x.walking;
  }catch{}
  return null;
}
function saveBannerWalkCache(detail,walking){
  try{
    localStorage.setItem(bannerWalkCacheKey(detail),JSON.stringify({
      sig:bannerWalkSignature(detail),
      walking,
      at:Date.now()
    }));
  }catch{}
}
async function fetchValhallaWalkingChunk(chunk){
  const lang=appLocale();
  const body={
    locations:chunk.map(x=>({
      lat:Number(x.point.latitude),
      lon:Number(x.point.longitude),
      type:'break'
    })),
    costing:'pedestrian',
    units:'kilometers',
    directions_options:{units:'kilometers',language:lang}
  };

  let data,status=0,transport='web';

  if(Capacitor.isNativePlatform()){
    transport='native';
    const response=await CapacitorHttp.post({
      url:VALHALLA_API,
      headers:{
        'Content-Type':'application/json',
        'Accept':'application/json',
        'X-Client-Id':'redacted-bannerlab'
      },
      data:body,
      connectTimeout:18000,
      readTimeout:18000,
      responseType:'json'
    });
    status=Number(response?.status)||0;
    data=response?.data;
    if(typeof data==='string'){
      try{data=JSON.parse(data)}catch{}
    }
  }else{
    // Browser/web fallback. GET with encoded json stays a simple request
    // and avoids the JSON POST preflight that can be blocked by CORS.
    const ctrl=new AbortController();
    const timer=setTimeout(()=>ctrl.abort(),18000);
    try{
      const url=`${VALHALLA_API}?json=${encodeURIComponent(JSON.stringify(body))}`;
      const response=await fetch(url,{
        method:'GET',
        headers:{'Accept':'application/json'},
        signal:ctrl.signal
      });
      status=response.status;
      if(response.ok)data=await response.json();
      else{
        let msg='';
        try{msg=await response.text()}catch{}
        throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg.slice(0,120)}`:''}`);
      }
    }finally{
      clearTimeout(timer);
    }
  }

  if(status<200||status>=300){
    const msg=data?.error||data?.error_code||data?.status_message||'';
    throw new Error(`Valhalla HTTP ${status}${msg?` · ${msg}`:''}`);
  }

  const legs=data?.trip?.legs||[];
  if(legs.length!==Math.max(0,chunk.length-1)){
    const msg=data?.error||data?.status_message||'incomplete route';
    throw new Error(`Valhalla ${msg} · ${legs.length}/${Math.max(0,chunk.length-1)} legs`);
  }

  return legs.map(leg=>({
    meters:(Number(leg?.summary?.length)||0)*1000,
    seconds:Number(leg?.summary?.time)||0,
    transport
  }));
}
async function calculateBannerWalkingStats(detail,{force=false}={}){
  const direct=bannerFunStats(detail);
  const flat=[];
  direct.missionRows.forEach(row=>{
    row.route.forEach((point,pointIndex)=>flat.push({
      point,
      missionIndex:row.index,
      pointIndex,
      title:point?.title||row.title||`M${row.index+1}`
    }));
  });
  if(flat.length<2)throw new Error(tr('statsUnavailable'));

  if(!force){
    const cached=loadBannerWalkCache(detail);
    if(cached)return {...cached,cached:true};
  }

  const missionMeters=Array.from({length:direct.totalMissions},()=>0);
  const missionSeconds=Array.from({length:direct.totalMissions},()=>0);
  let totalMeters=0,totalSeconds=0,transitionMeters=0,transitionSeconds=0;
  let rawValhallaMeters=0,rawValhallaSeconds=0;
  let correctedLegs=0,tooShortLegs=0,absurdDetourLegs=0;
  let longestLegMeters=0,longestLegNames=null;
  let transport=Capacitor.isNativePlatform()?'native':'web';

  let cursor=0;
  while(cursor<flat.length-1){
    const end=Math.min(flat.length,cursor+VALHALLA_MAX_POINTS);
    const chunk=flat.slice(cursor,end);
    const legs=await fetchValhallaWalkingChunk(chunk);
    if(legs[0]?.transport)transport=legs[0].transport;

    legs.forEach((leg,i)=>{
      const a=chunk[i],b=chunk[i+1];
      const directMeters=haversine(a.point,b.point);
      const rawMeters=Math.max(0,Number(leg.meters)||0);
      const rawSeconds=Math.max(0,Number(leg.seconds)||0);

      rawValhallaMeters+=rawMeters;
      rawValhallaSeconds+=rawSeconds;

      let acceptedMeters=rawMeters;
      let acceptedSeconds=rawSeconds;

      // Same portal / nearly identical coordinate: no meaningful walking.
      if(directMeters<3){
        acceptedMeters=0;
        acceptedSeconds=0;
        if(rawMeters>15)correctedLegs++;
      }else{
        // A pedestrian-network route cannot realistically be much shorter
        // than straight-line centre-to-centre distance. This catches bad
        // snapping/correlation shortcuts.
        const impossibleShortcut=rawMeters < directMeters*0.88;

        // Catch isolated OSM/Valhalla detours without throwing away the whole
        // banner. The additive allowance is important for rivers, stations,
        // parks and other genuine obstacles.
        const maxPlausible=Math.max(directMeters*4,directMeters+350);
        const absurdDetour=rawMeters > maxPlausible;

        if(impossibleShortcut || absurdDetour || !rawMeters){
          acceptedMeters=directMeters;
          acceptedSeconds=(directMeters/4800)*3600;
          correctedLegs++;
          if(impossibleShortcut)tooShortLegs++;
          if(absurdDetour)absurdDetourLegs++;
        }
      }

      totalMeters+=acceptedMeters;
      totalSeconds+=acceptedSeconds;

      if(a.missionIndex===b.missionIndex){
        missionMeters[a.missionIndex]=(missionMeters[a.missionIndex]||0)+acceptedMeters;
        missionSeconds[a.missionIndex]=(missionSeconds[a.missionIndex]||0)+acceptedSeconds;
      }else{
        transitionMeters+=acceptedMeters;
        transitionSeconds+=acceptedSeconds;
      }

      if(acceptedMeters>longestLegMeters){
        longestLegMeters=acceptedMeters;
        longestLegNames=[a.title||'Portal',b.title||'Portal'];
      }
    });

    if(end>=flat.length)break;
    cursor=end-1;
    await new Promise(r=>setTimeout(r,160));
  }

  let longestMission=null;
  missionMeters.forEach((meters,index)=>{
    if(meters>0&&(!longestMission||meters>longestMission.meters)){
      longestMission={index,meters,seconds:missionSeconds[index]||0};
    }
  });

  const walking={
    totalMeters,totalSeconds,
    transitionMeters,transitionSeconds,
    missionMeters,missionSeconds,
    longestLegMeters,longestLegNames,longestMission,
    rawValhallaMeters,rawValhallaSeconds,
    correctedLegs,tooShortLegs,absurdDetourLegs,
    source:'valhalla-sanitized',
    transport
  };
  saveBannerWalkCache(detail,walking);
  return walking;
}
function bannerFunStatsHtml(detail,{compact=false,walking=null,routingError=false,loading=false}={}){
  const s=bannerFunStats(detail);
  if(!s.points&&!s.bgMeters)return `<div class="bannerStatsUnavailable">${tr('statsUnavailable')}</div>`;

  const effectiveMeters=walking?.totalMeters||s.geometricMeters||s.bgMeters;
  const effectiveSeconds=walking?.totalSeconds||0;
  const directKmBase=s.geometricMeters;
  const networkDetour=walking&&directKmBase>0?walking.totalMeters/directKmBase:null;

  const longestMission=walking?.longestMission?.meters>0
    ? `${tr('missionShort',{n:walking.longestMission.index+1})} · ${formatBannerMeters(walking.longestMission.meters)}`
    : s.longestMission&&s.longestMission.meters>0
      ? `${tr('missionShort',{n:s.longestMission.index+1})} · ${formatBannerMeters(s.longestMission.meters)}`
      : '—';

  const avgMission=walking?.missionMeters?.length
    ? walking.missionMeters.reduce((a,b)=>a+(Number(b)||0),0)/Math.max(1,s.totalMissions)
    : s.avgMission;

  const longestLeg=walking?.longestLegMeters||s.longestLeg;
  const between=walking?.transitionMeters??s.transitionMeters;
  const stepsPerKm=effectiveMeters>0?s.points/(effectiveMeters/1000):0;

  const items=[
    [tr('bgDistance'),formatBannerDistance(s.bgMeters),'🛣'],
    [tr('calculatedTrack'),loading?'…':formatBannerMeters(walking?.totalMeters||s.geometricMeters),'🚶'],
    [tr('walkingEstimate'),loading?'…':(walking?formatWalkSeconds(effectiveSeconds):formatWalkEstimate(effectiveMeters)),'⏱'],
    [tr('directGeometric'),formatBannerMeters(s.geometricMeters),'〰'],
    [tr('routeSteps'),String(s.points),'◉'],
    [tr('uniquePlaces'),String(s.uniquePlaces),'⌖'],
    [tr('revisitedPlaces'),String(s.repeated),'↻'],
    [tr('stepsPerKm'),stepsPerKm?String(stepsPerKm.toFixed(1)).replace('.',','):'—','⋮'],
    [tr('avgMissionDistance'),formatBannerMeters(avgMission),'÷'],
    [tr('longestMission'),longestMission,'🏆'],
    [tr('longestLeg'),formatBannerMeters(longestLeg),'↔'],
    [tr('betweenMissions'),formatBannerMeters(between),'⇢'],
    [tr('routingDetour'),networkDetour?tr('xFactor',{n:networkDetour.toFixed(2).replace('.',',')}):'—','🌀'],
    [tr('straightLine'),formatBannerMeters(s.straight),'⌁'],
    [tr('routeCoverage'),`${s.coverage} %`,'◫'],
    [tr('correctedLegs'),walking?`${walking.correctedLegs||0}`:'—','⚙'],
    [tr('rawValhalla'),walking?formatBannerMeters(walking.rawValhallaMeters):'—','V'],
    [tr('routingSource'),walking
      ?(walking.transport==='native'?tr('routingNative'):tr('routingWeb'))
      :(routingError?tr('routingFallback'):tr('routingLoading')),'OSM']
  ];

  const shown=compact
    ? [items[0],items[1],items[2],items[7],items[9],items[15]]
    : items;

  return `<div class="bannerFunStats ${compact?'compact':''} ${walking?'walkRouted':''}">
    <div class="bannerFunStatsTitle"><span>📊</span><b>${tr('uselessStats')}</b>${walking?.cached?'<em>cache</em>':''}</div>
    <div class="bannerFunStatsGrid">${shown.map(([label,value,ico])=>`<div><i>${ico}</i><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>
    ${routingError?`<div class="bannerRoutingWarn">${tr('routingFailed')}${typeof routingError==='string'?`<small>${escapeHtml(tr('routingErrorDetail',{error:routingError}))}</small>`:''}</div>`:''}
    ${compact?'':`<small>${tr('funStatsDisclaimer')}</small>`}
  </div>`;
}
async function renderBannerWalkingStats(panel,detail,{compact=false}={}){
  if(!panel)return;
  panel.innerHTML=bannerFunStatsHtml(detail,{compact,loading:true});
  try{
    const walking=await calculateBannerWalkingStats(detail);
    panel.innerHTML=bannerFunStatsHtml(detail,{compact,walking});
    return walking;
  }catch(e){
    console.warn('[Banner walking stats]',e);
    panel.innerHTML=bannerFunStatsHtml(detail,{
      compact,
      routingError:String(e?.message||e||'unknown error')
    });
    return null;
  }
}
async function toggleSearchBannerStats(button,summary){
  const wrap=button.closest('.bannergressCardWrap');
  const panel=wrap?.querySelector('.bannerSearchStats');
  if(!panel)return;
  const opening=panel.hidden;
  if(!opening){
    panel.hidden=true;
    button.textContent=tr('showUselessStats');
    return;
  }
  panel.hidden=false;
  button.disabled=true;
  button.textContent=tr('routingLoading');
  panel.innerHTML=`<div class="loadingInline">${tr('routingLoading')}</div>`;
  try{
    const detail=await fetchBannerDetail(summary);
    await renderBannerWalkingStats(panel,detail,{compact:true});
    button.textContent=tr('hideUselessStats');
  }catch(e){
    panel.innerHTML=`<div class="bannerStatsUnavailable">${escapeHtml(tr('bannerLoadError',{error:e?.message||e}))}</div>`;
    button.textContent=tr('showUselessStats');
  }finally{
    button.disabled=false;
  }
}
function bindBannerList(container,list,onOpen){
  $$('.bannergressCard',container).forEach(btn=>{
    btn.onclick=()=>{
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerId));
      if(b)(onOpen||openBannerDetail)(b);
    };
  });
  $$('.bannerStatsBtn',container).forEach(btn=>{
    btn.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const b=list.find(x=>String(x.id)===String(btn.dataset.bannerStatsId));
      if(b)toggleSearchBannerStats(btn,b);
    };
  });
}
function unwrapBannerSearch(raw){
  if(Array.isArray(raw))return raw;
  for(const candidate of [raw?.items,raw?.banners,raw?.results,raw?.data]){
    if(Array.isArray(candidate))return candidate;
    if(candidate&&typeof candidate==='object'){
      for(const key of ['banners','items','results'])if(Array.isArray(candidate[key]))return candidate[key];
    }
  }
  return [];
}
function normalizeGeoPoint(p){
  if(!p)return null;
  const lat=Number(p.latitude??p.lat??p.location?.latitude??p.location?.lat);
  const lng=Number(p.longitude??p.lng??p.lon??p.location?.longitude??p.location?.lng??p.location?.lon);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  return {latitude:lat,longitude:lng,title:String(p.title??p.name??p.portalTitle??'')};
}
function normalizeMissionList(raw){
  let list=raw?.items?.missions??raw?.missions??raw?.banner?.items?.missions??raw?.banner?.missions??[];
  if(!Array.isArray(list)&&list&&typeof list==='object')list=Object.values(list);
  if(!Array.isArray(list))return [];
  const normalized=list.map((m,i)=>{
    let steps=m?.steps??m?.waypoints??m?.points??[];
    if(!Array.isArray(steps)&&steps&&typeof steps==='object')steps=Object.values(steps);
    const route=(Array.isArray(steps)?steps:[]).map(s=>normalizeGeoPoint(s?.poi??s?.portal??s?.point??s)).filter(Boolean);
    const direct=normalizeGeoPoint(m?.startPoint??m?.startPoi??m?.poi);
    if(!route.length&&direct)route.push(direct);
    return {
      id:String(m?.id??m?.missionId??m?.guid??'').trim(),
      title:String(m?.title??m?.name??m?.missionTitle??tr('missionLabel',{n:i+1})),
      order:Number(m?.order??m?.sequence??m?.position??m?.index??i),route
    };
  }).filter(m=>m.id);
  if(normalized.every(x=>Number.isFinite(x.order)))normalized.sort((a,b)=>a.order-b.order);
  return normalized.map(({id,title,route})=>({id,title,route}));
}
function normalizeBannerInfo(value){
  if(value==null)return '';
  if(typeof value==='string'||typeof value==='number')return String(value).trim();
  if(Array.isArray(value))return value.map(normalizeBannerInfo).filter(Boolean).join('\n').trim();
  if(typeof value==='object'){
    for(const key of ['text','value','content','description','info','bannerInfo']){
      const v=normalizeBannerInfo(value[key]);
      if(v)return v;
    }
  }
  return '';
}
function normalizeBannerDetail(raw,fallback={}){
  const b=raw?.banner??raw?.item??raw?.data?.banner??raw?.data??raw??{};
  const source={...fallback,...b};
  const missions=normalizeMissionList(raw);
  // Bannergress exposes the text shown as “Banner info” as `description`
  // on GET /bnrs/{id}. Do not let an empty bannerInfo from the search
  // summary mask the detailed description ('' is not nullish, so `??`
  // was the wrong tool here). Always pick the first genuinely non-empty
  // value, with the freshly fetched banner taking priority over fallback data.
  const bannerInfo=[
    b?.description,b?.bannerInfo,b?.banner_info,b?.info,
    raw?.description,raw?.bannerInfo,raw?.banner_info,raw?.info,
    fallback?.description,fallback?.bannerInfo,fallback?.banner_info,fallback?.info
  ].map(normalizeBannerInfo).find(Boolean)||'';
  return {
    id:String(source.id??fallback.id??''),
    title:String(source.title??fallback.title??tr('unnamed')),
    formattedAddress:String(source.formattedAddress??source.address??fallback.formattedAddress??''),
    lengthMeters:Number(source.lengthMeters??fallback.lengthMeters??0)||0,
    numberOfMissions:Number(source.numberOfMissions??missions.length??fallback.numberOfMissions??0)||missions.length,
    numberOfDisabledMissions:Number(source.numberOfDisabledMissions??fallback.numberOfDisabledMissions??0)||0,
    picture:String(source.picture??fallback.picture??''),
    author:String(source.author??source.authorName??source.creator?.name??source.agent?.name??fallback.author??''),
    bannerInfo,
    startPoint:normalizeGeoPoint(source.startPoint??source.startPoi??source.startLocation??source.location??((source.startPointLatitude??source.startLatitude)!=null?{latitude:source.startPointLatitude??source.startLatitude,longitude:source.startPointLongitude??source.startLongitude}:null)??fallback.startPoint),
    searchDistanceMeters:Number.isFinite(Number(source.searchDistanceMeters??fallback.searchDistanceMeters))?Number(source.searchDistanceMeters??fallback.searchDistanceMeters):null,
    missions
  };
}
async function fetchBannerDetail(summary){
  if(summary?.missions?.length&&summary.missions.some(m=>m?.route?.length)&&String(summary?.bannerInfo??'').trim())return summary;
  const r=await fetch(`${BANNERGRESS_API}/bnrs/${encodeURIComponent(summary.id??summary.bannerId)}`,{headers:{Accept:'application/json'}});
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return normalizeBannerDetail(await r.json(),summary);
}
function ingressMissionUrl(id){
  const intel=`https://intel.ingress.com/mission/${id}`;
  const p=new URLSearchParams({link:intel,apn:'com.nianticproject.ingress',isi:'576505181',ibi:'com.google.ingress',ifl:'https://apps.apple.com/app/ingress/id576505181',ofl:intel});
  return `https://link.ingress.com/?${p.toString()}`;
}
async function openIngressMission(id){
  if(!id)return;
  const url=ingressMissionUrl(id);
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:url,packageName:'com.nianticproject.ingress'});
    else await AppLauncher.openUrl({url});
  }catch{
    try{await AppLauncher.openUrl({url})}catch(e){console.warn('Ingress deeplink',e)}
  }
}
function savePlaySession(session){localStorage.setItem(PLAY_SESSION_KEY,JSON.stringify(session));markBackupChanged()}
function loadPlaySession(){try{return JSON.parse(localStorage.getItem(PLAY_SESSION_KEY)||'null')}catch{return null}}
function redactedOverlayEnabled(){return localStorage.getItem(REDACTED_OVERLAY_KEY)==='1'}
function redactedOverlayFaction(){return localStorage.getItem(REDACTED_FACTION_KEY)==='RES'?'RES':'ENL'}
function setRedactedOverlayFactionLocal(v){const f=v==='RES'?'RES':'ENL';localStorage.setItem(REDACTED_FACTION_KEY,f);return f}
async function redactedOverlayNativeState(){
  if(!Capacitor.isNativePlatform())return {active:false};
  try{return await MissionOverlay.getRedactedState()}catch(e){console.warn('[Redacted overlay state]',e);return {active:false}}
}
async function ensureRedactedOverlayRunning(){
  if(!Capacitor.isNativePlatform()||!redactedOverlayEnabled())return false;
  try{
    const p=await MissionOverlay.hasPermission();if(!p?.granted)return false;
    const st=await redactedOverlayNativeState();if(!st?.active)await MissionOverlay.startRedacted({faction:redactedOverlayFaction()});
    return true;
  }catch(e){console.warn('[Redacted overlay resume]',e);return false}
}
async function disableRedactedOverlay(){
  localStorage.setItem(REDACTED_OVERLAY_KEY,'0');
  try{if(Capacitor.isNativePlatform())await MissionOverlay.stopRedacted()}catch(e){console.warn('[Redacted overlay stop]',e)}
}
async function enableRedactedOverlayNow(){
  if(!Capacitor.isNativePlatform())return false;
  const p=await MissionOverlay.hasPermission();if(!p?.granted)return false;
  localStorage.setItem(REDACTED_OVERLAY_KEY,'1');
  const st=await redactedOverlayNativeState();
  await MissionOverlay.startRedacted({state:st?.state||'MAP',faction:redactedOverlayFaction()});
  return true;
}

const PRIME_HUD_COMPONENTS=[
  {id:'neon',labelText:'Cadre néon Lab',hintText:'Indépendant : vert ENL ou bleu RES. Peut être utilisé tout seul.',emoji:'◫'},
  {id:'sensorProfile',labelText:'Micro-capteur · Profil 1/2',hintText:'Premier accès au Profil depuis le Scanner.',emoji:'·'},
  {id:'sensorProfile2',labelText:'Micro-capteur · Profil 2/2',hintText:'Second accès au Profil depuis le Scanner.',emoji:'·'},
  {id:'sensorAction',labelText:'Micro-capteurs · Swipes ACTION',hintText:'Quelques pixels seulement au point de départ des swipes.',emoji:'⇆'},
  {id:'sensorInventoryDirect',labelText:'Micro-capteur · Accès direct Inventaire',hintText:'Bouton Inventaire du Scanner, en plus du swipe gauche.',emoji:'▱'},
  {id:'sensorCommDirect',labelText:'Micro-capteur · COMM 1/2',hintText:'Premier accès direct COMM, en plus du swipe droit.',emoji:'◉'},
  {id:'sensorCommDirect2',labelText:'Micro-capteur · COMM 2/2',hintText:'Second accès direct COMM, en plus du swipe droit.',emoji:'◉'},
  {id:'sensorProfileBack',labelText:'Micro-capteur · Retour Profil',hintText:'Détecte le retour depuis le Profil.',emoji:'·'},
  {id:'sensorInventoryBack',labelText:'Micro-capteur · Fermer Inventaire',hintText:'Détecte la fermeture de l’Inventaire.',emoji:'·'},
  {id:'sensorAttackBack',labelText:'Micro-capteur · Fermer Action',hintText:'Détecte la fermeture de l’écran Action.',emoji:'·'},
  {id:'sensorCommBack',labelText:'Micro-capteur · Retour COMM',hintText:'Détecte le retour depuis COMM.',emoji:'·'},
  {id:'visualRedacted',labelText:'REDACTED · visuel Scanner',hintText:'Se place exactement où tu veux et laisse 100 % des clics passer derrière.',icon:'/redacted-dino-cutout.png'},
  {id:'visualIgor',labelText:'IGOR · visuel Profil',hintText:'Décoration totalement traversante dans le Profil.',icon:'/igor.webp'},
  {id:'visualMilo',labelText:'MILO · visuel Inventaire',hintText:'Décoration totalement traversante dans l’Inventaire.',icon:'/arcade/milo.webp'},
  {id:'visualLeon',labelText:'LEON · visuel Action',hintText:'Décoration totalement traversante dans l’écran Action.',icon:'/leon.webp'},
  {id:'visualRita',labelText:'RITA · visuel COMM',hintText:'Décoration totalement traversante dans COMM.',icon:'/rita.webp'},
  {id:'visualStateBeacon',labelText:'Balise de niveau dynamique',hintText:'Affiche clairement SCANNER / PROFIL / INVENTAIRE / ACTION. Totalement traversante.',emoji:'●'},
  {id:'visualPulse',labelText:'Voyant lumineux du Lab',hintText:'Petit point néon décoratif déplaçable, traversant.',emoji:'✦'},
  {id:'visualSecret',labelText:'Marqueur secret du Lab',hintText:'Petit symbole discret à cacher où tu veux dans Prime.',emoji:'⌬'},
  {id:'visualCrosshair',labelText:'Viseur du Lab',hintText:'Petit réticule néon purement décoratif et traversant.',emoji:'⌖'},
  {id:'visualScanline',labelText:'Scanline technique',hintText:'Petite barre SCAN décorative, librement plaçable.',emoji:'━'},
  {id:'visualCode',labelText:'Étiquette RBL // LIVE',hintText:'Mini code technique traversant à cacher dans un coin.',emoji:'R'},
  {id:'visualCorner',labelText:'Coin technique lumineux',hintText:'Petit angle néon à poser comme détail du Lab.',emoji:'⌟'},
  {id:'visualTubeH',labelText:'Tube lumineux horizontal',hintText:'Tube de labo néon à poser le long d’un bord.',emoji:'━'},
  {id:'visualTubeV',labelText:'Tube lumineux vertical',hintText:'Tube de labo vertical, fin et brillant.',emoji:'┃'},
  {id:'visualLiquidTube',labelText:'Tube de fluide',hintText:'Éprouvette lumineuse avec fluide animé façon Lab.',emoji:'▥'},
  {id:'visualCable',labelText:'Câble technique',hintText:'Petit bout de câble et connecteurs à laisser traîner.',emoji:'⌁'},
  {id:'visualCableCoil',labelText:'Bobine de câble',hintText:'Câble enroulé, purement décoratif et traversant.',emoji:'◎'},
  {id:'visualScreen',labelText:'Écran diagnostic',hintText:'Mini écran technique avec état du système.',emoji:'▣'},
  {id:'visualTerminal',labelText:'Terminal du Lab',hintText:'Petit terminal avec lignes de données.',emoji:'▤'},
  {id:'visualCalculator',labelText:'Calculatrice de LEON',hintText:'Mini calculatrice AP/chiffres du Lab.',emoji:'▦'},
  {id:'visualScope',labelText:'Oscilloscope',hintText:'Courbe lumineuse façon banc de test.',emoji:'⌁'},
  {id:'visualGauge',labelText:'Cadran analogique',hintText:'Petit cadran de mesure scientifique.',emoji:'◴'},
  {id:'visualSegments',labelText:'Afficheur 7 segments',hintText:'Chiffres techniques lumineux.',emoji:'88'},
  {id:'visualRadar',labelText:'Mini radar',hintText:'Radar de détection du Lab.',emoji:'◉'},
  {id:'visualBattery',labelText:'Barre de charge',hintText:'Indicateur d’énergie décoratif.',emoji:'▰'},
  {id:'visualWarning',labelText:'Plaque haute tension',hintText:'Petit avertissement technique du Lab.',emoji:'⚡'},
  {id:'visualVent',labelText:'Grille d’aération',hintText:'Petit morceau de grille métallique.',emoji:'▥'},
  {id:'visualAntenna',labelText:'Antenne RITA',hintText:'Mini antenne et ondes de transmission.',emoji:'⌁'},
  {id:'visualData',labelText:'Flux de données',hintText:'Quelques lignes de données qui défilent.',emoji:'≡'},
  {id:'visualReactor',labelText:'Mini réacteur',hintText:'Petit cœur lumineux de laboratoire.',emoji:'◉'},
  {id:'visualBolts',labelText:'Plaque rivetée',hintText:'Vis, rivets et plaque technique pour habiller un coin.',emoji:'∷'}
]
async function openPrimeHudSelectionSheet({activation=false}={}){
  const st=await redactedOverlayNativeState();
  const rows=PRIME_HUD_COMPONENTS.map(c=>{
    const checked=st?.['enabled_'+c.id]!==false;
    const visual=c.icon?`<img src="${c.icon}" alt="">`:`<span class="primeHudChoiceEmoji">${c.emoji||'●'}</span>`;
    return `<label class="primeHudChoice"><input type="checkbox" data-component="${c.id}" ${checked?'checked':''}><span class="primeHudChoiceVisual">${visual}</span><span><b>${c.labelText||tr(c.label)}</b><small>${c.hintText||tr(c.hint)}</small></span></label>`
  }).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('primeHudChooseTitle')}</h2><p>${tr('primeHudChooseText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="primeHudChoiceToolbar"><button class="secondary chooseAll">${tr('primeHudChooseAll')}</button><button class="secondary chooseNone">${tr('primeHudChooseNone')}</button></div>
    <div class="primeHudChoices">${rows}</div>
    <div class="actions"><button class="primary configurePrime">${tr('primeHudConfigurePrime')}</button></div>`);
  $('.close',sh).onclick=()=>{closeSheet();if(activation){localStorage.setItem(REDACTED_OVERLAY_KEY,'0');setTimeout(openInfoSheet,80)}};
  $('.chooseAll',sh).onclick=()=>$$('.primeHudChoice input',sh).forEach(x=>x.checked=true);
  $('.chooseNone',sh).onclick=()=>$$('.primeHudChoice input',sh).forEach(x=>x.checked=false);
  $('.configurePrime',sh).onclick=async()=>{
    const ids=$$('.primeHudChoice input:checked',sh).map(x=>x.dataset.component);
    if(!ids.length){toast(tr('primeHudNoElement'));return}
    try{
      localStorage.setItem(REDACTED_OVERLAY_KEY,'1');
      await MissionOverlay.configureRedactedSelection({components:ids.join(','),faction:redactedOverlayFaction()});
      closeSheet();toast(activation?tr('primeHudSelectionSaved'):tr('primeHudSelectionApplied'));
      const needsSensors=ids.some(id=>id.startsWith('sensor'));
      if(needsSensors){const access=await MissionOverlay.hasAccessibilityAccess().catch(()=>({granted:false}));if(!access?.granted)toast(tr('primeHudAccessNeeded'));}
    }catch(err){toast(tr('overlayFailed',{error:err?.message||err}))}
  };
}
async function openRedactedOverlayPermissionSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('redactedOverlayPermissionTitle')}</h2><p>${tr('redactedOverlayPermissionText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playPermissionDino"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><b>Redacted Overlay</b><span>${tr('redactedOverlayText')}</span></div></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayDrawStepTitle')}</b><br>${tr('overlayDrawStepText')}</span></div>
    <div class="actions"><button class="primary allowoverlay">${tr('overlayPermissionButton')}</button></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayRestrictedStepTitle')}</b><br>${tr('overlayRestrictedStepText')}</span></div>
    <div class="actions"><button class="secondary restrictedsettings">${tr('overlayRestrictedButton')}</button></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayRetryStepTitle')}</b><br>${tr('overlayRetryStepText')}</span></div>
    <div class="actions"><button class="secondary retryoverlay">${tr('overlayRetryButton')}</button></div>`);
  $('.close',sh).onclick=openInfoSheet;
  const finish=async()=>{const p=await MissionOverlay.hasPermission();if(p?.granted){closeSheet();setTimeout(()=>enableRedactedOverlayNow(),90);return true}return false};
  $('.restrictedsettings',sh).onclick=async()=>{try{await MissionOverlay.openRestrictedSettings();if(await finish())return;toast(tr('overlayRestrictedReturned'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
  $('.allowoverlay',sh).onclick=async()=>{try{const r=await MissionOverlay.requestPermission();if(r?.granted&&await finish())return;toast(tr('overlayPermissionStillBlocked'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
  $('.retryoverlay',sh).onclick=async()=>{try{const r=await MissionOverlay.requestPermission();if(r?.granted&&await finish())return;toast(tr('overlayPermissionStillBlocked'))}catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}};
}

async function overlayState(){
  if(!Capacitor.isNativePlatform())return {active:false,currentIndex:loadPlaySession()?.currentIndex||0,total:loadPlaySession()?.missions?.length||0,doneJson:'[]'};
  try{return await MissionOverlay.getState()}catch(e){console.warn('overlay state',e);return {active:false}}
}
function bannerStartPoint(detail){
  for(const m of detail?.missions||[])if(m?.route?.length)return m.route[0];
  return normalizeGeoPoint(detail?.startPoint);
}
function bannerRoutePoints(detail){
  const out=[];(detail?.missions||[]).forEach((m,mi)=>(m.route||[]).forEach((p,pi)=>out.push({...p,missionIndex:mi,pointIndex:pi})));
  return out;
}
function rblGroupLink(detail,index=0){
  const id=String(detail?.id??detail?.bannerId??'');
  return `${TEST_BUILD?'redactedbannerlabtest':'redactedbannerlab'}://play?banner=${encodeURIComponent(id)}&mission=${Math.max(0,Number(index)||0)}`;
}
function bannergressBannerUrl(detail){return `https://bannergress.com/banner/${encodeURIComponent(String(detail?.id??detail?.bannerId??''))}`}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);return true}catch{}
  try{
    const ta=document.createElement('textarea');ta.value=String(text);ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';ta.style.pointerEvents='none';document.body.appendChild(ta);ta.select();ta.setSelectionRange(0,ta.value.length);const ok=document.execCommand('copy');ta.remove();return !!ok;
  }catch{return false}
}
async function openGroupShareSheet(detail,index=0){
  const link=rblGroupLink(detail,index);
  let qr='';try{qr=await QRCode.toDataURL(link,{width:420,margin:1,color:{dark:'#06140b',light:'#ffffff'}})}catch(e){console.warn('QR',e)}
  const sh=openSheet(`${MILO_GUIDE_STYLE}<div class="sheethead"><div><h2>${tr('shareGroup')}</h2><p>${tr('shareIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="groupShareCard">${qr?`<img class="groupQr" src="${qr}" alt="QR">`:''}<b>${escapeHtml(detail?.title||tr('unnamed'))}</b><span>${tr('missionStart',{n:Number(index)+1})}</span></div>
    <div class="shareLinkBox"><code>${escapeHtml(link)}</code></div>
    <div class="actions"><button class="secondary copygroup">${tr('copyLink')}</button><button class="primary sharegroup">${tr('shareNow')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('groupNoServer')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.copygroup',sh).onclick=async()=>{if(await copyText(link))toast(tr('linkCopied'))};
  $('.sharegroup',sh).onclick=async()=>{
    const text=`${detail?.title||'RBL'} · ${tr('missionStart',{n:Number(index)+1})}\n${link}`;
    try{await Share.share({title:detail?.title||'Redacted BannerLab',text,dialogTitle:tr('shareGroup')})}catch(e){console.warn('share group',e)}
  };
}
async function navigateToBannerStart(detail){
  const p=bannerStartPoint(detail);if(!p){toast(tr('startUnavailable'));return}
  const dest=`${p.latitude},${p.longitude}`;
  const web=`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=walking`;
  try{
    if(Capacitor.isNativePlatform())await IntentLauncher.startActivityAsync({action:ActivityAction.VIEW,data:web,packageName:'com.google.android.apps.maps'});
    else await AppLauncher.openUrl({url:web});
  }catch{try{await AppLauncher.openUrl({url:web})}catch(e){console.warn('maps',e)}}
}
function missionMapIcon(n,isStart=false){return L.divIcon({className:'rblLeafletIcon',html:`<span class="${isStart?'start':''}">${isStart?'▶':n}</span>`,iconSize:[30,30],iconAnchor:[15,15]})}
async function openBannerMap(detail){
  const points=bannerRoutePoints(detail);const start=bannerStartPoint(detail);
  if(!points.length&&!start){toast(tr('mapUnavailable'));return}
  const mapId=`rblMap_${Date.now().toString(36)}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('bannerMap')}</h2><p>${escapeHtml(detail.title||'')} · ${tr('routePoints',{n:points.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="bannerMapCanvas" id="${mapId}"></div>
    <div class="actions"><button class="primary navstart">📍 ${tr('navigateStart')}</button><button class="secondary sharemap">${tr('shareGroup')}</button></div>`);
  let map=null;
  const close=()=>{try{map?.remove()}catch{}closeSheet()};
  $('.close',sh).onclick=close;$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharemap',sh).onclick=()=>openGroupShareSheet(detail,0);
  await new Promise(r=>setTimeout(r,80));
  const el=document.getElementById(mapId);if(!el)return;
  map=L.map(el,{zoomControl:true,attributionControl:true});
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
  const bounds=[];
  (detail.missions||[]).forEach((m,mi)=>{
    const route=m.route||[];if(!route.length)return;
    const latlngs=route.map(p=>[p.latitude,p.longitude]);bounds.push(...latlngs);
    if(latlngs.length>1)L.polyline(latlngs,{color:'#31ed83',weight:4,opacity:.8}).addTo(map);
    {const popup=document.createElement('span');popup.textContent=`${mi===0?tr('startPoint')+' · ':''}${m.title||tr('missionStart',{n:mi+1})}`;L.marker(latlngs[0],{icon:missionMapIcon(mi+1,mi===0)}).addTo(map).bindPopup(popup);}
  });
  if(!bounds.length&&start)bounds.push([start.latitude,start.longitude]);
  if(bounds.length===1)map.setView(bounds[0],16);else map.fitBounds(bounds,{padding:[24,24]});
  setTimeout(()=>map.invalidateSize(),100);
}
async function joinSharedBanner(id,index=0){
  try{
    const detail=await fetchBannerDetail({id:String(id)});const i=clamp(Number(index)||0,0,Math.max(0,detail.missions.length-1));
    toast(tr('sharedBannerLoaded',{n:i+1}));openBannerDetail(detail,{startIndex:i,fromShare:true});
  }catch(e){toast(tr('sharedBannerError',{error:e?.message||e}))}
}
async function startPlaySession(detail,index=0){
  if(!detail?.missions?.length){toast(tr('bannerOffline'));return}
  const bannerId=String(detail.id??detail.bannerId??'');
  const previous=loadPlaySession();const same=String(previous?.bannerId||'')===bannerId;
  const session={format:'redacted-bannerlab-play-session',version:2,bannerId,title:detail.title,address:detail.formattedAddress??detail.address??'',picture:detail.picture||'',author:detail.author||'',lengthMeters:Number(detail.lengthMeters||0)||0,currentIndex:clamp(index,0,detail.missions.length-1),startedAt:same&&previous?.startedAt?previous.startedAt:Date.now(),missions:detail.missions};
  savePlaySession(session);upsertPlayHistory(session,{currentIndex:session.currentIndex,doneCount:same?Number(loadPlayHistory().find(x=>String(x.bannerId)===String(detail.id))?.doneCount||0):0,startedAt:session.startedAt});
  await openIngressMission(session.missions[session.currentIndex].id);
}
function openOverlayPermissionSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('overlayPermissionTitle')}</h2><p>${tr('overlayPermissionText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playPermissionDino"><img src="/redacted-logo-512.png" alt=""><div><b>Redacted Overlay</b><span>${tr('deepLinkOnly')}</span></div></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayDrawStepTitle')}</b><br>${tr('overlayDrawStepText')}</span></div>
    <div class="actions"><button class="primary allowoverlay">${tr('overlayPermissionButton')}</button></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayRestrictedStepTitle')}</b><br>${tr('overlayRestrictedStepText')}</span></div>
    <div class="actions"><button class="secondary restrictedsettings">${tr('overlayRestrictedButton')}</button></div>
    <div class="rule"><span class="dot"></span><span><b>${tr('overlayRetryStepTitle')}</b><br>${tr('overlayRetryStepText')}</span></div>
    <div class="actions"><button class="secondary retryoverlay">${tr('overlayRetryButton')}</button></div>
    <div class="rule"><span class="dot"></span><span>${tr('overlayPermissionWaiting')}</span></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.restrictedsettings',sh).onclick=async()=>{
    try{
      await MissionOverlay.openRestrictedSettings();
      const p=await MissionOverlay.hasPermission();
      if(p?.granted){await resumePendingPlayOverlay();return}
      toast(tr('overlayRestrictedReturned'));
    }catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}
  };
  $('.allowoverlay',sh).onclick=async()=>{
    try{
      const r=await MissionOverlay.requestPermission();
      if(r?.granted){await resumePendingPlayOverlay();return}
      toast(tr('overlayPermissionStillBlocked'));
    }catch(e){toast(tr('overlayFailed',{error:e?.message||e}))}
  };
  $('.retryoverlay',sh).onclick=$('.allowoverlay',sh).onclick;
}
async function resumePendingPlayOverlay(){return}
async function stopPlayOverlay(){
  const session=loadPlaySession();if(session)upsertPlayHistory(session,{currentIndex:Number(session.currentIndex||0),startedAt:Number(session.startedAt||Date.now())});
  localStorage.removeItem(PLAY_SESSION_KEY);localStorage.removeItem(PLAY_PENDING_KEY);toast(tr('stopBanner'));
}
function bannerCardHtml(b){
  const img=bannergressImage(b.picture||'');
  const fav=isBannerFavorite(b.id);
  const id=escapeAttr(String(b.id));
  return `<div class="bannergressCardWrap">
    <button class="bannergressCard" data-banner-id="${id}">
      <span class="bannerPic">${img?`<img src="${escapeAttr(img)}" alt="">`:`<span class="bannerPicFallback">${icon('image')}</span>`}</span>
      <span class="bannerCardCopy"><b>${escapeHtml(b.title||tr('unnamed'))}</b><small>${escapeHtml(b.formattedAddress||tr('addressUnknown'))}</small>${b.author?`<small class="bannerAuthorLine">${escapeHtml(tr('bannerAuthor',{author:b.author}))}</small>`:''}<em>${tr('missionsCount',{n:b.numberOfMissions||0})} · ${formatBannerDistance(b.lengthMeters)}${Number.isFinite(Number(b.searchDistanceMeters))?` · 📍 ${formatBannerDistance(b.searchDistanceMeters)}`:''}</em></span>
      <span class="bannerFavState">${fav?'★':'›'}</span>
    </button>
    <button class="bannerStatsBtn" data-banner-stats-id="${id}">${tr('showUselessStats')}</button>
    <div class="bannerSearchStats" hidden></div>
  </div>`;
}
async function openBannerDetail(summary,opts={}){
  let detail=summary;
  try{detail=await fetchBannerDetail(summary)}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}));return}
  const fav=isBannerFavorite(detail.id),todo=isBannerTodo(detail.id),img=bannergressImage(detail.picture);
  const bannerInfo=String(detail.bannerInfo||'').trim();
  const startIndex=clamp(Number(opts.startIndex)||0,0,Math.max(0,detail.missions.length-1));const hasMap=!!bannerStartPoint(detail);
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(detail.title)}</h2><p>${escapeHtml(detail.formattedAddress||tr('addressUnknown'))}${detail.author?` · ${escapeHtml(tr('bannerAuthor',{author:detail.author}))}`:''}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${opts.fromShare?`<div class="groupJoinNotice">${icon('route')}<div><b>${tr('joinAtMission',{n:startIndex+1})}</b><span>${tr('groupNoServer')}</span></div></div>`:''}
    <div class="bannerDetailHero">${img?`<div class="bannerDetailImageScroll"><img src="${escapeAttr(img)}" alt=""><span class="bannerImageScrollHint">↕ ${escapeHtml(tr('bannerImageScrollHint'))}</span></div>`:''}<div class="bannerDetailHeroMeta"><b>${tr('missionsCount',{n:detail.missions.length||detail.numberOfMissions})}</b><span>${formatBannerDistance(detail.lengthMeters)}</span>${detail.numberOfDisabledMissions?`<small>${tr('bannerDisabled',{n:detail.numberOfDisabledMissions})}</small>`:''}</div></div>
    ${bannerInfo?`<div class="bannerInfoCard"><b>${escapeHtml(tr('bannerInfoLabel'))}</b><p>${escapeHtml(bannerInfo)}</p></div>`:''}
    <div class="bannerDetailStats">${bannerFunStatsHtml(detail,{loading:true})}</div>
    <div class="actions"><button class="primary playbanner" ${detail.missions.length?'':'disabled'}>▶ ${opts.fromShare?tr('joinAtMission',{n:startIndex+1}):tr('playThisBanner')}</button></div>
    <div class="bannerUtilityGrid"><button class="secondary mapbanner" ${hasMap?'':'disabled'}>🗺 ${tr('openMap')}</button><button class="secondary navstart" ${hasMap?'':'disabled'}>📍 ${tr('navigateStart')}</button><button class="secondary sharebanner">▦ ${tr('shareGroup')}</button></div>
    <div class="bannerUtilityGrid two"><button class="secondary favbanner">${fav?'★ '+tr('removeFavorite'):'☆ '+tr('favorite')}</button><button class="secondary todobanner">${todo?'✓ '+tr('removeTodo'):'+ '+tr('addTodo')}</button></div>
    <div class="missionPreviewList">${detail.missions.slice(0,18).map((m,i)=>`<div class="${i===startIndex?'current':''}"><b>${String(i+1).padStart(2,'0')}</b><span>${escapeHtml(m.title)}</span></div>`).join('')}${detail.missions.length>18?`<small>+ ${detail.missions.length-18}</small>`:''}</div>
    <div class="rule"><span class="dot"></span><span>${tr('publicOnly')} · ${tr('deepLinkOnly')}</span></div>`);
  $('.close',sh).onclick=()=>openPlayHub(opts.returnTab||'search');
  $('.playbanner',sh).onclick=()=>startPlaySession(detail,startIndex);
  $('.mapbanner',sh).onclick=()=>openBannerMap(detail);$('.navstart',sh).onclick=()=>navigateToBannerStart(detail);$('.sharebanner',sh).onclick=()=>openGroupShareSheet(detail,startIndex);
  $('.favbanner',sh).onclick=()=>{if(isBannerFavorite(detail.id))unfavoriteBanner(detail.id);else favoriteBanner(detail);closeSheet();openBannerDetail(detail,{...opts})};
  $('.todobanner',sh).onclick=()=>{if(isBannerTodo(detail.id))removeBannerTodo(detail.id);else addBannerTodo(detail);closeSheet();openBannerDetail(detail,{...opts})};
  renderBannerWalkingStats($('.bannerDetailStats',sh),detail);
}


const BANNER_SEARCH_PREFS_KEY='rbl-bannergress-search-v3';
const BANNER_SEARCH_OLD_PREFS_KEY='rbl-bannergress-search-v2';
function loadBannerSearchPrefs(){
  try{
    const current=JSON.parse(localStorage.getItem(BANNER_SEARCH_PREFS_KEY)||'null');
    if(current&&typeof current==='object')return current;
    const old=JSON.parse(localStorage.getItem(BANNER_SEARCH_OLD_PREFS_KEY)||'{}')||{};
    return {query:old.query||'',city:old.city||'',nearMe:!!old.nearMe,radiusKm:5};
  }catch{return{radiusKm:5}}
}
function saveBannerSearchPrefs(p){localStorage.setItem(BANNER_SEARCH_PREFS_KEY,JSON.stringify(p||{}));markBackupChanged()}
function normalizeTextMatch(v=''){
  return String(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim().replace(/[’'`´]/g,' ').replace(/[-_/.,;:()]+/g,' ').replace(/\s+/g,' ');
}
function canonicalCityKey(v=''){
  return normalizeTextMatch(v).replace(/\bste\b/g,'sainte').replace(/\bst\b/g,'saint').replace(/\s+/g,' ').trim();
}
function citySearchVariants(city=''){
  const raw=String(city||'').trim();if(!raw)return[];
  const expanded=raw.replace(/\bSte\.?(?=\s|-|$)/gi,'Sainte').replace(/\bSt\.?(?=\s|-|$)/gi,'Saint').replace(/[’'`´]/g,' ');
  const spaced=expanded.replace(/-/g,' ').replace(/\s+/g,' ').trim();
  const hyphen=spaced.split(' ').filter(Boolean).join('-');
  const abbreviated=spaced.replace(/^Sainte\b/i,'Ste').replace(/^Saint\b/i,'St');
  const variants=[raw,expanded,spaced,hyphen,abbreviated,abbreviated.replace(/\s+/g,'-')];
  return [...new Set(variants.map(x=>x.trim()).filter(Boolean))];
}
function placeMatchValues(p){return [p?.shortName,p?.name,p?.formattedAddress,p?.title,p?.displayName].filter(Boolean)}
function placeDisplayLabel(p,fallback=''){return String(p?.formattedAddress??p?.displayName??p?.name??p?.shortName??fallback)}
function placeCenter(p){
  if(!p)return null;
  for(const candidate of [p.center,p.location,p.point,p]){
    const direct=normalizeGeoPoint(candidate);if(direct)return direct;
  }
  const minLat=Number(p.boundaryMinLatitude??p.minLatitude??p.bounds?.minLatitude??p.bounds?.south);
  const maxLat=Number(p.boundaryMaxLatitude??p.maxLatitude??p.bounds?.maxLatitude??p.bounds?.north);
  const minLng=Number(p.boundaryMinLongitude??p.minLongitude??p.bounds?.minLongitude??p.bounds?.west);
  const maxLng=Number(p.boundaryMaxLongitude??p.maxLongitude??p.bounds?.maxLongitude??p.bounds?.east);
  if([minLat,maxLat,minLng,maxLng].every(Number.isFinite))return {latitude:(minLat+maxLat)/2,longitude:(minLng+maxLng)/2};
  const lat=Number(p.centerLatitude??p.latitude??p.lat),lng=Number(p.centerLongitude??p.longitude??p.lng??p.lon);
  return Number.isFinite(lat)&&Number.isFinite(lng)?{latitude:lat,longitude:lng}:null;
}
async function resolveBannergressPlace(city){
  const q=String(city||'').trim();if(!q)return null;
  const variants=citySearchVariants(q),found=new Map();
  for(const variant of variants){
    const u=`${BANNERGRESS_API}/places?used=true&collapsePlaces=true&query=${encodeURIComponent(variant)}&limit=40&offset=0`;
    const r=await fetch(u,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const raw=await r.json();
    const list=Array.isArray(raw)?raw:(Array.isArray(raw?.items)?raw.items:(Array.isArray(raw?.results)?raw.results:(Array.isArray(raw?.data)?raw.data:[])));
    for(const p of list){const key=String(p?.id??p?.placeId??placeMatchValues(p)[0]??Math.random());if(!found.has(key))found.set(key,p)}
    if(found.size&&variant!==q)break;
  }
  const list=[...found.values()];if(!list.length)return null;
  const target=canonicalCityKey(q);
  const score=p=>{
    const vals=placeMatchValues(p).map(canonicalCityKey);
    if(vals.some(x=>x===target))return 0;
    if(vals.some(x=>x.startsWith(target)||target.startsWith(x)))return 1;
    if(vals.some(x=>x.includes(target)||target.includes(x)))return 2;
    return 3;
  };
  return list.sort((a,b)=>score(a)-score(b))[0]||null;
}
function locationError(code,message=''){
  const e=new Error(message||String(code));e.locationCode=code;return e;
}
async function nativeLocationStatus(){
  if(!Capacitor.isNativePlatform())return null;
  try{return await LocationStatus.getStatus()}catch(e){console.warn('LocationStatus',e);return null}
}
async function openNativeLocationSettings(kind='location'){
  if(!Capacitor.isNativePlatform())return false;
  try{if(kind==='app')await LocationStatus.openAppSettings();else await LocationStatus.openLocationSettings();return true}catch(e){console.warn('location settings',e);return false}
}
async function getCurrentBannerPosition(){
  if(!navigator.geolocation)throw locationError('UNSUPPORTED','géolocalisation indisponible');
  const native=await nativeLocationStatus();
  if(native&&native.enabled===false)throw locationError('LOCATION_DISABLED',tr('locationDisabled'));
  if(navigator.permissions?.query){
    try{const perm=await navigator.permissions.query({name:'geolocation'});if(perm.state==='denied')throw locationError('PERMISSION_DENIED',tr('locationPermissionDenied'))}catch(e){if(e?.locationCode)throw e}
  }
  return new Promise((resolve,reject)=>{
    navigator.geolocation.getCurrentPosition(
      p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy}),
      e=>{
        if(e?.code===1)reject(locationError('PERMISSION_DENIED',tr('locationPermissionDenied')));
        else if(e?.code===2)reject(locationError('UNAVAILABLE',tr('locationUnavailable')));
        else if(e?.code===3)reject(locationError('TIMEOUT',tr('locationTimeout')));
        else reject(locationError('UNKNOWN',e?.message||`code ${e?.code||'?'}`));
      },
      {enableHighAccuracy:true,maximumAge:120000,timeout:8000}
    );
  });
}
function searchRadiusBounds(position,radiusKm){
  if(!position)return null;
  const km=Math.max(1,Number(radiusKm)||5),lat=Number(position.latitude),lng=Number(position.longitude);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))return null;
  const latDelta=km/111.32,cos=Math.max(.08,Math.cos(lat*Math.PI/180)),lngDelta=km/(111.32*cos);
  return {minLatitude:lat-latDelta,maxLatitude:lat+latDelta,minLongitude:lng-lngDelta,maxLongitude:lng+lngDelta};
}
function buildBannergressSearchUrl({query='',position=null,radiusKm=5,placeId=''}){
  const u=new URL(`${BANNERGRESS_API}/bnrs`);
  u.searchParams.set('online','true');u.searchParams.set('limit','80');u.searchParams.set('offset','0');
  if(query.trim())u.searchParams.set('query',query.trim());
  if(placeId)u.searchParams.set('placeId',placeId);
  if(position){
    u.searchParams.set('orderBy','proximityStartPoint');u.searchParams.set('orderDirection','ASC');
    u.searchParams.set('proximityLatitude',String(position.latitude));u.searchParams.set('proximityLongitude',String(position.longitude));
    const bounds=searchRadiusBounds(position,radiusKm);
    if(bounds)for(const [key,value] of Object.entries(bounds))u.searchParams.set(key,String(value));
  }else if(query.trim()){
    u.searchParams.set('orderBy','relevance');u.searchParams.set('orderDirection','DESC');
  }else{
    u.searchParams.set('orderBy','created');u.searchParams.set('orderDirection','DESC');
  }
  return u.toString();
}
async function hydrateSearchStartPoints(list){
  const out=[...list],missing=[];
  out.forEach((b,i)=>{if(!bannerStartPoint(b))missing.push(i)});
  const concurrency=5;
  for(let start=0;start<missing.length;start+=concurrency){
    await Promise.all(missing.slice(start,start+concurrency).map(async i=>{
      try{const detail=await fetchBannerDetail(out[i]);out[i]={...out[i],startPoint:bannerStartPoint(detail)||detail.startPoint||null}}catch(e){console.warn('banner location',out[i]?.id,e)}
    }));
  }
  return out;
}
async function filterBannersByRadius(list,center,radiusKm){
  if(!center)return list;
  const hydrated=await hydrateSearchStartPoints(list),maxMeters=Math.max(1,Number(radiusKm)||5)*1000;
  return hydrated.map(b=>{
    const point=bannerStartPoint(b),distance=point?haversine(center,point):Infinity;
    return {...b,searchDistanceMeters:distance};
  }).filter(b=>Number.isFinite(b.searchDistanceMeters)&&b.searchDistanceMeters<=maxMeters+25).sort((a,b)=>a.searchDistanceMeters-b.searchDistanceMeters);
}
function locationErrorText(e){
  switch(e?.locationCode){
    case 'LOCATION_DISABLED':return tr('locationDisabled');
    case 'PERMISSION_DENIED':return tr('locationPermissionDenied');
    case 'UNAVAILABLE':return tr('locationUnavailable');
    case 'TIMEOUT':return tr('locationTimeout');
    default:return tr('locationError',{error:e?.message||e});
  }
}
function historyCardHtml(h){
  const total=Math.max(1,Number(h.total||h.numberOfMissions||1)),done=Math.min(total,Number(h.doneCount||0));const complete=done>=total;
  return `<button class="playHistoryCard" data-history-id="${escapeAttr(String(h.bannerId))}"><span class="historyState">${complete?'✓':'▶'}</span><span><b>${escapeHtml(h.title||tr('unnamed'))}</b><small>${formatPlayDate(h.startedAt)} · ${done}/${total}</small><em>${formatPlayDuration(activeDurationMs(h))} · ~${formatBannerDistance(estimatedPlayedMeters(h))}</em></span><strong>${complete?tr('completedBanner'):tr('resumeFromHistory')}</strong></button>`;
}
async function openHistoryBanner(h){
  try{const d=await fetchBannerDetail({id:h.bannerId,title:h.title,formattedAddress:h.formattedAddress,lengthMeters:h.lengthMeters,picture:h.picture,author:h.author,numberOfMissions:h.total});openBannerDetail(d,{startIndex:h.doneCount>=h.total?0:clamp(h.currentIndex,0,d.missions.length-1),returnTab:'history'})}catch(e){toast(tr('bannerLoadError',{error:e?.message||e}))}
}
function playStatsHtml(entry){
  const total=Math.max(1,Number(entry?.total||entry?.numberOfMissions||1)),done=Math.min(total,Number(entry?.doneCount||0));
  return `<div class="playStats"><b>${tr('playStats')}</b><div><span>${tr('startedAt')}</span><strong>${formatPlayDate(entry?.startedAt)}</strong></div><div><span>${tr('elapsed')}</span><strong>${formatPlayDuration(activeDurationMs(entry))}</strong></div><div><span>${tr('estimatedDistance')}</span><strong>~${formatBannerDistance(estimatedPlayedMeters(entry))}</strong></div><div><span>${tr('missionsDone')}</span><strong>${done}/${total}</strong></div>${entry?.finishedAt?`<div><span>${tr('finishedAt')}</span><strong>${formatPlayDate(entry.finishedAt)}</strong></div>`:''}</div>`;
}
async function renderPlayTab(sh,tab){
  const body=$('.playHubBody',sh);if(!body)return;
  if(tab==='todo'){
    const list=loadBannerTodo();body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">＋<b>${tr('noTodo')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b,{returnTab:'todo'}));return;
  }
  if(tab==='history'){
    const list=loadPlayHistory();body.innerHTML=list.length?`<div class="playHistoryList">${list.map(historyCardHtml).join('')}</div>`:`<div class="emptyPlayState">◷<b>${tr('noHistory')}</b></div>`;
    $$('.playHistoryCard',body).forEach(btn=>{btn.onclick=()=>{const h=list.find(x=>String(x.bannerId)===btn.dataset.historyId);if(h)openHistoryBanner(h)}});return;
  }
  if(tab==='favorites'){
    const list=loadBannerFavorites();
    body.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">☆<b>${tr('noFavorites')}</b></div>`;
    bindBannerList(body,list,b=>openBannerDetail(b));return;
  }
  if(tab==='current'){
    const session=loadPlaySession();const native=await overlayState();
    if(!session){body.innerHTML=`<div class="emptyPlayState">${icon('play')}<b>${tr('noPlaySession')}</b></div>`;return}
    let done=[];try{done=JSON.parse(native?.doneJson||'[]')}catch{}
    const index=clamp(Number(native?.currentIndex??session.currentIndex??0),0,Math.max(0,session.missions.length-1));
    const hist=upsertPlayHistory(session,{currentIndex:index,doneCount:done.length,startedAt:Number(native?.startedAt||session.startedAt||Date.now()),finishedAt:Number(native?.finishedAt||0),pausedTotal:Number(native?.pausedTotal||0),paused:!!native?.paused,pausedAt:Number(native?.pausedAt||0)});
    body.innerHTML=`<div class="currentPlayCard"><div class="playPermissionDino"><img src="/redacted-logo-512.png" alt=""><div><b>${escapeHtml(session.title)}</b><span>${tr('doneMissions',{done:done.length,total:session.missions.length})}</span></div></div>
      <div class="currentMissionLine"><strong>${index+1}/${session.missions.length}</strong><span>${escapeHtml(session.missions[index]?.title||tr('missionLabel',{n:index+1}))}</span></div>
      ${playStatsHtml(hist)}
      <div class="actions"><button class="primary resumeplay">▶ ${tr('resumeBanner')}</button><button class="secondary opencurrent">${tr('openCurrentMission')}</button></div>
      <div class="bannerUtilityGrid"><button class="secondary currentmap">🗺 ${tr('openMap')}</button><button class="secondary currentnav">📍 ${tr('navigateStart')}</button><button class="secondary currentshare">▦ ${tr('shareProgress')}</button></div>
      <button class="danger stopplay">${tr('stopBanner')}</button></div>`;
    $('.resumeplay',body).onclick=()=>startPlaySession(session,index);
    $('.opencurrent',body).onclick=()=>openIngressMission(session.missions[index]?.id);
    $('.currentmap',body).onclick=()=>openBannerMap({...session,id:session.bannerId,formattedAddress:session.address});
    $('.currentnav',body).onclick=()=>navigateToBannerStart({...session,id:session.bannerId});
    $('.currentshare',body).onclick=()=>openGroupShareSheet({...session,id:session.bannerId},index);
    $('.stopplay',body).onclick=async()=>{await stopPlayOverlay();openPlayHub('current')};return;
  }

  const prefs=loadBannerSearchPrefs();
  let nearMe=!!prefs.nearMe;
  let position=null;
  const initialRadius=clamp(Number(prefs.radiusKm)||5,1,50);
  body.innerHTML=`<div class="bannerSearchBox bannerSearchAdvanced">
      <div class="bannerSearchHeading"><div><b>${tr('searchBannergress')}</b><span>${tr('searchPrompt')}</span></div><span>${tr('searchSource')}</span></div>
      <div class="bannerSearchGuide">${icon('search')}<span>${tr('explorerHint')}</span></div><div class="field bannerSearchField"><label>${tr('bannerNameSearch')}</label><input class="bannerNameInput" placeholder="${escapeAttr(tr('searchPlaceholder'))}" value="${escapeAttr(prefs.query||'')}"></div>
      <div class="field bannerSearchField"><label>${tr('citySearch')}</label><input class="bannerCityInput" placeholder="${escapeAttr(tr('cityPlaceholder'))}" value="${escapeAttr(prefs.city||'')}" ${nearMe?'disabled':''}></div>
      <button class="nearMeButton ${nearMe?'on':''}" type="button">📍 <span>${nearMe?tr('nearMeOn'):tr('nearMe')}</span></button>
      <small class="nearMeHelp">${tr('nearMeHint')}</small>
      <div class="bannerRadiusBox">
        <div class="bannerRadiusHead"><label>${tr('searchRadius')}</label><strong class="bannerRadiusValue">${initialRadius} km</strong></div>
        <input class="bannerRadiusRange" type="range" min="1" max="50" step="1" value="${initialRadius}">
        <small>${tr('radiusHint')}</small>
      </div>
      <button class="secondary bannerLocationSettings" type="button" hidden>⚙ ${tr('openLocationSettings')}</button>
      <div class="bannerSearchActions"><button class="secondary bannerSearchReset">${tr('searchReset')}</button><button class="primary bannerSearchBtn">${icon('search')} ${tr('search')}</button></div>
      <div class="bannerSearchStatus"></div>
    </div><div class="bannerSearchResults"></div>`;

  const qInput=$('.bannerNameInput',body),cityInput=$('.bannerCityInput',body),radiusInput=$('.bannerRadiusRange',body),radiusValue=$('.bannerRadiusValue',body);
  const nearBtn=$('.nearMeButton',body),status=$('.bannerSearchStatus',body),results=$('.bannerSearchResults',body),settingsBtn=$('.bannerLocationSettings',body);
  let locationSettingsKind='location';
  const setStatus=(txt,cls='')=>{status.textContent=txt||'';status.className='bannerSearchStatus '+cls};
  const radiusKm=()=>clamp(Number(radiusInput.value)||5,1,50);
  const savePrefs=()=>saveBannerSearchPrefs({query:qInput.value,city:cityInput.value,nearMe,radiusKm:radiusKm()});
  const updateRadius=()=>{radiusValue.textContent=`${radiusKm()} km`;const active=nearMe||!!cityInput.value.trim();radiusInput.disabled=!active;$('.bannerRadiusBox',body)?.classList.toggle('disabled',!active);savePrefs()};
  const hideLocationAction=()=>{settingsBtn.hidden=true};
  const showLocationError=e=>{
    setStatus(locationErrorText(e),'error');
    if(Capacitor.isNativePlatform()&&['LOCATION_DISABLED','UNAVAILABLE','TIMEOUT','PERMISSION_DENIED'].includes(e?.locationCode)){
      locationSettingsKind=e?.locationCode==='PERMISSION_DENIED'?'app':'location';
      settingsBtn.textContent=`⚙ ${tr(locationSettingsKind==='app'?'openAppSettings':'openLocationSettings')}`;settingsBtn.hidden=false;
    }
  };
  settingsBtn.onclick=()=>openNativeLocationSettings(locationSettingsKind);

  const acquirePosition=async()=>{
    hideLocationAction();setStatus(tr('locationChecking'),'loading');
    const pos=await getCurrentBannerPosition();position=pos;setStatus(`${tr('locationReady')}${Number.isFinite(pos.accuracy)?` · ±${Math.round(pos.accuracy)} m`:''}`,'ok');return pos;
  };
  const toggleNear=async()=>{
    nearMe=!nearMe;position=null;cityInput.disabled=nearMe;nearBtn.classList.toggle('on',nearMe);
    $('span',nearBtn).textContent=nearMe?tr('nearMeOn'):tr('nearMe');hideLocationAction();updateRadius();savePrefs();
    if(nearMe){try{await acquirePosition()}catch(e){showLocationError(e)}}else setStatus('');
  };
  nearBtn.onclick=toggleNear;
  radiusInput.oninput=updateRadius;
  cityInput.addEventListener('input',updateRadius);
  updateRadius();

  const run=async()=>{
    const query=qInput.value.trim(),city=cityInput.value.trim();savePrefs();hideLocationAction();
    if(!query&&!city&&!nearMe){setStatus(tr('searchCriteriaRequired'),'error');results.innerHTML='';return}
    results.innerHTML=`<div class="loadingPlay">${tr('searching')}</div>`;setStatus('');
    try{
      let place=null,searchCenter=null;
      if(nearMe){if(!position)await acquirePosition();searchCenter=position}
      if(city&&!nearMe){
        setStatus(tr('cityResolving'),'loading');place=await resolveBannergressPlace(city);
        if(!place){results.innerHTML='';setStatus(tr('cityNotFound',{city}),'error');return}
        searchCenter=placeCenter(place);
        if(!searchCenter){results.innerHTML='';setStatus(tr('cityNoCoordinates',{city:placeDisplayLabel(place,city)}),'error');return}
        setStatus(tr('cityUsingRadius',{city:placeDisplayLabel(place,city),radius:radiusKm()}),'ok');
      }
      const url=buildBannergressSearchUrl({query,position:searchCenter,radiusKm:radiusKm()});
      const r=await fetch(url,{headers:{Accept:'application/json'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);
      let list=unwrapBannerSearch(await r.json()).map(b=>normalizeBannerDetail(b,b));
      if(searchCenter)list=await filterBannersByRadius(list,searchCenter,radiusKm());
      const filterBits=[];if(query)filterBits.push(`“${query}”`);if(city&&!nearMe)filterBits.push(placeDisplayLabel(place,city));if(nearMe)filterBits.push('📍');if(searchCenter)filterBits.push(`≤ ${radiusKm()} km`);
      const countText=searchCenter?tr('radiusResults',{n:list.length,radius:radiusKm()}):tr('resultsCount',{n:list.length});
      setStatus(`${countText}${filterBits.length?' · '+filterBits.join(' · '):''}`,list.length?'ok':'');
      results.innerHTML=list.length?`<div class="bannergressList">${list.map(bannerCardHtml).join('')}</div>`:`<div class="emptyPlayState">⌕<b>0</b></div>`;
      bindBannerList(results,list,b=>openBannerDetail(b));
    }catch(e){console.error(e);if(e?.locationCode)showLocationError(e);else setStatus(tr('searchError',{error:e?.message||e}),'error');results.innerHTML=''}
  };
  $('.bannerSearchBtn',body).onclick=run;
  $('.bannerSearchReset',body).onclick=()=>{qInput.value='';cityInput.value='';radiusInput.value='5';nearMe=false;position=null;cityInput.disabled=false;nearBtn.classList.remove('on');$('span',nearBtn).textContent=tr('nearMe');hideLocationAction();updateRadius();savePrefs();setStatus('');results.innerHTML=''};
  [qInput,cityInput].forEach(inp=>inp.addEventListener('keydown',e=>{if(e.key==='Enter')run()}));
  setTimeout(()=>qInput.focus(),80);
}
function openPlayHub(tab='search'){
  const sh=openSheet(`<div class="sheethead playHubHead"><div><span class="playHubEyebrow">BANNERGRESS</span><h2>${tr('playHub')}</h2><p>${tr('playHubIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="playTabs"><button data-playtab="search" class="${tab==='search'?'on':''}">${icon('search')}<span>${tr('searchTab')}</span></button><button data-playtab="todo" class="${tab==='todo'?'on':''}">${icon('plus')}<span>${tr('todo')}</span></button><button data-playtab="favorites" class="${tab==='favorites'?'on':''}">${icon('star')}<span>${tr('favorites')}</span></button><button data-playtab="current" class="${tab==='current'?'on':''}">${icon('play')}<span>${tr('currentTab')}</span></button><button data-playtab="history" class="${tab==='history'?'on':''}"><span class="playTabClock">◷</span><span>${tr('history')}</span></button></div>
    <div class="playHubBody"></div>`);
  sh.classList.add('playHubSheet');
  $('.close',sh).onclick=closeSheet;
  $$('[data-playtab]',sh).forEach(btn=>btn.onclick=()=>openPlayHub(btn.dataset.playtab));
  renderPlayTab(sh,tab);
}



let studioEditorRoot=null,studioCanvasHome=null,studioZoom=1,studioOrientationLocked=false,studioPanMode=false,studioFitMode='six',studioViewScale=1;
function studioActiveLayer(){return activeImageLayer()}
function studioActiveText(){return state.active.startsWith('text:')?state.texts.find(t=>t.id===state.active.slice(5))||null:null}
function studioLayerClass(l){const g=groupInfoForLayer(l);return g?` groupColor${g.color}`:''}
function studioLayerRowsHtml(){
  normalizeLayerGroups();
  const rows=[...state.imageLayers].map((l,i)=>({l,i})).reverse().map(({l,i})=>{
    const active=state.active==='image:'+l.id,g=groupInfoForLayer(l),top=i===state.imageLayers.length-1,bottom=i===0;
    return `<div class="studioLayerRow${active?' active':''}${l.visible===false?' hidden':''}${studioLayerClass(l)}" data-studio-layer="${escapeAttr(l.id)}">
      <label class="studioGroupCheck" title="${tr('multiSelection')}"><input type="checkbox" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="studioLayerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:g?'▱':'▧',alt:imageLayerLabel(l,i),studio:true})}<span><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:`${l.image?.naturalWidth||0} × ${l.image?.naturalHeight||0}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}`}</small></span></button>
      <button class="studioEye" type="button">${l.visible===false?'◌':'◉'}</button>
      <div class="studioLayerOrder"><button type="button" class="studioDown" ${bottom?'disabled':''}>↓</button><button type="button" class="studioUp" ${top?'disabled':''}>↑</button></div>
    </div>`;
  }).join('');
  return `${rows}<div class="studioLayerRow background${state.active==='background'?' active':''}${state.bg.visible===false?' hidden':''}"><span class="studioGroupLock">⌄</span><button class="studioLayerSelect studioBackground" type="button">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer'),studio:true})}<span><b>${tr('backgroundLayer')}</b><small>${state.bg.image?`${state.bg.image.naturalWidth} × ${state.bg.image.naturalHeight}`:tr('backgroundMissing')}</small></span></button><button class="studioEye studioBackgroundEye" type="button">${state.bg.visible===false?'◌':'◉'}</button><span class="studioLock">🔒</span></div>`;
}
function studioTextRowsHtml(){
  if(!state.texts.length)return `<div class="studioNoLayer">${tr('studioNoText')}</div>`;
  return state.texts.map((t,i)=>`<div class="studioTextRow${state.active==='text:'+t.id?' active':''}" data-studio-text="${escapeAttr(t.id)}"><button class="studioTextSelect" type="button"><span class="studioLayerGlyph">T</span><span><b>${escapeHtml((t.text||tr('text')).slice(0,42))}</b><small>${tr('size')} ${Math.round(t.fontSize||180)} · ${tr('rotation')} ${Math.round((t.rotation||0)*180/Math.PI)}°</small></span></button><button class="studioTextDelete" type="button">${icon('trash')}</button></div>`).join('');
}
function studioAddTextNow(){
  const before=beginHistory();const t=textDefaults({id:uid(),text:'I LOVE REDACTED',x:WORLD_W/2,y:worldH()/2,fontSize:180,color:'#ffffff',strokeColor:'#07100c',strokeWidth:14,scale:1,rotation:0});state.texts.push(t);setActive('text:'+t.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();
}
function studioDuplicateText(id){const src=state.texts.find(t=>t.id===id);if(!src)return;const before=beginHistory(),copy={...src,id:uid(),x:(src.x||0)+24,y:(src.y||0)+24,text:src.text||tr('text')};state.texts.push(copy);setActive('text:'+copy.id);commitHistory(before,tr('histAddText'));scheduleSave();render();refreshStudioEditor();}
function studioDeleteText(id){const t=state.texts.find(x=>x.id===id);if(!t)return;const before=beginHistory();state.texts=state.texts.filter(x=>x.id!==id);state.active='background';commitHistory(before,tr('histDeleteText'));scheduleSave();render();refreshStudioEditor();toast(tr('textDeleted'));}
function studioToolsHtml(){
  const txt=studioActiveText();
  if(txt){
    normalizeTextStyle(txt);return `<div class="studioSelectedCard"><b>${escapeHtml((txt.text||tr('text')).slice(0,48))}</b><small>${tr('studioSelected')} · ${tr('text')}</small></div>
      <div class="studioTextQuick">
        <label><span>${tr('text')}</span><input class="studioTextValue" maxlength="120" value="${escapeAttr(txt.text||'')}"></label>
        <div class="studioTypographyTitle">${tr('textTypography')}</div>
        <div class="studioFontLine"><label><span>${tr('font')}</span><select class="studioTextFont">${fontOptionsHtml(txt.fontFamily)}</select></label><button class="secondary studioImportFont" type="button">＋ ${tr('importFont')}</button></div>
        <div class="grid2"><label><span>${tr('size')}</span><input class="studioTextSize" type="number" min="40" max="700" value="${txt.fontSize||180}"></label><label><span>${tr('fontWeight')}</span><select class="studioTextWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${txt.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></label></div>
        <div class="grid2"><label><span>${tr('letterSpacing')}</span><input class="studioTextSpacing" type="number" min="-40" max="160" step="1" value="${txt.letterSpacing||0}"></label><label><span>${tr('lineHeight')}</span><input class="studioTextLineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${txt.lineHeight||1.08}"></label></div>
        <div class="grid2"><label><span>${tr('textAlign')}</span><select class="studioTextAlign"><option value="left" ${txt.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${txt.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${txt.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></label><label class="studioCheckLabel"><span>${tr('fontItalic')}</span><input class="studioTextItalic" type="checkbox" ${txt.fontItalic?'checked':''}></label></div>
        <div class="grid2"><label><span>${tr('outline')}</span><input class="studioTextStroke" type="number" min="0" max="60" value="${txt.strokeWidth??14}"></label><label><span>${tr('color')}</span><input class="studioTextColor" type="color" value="${txt.color||'#ffffff'}"></label></div>
        <label><span>${tr('outlineColor')}</span><input class="studioTextStrokeColor" type="color" value="${txt.strokeColor||'#07100c'}"></label>
        <label class="studioSwitch"><input class="studioTextBgEnabled" type="checkbox" ${txt.backgroundEnabled?'checked':''}><span>${tr('textBackground')}</span></label>
        <div class="studioTextBgFields" ${txt.backgroundEnabled?'':'hidden'}><div class="grid2"><label><span>${tr('textBackgroundColor')}</span><input class="studioTextBgColor" type="color" value="${txt.backgroundColor||'#07100c'}"></label><label><span>${tr('textBackgroundOpacity')}</span><input class="studioTextBgOpacity" type="number" min="0" max="100" value="${Math.round((txt.backgroundOpacity??.72)*100)}"></label></div><div class="grid2"><label><span>${tr('textBackgroundPadding')}</span><input class="studioTextBgPadding" type="number" min="0" max="180" value="${txt.backgroundPadding??24}"></label><label><span>${tr('textBackgroundRadius')}</span><input class="studioTextBgRadius" type="number" min="0" max="240" value="${txt.backgroundRadius??24}"></label></div></div>
      </div>
      <div class="studioToolGrid"><button type="button" class="studioTransform">${icon('move')}<span>${tr('transformText')}</span></button><button type="button" class="studioDuplicateText">${icon('copy')}<span>${tr('studioDuplicateText')}</span></button><button type="button" class="studioDeleteText danger">${icon('trash')}<span>${tr('delete')}</span></button></div>`;
  }
  const l=studioActiveLayer();
  if(!l)return `<div class="studioNoLayer">${tr('studioNoLayer')}</div>`;
  const isBg=l===state.bg,idx=isBg?-1:imageLayerIndex(l.id),g=!isBg?groupInfoForLayer(l):null;
  return `<div class="studioSelectedCard${g?` groupColor${g.color}`:''}"><b>${escapeHtml(isBg?tr('backgroundLayer'):imageLayerLabel(l,idx))}</b><small>${g?`${escapeHtml(g.label)} · ${tr('groupCount',{n:g.count})}`:tr('studioSelected')}</small></div>
    <label class="studioOpacity"><span>${tr('studioOpacity')}</span><strong>${Math.round((l.opacity??1)*100)}%</strong><input type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></label>
    <div class="studioToolGrid">
      <button type="button" class="studioTransform">${icon('move')}<span>${g?tr('groupTransform'):tr('layerTransform')}</span></button>
      <button type="button" class="studioVisibility">${l.visible===false?'◌':'◉'}<span>${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}</span></button>
      ${isBg?'':`<button type="button" class="studioMoveDown" ${idx===0?'disabled':''}>↓<span>${tr('moveDown')}</span></button><button type="button" class="studioMoveUp" ${idx===state.imageLayers.length-1?'disabled':''}>↑<span>${tr('moveUp')}</span></button><button type="button" class="studioDuplicate">${icon('copy')}<span>${tr('duplicateLayer')}</span></button><button type="button" class="studioRename">${icon('edit')}<span>${tr('renameLayer')}</span></button>${g?`<button type="button" class="studioUngroup">⇱<span>${tr('ungroup')}</span></button>`:''}<button type="button" class="studioDelete danger">${icon('trash')}<span>${tr('deleteLayer')}</span></button>`}
    </div>`;
}
function studioMoveLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;const before=beginHistory();[state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];commitHistory(before,tr('histReorderLayer'));scheduleSave();render();refreshStudioEditor();
}
function studioToggleLayer(id){
  if(id==='background'){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  else{const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;commitHistory(before,tr('histVisibilityLayer'));}
  scheduleSave();render();refreshStudioEditor();
}
function studioDeleteLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDeleted'));
}
function studioDuplicateLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();refreshStudioEditor();toast(tr('layerDuplicated'));
}
function studioUngroupLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupRemoved'));
}
function studioGroupSelected(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));if(ids.length<2){toast(tr('groupNeedTwo'));return}const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();refreshStudioEditor();toast(tr('groupCreated'));
}
function studioSelectedMissionRc(){return parseMissionKey(state.selectedMissionKey)||rowColForMission(1)}
function studioMissionVisualPosition(rc,scale=studioViewScale){return {left:(worldH()-(rc.row+1)*STEP)*scale,top:rc.col*STEP*scale,size:STEP*scale}}
function studioScrollToSelectedMission(behavior='smooth'){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),rc=studioSelectedMissionRc();if(!sc||!rc)return;const p=studioMissionVisualPosition(rc);sc.scrollTo({left:Math.max(0,p.left-(sc.clientWidth-p.size)/2),top:Math.max(0,p.top-(sc.clientHeight-p.size)/2),behavior});
}
function applyStudioCanvasSize({recenter=false}={}){
  if(!studioEditorRoot)return;const sc=$('.studioScroll',studioEditorRoot),stage=$('.studioCanvasStage',studioEditorRoot);if(!sc||!stage)return;
  const availH=Math.max(220,sc.clientHeight-20),availW=Math.max(220,sc.clientWidth-20);let fit;
  if(studioFitMode==='one')fit=Math.min(availH,availW)/STEP;
  else if(studioFitMode==='all')fit=Math.min(availH/WORLD_W,availW/worldH());
  else fit=availH/WORLD_W;
  studioViewScale=Math.max(.04,fit*studioZoom);
  const cssW=WORLD_W*studioViewScale,cssH=worldH()*studioViewScale,mount=$('.studioCanvasMount',studioEditorRoot);
  stage.style.width=`${Math.round(cssH)}px`;stage.style.height=`${Math.round(cssW)}px`;
  if(mount){mount.style.width=`${Math.max(Math.round(cssH),Math.max(1,sc.clientWidth-20))}px`;mount.style.height=`${Math.max(Math.round(cssW),Math.max(1,sc.clientHeight-20))}px`;}
  canvas.style.width=`${Math.round(cssW)}px`;canvas.style.height=`${Math.round(cssH)}px`;canvas.style.position='absolute';canvas.style.left=`${Math.round(cssH)}px`;canvas.style.top='0';canvas.style.transformOrigin='0 0';canvas.style.transform='rotate(90deg)';
  if(recenter){requestAnimationFrame(()=>{if(studioFitMode==='one')studioScrollToSelectedMission('smooth');else {const scroll=$('.studioScroll',studioEditorRoot),mx=Math.max(0,((mount?.scrollWidth||0)-scroll.clientWidth)/2),my=Math.max(0,((mount?.scrollHeight||0)-scroll.clientHeight)/2);scroll?.scrollTo({left:mx,top:my,behavior:'smooth'})}})}
}
function bindStudioPanels(){
  if(!studioEditorRoot)return;const root=studioEditorRoot;
  $$('.studioLayerRow[data-studio-layer]',root).forEach(row=>{const id=row.dataset.studioLayer;$('.studioLayerSelect',row).onclick=()=>{setEditMode('fresco');setActive('image:'+id);refreshStudioEditor()};$('.studioEye',row).onclick=()=>studioToggleLayer(id);$('.studioDown',row).onclick=()=>studioMoveLayer(id,-1);$('.studioUp',row).onclick=()=>studioMoveLayer(id,1);$('input',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);row.classList.toggle('multiSelected',e.target.checked);const cnt=$('.studioGroupCount',root);if(cnt)cnt.textContent=String(layerGroupSelection.size);const gb=$('.studioGroupNow',root);if(gb)gb.disabled=layerGroupSelection.size<2;const act=$('.studioSelectionActions',root);if(act)act.disabled=layerGroupSelection.size<1};});
  const bg=$('.studioBackground',root),bgEye=$('.studioBackgroundEye',root);if(bg)bg.onclick=()=>{setActive('background');refreshStudioEditor()};if(bgEye)bgEye.onclick=()=>studioToggleLayer('background');
  $$('.studioTextRow[data-studio-text]',root).forEach(row=>{const id=row.dataset.studioText;$('.studioTextSelect',row).onclick=()=>{setEditMode('fresco');setActive('text:'+id);refreshStudioEditor()};$('.studioTextDelete',row).onclick=()=>studioDeleteText(id)});
  const addText=$('.studioAddText',root);if(addText)addText.onclick=studioAddTextNow;
  const groupBtn=$('.studioGroupNow',root);if(groupBtn)groupBtn.onclick=studioGroupSelected;const selectionActions=$('.studioSelectionActions',root);if(selectionActions)selectionActions.onclick=()=>openSelectedLayersActionsSheet({returnToStudio:true});const clear=$('.studioClearGroup',root);if(clear)clear.onclick=()=>{layerGroupSelection.clear();$$('.studioGroupCheck input',root).forEach(cb=>cb.checked=false);$$('.studioLayerRow.multiSelected',root).forEach(row=>row.classList.remove('multiSelected'));const cnt=$('.studioGroupCount',root);if(cnt)cnt.textContent='0';if(groupBtn)groupBtn.disabled=true;if(selectionActions)selectionActions.disabled=true};
  const openFull=$('.studioOpenManager',root);if(openFull)openFull.onclick=()=>{closeStudioEditor();openImageLayersSheet()};
  const txt=studioActiveText();if(txt){
    normalizeTextStyle(txt);const value=$('.studioTextValue',root),size=$('.studioTextSize',root),stroke=$('.studioTextStroke',root),color=$('.studioTextColor',root),strokeColor=$('.studioTextStrokeColor',root),font=$('.studioTextFont',root),weight=$('.studioTextWeight',root),italic=$('.studioTextItalic',root),spacing=$('.studioTextSpacing',root),lineHeight=$('.studioTextLineHeight',root),align=$('.studioTextAlign',root),bgEnabled=$('.studioTextBgEnabled',root),bgColor=$('.studioTextBgColor',root),bgOpacity=$('.studioTextBgOpacity',root),bgPadding=$('.studioTextBgPadding',root),bgRadius=$('.studioTextBgRadius',root);
    const update=()=>{txt.text=value?.value||tr('text');txt.fontSize=clamp(+size?.value||180,40,700);txt.strokeWidth=clamp(+stroke?.value||0,0,60);if(color)txt.color=color.value;if(strokeColor)txt.strokeColor=strokeColor.value;if(font)txt.fontFamily=font.value;if(weight)txt.fontWeight=clamp(+weight.value||800,100,900);if(italic)txt.fontItalic=italic.checked;if(spacing)txt.letterSpacing=clamp(+spacing.value||0,-40,160);if(lineHeight)txt.lineHeight=clamp(+lineHeight.value||1.08,.7,2.4);if(align)txt.textAlign=align.value;if(bgEnabled)txt.backgroundEnabled=bgEnabled.checked;if(bgColor)txt.backgroundColor=bgColor.value;if(bgOpacity)txt.backgroundOpacity=clamp((+bgOpacity.value||0)/100,0,1);if(bgPadding)txt.backgroundPadding=clamp(+bgPadding.value||0,0,180);if(bgRadius)txt.backgroundRadius=clamp(+bgRadius.value||0,0,240);normalizeTextStyle(txt);const fields=$('.studioTextBgFields',root);if(fields)fields.hidden=!txt.backgroundEnabled;render();scheduleSave()};
    [value,size,stroke,color,strokeColor,font,weight,italic,spacing,lineHeight,align,bgEnabled,bgColor,bgOpacity,bgPadding,bgRadius].filter(Boolean).forEach(el=>el.addEventListener(el.type==='checkbox'||el.tagName==='SELECT'?'change':'input',update));
    const imp=$('.studioImportFont',root);if(imp)imp.onclick=()=>importProjectFont(txt,()=>refreshStudioEditor());
    const transform=$('.studioTransform',root),dup=$('.studioDuplicateText',root),del=$('.studioDeleteText',root);if(transform)transform.onclick=()=>openTransformSheet();if(dup)dup.onclick=()=>studioDuplicateText(txt.id);if(del)del.onclick=()=>studioDeleteText(txt.id);return;
  }
  const l=studioActiveLayer();if(!l)return;const isBg=l===state.bg,id=isBg?'background':l.id;const rng=$('.studioOpacity input',root);if(rng){rng.oninput=e=>{l.opacity=+e.target.value/100;$('.studioOpacity strong',root).textContent=`${e.target.value}%`;render();scheduleSave()};}
  const transform=$('.studioTransform',root);if(transform)transform.onclick=()=>openTransformSheet();const vis=$('.studioVisibility',root);if(vis)vis.onclick=()=>studioToggleLayer(id);
  if(!isBg){const down=$('.studioMoveDown',root),up=$('.studioMoveUp',root),dup=$('.studioDuplicate',root),ren=$('.studioRename',root),del=$('.studioDelete',root),ung=$('.studioUngroup',root);if(down)down.onclick=()=>studioMoveLayer(id,-1);if(up)up.onclick=()=>studioMoveLayer(id,1);if(dup)dup.onclick=()=>studioDuplicateLayer(id);if(del)del.onclick=()=>studioDeleteLayer(id);if(ung)ung.onclick=()=>studioUngroupLayer(id);if(ren)ren.onclick=()=>{closeStudioEditor({keepOrientation:true});renameImageLayer(id)};}
}
function refreshStudioEditor(){
  if(!studioEditorRoot)return;normalizeLayerGroups();const left=$('.studioLayerList',studioEditorRoot),texts=$('.studioTextList',studioEditorRoot),right=$('.studioToolsBody',studioEditorRoot);if(left)left.innerHTML=studioLayerRowsHtml();if(texts)texts.innerHTML=studioTextRowsHtml();if(right)right.innerHTML=studioToolsHtml();const cnt=$('.studioGroupCount',studioEditorRoot);if(cnt)cnt.textContent=String(layerGroupSelection.size);const gb=$('.studioGroupNow',studioEditorRoot);if(gb)gb.disabled=layerGroupSelection.size<2;bindStudioPanels();refreshStudioMissionControls();applyStudioCanvasSize();
}
function refreshStudioMissionControls(){
  if(!studioEditorRoot)return;const mission=$('.studioMissionMode',studioEditorRoot),fresco=$('.studioFrescoMode',studioEditorRoot),rc=parseMissionKey(state.selectedMissionKey);
  mission?.classList.toggle('on',state.editMode==='mission');fresco?.classList.toggle('on',state.editMode==='fresco');
  if(mission){const label=$('.studioMissionLabel',mission);if(label)label.textContent=state.editMode==='mission'&&rc?`M${missionNumber(rc.row,rc.col)}`:tr('studioMissionMode');mission.title=state.editMode==='mission'&&rc?tr('missionSelected',{n:missionNumber(rc.row,rc.col)}):tr('tapMedallion');}
}
async function requestStudioFullscreen(){if(!studioEditorRoot)return;try{if(document.documentElement.requestFullscreen&&!document.fullscreenElement)await document.documentElement.requestFullscreen()}catch{}setTimeout(()=>applyStudioCanvasSize(),160)}
function studioToggleDrawer(selector){if(!studioEditorRoot)return;const target=$(selector,studioEditorRoot);$$('.studioDrawer',studioEditorRoot).forEach(d=>{if(d!==target)d.classList.remove('open')});target?.classList.toggle('open')}
function openStudioEditor(){
  if(!requireFrescoFlow())return;setEditMode('fresco');if(studioEditorRoot)return;closeSheet();studioZoom=1;studioFitMode='six';studioPanMode=false;
  studioCanvasHome={parent:canvas.parentNode,next:canvas.nextSibling};const root=document.createElement('div');root.className='studioEditorBack';root.innerHTML=`<div class="studioTop"><button class="studioClose" type="button">${icon('close')}</button><div class="studioTitle"><b>${tr('studioTitle')}</b><small>${state.rows*6} ${tr('missions').toLowerCase()} · ${tr('studioRotateHint')}</small></div><div class="studioZoom"><button type="button" class="studioMissionMode" title="${tr('tapMedallion')}">🎯 <span class="studioMissionLabel">${tr('studioMissionMode')}</span></button><button type="button" class="studioFrescoMode on" title="${tr('studioFrescoMode')}">◎ <span>${tr('studioFrescoMode')}</span></button><button type="button" class="studioZoomOut" title="−">−</button><button type="button" class="studioZoomIn" title="＋">＋</button><button type="button" class="studioPan" title="${tr('studioPan')}">✋</button><button type="button" class="studioFullscreen" title="${tr('studioFullscreen')}" aria-label="${tr('studioFullscreen')}">⛶</button></div></div><div class="studioBody"><div class="studioScroll"><div class="studioCanvasMount"><div class="studioCanvasStage"></div></div></div><button class="studioEdge studioEdgeLeft" type="button">${icon('layers')}<span>${tr('studioLayers')}</span></button><button class="studioEdge studioEdgeText" type="button">${icon('text')}<span>${tr('studioTexts')}</span></button><button class="studioEdge studioEdgeRight" type="button">${icon('move')}<span>${tr('studioTools')}</span></button><aside class="studioDrawer studioDrawerLeft"><div class="studioDrawerHead"><b>${tr('studioLayers')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioLayerActions"><button class="studioAddLayer primary" type="button">＋ ${tr('addLayerChoiceTitle')}</button><button class="studioOpenManager secondary" type="button">⋯ ${tr('layersTitle')}</button></div><div class="studioLayerList"></div><div class="studioGroupMini" ${layerGroupSelection.size>=2?'':'hidden'}><span>${tr('multiSelection')} <b class="studioGroupCount">${layerGroupSelection.size}</b></span><div><button class="studioClearGroup" type="button">×</button><button class="studioSelectionActions" type="button" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('editSelection')}</button><button class="studioGroupNow" type="button" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('studioGroupNow')}</button></div></div></aside><aside class="studioDrawer studioDrawerText"><div class="studioDrawerHead"><b>${tr('studioTexts')}</b><button class="studioDrawerClose" type="button">×</button></div><button class="studioAddText primary" type="button">＋ ${tr('studioAddText')}</button><div class="studioTextList"></div></aside><aside class="studioDrawer studioDrawerRight"><div class="studioDrawerHead"><b>${tr('studioTools')}</b><button class="studioDrawerClose" type="button">×</button></div><div class="studioToolsBody"></div></aside></div>`;document.body.appendChild(root);studioEditorRoot=root;$('.studioCanvasStage',root).appendChild(canvas);canvas.classList.add('studioCanvas');
  $('.studioClose',root).onclick=()=>closeStudioEditor();$('.studioEdgeLeft',root).onclick=()=>studioToggleDrawer('.studioDrawerLeft');$('.studioEdgeText',root).onclick=()=>studioToggleDrawer('.studioDrawerText');$('.studioEdgeRight',root).onclick=()=>studioToggleDrawer('.studioDrawerRight');$$('.studioDrawerClose',root).forEach(b=>b.onclick=()=>b.closest('.studioDrawer').classList.remove('open'));
  $('.studioMissionMode',root).onclick=()=>{studioPanMode=false;root.classList.remove('panMode');canvas.style.pointerEvents='';$('.studioPan',root).classList.remove('on');setEditMode('mission');refreshStudioMissionControls();};
  $('.studioFrescoMode',root).onclick=()=>{setEditMode('fresco');studioFitMode='all';studioZoom=1;applyStudioCanvasSize({recenter:true});refreshStudioMissionControls();};
  $('.studioZoomOut',root).onclick=()=>{studioZoom=clamp(studioZoom-.2,.35,4);applyStudioCanvasSize()};$('.studioZoomIn',root).onclick=()=>{studioZoom=clamp(studioZoom+.2,.35,4);applyStudioCanvasSize()};$('.studioFullscreen',root).onclick=requestStudioFullscreen;$('.studioPan',root).onclick=()=>{studioPanMode=!studioPanMode;root.classList.toggle('panMode',studioPanMode);canvas.style.pointerEvents=studioPanMode?'none':'';$('.studioPan',root).classList.toggle('on',studioPanMode)};$('.studioAddLayer',root).onclick=()=>openAddLayerChoiceSheet({returnToStudio:true});
  refreshStudioEditor();render();setTimeout(()=>{applyStudioCanvasSize({recenter:true});requestStudioFullscreen()},50);window.addEventListener('resize',applyStudioCanvasSize);
}
function closeStudioEditor({keepOrientation=false}={}){
  if(!studioEditorRoot)return;window.removeEventListener('resize',applyStudioCanvasSize);canvas.classList.remove('studioCanvas');canvas.style.width='';canvas.style.height='';canvas.style.pointerEvents='';canvas.style.position='';canvas.style.left='';canvas.style.top='';canvas.style.transform='';canvas.style.transformOrigin='';studioPanMode=false;if(studioCanvasHome?.parent){if(studioCanvasHome.next)studioCanvasHome.parent.insertBefore(canvas,studioCanvasHome.next);else studioCanvasHome.parent.appendChild(canvas)}const root=studioEditorRoot;studioEditorRoot=null;root.remove();if(!keepOrientation){try{screen.orientation?.unlock?.()}catch{}studioOrientationLocked=false;try{if(document.fullscreenElement)document.exitFullscreen()}catch{}}render();
}


let layerGroupSelection=new Set();
function normalizeLayerGroups(){
  const counts=new Map();
  for(const l of state.imageLayers)if(l.groupId)counts.set(l.groupId,(counts.get(l.groupId)||0)+1);
  for(const l of state.imageLayers){
    if(l.groupId&&(counts.get(l.groupId)||0)<2){l.groupId=null;l.groupNumber=null;}
  }
  const validGroups=[...new Set(state.imageLayers.filter(l=>l.groupId).map(l=>l.groupId))];
  const assigned=new Map(),used=new Set();
  for(const gid of validGroups){
    const existing=state.imageLayers.find(l=>l.groupId===gid&&Number.isInteger(+l.groupNumber)&&+l.groupNumber>0&&!used.has(+l.groupNumber));
    if(existing){assigned.set(gid,+existing.groupNumber);used.add(+existing.groupNumber);}
  }
  let next=1;
  for(const gid of validGroups){
    if(!assigned.has(gid)){while(used.has(next))next++;assigned.set(gid,next);used.add(next);}
    const n=assigned.get(gid);for(const l of state.imageLayers)if(l.groupId===gid)l.groupNumber=n;
  }
}
function groupInfoForLayer(l){
  if(!l?.groupId)return null;normalizeLayerGroups();
  const n=Math.max(1,parseInt(l.groupNumber)||1),count=state.imageLayers.filter(x=>x.groupId===l.groupId).length;
  return {number:n,count,color:((n-1)%6)+1,label:tr('groupName',{n})};
}
function missionOptionsHtml(selected=1){const total=state.rows*COLS;return Array.from({length:total},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===+selected?'selected':''}>${tr('missionLabel',{n})}</option>`).join('')}
async function createMissionImageLayer(file,{missionNumber=1,fitMode='cover',name=null}={}){if(!file)return null;if(file.size>45*1024*1024)toast(tr('heavyImage'));const img=await blobToImage(file);const layer={id:uid(),name:name||file.name?.replace(/\.[^.]+$/,'')||tr('layerName'),image:img,blob:file,x:0,y:0,scale:1,rotation:0,opacity:1,visible:true,groupId:null,groupNumber:null,scope:'mission',missionNumber:clamp(parseInt(missionNumber)||1,1,state.rows*COLS),fitMode:fitMode==='contain'?'contain':'cover'};fitImageLayer(layer);state.imageLayers.push(layer);return layer}
function openAddLayerChoiceSheet({returnToStudio=!!studioEditorRoot}={}){
  const sh=openSheet(`<div class="sheethead"><div><h2>＋ ${tr('addLayerChoiceTitle')}</h2><p>${tr('addLayerChoiceText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule"><span class="dot"></span><span>${tr('layerScopeHelp')}</span></div><div class="layerScopeChoice"><button class="primary addWholeLayer" type="button"><b>▣ ${tr('addLayerWhole')}</b><small>${tr('addLayerWholeText')}</small></button><button class="secondary addOneMissionLayer" type="button"><b>🎯 ${tr('addLayerOneMission')}</b><small>${tr('addLayerOneMissionText')}</small></button><button class="secondary addManyMissionLayers" type="button"><b>▦ ${tr('addLayerManyMissions')}</b><small>${tr('addLayerManyMissionsText')}</small></button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};
  $('.close',sh).onclick=back;
  $('.addWholeLayer',sh).onclick=()=>{closeSheet();chooseImageFile('layer')};
  $('.addOneMissionLayer',sh).onclick=()=>{closeSheet();chooseMissionLayerFile()};
  $('.addManyMissionLayers',sh).onclick=()=>{closeSheet();chooseMissionSeriesFiles()};
}
function chooseMissionLayerFile(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const file=input.files?.[0];input.remove();if(file)openMissionLayerImportSheet(file,{returnToStudio})};input.click()}
function openMissionLayerImportSheet(file,{returnToStudio=false}={}){const url=URL.createObjectURL(file),defaultMission=1;const sh=openSheet(`<div class="sheethead"><div><h2>🎯 ${tr('addMissionLayer')}</h2><p>${tr('missionLayerHint',{n:defaultMission})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="missionLayerImportPreview"><img src="${escapeAttr(url)}" alt=""><div><b>${escapeHtml(file.name)}</b><small>${Math.round(file.size/1024)} KB</small></div></div><div class="field"><label>${tr('missionTarget')}</label><select class="missionLayerTarget">${missionOptionsHtml(defaultMission)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="missionLayerFit"><option value="cover">${tr('fitCover')}</option><option value="contain">${tr('fitContain')}</option></select></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('add')}</button></div>`);const cleanup=()=>URL.revokeObjectURL(url),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.missionLayerTarget',sh).onchange=e=>{$('.sheethead p',sh).textContent=tr('missionLayerHint',{n:e.target.value})};$('.import',sh).onclick=async()=>{const before=beginHistory(),n=+$('.missionLayerTarget',sh).value,fit=$('.missionLayerFit',sh).value,layer=await createMissionImageLayer(file,{missionNumber:n,fitMode:fit});if(!layer){cleanup();return}setEditMode('fresco');setActive('image:'+layer.id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionLayerAdded',{n}));done()}}
function chooseMissionSeriesFiles(){const returnToStudio=!!studioEditorRoot,input=document.createElement('input');input.type='file';input.multiple=true;input.accept='image/png,image/jpeg,image/webp';input.style.display='none';document.body.appendChild(input);input.onchange=()=>{const files=[...(input.files||[])];input.remove();if(files.length)openMissionSeriesSheet(files,{returnToStudio})};input.click()}
function openMissionSeriesSheet(files,{returnToStudio=false}={}){const items=files.slice().sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})).map((file,i)=>({file,missionNumber:(i%(state.rows*COLS))+1,url:URL.createObjectURL(file)}));let fitMode='cover';const cleanup=()=>items.forEach(x=>URL.revokeObjectURL(x.url)),done=()=>{cleanup();if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};const renderSheet=()=>{const rows=items.map((x,i)=>`<div class="missionSeriesRow" data-series-index="${i}"><img src="${escapeAttr(x.url)}" alt=""><div class="missionSeriesInfo"><b>${escapeHtml(x.file.name)}</b><select class="seriesMission">${missionOptionsHtml(x.missionNumber)}</select></div><div class="missionSeriesOrder"><button type="button" class="seriesUp" ${i===0?'disabled':''}>↑</button><button type="button" class="seriesDown" ${i===items.length-1?'disabled':''}>↓</button></div></div>`).join('');const sh=openSheet(`<div class="sheethead"><div><h2>▦ ${tr('missionSeriesTitle')}</h2><p>${tr('missionSeriesText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule"><span class="dot"></span><span>${tr('missionSeriesDetected',{n:items.length})}${items.length>state.rows*COLS?` · ${tr('missionSeriesTooMany')}`:''}</span></div><div class="field"><label>${tr('fitMode')}</label><select class="seriesFit"><option value="cover" ${fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="missionSeriesList">${rows}</div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary import">${tr('missionSeriesImport')}</button></div>`);$('.close',sh).onclick=done;$('.cancel',sh).onclick=done;$('.seriesFit',sh).onchange=e=>{fitMode=e.target.value};$$('.missionSeriesRow',sh).forEach(row=>{const i=+row.dataset.seriesIndex;$('.seriesMission',row).onchange=e=>items[i].missionNumber=+e.target.value;$('.seriesUp',row).onclick=()=>{if(i<=0)return;[items[i-1],items[i]]=[items[i],items[i-1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()};$('.seriesDown',row).onclick=()=>{if(i>=items.length-1)return;[items[i+1],items[i]]=[items[i],items[i+1]];items.forEach((x,j)=>x.missionNumber=j<state.rows*COLS?j+1:x.missionNumber);renderSheet()}});$('.import',sh).onclick=async()=>{const before=beginHistory(),created=[];for(const x of items){const l=await createMissionImageLayer(x.file,{missionNumber:x.missionNumber,fitMode});if(l)created.push(l)}if(created.length){setEditMode('fresco');setActive('image:'+created[created.length-1].id);commitHistory(before,tr('histAddLayer'));scheduleSave();render();toast(tr('missionSeriesAdded',{n:created.length}))}done()}};renderSheet()}
function imageLayerIndex(id){return state.imageLayers.findIndex(l=>l.id===id)}
function chooseImageFile(mode='background'){
  pendingImageMode=mode==='background'?'background':'layer';
  const input=$('#fileInput');if(!input)return;input.value='';input.click();
}
function activateImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  setEditMode('fresco');setActive('image:'+id);render();scheduleSave();
}
function moveImageLayer(id,delta){
  const i=imageLayerIndex(id),j=i+delta;if(i<0||j<0||j>=state.imageLayers.length)return;
  const before=beginHistory();
  [state.imageLayers[i],state.imageLayers[j]]=[state.imageLayers[j],state.imageLayers[i]];
  commitHistory(before,tr('histReorderLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleImageLayerVisibility(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;const before=beginHistory();l.visible=l.visible===false;
  commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet();
}
function toggleBackgroundVisibility(){const before=beginHistory();state.bg.visible=state.bg.visible===false;commitHistory(before,tr('histVisibilityLayer'));scheduleSave();render();openImageLayersSheet()}
function deleteImageLayer(id){
  const i=imageLayerIndex(id);if(i<0)return;const before=beginHistory();
  state.imageLayers.splice(i,1);layerGroupSelection.delete(id);if(state.active==='image:'+id)state.active='background';normalizeLayerGroups();
  commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDeleted'));
}
function duplicateImageLayer(id){
  const src=state.imageLayers.find(x=>x.id===id);if(!src)return;const before=beginHistory();
  const copy={...src,id:uid(),name:`${imageLayerLabel(src,imageLayerIndex(id))} ${tr('copySuffix')}`,x:(src.x||0)+24,y:(src.y||0)+24,groupId:null,groupNumber:null};
  const i=imageLayerIndex(id);state.imageLayers.splice(i+1,0,copy);state.active='image:'+copy.id;
  commitHistory(before,tr('histDuplicateLayer'));scheduleSave();render();openImageLayersSheet();toast(tr('layerDuplicated'));
}
function renameImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameLayer')}</h2><p>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layer')}</label><input id="layerRename" maxlength="60" value="${escapeAttr(imageLayerLabel(l,imageLayerIndex(id)))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=()=>openImageLayersSheet();$('.cancel',sh).onclick=()=>openImageLayersSheet();
  $('.save',sh).onclick=()=>{const before=beginHistory();l.name=$('#layerRename',sh).value.trim()||tr('layerName');commitHistory(before,tr('histRenameLayer'));scheduleSave();openImageLayersSheet()};
}
function selectedImageLayerIds(){return [...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id))}
function syncLayerSelectionUi(sh=currentSheet){
  if(!sh)return;const ids=selectedImageLayerIds(),n=ids.length;
  const bulk=$('.layerBulkPanel',sh);if(bulk)bulk.hidden=n<2;
  const count=$('.layerSelectionCount',sh);if(count)count.textContent=String(n);
  const clear=$('.clearGroup',sh);if(clear)clear.disabled=n<2;
  const group=$('.doGroup',sh);if(group)group.disabled=n<2;
  const edit=$('.editSelection',sh);if(edit)edit.disabled=n<2;
  const del=$('.deleteSelection',sh);if(del)del.disabled=n<2;
  const summary=$('.selectedLayersSummary',sh);if(summary)summary.textContent=tr('selectedLayersCount',{n});
  $$('.imageLayerRow[data-layer]',sh).forEach(row=>{const id=row.dataset.layer,checked=layerGroupSelection.has(id);row.classList.toggle('multiSelected',checked);const cb=$('.layerGroupCheck',row);if(cb)cb.checked=checked});
  if(studioEditorRoot){const mini=$('.studioGroupMini',studioEditorRoot);if(mini)mini.hidden=n<2;const sc=$('.studioGroupCount',studioEditorRoot);if(sc)sc.textContent=String(n);const se=$('.studioSelectionActions',studioEditorRoot);if(se)se.disabled=n<2;const sg=$('.studioGroupNow',studioEditorRoot);if(sg)sg.disabled=n<2;}
}
function openSelectedLayersActionsSheet({returnToStudio=!!studioEditorRoot}={}){
  const ids=selectedImageLayerIds();if(!ids.length){toast(tr('selectionEmpty'));return}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('editSelection')}</h2><p>${tr('selectedLayersCount',{n:ids.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layerScope')}</label><select class="bulkScope"><option value="keep">${tr('bulkScopeKeep')}</option><option value="global">${tr('wholeBanner')}</option><option value="mission">${tr('missionLayer')}</option></select></div><div class="field bulkMissionField" hidden><label>${tr('missionTarget')}</label><select class="bulkMission">${missionOptionsHtml(1)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="bulkFit"><option value="keep">${tr('bulkFitKeep')}</option><option value="cover">${tr('fitCover')}</option><option value="contain">${tr('fitContain')}</option></select></div><div class="field"><label>${tr('bulkVisibility')}</label><select class="bulkVisibility"><option value="keep">${tr('bulkVisibilityKeep')}</option><option value="show">${tr('bulkShow')}</option><option value="hide">${tr('bulkHide')}</option></select></div><label class="switchline"><input type="checkbox" class="bulkOpacityEnable"> ${tr('bulkOpacityEnable')}</label><div class="field bulkOpacityField" hidden><label>${tr('layerOpacity')} <span class="bulkOpacityVal">100%</span></label><input class="bulkOpacity" type="range" min="0" max="100" value="100"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary apply">${tr('applyToSelection')}</button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};
  $('.close',sh).onclick=back;$('.cancel',sh).onclick=back;
  const scope=$('.bulkScope',sh),missionField=$('.bulkMissionField',sh),opEnable=$('.bulkOpacityEnable',sh),opField=$('.bulkOpacityField',sh),op=$('.bulkOpacity',sh);
  scope.onchange=()=>missionField.hidden=scope.value!=='mission';opEnable.onchange=()=>opField.hidden=!opEnable.checked;op.oninput=()=>$('.bulkOpacityVal',sh).textContent=`${op.value}%`;
  $('.apply',sh).onclick=()=>{const before=beginHistory(),scopeValue=scope.value,mission=+$('.bulkMission',sh).value,fit=$('.bulkFit',sh).value,vis=$('.bulkVisibility',sh).value,opacity=+op.value/100,touchedGroups=new Set(ids.map(id=>state.imageLayers.find(x=>x.id===id)?.groupId).filter(Boolean));if(scopeValue!=='keep'&&touchedGroups.size){for(const x of state.imageLayers)if(touchedGroups.has(x.groupId)){x.groupId=null;x.groupNumber=null}}for(const id of ids){const l=state.imageLayers.find(x=>x.id===id);if(!l)continue;normalizeImageLayerScope(l);if(scopeValue!=='keep'){const previousFit=l.fitMode;l.scope=scopeValue==='mission'?'mission':'global';if(l.scope==='mission'){l.missionNumber=clamp(mission,1,state.rows*COLS);l.fitMode=fit==='keep'?(previousFit==='contain'?'contain':'cover'):(fit==='contain'?'contain':'cover');fitImageLayer(l)}else{l.missionNumber=null;fitImageLayer(l)}}else if(fit!=='keep'&&l.scope==='mission'){l.fitMode=fit==='contain'?'contain':'cover';fitImageLayer(l)}if(vis==='show')l.visible=true;else if(vis==='hide')l.visible=false;if(opEnable.checked)l.opacity=clamp(opacity,0,1)}normalizeLayerGroups();commitHistory(before,tr('histImageZoom'));scheduleSave();render();toast(tr('selectionUpdated'));back()};
}
function confirmDeleteSelectedLayers({returnToStudio=!!studioEditorRoot}={}){
  const ids=selectedImageLayerIds();if(!ids.length){toast(tr('selectionEmpty'));return}
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteSelection')}</h2><p>${tr('deleteSelectionConfirm',{n:ids.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirm">${icon('trash')} ${tr('delete')}</button></div>`);
  const back=()=>{if(returnToStudio){closeSheet();refreshStudioEditor()}else openImageLayersSheet()};$('.close',sh).onclick=back;$('.cancel',sh).onclick=back;$('.confirm',sh).onclick=()=>{const before=beginHistory(),set=new Set(ids),touchedGroups=new Set(state.imageLayers.filter(l=>set.has(l.id)&&l.groupId).map(l=>l.groupId));state.imageLayers=state.imageLayers.filter(l=>!set.has(l.id));if(touchedGroups.size){for(const l of state.imageLayers)if(touchedGroups.has(l.groupId)){l.groupId=null;l.groupNumber=null}}for(const id of ids)layerGroupSelection.delete(id);if(state.active.startsWith('image:')&&set.has(state.active.slice(6)))state.active='background';normalizeLayerGroups();commitHistory(before,tr('histDeleteLayer'));scheduleSave();render();toast(tr('selectionDeleted'));back()};
}
function groupSelectedImageLayers(){
  const ids=[...layerGroupSelection].filter(id=>state.imageLayers.some(l=>l.id===id));
  if(ids.length<2){toast(tr('groupNeedTwo'));return}
  const chosen=state.imageLayers.filter(l=>ids.includes(l.id)).map(normalizeImageLayerScope),scopeKey=l=>l.scope==='mission'?`mission:${l.missionNumber}`:'global';if(new Set(chosen.map(scopeKey)).size>1){toast(tr('missionScopeMismatch'));return}
  const before=beginHistory(),gid='g_'+uid();for(const l of state.imageLayers)if(ids.includes(l.id)){l.groupId=gid;l.groupNumber=null;}normalizeLayerGroups();
  state.active='image:'+ids[0];layerGroupSelection.clear();commitHistory(before,tr('histGroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupCreated'));
}
function ungroupImageLayer(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l?.groupId)return;const gid=l.groupId,before=beginHistory();
  for(const x of state.imageLayers)if(x.groupId===gid){x.groupId=null;x.groupNumber=null;}commitHistory(before,tr('histUngroupLayers'));scheduleSave();render();openImageLayersSheet();toast(tr('groupRemoved'));
}
function setLayerOpacity(id,value){const l=state.imageLayers.find(x=>x.id===id);if(!l)return;l.opacity=clamp(value,0,1);render();scheduleSave()}
const layerPreviewUrls=new WeakMap();
function layerPreviewUrl(blob,image){
  if(blob instanceof Blob){
    let url=layerPreviewUrls.get(blob);
    if(!url){url=URL.createObjectURL(blob);layerPreviewUrls.set(blob,url)}
    return url;
  }
  const src=image?.src||'';
  return src&&!src.startsWith('blob:')?src:'';
}
function imageLayerThumbHtml(blob,image,{fallback='▧',alt='',studio=false}={}){
  const src=layerPreviewUrl(blob,image);
  if(!src)return `<span class="${studio?'studioLayerGlyph':'layerGlyph'}">${fallback}</span>`;
  return `<span class="${studio?'studioLayerThumb':'layerThumb'}"><img src="${escapeAttr(src)}" alt="" aria-label="${escapeAttr(alt)}"></span>`;
}
function openImageLayersSheet(){
  setEditMode('fresco');normalizeLayerGroups();
  for(const id of [...layerGroupSelection])if(!state.imageLayers.some(l=>l.id===id))layerGroupSelection.delete(id);
  const ordered=[...state.imageLayers].map((l,i)=>({l,i})).reverse();
  const layerRows=ordered.map(({l,i})=>{
    const active=state.active==='image:'+l.id,top=i===state.imageLayers.length-1,bottom=i===0,grouped=!!l.groupId,ginfo=groupInfoForLayer(l);
    const w=l.image?.naturalWidth||0,h=l.image?.naturalHeight||0;
    return `<div class="imageLayerRow ${active?'active':''} ${l.visible===false?'hidden':''} ${grouped?`groupedLayer groupColor${ginfo.color}`:''}" data-layer="${escapeAttr(l.id)}">
      ${grouped?`<span class="groupEdge" aria-hidden="true"></span>`:''}
      <label class="layerCheck" title="${tr('multiSelection')}"><input type="checkbox" class="layerGroupCheck" ${layerGroupSelection.has(l.id)?'checked':''}></label>
      <button class="layerSelect" type="button">${imageLayerThumbHtml(l.blob,l.image,{fallback:grouped?'▱':'▧',alt:imageLayerLabel(l,i)})}<span class="layerCopy"><b>${escapeHtml(imageLayerLabel(l,i))} ${missionLayerBadgeHtml(l)}</b><small>${w&&h?tr('layerDimensions',{w,h}):''}${l.scope==='mission'?` · ${tr('missionLayer')}`:''}${grouped?` · <span class="groupInline">${tr('groupCount',{n:ginfo.count})}</span>`:''}</small>${grouped?`<span class="groupBadge">${escapeHtml(ginfo.label)}</span>`:''}</span>${active?`<em>${tr('selected')}</em>`:''}</button>
      <button class="layerEye" title="${l.visible===false?tr('hiddenLayer'):tr('visibleLayer')}">${l.visible===false?'◌':'◉'}</button>
      <div class="layerQuick"><button class="layerDown" ${bottom?'disabled':''} title="${tr('moveDown')}">↓</button><button class="layerUp" ${top?'disabled':''} title="${tr('moveUp')}">↑</button><button class="layerMore" title="${tr('layerTransform')}">⋯</button></div>
    </div>`;
  }).join('')||`<div class="layerEmpty">${tr('layersDesc')}</div>`;
  const activeLayer=activeImageLayer(),activeIsExtra=state.active.startsWith('image:'),groupedActive=activeIsExtra&&!!activeLayer?.groupId;
  const sh=openSheet(`<div class="sheethead"><div><h2>${icon('layers')} ${tr('layersTitle')}</h2><p>${tr('layersDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="layerAddGrid"><button class="primary addBackground">${icon('image')} ${tr('addBackground')}</button><button class="secondary addImageLayer">${icon('plus')} ${tr('addLayerChoiceTitle')}</button></div><div class="layerImportHint">${tr('layerScopeHelp')}</div>
    <div class="imageLayerStack">
      ${layerRows}
      <div class="imageLayerRow backgroundRow ${state.active==='background'?'active':''} ${state.bg.visible===false?'hidden':''}">
        <span class="layerCheck lock">⌄</span><button class="layerSelect selectBackground">${imageLayerThumbHtml(state.bg.blob,state.bg.image,{fallback:'▰',alt:tr('backgroundLayer')})}<span class="layerCopy"><b>${tr('backgroundLayer')}</b><small>${state.bg.image?tr('layerDimensions',{w:state.bg.image.naturalWidth,h:state.bg.image.naturalHeight}):tr('backgroundMissing')}</small></span>${state.active==='background'?`<em>${tr('selected')}</em>`:''}</button><button class="layerEye backgroundEye">${state.bg.visible===false?'◌':'◉'}</button><span class="layerBottomLock">🔒</span>
      </div>
    </div>
    <div class="layerBulkPanel" ${layerGroupSelection.size>=2?'':'hidden'}><div class="layerGroupBar"><div><b>${tr('multiSelection')}</b><small>${tr('multiSelectionHint')}</small><small class="selectedLayersSummary">${tr('selectedLayersCount',{n:layerGroupSelection.size})}</small></div><span class="layerSelectionCount">${layerGroupSelection.size}</span></div>
    <div class="actions layerGroupActions"><button class="secondary clearGroup" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('clearGroupSelection')}</button><button class="secondary editSelection" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('editSelection')}</button><button class="primary doGroup" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('group')}</button><button class="danger deleteSelection" ${layerGroupSelection.size>=2?'':'disabled'}>${tr('deleteSelection')}</button></div></div>${groupedActive?`<div class="actions"><button class="secondary doUngroup">${tr('layerUngroup')}</button></div>`:''}
    <p class="small layerFooterHint">${tr('backgroundFixed')} ${tr('layerSelectHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('.addBackground',sh).onclick=()=>{closeSheet();chooseImageFile('background')};$('.addImageLayer',sh).onclick=()=>openAddLayerChoiceSheet();
  $('.selectBackground',sh).onclick=()=>{setActive('background');openImageLayersSheet()};$('.backgroundEye',sh).onclick=toggleBackgroundVisibility;
  $$('.imageLayerRow[data-layer]',sh).forEach(row=>{
    const id=row.dataset.layer;$('.layerSelect',row).onclick=()=>{activateImageLayer(id);openImageLayersSheet()};
    $('.layerEye',row).onclick=()=>toggleImageLayerVisibility(id);$('.layerDown',row).onclick=()=>moveImageLayer(id,-1);$('.layerUp',row).onclick=()=>moveImageLayer(id,1);
    $('.layerGroupCheck',row).onchange=e=>{if(e.target.checked)layerGroupSelection.add(id);else layerGroupSelection.delete(id);syncLayerSelectionUi(sh)};
    $('.layerMore',row).onclick=()=>openLayerActionsSheet(id);
  });
  $('.clearGroup',sh).onclick=()=>{layerGroupSelection.clear();syncLayerSelectionUi(sh)};$('.editSelection',sh).onclick=()=>openSelectedLayersActionsSheet();$('.deleteSelection',sh).onclick=()=>confirmDeleteSelectedLayers();$('.doGroup',sh).onclick=groupSelectedImageLayers;if($('.doUngroup',sh))$('.doUngroup',sh).onclick=()=>ungroupImageLayer(activeLayer.id);syncLayerSelectionUi(sh);
}
function openLayerActionsSheet(id){
  const l=state.imageLayers.find(x=>x.id===id);if(!l)return;activateImageLayer(id);normalizeImageLayerScope(l);
  const grouped=!!l.groupId,ginfo=groupInfoForLayer(l),missionControls=l.scope==='mission'?`<div class="field"><label>${tr('missionTarget')}</label><select class="layerMissionTarget">${missionOptionsHtml(l.missionNumber)}</select></div><div class="field"><label>${tr('fitMode')}</label><select class="layerMissionFit"><option value="cover" ${l.fitMode==='cover'?'selected':''}>${tr('fitCover')}</option><option value="contain" ${l.fitMode==='contain'?'selected':''}>${tr('fitContain')}</option></select></div><div class="rule"><span class="dot"></span><span>${tr('missionLayerHint',{n:l.missionNumber})}</span></div>`:'';
  const sh=openSheet(`<div class="sheethead"><div><h2>${escapeHtml(imageLayerLabel(l,imageLayerIndex(id)))} ${missionLayerBadgeHtml(l)}</h2><p>${grouped?`${tr('groupTransform')} · ${escapeHtml(ginfo.label)} · ${tr('groupCount',{n:ginfo.count})}`:tr('layerTransform')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('layerScope')}</label><select class="layerScopeSelect"><option value="global" ${l.scope==='global'?'selected':''}>${tr('wholeBanner')}</option><option value="mission" ${l.scope==='mission'?'selected':''}>${tr('missionLayer')}</option></select></div>${missionControls}<div class="field"><label>${tr('layerOpacity')} <span class="opacityVal">${Math.round((l.opacity??1)*100)}%</span></label><input class="layerOpacityRange" type="range" min="0" max="100" value="${Math.round((l.opacity??1)*100)}"></div><div class="layerActionGrid"><button class="secondary transformLayer">${icon('move')} ${grouped?tr('groupTransform'):tr('layerTransform')}</button><button class="secondary renameLayerBtn">${icon('edit')} ${tr('renameLayer')}</button><button class="secondary duplicateLayerBtn">${icon('copy')} ${tr('duplicateLayer')}</button>${grouped?`<button class="secondary ungroupLayerBtn">${tr('ungroup')}</button>`:''}<button class="danger deleteLayerBtn">${icon('trash')} ${tr('deleteLayer')}</button></div>`);
  $('.close',sh).onclick=openImageLayersSheet;const rng=$('.layerOpacityRange',sh);rng.oninput=e=>{setLayerOpacity(id,+e.target.value/100);$('.opacityVal',sh).textContent=`${e.target.value}%`};historyControl(rng,tr('histVisibilityLayer'));
  $('.layerScopeSelect',sh).onchange=e=>{const before=beginHistory();l.scope=e.target.value==='mission'?'mission':'global';l.groupId=null;l.groupNumber=null;if(l.scope==='mission'){l.missionNumber=clamp(parseInt(l.missionNumber)||1,1,state.rows*COLS);l.fitMode=l.fitMode==='contain'?'contain':'cover'}else l.missionNumber=null;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionTarget',sh))$('.layerMissionTarget',sh).onchange=e=>{const before=beginHistory();l.missionNumber=+e.target.value;fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  if($('.layerMissionFit',sh))$('.layerMissionFit',sh).onchange=e=>{const before=beginHistory();l.fitMode=e.target.value==='contain'?'contain':'cover';fitImageLayer(l);commitHistory(before,tr('histImageZoom'));scheduleSave();render();openLayerActionsSheet(id)};
  $('.transformLayer',sh).onclick=openTransformSheet;$('.renameLayerBtn',sh).onclick=()=>renameImageLayer(id);$('.duplicateLayerBtn',sh).onclick=()=>duplicateImageLayer(id);$('.deleteLayerBtn',sh).onclick=()=>deleteImageLayer(id);if($('.ungroupLayerBtn',sh))$('.ungroupLayerBtn',sh).onclick=()=>ungroupImageLayer(id);
}
function imageFitScale(o){
  if(!o?.image)return 1;
  if(o===state.bg)return Math.max(WORLD_W/o.image.naturalWidth,worldH()/o.image.naturalHeight);
  normalizeImageLayerScope(o);if(o.scope==='mission')return missionLayerFitScale(o);
  return Math.min(WORLD_W*.72/o.image.naturalWidth,worldH()*.72/o.image.naturalHeight);
}
function shiftImageItems(items,dx,dy){for(const x of items){x.x=(x.x||0)+dx;x.y=(x.y||0)+dy}}
function groupTransformBaseline(items){
  const snap=captureTransformTargets(items),center=transformCenter(snap);return {snap,center};
}
function applyRelativeGroupTransform(base,scaleFactor,rotationDelta){
  const cs=Math.cos(rotationDelta),sn=Math.sin(rotationDelta);
  for(const t of base.snap){const ox=(t.x-base.center.x)*scaleFactor,oy=(t.y-base.center.y)*scaleFactor;t.obj.x=base.center.x+ox*cs-oy*sn;t.obj.y=base.center.y+ox*sn+oy*cs;t.obj.scale=clamp(t.scale*scaleFactor,.02,30);t.obj.rotation=t.rotation+rotationDelta}
}

function openTransformSheet(){
  if(state.editMode==='mission'){
    const rc=parseMissionKey(state.selectedMissionKey);
    if(!rc){toast(tr('touchMissionFirst'));return}
    const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
    const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${n}</h2><p>${tr('missionCropOnly')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
      <div class="field"><label>${tr('localZoom')} <span id="zoomVal">${Math.round((o.scale||1)*100)}%</span></label><input id="zoom" type="range" min="20" max="500" value="${Math.round((o.scale||1)*100)}"></div>
      <div class="field"><label>${tr('rotation')} <span id="rotVal">${Math.round((o.rotation||0)*180/Math.PI)}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${Math.round((o.rotation||0)*180/Math.PI)}"></div>
      <div class="actions"><button class="secondary" id="resetBtn">${icon('reset')} ${tr('resetThisMission')}</button></div>`);
    $('.close',sh).onclick=closeSheet;
    $('#zoom',sh).oninput=e=>{o.scale=+e.target.value/100;$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),tr('histMissionZoom'));
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),tr('histMissionRotation'));
    $('#resetBtn',sh).onclick=()=>{resetSelectedMission();closeSheet()};
    return;
  }
  const o=selectedObj();if(!o)return;const isText=state.active.startsWith('text:'),isImage=!isText;
  const items=isImage?frescoTransformTargets():[o],isGroup=isImage&&items.length>1,groupBase=isGroup?groupTransformBaseline(items):null;
  const fit=isImage&&!isGroup?imageFitScale(o):1,zoomValue=isGroup?100:Math.round((isText?o.scale:o.scale/Math.max(.0001,fit))*100),rotValue=isGroup?0:Math.round((o.rotation||0)*180/Math.PI);
  const title=isText?tr('transformText'):(isGroup?tr('groupTransform'):tr('layerTransform'));
  const sh=openSheet(`<div class="sheethead"><div><h2>${title}</h2><p>${isGroup?tr('groupRelative'):tr('pinchHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${isGroup?tr('groupZoom'):tr('zoom')} <span id="zoomVal">${zoomValue}%</span></label><input id="zoom" type="range" min="20" max="500" value="${zoomValue}"></div>
    <div class="field"><label>${isGroup?tr('groupRotation'):tr('rotation')} <span id="rotVal">${rotValue}°</span></label><input id="rotation" type="range" min="-180" max="180" value="${rotValue}"></div>
    <div class="actions"><button class="secondary" id="centerBtn">${tr('center')}</button>${!isGroup?`<button class="secondary" id="resetBtn">${icon('reset')} ${tr('reset')}</button>`:''}${isText?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`);
  $('.close',sh).onclick=closeSheet;
  if(isGroup){
    const apply=()=>{applyRelativeGroupTransform(groupBase,+$('#zoom',sh).value/100,+$('#rotation',sh).value*Math.PI/180);$('#zoomVal',sh).textContent=`${$('#zoom',sh).value}%`;$('#rotVal',sh).textContent=`${$('#rotation',sh).value}°`;render();scheduleSave()};
    $('#zoom',sh).oninput=apply;$('#rotation',sh).oninput=apply;historyControl($('#zoom',sh),tr('histImageZoom'));historyControl($('#rotation',sh),tr('histImageRotation'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory(),now=transformCenter(captureTransformTargets(items));shiftImageItems(items,WORLD_W/2-now.x,worldH()/2-now.y);render();commitHistory(before,tr('histCenterImage'));scheduleSave()};
  }else{
    $('#rotation',sh).oninput=e=>{o.rotation=+e.target.value*Math.PI/180;$('#rotVal',sh).textContent=`${e.target.value}°`;render();scheduleSave()};historyControl($('#rotation',sh),isText?tr('histTextRotation'):tr('histImageRotation'));
    $('#zoom',sh).oninput=e=>{o.scale=(isText?1:fit)*(+e.target.value/100);$('#zoomVal',sh).textContent=`${e.target.value}%`;render();scheduleSave()};historyControl($('#zoom',sh),isText?tr('histTextZoom'):tr('histImageZoom'));
    $('#centerBtn',sh).onclick=()=>{const before=beginHistory();if(!isText&&o.scope==='mission'){const mr=missionLayerRect(o);if(mr){o.x=mr.cx;o.y=mr.cy}}else{o.x=WORLD_W/2;o.y=worldH()/2}render();commitHistory(before,isText?tr('histCenterText'):tr('histCenterImage'));scheduleSave()};
    $('#resetBtn',sh).onclick=()=>{const before=beginHistory();if(isText){o.scale=1;o.rotation=0;o.x=WORLD_W/2;o.y=worldH()/2}else if(o===state.bg)fitBackground();else fitImageLayer(o);closeSheet();render();commitHistory(before,isText?tr('histResetText'):tr('histResetImage'));scheduleSave()};
  }
  if(isText)$('#deleteText',sh).onclick=()=>deleteTextById(o.id);
}

function openMissionEditor(){
  const rc=parseMissionKey(state.selectedMissionKey);
  if(!rc||rc.row<0||rc.row>=state.rows){toast(tr('selectMissionFirst'));return}
  closeMissionEditor();
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorShowCircle=true;
  const n=missionNumber(rc.row,rc.col);
  const back=document.createElement('div');back.className='missioneditorback';
  back.innerHTML=`<section class="missioneditor">
    <header class="missioneditorhead">
      <button class="iconbtn missionclose" aria-label="${tr('close')}">${icon('close')}</button>
      <div><strong id="missionEditorTitle">${tr('missions')} ${n}</strong><span>${tr('individualCrop')}</span></div>
      <div class="grow"></div>
      <button class="iconbtn missioncircle on" aria-label="${tr('previewPrime')}">${icon('eye')}</button>
    </header>
    <div class="missioneditorstage"><canvas id="missionEditorCanvas" width="1024" height="1024"></canvas></div>
    <div class="missioneditorhint"><b>${tr('oneFinger')}</b> ${tr('move')} · <b>${tr('twoFingers')}</b> ${tr('zoomRotate')}</div>
    <section class="missioneditorcontrols">
      <div class="missionhistory"><button class="secondary undoActionBtn missionundo" disabled>↶ ${tr('undo')}</button><button class="secondary redoActionBtn missionredo" disabled>↷ ${tr('redo')}</button></div>
      <div class="missionnav">
        <button class="secondary missionprev">‹ ${tr('prev')}</button>
        <button class="secondary missionnext">${tr('next')} ›</button>
      </div>
      <div class="field"><label>${tr('zoom')} <span id="missionEditorZoomVal">100%</span></label><input id="missionEditorZoom" type="range" min="20" max="500" value="100"></div>
      <div class="field"><label>${tr('rotation')} <span id="missionEditorRotVal">0°</span></label><input id="missionEditorRot" type="range" min="-180" max="180" value="0"></div>
      <div class="actions"><button class="secondary missionreset">${icon('reset')} ${tr('reset')}</button><button class="primary missiondone">${tr('done')}</button></div>
    </section>
  </section>`;
  document.body.appendChild(back);missionEditorBack=back;missionEditorCanvas=$('#missionEditorCanvas',back);
  $('.missionclose',back).onclick=closeMissionEditor;$('.missiondone',back).onclick=closeMissionEditor;
  $('.missioncircle',back).onclick=()=>{missionEditorShowCircle=!missionEditorShowCircle;$('.missioncircle',back).classList.toggle('on',missionEditorShowCircle);renderMissionEditor()};
  $('.missionreset',back).onclick=()=>{const x=currentMissionEditorRc();if(!x)return;const before=beginHistory(),o=overrideFor(x.row,x.col,true);Object.assign(o,{dx:0,dy:0,scale:1,rotation:0});render();renderMissionEditor();commitHistory(before,tr('histResetMission'));scheduleSave();};
  $('.missionundo',back).onclick=undoAction;$('.missionredo',back).onclick=redoAction;
  $('.missionprev',back).onclick=()=>switchMissionEditor(-1);$('.missionnext',back).onclick=()=>switchMissionEditor(1);
  $('#missionEditorZoom',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).scale=+e.target.value/100;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorZoom',back),tr('histMissionZoom'));
  $('#missionEditorRot',back).oninput=e=>{const x=currentMissionEditorRc();if(!x)return;overrideFor(x.row,x.col,true).rotation=+e.target.value*Math.PI/180;render();renderMissionEditor();scheduleSave()};historyControl($('#missionEditorRot',back),tr('histMissionRotation'));
  bindMissionEditorGestures();renderMissionEditor();
}

function closeMissionEditor(){
  if(!missionEditorBack)return;
  missionEditorPointers.clear();missionEditorGesture=null;missionEditorBack.remove();missionEditorBack=null;missionEditorCanvas=null;scheduleSave();render();
}

function currentMissionEditorRc(){
  const rc=parseMissionKey(state.selectedMissionKey);
  return rc&&rc.row>=0&&rc.row<state.rows&&rc.col>=0&&rc.col<COLS?rc:null;
}

function switchMissionEditor(delta){
  const rc=currentMissionEditorRc();if(!rc)return;
  const total=state.rows*COLS,current=missionNumber(rc.row,rc.col);let next=current+delta;
  if(next<1)next=total;if(next>total)next=1;
  const dest=rowColForMission(next);state.selectedMissionKey=missionKey(dest.row,dest.col);overrideFor(dest.row,dest.col,true);updateMissionUi();render();renderMissionEditor();scheduleSave();
}

function renderMissionEditor(){
  if(!missionEditorCanvas||!missionEditorBack)return;
  const rc=currentMissionEditorRc();if(!rc)return;
  drawTile(missionEditorCanvas,rc.row,rc.col,missionEditorCanvas.width);
  const c=missionEditorCanvas.getContext('2d'),size=missionEditorCanvas.width;
  if(missionEditorShowCircle){
    c.save();c.fillStyle='rgba(0,0,0,.55)';c.beginPath();c.rect(0,0,size,size);c.moveTo(size,size/2);c.arc(size/2,size/2,size/2-5,0,Math.PI*2,true);c.fill('evenodd');c.strokeStyle='rgba(54,240,138,.95)';c.lineWidth=8;c.beginPath();c.arc(size/2,size/2,size/2-8,0,Math.PI*2);c.stroke();c.restore();
  }else{
    c.save();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.restore();
  }
  const o=overrideFor(rc.row,rc.col,true),n=missionNumber(rc.row,rc.col);
  const title=$('#missionEditorTitle',missionEditorBack),z=$('#missionEditorZoom',missionEditorBack),r=$('#missionEditorRot',missionEditorBack),zv=$('#missionEditorZoomVal',missionEditorBack),rv=$('#missionEditorRotVal',missionEditorBack);
  if(title)title.textContent=tr('missionLabel',{n});
  const zp=Math.round((o.scale||1)*100),deg=Math.round((o.rotation||0)*180/Math.PI);
  if(z&&document.activeElement!==z)z.value=String(zp);if(r&&document.activeElement!==r)r.value=String(deg);if(zv)zv.textContent=`${zp}%`;if(rv)rv.textContent=`${deg}°`;
}

function missionEditorCssToTile(){
  const rect=missionEditorCanvas?.getBoundingClientRect();return rect?.width?TILE/rect.width:1;
}

function bindMissionEditorGestures(){
  const c=missionEditorCanvas;if(!c)return;c.style.touchAction='none';
  c.addEventListener('pointerdown',e=>{
    c.setPointerCapture(e.pointerId);missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true);
    if(missionEditorPointers.size===1)missionEditorGesture={mode:'one',startX:e.clientX,startY:e.clientY,dx:o.dx||0,dy:o.dy||0,historyBefore:beginHistory()};
    else if(missionEditorPointers.size===2){const pts=[...missionEditorPointers.values()];missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};}
  });
  c.addEventListener('pointermove',e=>{
    if(!missionEditorPointers.has(e.pointerId))return;missionEditorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const rc=currentMissionEditorRc();if(!rc)return;const o=overrideFor(rc.row,rc.col,true),factor=missionEditorCssToTile();
    if(missionEditorPointers.size===1&&missionEditorGesture?.mode==='one'){
      o.dx=missionEditorGesture.dx+(e.clientX-missionEditorGesture.startX)*factor;o.dy=missionEditorGesture.dy+(e.clientY-missionEditorGesture.startY)*factor;
    }else if(missionEditorPointers.size===2){
      const pts=[...missionEditorPointers.values()];
      if(missionEditorGesture?.mode!=='two'){missionEditorGesture={mode:'two',dist:distance(pts[0],pts[1]),angle:angle(pts[0],pts[1]),mid:mid(pts[0],pts[1]),dx:o.dx||0,dy:o.dy||0,scale:o.scale||1,rotation:o.rotation||0,historyBefore:missionEditorGesture?.historyBefore||beginHistory()};return}
      const d=distance(pts[0],pts[1]),a=angle(pts[0],pts[1]),m=mid(pts[0],pts[1]);
      o.scale=clamp(missionEditorGesture.scale*(d/Math.max(1,missionEditorGesture.dist)),.2,5);o.rotation=missionEditorGesture.rotation+(a-missionEditorGesture.angle);o.dx=missionEditorGesture.dx+(m.x-missionEditorGesture.mid.x)*factor;o.dy=missionEditorGesture.dy+(m.y-missionEditorGesture.mid.y)*factor;
    }
    render();renderMissionEditor();
  });
  const end=e=>{
    missionEditorPointers.delete(e.pointerId);
    const rc=currentMissionEditorRc(),o=rc?overrideFor(rc.row,rc.col,true):null;
    if(missionEditorPointers.size===0){const before=missionEditorGesture?.historyBefore;missionEditorGesture=null;commitHistory(before,tr('histResetMission'));scheduleSave();}
    else if(missionEditorPointers.size===1&&o){const pt=[...missionEditorPointers.values()][0],before=missionEditorGesture?.historyBefore;missionEditorGesture={mode:'one',startX:pt.x,startY:pt.y,dx:o.dx||0,dy:o.dy||0,historyBefore:before};}
  };
  c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);
}

function resetSelectedMission(){
  const rc=parseMissionKey(state.selectedMissionKey);if(!rc)return;
  const before=beginHistory();
  delete state.missionOverrides[missionKey(rc.row,rc.col)];render();commitHistory(before,tr('histResetMission'));scheduleSave();toast(tr('missionResetDone',{n:missionNumber(rc.row,rc.col)}));
}

function deleteTextById(id){
  const t=state.texts.find(x=>x.id===id);if(!t)return;
  const before=beginHistory();
  state.texts=state.texts.filter(x=>x.id!==id);state.active='background';closeSheet();render();commitHistory(before,tr('histDeleteText'));scheduleSave();toast(tr('textDeleted'));
}

function openTextSheet(){
  const texts=state.texts;const activeText=state.active.startsWith('text:')?texts.find(t=>t.id===state.active.slice(5)):null;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('text')}</h2><p>${tr('textLayerDesc')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('layer')}</label><select id="textLayer"><option value="new">${tr('newText')}</option>${texts.map(t=>`<option value="${t.id}" ${activeText?.id===t.id?'selected':''}>${escapeAttr(t.text.slice(0,30))}</option>`).join('')}</select></div>
    <div id="textEditor"></div>`);
  $('.close',sh).onclick=closeSheet;const sel=$('#textLayer',sh);sel.onchange=()=>drawTextEditor(sel.value);drawTextEditor(sel.value);
  function drawTextEditor(id){
    let t=id==='new'?null:texts.find(x=>x.id===id);if(t)normalizeTextStyle(t);const box=$('#textEditor',sh),td=textDefaults(t||{});
    box.innerHTML=`<div class="field"><label>${tr('text')}</label><input id="txt" value="${escapeAttr(t?.text||'I LOVE REDACTED')}" maxlength="120"></div>
      <div class="textTypographyCard"><b>${tr('textTypography')}</b><div class="field"><label>${tr('font')}</label><div class="fontPickerLine"><select id="fontFamily">${fontOptionsHtml(td.fontFamily)}</select><button type="button" class="secondary" id="importFont">＋ ${tr('importFont')}</button></div></div>
      <div class="grid2"><div class="field"><label>${tr('size')}</label><input id="size" type="number" min="40" max="700" value="${t?.fontSize||180}"></div><div class="field"><label>${tr('fontWeight')}</label><select id="fontWeight">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${td.fontWeight===w?'selected':''}>${w}</option>`).join('')}</select></div></div>
      <div class="grid2"><div class="field"><label>${tr('letterSpacing')}</label><input id="letterSpacing" type="number" min="-40" max="160" value="${td.letterSpacing||0}"></div><div class="field"><label>${tr('lineHeight')}</label><input id="lineHeight" type="number" min="0.7" max="2.4" step="0.05" value="${td.lineHeight||1.08}"></div></div>
      <div class="grid2"><div class="field"><label>${tr('textAlign')}</label><select id="textAlign"><option value="left" ${td.textAlign==='left'?'selected':''}>${tr('alignLeft')}</option><option value="center" ${td.textAlign==='center'?'selected':''}>${tr('alignCenter')}</option><option value="right" ${td.textAlign==='right'?'selected':''}>${tr('alignRight')}</option></select></div><label class="switchline textItalicLine"><input id="fontItalic" type="checkbox" ${td.fontItalic?'checked':''}> ${tr('fontItalic')}</label></div></div>
      <div class="grid2"><div class="field"><label>${tr('outline')}</label><input id="stroke" type="number" min="0" max="60" value="${t?.strokeWidth??14}"></div><div class="field"><label>${tr('color')}</label><input id="color" type="color" value="${t?.color||'#ffffff'}"></div></div>
      <div class="field"><label>${tr('outlineColor')}</label><input id="strokeColor" type="color" value="${t?.strokeColor||'#07100c'}"></div>
      <label class="switchline"><input id="textBgEnabled" type="checkbox" ${td.backgroundEnabled?'checked':''}> ${tr('textBackground')}</label>
      <div id="textBgFields" ${td.backgroundEnabled?'':'hidden'}><div class="grid2"><div class="field"><label>${tr('textBackgroundColor')}</label><input id="textBgColor" type="color" value="${td.backgroundColor}"></div><div class="field"><label>${tr('textBackgroundOpacity')}</label><input id="textBgOpacity" type="number" min="0" max="100" value="${Math.round(td.backgroundOpacity*100)}"></div></div><div class="grid2"><div class="field"><label>${tr('textBackgroundPadding')}</label><input id="textBgPadding" type="number" min="0" max="180" value="${td.backgroundPadding}"></div><div class="field"><label>${tr('textBackgroundRadius')}</label><input id="textBgRadius" type="number" min="0" max="240" value="${td.backgroundRadius}"></div></div></div>
      <div class="actions"><button class="primary" id="saveText">${t?tr('update'):tr('add')}</button>${t?`<button class="danger dangerwide" id="deleteText">${icon('trash')} ${tr('delete')}</button>`:''}</div>`;
    $('#textBgEnabled',box).onchange=e=>$('#textBgFields',box).hidden=!e.target.checked;$('#importFont',box).onclick=()=>importProjectFont(t,rec=>{if(t){t.fontFamily=rec.family;drawTextEditor(t.id)}else{const select=$('#fontFamily',box);if(select){select.insertAdjacentHTML('beforeend',`<option value="${escapeAttr(rec.family)}">★ ${escapeHtml(rec.name)}</option>`);select.value=rec.family}}});
    $('#saveText',box).onclick=()=>{
      const before=beginHistory(),wasNew=!t;
      const style={text:$('#txt',box).value||tr('text'),fontSize:+$('#size',box).value||180,color:$('#color',box).value,strokeColor:$('#strokeColor',box).value,strokeWidth:+$('#stroke',box).value||0,fontFamily:$('#fontFamily',box).value,fontWeight:+$('#fontWeight',box).value||800,fontItalic:$('#fontItalic',box).checked,letterSpacing:+$('#letterSpacing',box).value||0,lineHeight:+$('#lineHeight',box).value||1.08,textAlign:$('#textAlign',box).value,backgroundEnabled:$('#textBgEnabled',box).checked,backgroundColor:$('#textBgColor',box).value,backgroundOpacity:clamp((+$('#textBgOpacity',box).value||0)/100,0,1),backgroundPadding:clamp(+$('#textBgPadding',box).value||0,0,180),backgroundRadius:clamp(+$('#textBgRadius',box).value||0,0,240)};
      if(!t){t=textDefaults({id:uid(),x:WORLD_W/2,y:worldH()/2,scale:1,rotation:0,...style});state.texts.push(t)}else Object.assign(t,style);normalizeTextStyle(t);
      setActive('text:'+t.id);commitHistory(before,wasNew?tr('histAddText'):tr('histEditText'));scheduleSave();closeSheet();render();openTransformSheet();
    };
    if(t)$('#deleteText',box).onclick=()=>deleteTextById(t.id);
  }
}

function fillPreviewGrid(grid,size=180){
  if(!grid)return;
  grid.innerHTML='';
  for(let r=0;r<state.rows;r++)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';
    const c=document.createElement('canvas');c.width=c.height=size;box.appendChild(c);
    const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);
    grid.appendChild(box);drawTile(c,r,col,size);
  }
}

function fillPreviewFullscreenGrid(grid,size=256){
  if(!grid)return;
  grid.innerHTML='';
  // Le Studio plein écran affiche la fresque entière tournée à 90° :
  // on garde 6 missions en hauteur et chaque médaillon reprend ce même sens.
  for(let r=state.rows-1;r>=0;r--)for(let col=0;col<6;col++){
    const box=document.createElement('div');box.className='previewtile';
    const c=document.createElement('canvas');c.width=c.height=size;box.appendChild(c);
    const sp=document.createElement('span');sp.textContent=missionNumber(r,col);box.appendChild(sp);
    grid.appendChild(box);drawTileRotated(c,r,col,size,1);
  }
}
function layoutPreviewFullscreen(back){
  if(!back)return;
  const scroll=$('.previewFullScroll',back),grid=$('.previewFullGrid',back),order=$('.previewFullOrder',back);
  if(!scroll||!grid)return;
  const gap=8;
  const orderH=(order?.offsetHeight||0)+10;
  const usable=Math.max(240,scroll.clientHeight-orderH-12);
  const tile=Math.max(42,Math.floor((usable-gap*5)/6));
  grid.style.gridTemplateRows=`repeat(6, ${tile}px)`;
  grid.style.gridAutoColumns=`${tile}px`;
  grid.style.gap=`${gap}px`;
  grid.style.width='max-content';
  grid.style.maxWidth='none';
}
function openPreviewFullscreen(){
  const back=document.createElement('div');
  back.className='previewFullBack';
  back.innerHTML=`<div class="previewFullShell"><header class="previewFullHead"><div><small>${tr('preview')}</small><strong>${tr('previewPrime')}</strong><span>${state.rows*6} ${tr('missions').toLowerCase()}</span></div><button class="iconbtn previewFullClose" aria-label="${tr('tutorialClose')||'Close'}">${icon('close')}</button></header><div class="previewFullScroll"><div class="previewFullGrid"></div><p class="small previewFullOrder">${tr('previewOrder')}</p></div></div>`;
  document.body.appendChild(back);
  fillPreviewFullscreenGrid($('.previewFullGrid',back),256);
  const relayout=()=>layoutPreviewFullscreen(back);
  requestAnimationFrame(relayout);
  window.addEventListener('resize',relayout);
  const close=()=>{window.removeEventListener('resize',relayout);back.remove()};
  $('.previewFullClose',back).onclick=close;
  back.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  back.tabIndex=-1;back.focus({preventScroll:true});
}

function openPreviewSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('previewPrime')}</h2><p>${tr('previewApplied')}</p></div><div class="grow"></div><button class="secondary previewFullscreen">${icon('expand')} ${tr('studioFullscreen')}</button><button class="iconbtn close">${icon('close')}</button></div><div class="previewgrid" id="previewGrid"></div><p class="small">${tr('previewOrder')}</p>`);
  $('.close',sh).onclick=closeSheet;
  $('.previewFullscreen',sh).onclick=openPreviewFullscreen;
  fillPreviewGrid($('#previewGrid',sh),180);
}

function drawTile(c,row,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  const k=size/TILE,cropX=col*STEP+PAD,cropY=row*STEP+PAD,o=overrideFor(row,col,false);
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);if(o&&!isIdentityOverride(o))applyMissionTransform(cc,row,col,o);drawBaseBackground(cc);cc.restore();
  cc.save();cc.scale(k,k);cc.translate(-cropX,-cropY);drawOverlayWorld(cc);cc.restore();
}
function drawTileRotated(c,row,col,size=512,quarterTurns=1){
  const temp=document.createElement('canvas');
  temp.width=temp.height=size;
  drawTile(temp,row,col,size);
  const cc=c.getContext('2d');
  cc.setTransform(1,0,0,1,0,0);
  cc.clearRect(0,0,size,size);
  cc.fillStyle='#020604';
  cc.fillRect(0,0,size,size);
  cc.save();
  cc.translate(size/2,size/2);
  cc.rotate((Math.PI/2)*quarterTurns);
  cc.drawImage(temp,-size/2,-size/2,size,size);
  cc.restore();
}

function openExportSheet(){
  const count=state.rows*6;const adjusted=Object.values(state.missionOverrides).filter(o=>!isIdentityOverride(o)).length;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('exportTitle',{n:count})}</h2><p>${tr('exportIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    ${!hasImageContent()?`<div class="rule warning"><span class="dot"></span><span>${tr('noImageContent')}</span></div>`:''}
    <div class="field"><label>${tr('missionFormat')}</label><select id="exportFormat"><option value="jpeg" selected>${tr('jpgFast')}</option><option value="png">${tr('pngLossless')}</option></select></div>
    <div class="rulelist"><div class="rule"><span class="dot"></span><span>${tr('fastEncoding')}</span></div><div class="rule"><span class="dot"></span><span>${tr('rowRender')}</span></div><div class="rule"><span class="dot"></span><span>${tr('adjusted',{n:adjusted})}</span></div><div class="rule warning"><span class="dot"></span><span>${tr('nianticCheck')}</span></div></div>
    <div class="progress"><div id="progressBar"></div></div><div class="small" id="progressText" style="margin-top:7px">${tr('ready')}</div>
    <div class="actions"><button class="primary" id="doExport" ${!hasImageContent()?'disabled':''}>${tr('createZip')}</button></div>`);$('.close',sh).onclick=closeSheet;$('#doExport',sh).onclick=()=>exportZip(sh);
}

function makeRowBaseCanvas(row){
  const c=document.createElement('canvas');c.width=WORLD_W;c.height=STEP;const cc=c.getContext('2d');
  cc.fillStyle='#020604';cc.fillRect(0,0,c.width,c.height);cc.save();cc.translate(0,-row*STEP);drawBaseBackground(cc);drawOverlayWorld(cc);cc.restore();return c;
}
function drawTileFromRowBase(c,rowBase,col,size=512){
  const cc=c.getContext('2d');cc.setTransform(1,0,0,1,0,0);cc.clearRect(0,0,size,size);cc.fillStyle='#020604';cc.fillRect(0,0,size,size);
  cc.drawImage(rowBase,col*STEP+PAD,PAD,TILE,TILE,0,0,size,size);
}

async function exportZip(sh){
  const btn=$('#doExport',sh),bar=$('#progressBar',sh),txt=$('#progressText',sh),format=$('#exportFormat',sh)?.value||'jpeg';
  btn.disabled=true;
  const zip=new JSZip(),folder=zip.folder('missions'),total=state.rows*6;
  const jpeg=format==='jpeg',mime=jpeg?'image/jpeg':'image/png',ext=jpeg?'jpg':'png',quality=jpeg?.94:undefined;
  try{
    let done=0;
    // Une seule rasterisation du fond par rangée. Les missions avec correction locale
    // gardent le rendu complet afin de respecter leur transformation particulière.
    for(let row=0;row<state.rows;row++){
      const rowBase=makeRowBaseCanvas(row);
      const jobs=[];
      for(let col=0;col<COLS;col++){
        jobs.push((async()=>{
          const n=missionNumber(row,col),o=overrideFor(row,col,false),c=document.createElement('canvas');c.width=c.height=512;
          if(o&&!isIdentityOverride(o))drawTile(c,row,col,512);else drawTileFromRowBase(c,rowBase,col,512);
          const blob=await canvasBlob(c,mime,quality);return {n,blob};
        })());
      }
      const rendered=await Promise.all(jobs);
      for(const {n,blob} of rendered){folder.file(`${String(n).padStart(3,'0')}.${ext}`,blob,{compression:'STORE'});done++;}
      bar.style.width=`${Math.round(done/total*78)}%`;txt.textContent=`Missions ${done}/${total}`;await tick();
    }
    const preview=makeFlatPreview();
    const previewBlob=await canvasBlob(preview,'image/jpeg',.86);
    zip.file('apercu_fresque.jpg',previewBlob,{compression:'STORE'});
    zip.file('ordre.txt',orderText(ext),{compression:'STORE'});
    zip.file('projet.json',JSON.stringify(serializeState(),null,2),{compression:'STORE'});
    txt.textContent=tr('zipAssembly');bar.style.width='82%';
    const onProgress=meta=>{bar.style.width=`${82+Math.round((meta.percent||0)*.17)}%`;txt.textContent=`${tr('zipAssembly')} ${Math.round(meta.percent||0)}%`};
    const filename=`${safeName(state.name)}_${total}_missions.zip`;
    if(Capacitor.isNativePlatform()){
      const base64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true},onProgress);
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${filename}`,data:base64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${filename}`,directory:Directory.Cache});
      bar.style.width='100%';txt.textContent=tr('zipCreated');
      await Share.share({title:'Export Redacted BannerLab',text:`${total} ${tr('missions').toLowerCase()} · ${state.name}`,url:uri.uri,dialogTitle:tr('saveShareZip')});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE',streamFiles:true},onProgress);
      downloadBlob(blob,filename);bar.style.width='100%';txt.textContent=tr('zipDownloaded');
    }
    toast(tr('exportFinished',{format:jpeg?'JPG':'PNG'}));
  }catch(err){console.error(err);txt.textContent=tr('exportImpossible',{error:err?.message||err});toast(tr('exportFailed'))}finally{btn.disabled=false}
}

function makeFlatPreview(){const w=1200,h=Math.round(w*worldH()/WORLD_W);const c=document.createElement('canvas');c.width=w;c.height=h;const cc=c.getContext('2d');cc.fillStyle='#020604';cc.fillRect(0,0,w,h);cc.save();cc.scale(w/WORLD_W,w/WORLD_W);drawComposedWorld(cc);cc.restore();return c}
function orderText(ext='png'){let s=`Redacted BannerLab v${APP_VERSION}
${state.name}
${tr('orderRowsLine',{rows:state.rows,missions:state.rows*6})}

${tr('orderTitle')}
`;for(let n=1;n<=state.rows*6;n++){const {row,col}=rowColForMission(n);const o=overrideFor(row,col,false),file=`${String(n).padStart(3,'0')}.${ext}`,adjusted=o&&!isIdentityOverride(o)?tr('orderAdjusted'):'';s+=tr('orderItem',{file,row:row+1,col:col+1,adjusted})+'\n'}return s}
function safeName(s){return (s||'fresque').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9-_]+/g,'_').replace(/^_+|_+$/g,'').slice(0,50)||'fresque'}
function canvasBlob(c,type='image/png',quality){return new Promise((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error(tr('canvasExportFailed'))),type,quality))}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function tick(){return new Promise(r=>setTimeout(r,0))}


const MIN_PORTALS_PER_MISSION=6;

const OBJECTIVE_LABELS={
  HACK_PORTAL:'hack',
  INSTALL_MOD:'mod',
  CAPTURE_PORTAL:'capture',
  CREATE_LINK:'link',
  CREATE_FIELD:'field',
  PASSPHRASE:'passphrase'
};
function objectiveLabel(type){return tr(OBJECTIVE_LABELS[type]||'hack')}
function missionSequential(m){return typeof m?.sequential==='boolean'?m.sequential:state.planner.sequential!==false}
function missionHidden(m){return missionSequential(m)&&(typeof m?.hiddenLocation==='boolean'?m.hiddenLocation:!!state.planner.hiddenLocation)}

function projectLanguage(){return SUPPORTED_LANGS.includes(state.projectLanguage)?state.projectLanguage:APP_LANG}
function trProject(key,vars={}){
  let txt=(I18N[projectLanguage()]&&I18N[projectLanguage()][key])||I18N.en[key]||I18N.fr[key]||key;
  for(const [k,v] of Object.entries(vars))txt=txt.replaceAll('{'+k+'}',String(v));
  return txt;
}
function defaultMissionPassphrase(mi){return {question:trProject('missionNumberQuestion'),answer:String(Math.max(0,Number(mi)||0)+1)}}
function fillPassphraseDefaults(portal,mi){
  if(!portal?.objective||portal.objective.type!=='PASSPHRASE')return portal;
  portal.objective.passphrase_params=portal.objective.passphrase_params||{question:'',_single_passphrase:''};
  const d=defaultMissionPassphrase(mi);
  if(!String(portal.objective.passphrase_params.question||'').trim())portal.objective.passphrase_params.question=d.question;
  if(!String(portal.objective.passphrase_params._single_passphrase||'').trim())portal.objective.passphrase_params._single_passphrase=d.answer;
  return portal;
}


function newIitcSessionId(){
  try{if(globalThis.crypto?.randomUUID)return 'iitc_'+globalThis.crypto.randomUUID()}catch(e){}
  return `iitc_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,10)}`;
}
function normalizePlanner(p={}){
  const planner={
    iitcSessionId: typeof p.iitcSessionId==='string'&&p.iitcSessionId.trim()?p.iitcSessionId.trim():newIitcSessionId(),
    description: typeof p.description==='string'?p.description:'',
    titleFormat: typeof p.titleFormat==='string'&&p.titleFormat.trim()?p.titleFormat:'$T $0N / $M',
    sequential: p.sequential!==false,
    hiddenLocation: !!p.hiddenLocation,
    portalsPerMission: clamp(parseInt(p.portalsPerMission)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24),
    autoAdvance: p.autoAdvance!==false,
    reuseLastPortal: p.reuseLastPortal!==false,
    iitcTutorialSeen: !!p.iitcTutorialSeen,
    currentMission: Math.max(0,parseInt(p.currentMission)||0),
    missions: Array.isArray(p.missions)?p.missions.map((m,i)=>normalizeMissionPlan(m,i)):[]
  };
  return planner;
}
function normalizeMissionPlan(m={},i=0){
  return {
    title: typeof m.title==='string'?m.title:'',
    description: typeof m.description==='string'?m.description:'',
    titleCustom: !!m.titleCustom,
    descriptionCustom: !!m.descriptionCustom,
    sequential: typeof m.sequential==='boolean'?m.sequential:null,
    hiddenLocation: typeof m.hiddenLocation==='boolean'?m.hiddenLocation:null,
    portals: Array.isArray(m.portals)?m.portals.map(normalizePortal).filter(Boolean):[]
  };
}
function normalizePortal(p){
  if(!p||typeof p!=='object')return null;
  const lat=Number(p.location?.latitude??p.lat??p.latitude),lng=Number(p.location?.longitude??p.lng??p.longitude);
  const objective=String(p.objective?.type||'HACK_PORTAL');
  return {
    guid:String(p.guid||''),
    title:String(p.title||tr('portalDefault')),
    imageUrl:String(p.imageUrl||p.image||''),
    description:String(p.description||''),
    location:{latitude:Number.isFinite(lat)?lat:0,longitude:Number.isFinite(lng)?lng:0},
    isOrnamented:false,
    isStartPoint:false,
    type:'PORTAL',
    objective:{
      type:OBJECTIVE_LABELS[objective]?objective:'HACK_PORTAL',
      passphrase_params:{
        question:String(p.objective?.passphrase_params?.question||''),
        _single_passphrase:String(p.objective?.passphrase_params?._single_passphrase||'')
      }
    }
  };
}
function ensurePlannerMissions(){
  state.planner=normalizePlanner(state.planner||{});
  const count=state.rows*COLS;
  while(state.planner.missions.length<count)state.planner.missions.push(normalizeMissionPlan({},state.planner.missions.length));
  if(state.planner.missions.length>count)state.planner.missions.length=count;
  state.planner.currentMission=clamp(state.planner.currentMission,0,Math.max(0,count-1));
  refreshGeneratedMissionTitles();
  for(const m of state.planner.missions)if(!m.descriptionCustom&&!m.description)m.description=state.planner.description||'';
}
function generatedMissionTitle(index){
  const format=state.planner.titleFormat||'$T $0N / $M',total=state.rows*COLS,title=state.name||tr('bannerDefault');
  return format.replace(/\$(\d*)?(\w)/g,(_,flags='',token)=>{
    let value=token;
    switch(token.toLowerCase()){
      case't':value=title;break;
      case'm':value=String(total);break;
      case'n':value=String(index+1);break;
    }
    let zero=flags.startsWith('0');if(zero)flags=flags.slice(1);
    let len=parseInt(flags);if(Number.isNaN(len))len=zero?String(total).length:1;
    return String(value).padStart(len,zero?'0':' ');
  });
}
function refreshGeneratedMissionTitles(){
  const missions=state.planner?.missions;if(!Array.isArray(missions))return;
  missions.forEach((m,i)=>{if(!m.titleCustom||!m.title)m.title=generatedMissionTitle(i)});
}
function plannerMission(index=state.planner.currentMission){ensurePlannerMissions();return state.planner.missions[clamp(index,0,state.planner.missions.length-1)]}
function setPlannerMission(index,reopen='route'){
  ensurePlannerMissions();state.planner.currentMission=clamp(index,0,state.planner.missions.length-1);scheduleSave();
  if(reopen==='route')openRoutePlanner();else if(reopen==='missions')openMissionSettings();
}
function haversine(a,b){
  if(!a||!b)return 0;const R=6371000,toRad=x=>x*Math.PI/180;
  const p1=toRad(a.latitude),p2=toRad(b.latitude),dp=toRad(b.latitude-a.latitude),dl=toRad(b.longitude-a.longitude);
  const s=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function missionDistance(m){return (m?.portals||[]).reduce((sum,p,i,a)=>i?sum+haversine(a[i-1].location,p.location):sum,0)}
function totalRouteDistance(){
  ensurePlannerMissions();const all=state.planner.missions.flatMap(m=>m.portals||[]);
  return all.reduce((sum,p,i)=>i?sum+haversine(all[i-1].location,p.location):sum,0);
}
function formatDistance(m){if(!Number.isFinite(m)||m<=0)return '0 m';return m<1000?`${Math.round(m)} m`:`${(m/1000).toFixed(m<10000?2:1)} km`}
function guidOccurrences(guid){
  const out=[];
  state.planner.missions.forEach((m,mi)=>(m.portals||[]).forEach((p,pi)=>{if(guid&&p.guid===guid)out.push({mi,pi})}));
  return out;
}
function isAllowedHandoverOccurrences(occ){
  if(occ.length!==2)return false;
  const [a,b]=occ;
  if(b.mi!==a.mi+1||b.pi!==0)return false;
  const prev=state.planner.missions[a.mi]?.portals||[];
  return a.pi===prev.length-1;
}
function duplicateGuidCount(){
  let bad=0;
  for(const m of state.planner.missions){
    const seen=new Set(),dupes=new Set();
    for(const p of (m.portals||[]))if(p.guid){if(seen.has(p.guid))dupes.add(p.guid);else seen.add(p.guid)}
    bad+=dupes.size;
  }
  return bad;
}
function canReuseAsHandover(portal,mi){
  if(!portal?.guid||mi<=0)return false;
  const cur=plannerMission(mi),prev=plannerMission(mi-1);
  return cur.portals.length===0&&prev?.portals?.at(-1)?.guid===portal.guid;
}
function portalHtml(p,i,mission){
  const prev=i>0?mission.portals[i-1]:null,dist=prev?formatDistance(haversine(prev.location,p.location)):tr('route');
  const badGuid=!p.guid,pass=p.objective?.type==='PASSPHRASE';
  const extra=pass&&p.objective?.passphrase_params?.question?` · ${escapeHtml(p.objective.passphrase_params.question)}`:'';
  return `<div class="portalrow portalrow-v2" data-portal-index="${i}">
    <div class="portalnum">${i+1}</div>
    <div class="portalmain"><strong>${escapeHtml(p.title||tr('portalDefault'))}</strong><span>${dist}${badGuid?' · GUID ?':''}</span>
      <button class="portalactionbtn">${escapeHtml(objectiveLabel(p.objective?.type))}${extra}</button>
    </div>
    <div class="portalactions"><button class="mini up" ${i===0?'disabled':''} aria-label="↑">${icon('chevronUp')}</button><button class="mini down" ${i===mission.portals.length-1?'disabled':''} aria-label="↓">${icon('chevronDown')}</button><button class="mini remove danger" aria-label="×">${icon('trash')}</button></div>
  </div>`;
}
function openRoutePlanner(){
  ensurePlannerMissions();
  const idx=state.planner.currentMission,m=plannerMission(idx),need=state.planner.portalsPerMission,count=m.portals.length;
  const dup=duplicateGuidCount(),distance=formatDistance(missionDistance(m));
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('route')} · ${tr('missions')} ${idx+1}/${state.planner.missions.length}</h2><p>${count}/${need} ${tr('portalsPerMission').split(' / ')[0].toLowerCase()} · ${distance}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionnav planner-nav"><button class="secondary prevmission" ${idx===0?'disabled':''}>‹ ${tr('prev')}</button><button class="secondary nextmission" ${idx===state.planner.missions.length-1?'disabled':''}>${tr('next')} ›</button></div>
    <div class="routehero">
      <div><b>${escapeHtml(m.title||generatedMissionTitle(idx))}</b><span>${count>=need?tr('complete'):tr('remaining',{n:Math.max(0,need-count)})}</span></div>
      <span class="routebadge ${count>=need?'ok':''}">${count}/${need}</span>
    </div>
    <div class="iitccompanion igorLaunchCompact">
      <div class="iitccompanion-head"><img src="/igor.webp" alt="IGOR"><div><b>${escapeHtml(op('routeIitcTitle'))}</b><span>${escapeHtml(op('routeIitcText'))}</span></div><button class="iconbtn igorRouteSettings" title="${escapeHtml(op('igorSettings'))}">⚙</button></div>
      ${Capacitor.isNativePlatform()?`<div class="rule iitc-install-summary"><span class="dot"></span><span>${escapeHtml(op('checkingIgor'))}</span></div>`:''}
      <button class="primary launchIgorMission">${icon('globe')} ${escapeHtml(op('launchIgor'))}</button>
    </div>
    ${dup?`<div class="rule warning"><span class="dot"></span><span>${tr('duplicateBad',{n:dup})}</span></div>`:''}
    <div class="portallist">${m.portals.length?m.portals.map((p,i)=>portalHtml(p,i,m)).join(''):`<div class="emptyroute">${tr('noPortal')}</div>`}</div>`);
  $('.close',sh).onclick=closeSheet;
  $('.prevmission',sh).onclick=()=>setPlannerMission(idx-1,'route');$('.nextmission',sh).onclick=()=>setPlannerMission(idx+1,'route');
  $('.launchIgorMission',sh).onclick=()=>launchIgor('mission');
  $('.igorRouteSettings',sh).onclick=()=>openIgorSettings({launchView:'mission'});
  refreshIitcCompanionStatus(sh);
  $$('.portalrow',sh).forEach(row=>{
    const pi=+row.dataset.portalIndex;
    $('.up',row).onclick=()=>movePortal(idx,pi,-1);$('.down',row).onclick=()=>movePortal(idx,pi,1);$('.remove',row).onclick=()=>removePortal(idx,pi);
    $('.portalactionbtn',row).onclick=()=>openPortalObjectiveSheet(idx,pi);
  });
}
function currentPlannerScrollTop(){
  const el=currentSheet?.querySelector?.('.sheet');
  return el?el.scrollTop:0;
}
function reopenRoutePlannerKeepingScroll(scrollTop=0){
  openRoutePlanner();
  requestAnimationFrame(()=>{
    const el=currentSheet?.querySelector?.('.sheet');
    if(el)el.scrollTop=Math.max(0,Number(scrollTop)||0);
  });
}
function movePortal(mi,pi,delta){
  const m=plannerMission(mi),to=pi+delta;if(!m||to<0||to>=m.portals.length)return;
  const scrollTop=currentPlannerScrollTop();
  [m.portals[pi],m.portals[to]]=[m.portals[to],m.portals[pi]];scheduleSave();reopenRoutePlannerKeepingScroll(scrollTop);
}
function removePortal(mi,pi){
  const m=plannerMission(mi);if(!m)return;
  const scrollTop=currentPlannerScrollTop();
  m.portals.splice(pi,1);scheduleSave();reopenRoutePlannerKeepingScroll(scrollTop);
}

function openPortalObjectiveSheet(mi,pi){
  const m=plannerMission(mi),p=m?.portals?.[pi];if(!p)return;
  const options=Object.keys(OBJECTIVE_LABELS).map(v=>`<option value="${v}" ${p.objective?.type===v?'selected':''}>${escapeHtml(objectiveLabel(v))}</option>`).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('action')}</h2><p>${escapeHtml(p.title)}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="field"><label>${tr('action')}</label><select id="objectiveType">${options}</select></div>
    <div class="passphraseFields" ${p.objective?.type==='PASSPHRASE'?'':'hidden'}>
      <div class="field"><label>${tr('question')}</label><input id="passQuestion" value="${escapeAttr(p.objective?.passphrase_params?.question||'')}"></div>
      <div class="field"><label>${tr('answer')}</label><input id="passAnswer" value="${escapeAttr(p.objective?.passphrase_params?._single_passphrase||'')}"></div>
    </div>
    <div class="actions"><button class="secondary close2">${tr('cancel')}</button><button class="primary saveobj">${tr('save')}</button></div>`);
  const update=()=>{
    const isPass=$('#objectiveType',sh).value==='PASSPHRASE';
    $('.passphraseFields',sh).hidden=!isPass;
    if(isPass){const d=defaultMissionPassphrase(mi);const q=$('#passQuestion',sh),a=$('#passAnswer',sh);if(q&&!q.value.trim())q.value=d.question;if(a&&!a.value.trim())a.value=d.answer}
  };
  $('#objectiveType',sh).onchange=update;update();
  $('.close',sh).onclick=closeSheet;$('.close2',sh).onclick=closeSheet;
  $('.saveobj',sh).onclick=()=>{
    p.objective.type=$('#objectiveType',sh).value;
    p.objective.passphrase_params.question=$('#passQuestion',sh)?.value?.trim()||'';
    p.objective.passphrase_params._single_passphrase=$('#passAnswer',sh)?.value?.trim()||'';
    fillPassphraseDefaults(p,mi);
    scheduleSave();openRoutePlanner();
  };
}

function addPortalToMission(portal,mi=state.planner.currentMission,opts={}){
  ensurePlannerMissions();const m=plannerMission(mi);if(!m||!portal)return;
  const p=normalizePortal(portal);fillPassphraseDefaults(p,mi);
  if(p.guid&&(m.portals||[]).some(x=>x.guid===p.guid)){toast(tr('duplicateElsewhere'));return false}
  m.portals.push(p);scheduleSave();
  const need=state.planner.portalsPerMission;
  if(state.planner.autoAdvance&&m.portals.length>=need&&mi<state.planner.missions.length-1){
    const last=m.portals.at(-1);
    state.planner.currentMission=mi+1;
    const next=plannerMission(mi+1);
    if(state.planner.reuseLastPortal&&next.portals.length===0&&last)next.portals.push(structuredClone(last));
    scheduleSave();
    toast(tr('missionCompleteAdded',{n:mi+1,next:mi+2}));
  }else toast(tr('portalAdded',{n:mi+1}));
  return true;
}
function bridgeEncode(obj){
  const bytes=new TextEncoder().encode(JSON.stringify(obj));let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bridgeDecode(raw){
  let b64=String(raw||'').replace(/-/g,'+').replace(/_/g,'/');while(b64.length%4)b64+='=';
  const bin=atob(b64),bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));
}
function bridgePortalCompact(p){return [p.guid||'',p.title||tr('portalDefault'),Number(p.location?.latitude)||0,Number(p.location?.longitude)||0,p.imageUrl||'',p.objective?.type||'HACK_PORTAL',p.objective?.passphrase_params?.question||'',p.objective?.passphrase_params?._single_passphrase||'']}
function bridgePortalExpand(a){return normalizePortal({guid:a?.[0]||'',title:a?.[1]||tr('portalDefault'),location:{latitude:Number(a?.[2])||0,longitude:Number(a?.[3])||0},imageUrl:a?.[4]||'',objective:{type:a?.[5]||'HACK_PORTAL',passphrase_params:{question:a?.[6]||'',_single_passphrase:a?.[7]||''}}})}
function bridgePlannerPayload(mode='resume',view='mission'){
  // tx rend chaque ouverture unique. C'est surtout important pour « Charger depuis RBL » :
  // IITC Mobile peut réutiliser sa WebView existante, donc IGOR doit pouvoir distinguer
  // un nouveau payload du fragment déjà présent.
  ensurePlannerMissions();
  const normalizedView=['mission','keys','uniques','inventory-sync','keys-sync'].includes(String(view||'mission'))?String(view):'mission';
  // Key Sync transporte aussi les clés ajoutées manuellement dans RBL. IGOR peut alors
  // résoudre le lien/les coordonnées dans Intel et renvoyer nom, image, adresse et GUID réel.
  const manualKeys=normalizedView==='keys-sync'
    ? Object.values(rblKeys()).filter(k=>k?.manual).slice(0,120).map(k=>[
        String(k.guid||''),Number(k.lat),Number(k.lng),Math.max(0,Number(k.total)||0),
        String(k.title||''),String(k.address||''),String(k.imageUrl||'')
      ])
    : [];
  return {v:7,bv:2,bt:bridgeAuthToken(),cb:TEST_BUILD?'redactedbannerlabtest':'redactedbannerlab',mode:String(mode||'resume'),view:normalizedView,tx:Date.now(),sid:state.planner.iitcSessionId||'',pid:state.projectId||'',name:state.name||'',c:state.planner.currentMission,n:state.planner.missions.length,ppm:state.planner.portalsPerMission,auto:state.planner.autoAdvance!==false,carry:state.planner.reuseLastPortal!==false,lang:projectLanguage(),m:state.planner.missions.map(m=>(m.portals||[]).map(bridgePortalCompact)),rk:manualKeys};
}
function mergeIitcSyncIntoPlanner(planner,data,missionCount){
  planner=normalizePlanner(planner||{});
  const count=Math.max(1,parseInt(missionCount)||0,parseInt(data?.n)||0,planner.missions.length||0);
  while(planner.missions.length<count)planner.missions.push(normalizeMissionPlan({},planner.missions.length));
  if(planner.missions.length>count)planner.missions=planner.missions.slice(0,count);
  planner.portalsPerMission=clamp(parseInt(data?.ppm)||planner.portalsPerMission,MIN_PORTALS_PER_MISSION,24);
  if(String(data?.sid||'').trim())planner.iitcSessionId=String(data.sid).trim();
  if(typeof data?.auto==='boolean')planner.autoAdvance=data.auto!==false;
  if(typeof data?.carry==='boolean')planner.reuseLastPortal=data.carry!==false;
  if(Array.isArray(data?.m)){
    data.m.slice(0,count).forEach((portals,i)=>{
      if(Array.isArray(portals))planner.missions[i].portals=portals.map(bridgePortalExpand).filter(Boolean);
    });
  }else if(Number.isFinite(Number(data?.mi))&&Array.isArray(data?.mission)){
    const mi=clamp(parseInt(data.mi)||0,0,count-1);
    planner.missions[mi].portals=data.mission.map(bridgePortalExpand).filter(Boolean);
  }
  planner.currentMission=clamp(parseInt(data?.c)||0,0,count-1);
  return planner;
}
async function applyIitcSyncData(data,{openPlanner=false,notify=false}={}){
  if(!data||!Number.isFinite(Number(data.v))||Number(data.v)<2||(!Array.isArray(data.m)&&!(Number.isFinite(Number(data.mi))&&Array.isArray(data.mission))))return false;

  const requestedPid=String(data.pid||'').trim();
  const requestedSid=String(data.sid||'').trim();
  const currentId=String(state.projectId||'current');
  let targetId=await resolveIitcProjectForPull(requestedPid,requestedSid);

  // Une synchro MANUELLE doit etre visible : si IITC envoie un autre projet que celui
  // actuellement affiche, on ouvre ce projet avant d'appliquer son etat complet.
  // L'ancienne logique d'autosynchro mettait seulement IndexedDB a jour en arriere-plan,
  // ce qui donnait exactement l'impression que "rien ne s'est synchronise".
  if(openPlanner&&targetId&&targetId!==currentId){
    try{
      await loadProject(targetId);
    }catch(e){
      console.warn('[IITC manual sync open project]',e);
      return false;
    }
  }

  // Si aucun projet n'a pu etre retrouve par pid/sid, on n'ecrase jamais arbitrairement
  // le projet actuellement ouvert. Une synchro manuelle doit echouer clairement plutot
  // que de verser les portails dans la mauvaise fresque.
  if((requestedPid||requestedSid)&&!targetId){
    // Manual IITC -> RBL sync is an explicit user action. If the historical pid/sid
    // cannot be resolved (old Companion state, project id migration, etc.), RBL is
    // normally still open on the intended project. Do not silently discard the sync:
    // use the currently open project as a last-resort target.
    if(openPlanner){
      console.warn('[IITC sync project id unresolved: fallback to current project]',{requestedPid,requestedSid,currentId});
      targetId=currentId;
    }else{
      console.warn('[IITC sync project not found]',{requestedPid,requestedSid,currentId});
      return false;
    }
  }

  // Branche reservee aux anciennes mises a jour de fond, sans navigation UI.
  if(!openPlanner&&targetId&&targetId!=='current'&&targetId!==currentId){
    try{
      const db=await openDB();
      let tx=db.transaction('project','readonly');
      const rec=await request(tx.objectStore('project').get(targetId));
      if(!rec)return false;
      const count=Math.max(1,(parseInt(rec.data?.rows)||3)*COLS,parseInt(data.n)||0);
      rec.data=rec.data||{};
      rec.data.planner=mergeIitcSyncIntoPlanner(rec.data.planner||{},data,count);
      rec.data.updatedAt=new Date().toISOString();
      tx=db.transaction('project','readwrite');
      tx.objectStore('project').put(rec);
      await txDone(tx);
      markBackupChanged();
      return true;
    }catch(e){console.warn('[IITC background sync project]',e);return false}
  }

  ensurePlannerMissions();
  state.planner=mergeIitcSyncIntoPlanner(state.planner,data,state.rows*COLS);
  await saveProject();
  if(notify){
    if(!data.pv)toast(tr('syncOld'));
    else toast(tr('syncOk',{v:data.pv}));
  }
  if(openPlanner){closeSheet();setFlowStep('missions');}
  return true;
}
async function openIntel({mode='resume',view='mission'}={}){
  await saveProject();
  const last=plannerMission()?.portals?.at(-1),center=last?.location;
  const u=new URL('https://intel.ingress.com/intel');
  if(center){u.searchParams.set('ll',`${center.latitude},${center.longitude}`);u.searchParams.set('z','17')}
  // Chaque ouverture reçoit un nonce réseau, même en reprise normale. C'est indispensable
  // quand la mission active est vide : sans ll/z, IITC Mobile peut considérer l'URL Intel comme
  // identique à la précédente et ne jamais livrer le nouveau #rbl au Companion. Le payload reste
  // dans le fragment local ; ce petit paramètre sert uniquement à rendre l'Intent unique.
  u.searchParams.set('rblopen',Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7));
  const bridgeSyncView=['inventory-sync','keys-sync'].includes(String(view||'').toLowerCase());
  // TEST-27 : deux commandes volontairement séparées.
  // - inventory-sync -> IGOR appelle getInventory
  // - keys-sync      -> IGOR lit le module Keys IITC, sans appeler getInventory
  if(bridgeSyncView){
    const syncKind=String(view).toLowerCase();
    const returnView=syncKind==='keys-sync'?'keys':'inventory';
    const existing=rblPendingSync(syncKind);
    const requestId=existing?.requestId||markRblSyncStarting(syncKind,returnView);
    u.searchParams.set('rblcmd',syncKind);u.searchParams.set('rblcmdv','3');u.searchParams.set('rblreturn',returnView);u.searchParams.set('rblreq',requestId);u.searchParams.set('rblcb',TEST_BUILD?'redactedbannerlabtest':'redactedbannerlab');
  }
  if(String(mode||'resume').toLowerCase()==='replace')u.searchParams.set('rblrefresh','1');
  // Transport historique fiable : le payload reste dans le fragment local.
  // Il n'est jamais envoyé au serveur Intel et IGOR le lit au chargement.
  u.hash='rbl='+encodeURIComponent(bridgeEncode(bridgePlannerPayload(mode,view)));

  if(!Capacitor.isNativePlatform()){
    window.open(u.toString(),'_blank','noopener');
    return;
  }

  // Android : TEST-31 passe d'abord par un lanceur natif qui réutilise la tâche IITC
  // sans CLEAR_TASK. Cela livre le nouvel rblcmd/rblreq à l'activité IITC existante au lieu
  // de multiplier les écrans splash et les tentatives manuelles.
  try{
    const opened=await IitcBridgeLauncher.open({url:u.toString()});
    if(opened?.opened){toast(String(opened.packageName||'').includes('iitcprime')?tr('intelPrimeOpened'):tr('intelOpened'));return}
  }catch(e){console.warn('[IITC native bridge launcher]',e)}

  // Secours compatible avec les anciens builds Android du Lab.
  const candidates=[
    'org.exarhteam.iitc_mobile',
    'org.exarhteam.iitcprime'
  ];

  for(const packageName of candidates){
    try{
      const intentOptions={
        action: ActivityAction.VIEW,
        data: u.toString(),
        packageName
      };
      // TEST-27 : ne jamais CLEAR_TASK IITC pour une synchro C.O.R.E.
      // L'URL contient déjà un nonce unique et IGOR surveille les nouveaux intents à chaud.
      // Forcer NEW_TASK+CLEAR_TASK provoquait des redémarrages visibles d'IITC et des
      // allers-retours RBL/IITC en boucle sur certains Android.
      await IntentLauncher.startActivityAsync(intentOptions);
      toast(packageName.includes('iitcprime')
        ? tr('intelPrimeOpened')
        : tr('intelOpened'));
      return;
    }catch(e){
      console.warn(`IITC non ouvert via ${packageName}`,e);
    }
  }

  // Ultime secours : on ouvre IITC Mobile sans payload si Android refuse
  // l'intent ciblé, puis seulement le navigateur si IITC n'est pas installé.
  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitc_mobile'});
    toast(tr('intelFallback'));
    return;
  }catch(e){
    console.warn('IITC Mobile absent',e);
  }

  try{
    await IntentLauncher.openApplication({packageName:'org.exarhteam.iitcprime'});
    toast(tr('intelPrimeFallback'));
    return;
  }catch(e){
    console.warn('IITC Prime absent',e);
  }

  // Si IITC n'est pas installé, ne livre jamais la clé d'appairage IGOR au navigateur
  // de secours. Le fragment RBL n'a de toute façon aucune utilité sans le Companion IITC.
  await AppLauncher.openUrl({url:'https://intel.ingress.com/intel'});
  toast(tr('intelBrowser'));
}
async function bridgeUserscriptText(){
  const r=await fetch('/igor.user.js',{cache:'no-store'});
  if(!r.ok)throw new Error(op('pluginMissing'));
  const text=await r.text();
  if(!text||text.length<1024)throw new Error(op('pluginInvalid',{n:text?.length||0}));
  return text;
}
async function bundledIitcInfo(){
  if(!Capacitor.isNativePlatform())return null;
  const info=await BackupFolder.getBundledIitcInfo();
  if(!info?.available||Number(info?.bytes||0)<1024)throw new Error(op('bundledPluginInvalid',{n:Number(info?.bytes||0)}));
  return info;
}
async function saveIitcBridgeFile(name='igor.user.js'){
  const info=await bundledIitcInfo();
  const result=await BackupFolder.saveBundledIitcAs({fileName:name});
  if(result?.cancelled)return false;
  if(!result?.saved||Number(result?.bytes||0)!==Number(info?.bytes||0))throw new Error(`IITC plugin save failed (${Number(result?.bytes||0)}/${Number(info?.bytes||0)} bytes)`);
  toast(tr('pluginSaved'));
  return true;
}
async function openIitcBridgeDirect(name='igor.user.js'){
  try{
    const info=await bundledIitcInfo();
    const result=await BackupFolder.openBundledIitcWithIitc({
      fileName:name,
      packageName:'org.exarhteam.iitc_mobile'
    });
    if(!result?.opened||Number(result?.bytes||0)!==Number(info?.bytes||0))throw new Error(`IITC direct open failed (${Number(result?.bytes||0)}/${Number(info?.bytes||0)} bytes)`);
    toast(tr('pluginOpenedIitc'));
    return true;
  }catch(e){
    console.warn('[IITC direct plugin open]',e);
    toast(`${tr('pluginOpenFailed')} · ${e?.message||e}`);
    return false;
  }
}
async function getIitcCompanionStatus(){
  if(!Capacitor.isNativePlatform())return null;
  return await BackupFolder.getIitcCompanionStatus();
}
function iitcCompanionReady(status){
  if(!status?.configured||!status?.installed||status?.legacy)return false;
  if(status?.upToDate||status?.sameVersion)return true;
  const sameVersion=!!status?.installedVersion&&status.installedVersion===status.availableVersion;
  const sameId=!status?.installedId||!status?.availableId||status.installedId===status.availableId;
  return sameVersion&&sameId;
}
function iitcInstalledLabel(status){
  if(!status?.configured)return tr('iitcAccessMissing');
  if(!status?.installed)return tr('iitcNotInstalled');
  const version=status.installedVersion?`v${status.installedVersion}`:'?';
  if(iitcCompanionReady(status))return `${version} · ${tr('iitcUpToDate')}`;
  if(status.installedVersion&&status.installedVersion===status.availableVersion)return `${version} · ${tr('iitcUpToDate')}`;
  return version;
}
async function refreshIitcCompanionStatus(root=document){
  const el=$('.iitc-install-summary',root);
  if(!el||!Capacitor.isNativePlatform())return;
  try{
    const st=await getIitcCompanionStatus();
    const available=st?.availableVersion||'0.6.32';
    el.classList.toggle('ok',iitcCompanionReady(st));
    el.innerHTML=st?.installed
      ? `<span class="dot"></span><span><b>${escapeHtml(tr('igorConnected'))}</b><br><small>${escapeHtml(tr('iitcInstalled'))} : ${escapeHtml(iitcInstalledLabel(st))} · ${escapeHtml(tr('iitcAvailable'))} : v${escapeHtml(available)}</small></span>`
      : `<span class="dot"></span><span>${escapeHtml(tr('iitcInstalled'))} : ${escapeHtml(iitcInstalledLabel(st))}<br><small>${escapeHtml(tr('iitcAvailable'))} : v${escapeHtml(available)}</small></span>`;
  }catch(e){
    console.warn('[IITC status]',e);
    el.innerHTML=`<span class="dot"></span><span>${escapeHtml(tr('iitcAccessMissing'))}</span>`;
  }
}
async function chooseIitcFolder(){
  try{
    const st=await BackupFolder.chooseIitcFolder();
    return st?.configured?st:null;
  }catch(e){
    console.warn('[IITC folder]',e);
    toast(`${tr('iitcFolderError')} · ${e?.message||e}`);
    return null;
  }
}
async function installOrUpdateIitcCompanion(status=null){
  let st=status;
  if(!st)st=await getIitcCompanionStatus();
  if(!st?.configured){
    st=await chooseIitcFolder();
    if(!st)return null;
  }
  const result=await BackupFolder.installOrUpdateBundledIitc();
  if(!result?.written||!iitcCompanionReady(result))throw new Error(op('installedMismatch'));
  toast(result.updated?tr('iitcDirectUpdated'):tr('iitcDirectDone'));
  if(result.migratedLegacy)setTimeout(()=>toast(tr('iitcLegacyMigrated')),400);
  return result;
}
async function installIitcAndOpenPlugins(status=null){
  try{
    let st=status;
    if(!st){
      try{st=await getIitcCompanionStatus()}catch(e){console.warn('[IITC prompt status]',e)}
    }

    // Si IGOR existe déjà, on le met à jour EN PLACE via le dossier IITC autorisé.
    // Ne jamais repasser par l'importeur externe d'IITC : supprimer/recréer igor.user.js
    // fait perdre l'état de la case à cocher du plugin sur certains builds IITC Mobile.
    if(st?.configured&&st?.installed){
      if(!iitcCompanionReady(st))st=await installOrUpdateIitcCompanion(st);
      try{
        const opened=await BackupFolder.openIitcPluginSettings({packageName:'org.exarhteam.iitc_mobile'});
        return !!opened?.opened;
      }catch(e){
        console.warn('[IITC normal reopen after in-place update]',e);
        await openIntel({view:'mission'});return true;
      }
    }

    // Première installation seulement : IITC reçoit le .user.js et affiche sa confirmation.
    const ok=await openIitcBridgeDirect();
    return !!ok;
  }catch(e){
    console.error('[IITC install + open]',e);
    toast(`${tr('pluginSaveFailed')} · ${e?.message||e}`);
    return false;
  }
}

async function openIgorSettings({launchView=null}={}){
  const t=elevatorCopy();
  const sh=openLabFloorPage('igor-settings',`<header class="floorTopbar"><div><small>2 // IGOR · SETTINGS</small><h1>${escapeHtml(t.igorSettingsTitle)}</h1><p>${escapeHtml(t.igorSettingsTitleSub)}</p></div><div class="floorTopActions"><button class="floorIgorTopBack" type="button">‹ ${escapeHtml(t.igorRoomBack)}</button>${elevatorButtonHtml('floorLiftBtn')}</div></header>
    <div class="igorSettingsHero"><img src="/igor.webp" alt="IGOR"><div><b>🧪 IGOR 0.6.39</b><span class="igorSettingsState">${escapeHtml(op('checking'))}</span><small class="igorSettingsDetail">${escapeHtml(op('iitcAssistant'))}</small></div></div>
    <div class="igorSettingsActions"></div>
    <details class="igorAdvanced"><summary>${escapeHtml(op('advancedInstall'))}</summary><p>${escapeHtml(op('advancedInstallText'))}</p><div class="actions"><button class="secondary igorInstallViaIitc">${escapeHtml(op('installViaIitc'))}</button><button class="secondary igorSaveCopy">${escapeHtml(op('saveUserscript'))}</button></div></details>
    <button class="secondary floorIgorBack">‹ ${escapeHtml(op('igorRoom'))}</button>`);
  $('.floorIgorBack',sh).onclick=openIgorFloor;$('.floorIgorTopBack',sh).onclick=openIgorFloor;$('.floorLiftBtn',sh).onclick=returnToLabElevator;
  const actions=$('.igorSettingsActions',sh),stateEl=$('.igorSettingsState',sh),detail=$('.igorSettingsDetail',sh);
  async function renderStatus(){
    if(!Capacitor.isNativePlatform()){
      stateEl.textContent=op('webVersion');detail.textContent=op('downloadAddIitc');
      actions.innerHTML=`<button class="primary igorDownload">${escapeHtml(op('downloadIgor'))}</button>`;
      $('.igorDownload',sh).onclick=async()=>{const text=await bridgeUserscriptText();downloadBlob(new Blob([text],{type:'text/javascript;charset=utf-8'}),'igor.user.js')};
      return;
    }
    try{
      const st=await getIitcCompanionStatus();
      const ready=iitcCompanionReady(st);
      stateEl.textContent=ready?op('igorReady'):(!st?.configured?op('iitcFolderRequired'):!st?.installed?op('igorNotInstalled'):op('updateAvailable'));
      detail.textContent=op('installedAvailable',{installed:iitcInstalledLabel(st||{}),available:st?.availableVersion||'0.6.32'});
      actions.innerHTML=ready
        ? `${launchView?`<button class="primary igorLaunchReady">${escapeHtml(launchView==='keys-sync'?op('launchKeySync'):launchView==='inventory-sync'?op('launchInventorySync'):launchView==='uniques'?op('launchUniques'):op('launchMission'))}</button>`:''}<button class="secondary igorChangeFolder">${escapeHtml(op('changeIitcFolder'))}</button>`
        : `<button class="primary igorInstallPrimary">${escapeHtml(!st?.configured?op('chooseInstallIgor'):!st?.installed?op('installIgor'):op('updateIgor'))}</button><button class="secondary igorChangeFolder">${escapeHtml(op('changeIitcFolder'))}</button>`;
      $('.igorLaunchReady',sh)?.addEventListener('click',()=>{const v=launchView||'mission';openIntel({mode:v==='mission'?'replace':'resume',view:v})});
      $('.igorInstallPrimary',sh)?.addEventListener('click',async e=>{const b=e.currentTarget;b.disabled=true;try{await installOrUpdateIitcCompanion(st);await renderStatus()}catch(err){console.error('[IGOR install]',err);toast(`${tr('pluginSaveFailed')} · ${err?.message||err}`)}finally{b.disabled=false}});
      $('.igorChangeFolder',sh)?.addEventListener('click',async()=>{const x=await chooseIitcFolder();if(x)await renderStatus()});
    }catch(e){console.warn('[IGOR settings status]',e);stateEl.textContent=op('stateUnavailable');detail.textContent=String(e?.message||e);actions.innerHTML=`<button class="primary igorInstallPrimary">${escapeHtml(op('configureIgor'))}</button>`;$('.igorInstallPrimary',sh).onclick=async()=>{await installOrUpdateIitcCompanion(null);await renderStatus()}}
  }
  $('.igorInstallViaIitc',sh).onclick=async()=>{await installIitcAndOpenPlugins()};
  $('.igorSaveCopy',sh).onclick=async()=>{try{await saveIitcBridgeFile('igor.user.js')}catch(e){toast(`${tr('pluginSaveFailed')} · ${e?.message||e}`)}};
  await renderStatus();
}
async function shareIitcBridge(){return openIgorSettings()}

function openIitcTutorial(){
  const sh=openSheet(`<div class="sheethead"><div><h2>IITC Companion</h2><p>${tr('tutorialIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="tutorialsteps">
      <div class="tutorialstep"><b>1</b><div><strong>${tr('tut1Title')}</strong><span>${tr('tut1Text')}</span></div></div>
      <div class="tutorialstep"><b>2</b><div><strong>${tr('tut2Title')}</strong><span>${tr('tut2Text')}</span></div></div>
      <div class="tutorialstep"><b>3</b><div><strong>${tr('tut3Title')}</strong><span>${tr('tut3Text')}</span></div></div>
      <div class="tutorialstep"><b>4</b><div><strong>${tr('tut4Title')}</strong><span>${tr('tut4Text')}</span></div></div>
    </div>
    <div class="tutorialnote"><img src="/redacted-logo-512.png" alt=""><span>${tr('tutNote')}</span></div>
    <div class="actions"><button class="secondary installplugin">${tr('installUpdate')}</button><button class="primary launchiitc">${tr('openIitc')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.installplugin',sh).onclick=shareIitcBridge;
  $('.launchiitc',sh).onclick=()=>{state.planner.iitcTutorialSeen=true;scheduleSave();openIntel()};
}

async function resolveIitcProjectForPull(pid='',sid=''){
  const wantedPid=String(pid||'').trim(),wantedSid=String(sid||'').trim();
  if(wantedPid&&wantedPid===String(state.projectId||''))return wantedPid;
  try{
    const projects=await getAllProjects();
    if(wantedPid&&projects.some(p=>String(p.id)===wantedPid))return wantedPid;
    if(wantedSid){
      const hit=projects.find(p=>String(p.data?.planner?.iitcSessionId||'').trim()===wantedSid);
      if(hit)return String(hit.id);
    }
  }catch(e){console.warn('[IITC pull resolve]',e)}
  return '';
}
let lastHandledBridgeUrl='';
let lastHandledBridgeUrlAt=0;
async function handleBridgeUrl(raw){
  raw=String(raw||'');
  const nowUrl=Date.now();
  if(raw&&raw===lastHandledBridgeUrl&&nowUrl-lastHandledBridgeUrlAt<5000)return true;
  lastHandledBridgeUrl=raw;lastHandledBridgeUrlAt=nowUrl;
  try{
    const u=new URL(raw);if(!['redactedbannerlab:','redactedbannerlabtest:'].includes(u.protocol))return false;
    if(u.hostname==='play'||u.hostname==='banner'){
      const id=u.searchParams.get('banner')||u.searchParams.get('id')||'';const mission=Math.max(0,parseInt(u.searchParams.get('mission')||'0')||0);
      if(!id)return false;setTimeout(()=>joinSharedBanner(id,mission),120);return true;
    }
    const protectedHosts=new Set(['portal','publisher-chrome-ready','publisher-firefox-ready','publisher-next','publisher-return','pull','sync','autosync','igor-inventory','igor-keys','igor-core']);
    if(protectedHosts.has(u.hostname)&&!(await verifySignedBridgeUrl(u))){
      console.warn('[RBL bridge] rejected unauthenticated deep link',u.hostname);
      toast(tr('bridgeRejected'));
      return false;
    }
    if(u.hostname==='portal'){
      const lat=Number(u.searchParams.get('lat')),lng=Number(u.searchParams.get('lng'));if(!Number.isFinite(lat)||!Number.isFinite(lng))return false;
      const p=normalizePortal({guid:u.searchParams.get('guid')||'',title:u.searchParams.get('title')||tr('portalDefault'),imageUrl:u.searchParams.get('image')||'',location:{latitude:lat,longitude:lng}});
      addPortalToMission(p,state.planner.currentMission);openRoutePlanner();return true;
    }
    if(u.hostname==='publisher-chrome-ready'){
      setPublisherReady('chrome',true);
      setChromeSetupStep(8);
      setPublisherBrowser('chrome');
      toast(tr('setupConfirmed'));
      closeSheet();
      setTimeout(()=>openChromeSetupSheet(8),120);
      return true;
    }
    if(u.hostname==='publisher-firefox-ready'){
      setPublisherReady('firefox',true);
      setPublisherBrowser('firefox');
      toast(tr('setupConfirmed'));
      return true;
    }
    if(u.hostname==='publisher-next'){
      const index=clamp(parseInt(u.searchParams.get('mission'))||0,0,state.planner.missions.length-1);
      state.planner.currentMission=index;
      scheduleSave();saveProject();
      setTimeout(()=>openBrowserPublisher(index),180);
      return true;
    }
    if(u.hostname==='publisher-return'){
      toast(tr('publisherReturn'));
      return true;
    }
    if(u.hostname==='pull'){
      // Action volontaire depuis IITC : charger la version actuellement enregistrée dans RBL.
      // Les anciens projets/anciens Companion peuvent encore porter un pid/sid historique.
      // Comme cette action est explicite et que RBL est normalement encore ouvert sur le bon
      // projet, on utilise le projet courant en dernier recours plutôt que d'abandonner le pull.
      let target=await resolveIitcProjectForPull(u.searchParams.get('pid')||'',u.searchParams.get('sid')||'');
      if(!target)target=String(state.projectId||'current');
      if(target!==String(state.projectId||''))await loadProject(target);
      await saveProject();
      // Android may ignore a task switch requested synchronously while handling the
      // incoming RBL deep-link. Return to IITC on the next activity/frame instead.
      setTimeout(()=>openIntel({mode:'replace',view:'mission'}).catch(e=>console.warn('[IITC pull return]',e)),180);
      return true;
    }
    if(u.hostname==='igor-core'){
      const rawData=String(u.searchParams.get('data')||'');if(!rawData||rawData.length>900000){toast(op('coreUnreadable'));return false}
      const data=bridgeDecode(rawData),returnedReq=String(u.searchParams.get('req')||data?.requestId||''),returnedView=String(u.searchParams.get('view')||data?.returnView||'');
      const pending=safeLocalJson(RBL_IGOR_PENDING_SYNC_KEY,{}),freshPending=Number(pending?.at)>0&&Date.now()-Number(pending.at)<10*60*1000;
      if(freshPending&&pending.requestId&&returnedReq&&String(pending.requestId)!==returnedReq){console.warn('[RBL CORE sync] stale callback ignored',returnedReq);toast(op('oldSyncIgnored'));return true}
      const returnView=(freshPending&&['keys','inventory'].includes(String(pending.returnView)))?String(pending.returnView):(['keys','inventory'].includes(returnedView)?returnedView:'inventory');
      const now=Date.now();
      if(!data?.available||!data.snapshot){
        const msg=String(data?.message||op('coreUnavailable'));
        localStorage.setItem(RBL_IGOR_SYNC_STATUS_KEY,JSON.stringify({ok:false,at:now,message:msg,diagnostic:data?.diagnostic||{}}));
        localStorage.setItem(RBL_IGOR_LAST_CORE_REQUEST_KEY,JSON.stringify({requestId:returnedReq||pending.requestId||'',returnView,at:now}));localStorage.removeItem(RBL_IGOR_PENDING_SYNC_KEY);toast(op('coreSyncIncomplete'));
        setTimeout(returnView==='keys'?openRblKeysFloor:openRblInventoryFloor,120);return true;
      }
      const counts=coreSnapshotToCounts(data.snapshot),n=rblInventoryTotal(counts);saveRblInventoryCounts(counts);
      if(Array.isArray(data.snapshot.containers))saveRblContainers(data.snapshot.containers.map(c=>({id:String(c.id||c.name||''),label:String(c.label||c.name||c.id||'Conteneur'),type:String(c.type||'capsule')})));
      const syncedKeys=applyIgorKeysSnapshot({core:Array.isArray(data.snapshot.keys)?data.snapshot.keys:[],containers:data.snapshot.containers||[],manual:data.manual&&typeof data.manual==='object'?data.manual:{},titles:data.titles&&typeof data.titles==='object'?data.titles:{},source:'C.O.R.E. via IITC'});
      const portalCount=Object.values(syncedKeys||{}).filter(k=>Math.max(0,Number(k?.total)||0)>0).length;
      localStorage.setItem(RBL_IGOR_LAST_SYNC_KEY,String(now));
      localStorage.setItem(RBL_IGOR_SYNC_STATUS_KEY,JSON.stringify({ok:true,at:now,message:op('coreStatus',{objects:n,portals:portalCount})}));
      localStorage.setItem(RBL_IGOR_LAST_CORE_REQUEST_KEY,JSON.stringify({requestId:returnedReq||pending.requestId||'',returnView,at:now}));
      localStorage.removeItem(RBL_IGOR_PENDING_SYNC_KEY);
      toast(op('coreSynced',{objects:n,portals:portalCount}));
      setTimeout(returnView==='keys'?openRblKeysFloor:openRblInventoryFloor,120);return true;
    }
    if(u.hostname==='igor-inventory'||u.hostname==='igor-keys'){
      const expectedKind=u.hostname==='igor-keys'?'keys-sync':'inventory-sync';
      const returnedReq=String(u.searchParams.get('req')||'');
      const pending=safeLocalJson(RBL_IGOR_PENDING_SYNC_KEY,{});
      const fresh=Number(pending?.at)>0&&Date.now()-Number(pending.at)<10*60*1000;
      const last=safeLocalJson(RBL_IGOR_LAST_CORE_REQUEST_KEY,{});
      if(fresh&&pending.kind&&pending.kind!==expectedKind){console.warn('[RBL sync] wrong callback kind ignored',u.hostname,pending.kind);return true}
      if(fresh&&pending.requestId&&returnedReq&&String(pending.requestId)!==returnedReq){console.warn('[RBL sync] stale callback ignored',u.hostname,returnedReq);return true}
      if(!fresh&&returnedReq&&String(last?.requestId||'')===returnedReq){console.warn('[RBL sync] duplicate callback ignored',u.hostname,returnedReq);return true}
      const rawData=String(u.searchParams.get('data')||'');
      if(!rawData||rawData.length>900000){toast(u.hostname==='igor-keys'?op('keySyncUnreadable'):op('inventorySyncUnreadable'));return false}
      const data=bridgeDecode(rawData);
      localStorage.setItem(RBL_IGOR_LAST_CORE_REQUEST_KEY,JSON.stringify({requestId:returnedReq||pending.requestId||'',kind:expectedKind,returnView:expectedKind==='keys-sync'?'keys':'inventory',at:Date.now()}));
      localStorage.removeItem(RBL_IGOR_PENDING_SYNC_KEY);
      if(expectedKind==='inventory-sync'){applyIgorInventorySnapshot(data);return true}
      const synced=applyIgorKeysSnapshot(data),count=Object.values(synced||{}).filter(k=>Math.max(0,Number(k?.total)||0)>0).length;
      toast(op('keysSynced',{n:count}));setTimeout(openRblKeysFloor,120);return true;
    }
    if(u.hostname==='sync'){
      // Bridge v2 : le secret d'appairage ne voyage plus dans l'URI de retour.
      // L'URL entière est authentifiée par HMAC-SHA256 + timestamp + nonce anti-rejeu.
      const rawData=String(u.searchParams.get('data')||'');
      if(!rawData||rawData.length>750000){toast(tr('syncUnreadable'));return false}
      const data=bridgeDecode(rawData);
      return await applyIitcSyncData(data,{openPlanner:true,notify:true});
    }
    if(u.hostname==='autosync'){return false}
    return false;
  }catch(e){console.warn('bridge',e);toast(tr('syncUnreadable'));return false}
}
function openMissionSettings(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(m=>m.portals.length>=need).length;
  const hasDescription=!!state.planner.description.trim();

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')}</h2><p>${complete}/${state.planner.missions.length} ${tr('missionReady').toLowerCase()}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>

    <div class="requiredFieldCard ${hasDescription?'ok':'missing'}">
      <div class="requiredFieldHead">
        <div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div>
        <strong>${hasDescription?'✓':'!'}</strong>
      </div>
      <textarea id="bannerDesc" rows="4" placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
      <small>${tr('bannerDescriptionHint')}</small>
    </div>

    <details class="missiondefaults">
      <summary>${tr('settings')}</summary>
      <div class="missiondefaults-body">
        <div class="field"><label>${tr('titleFormat')}</label><input id="titleFormat" value="${escapeAttr(state.planner.titleFormat)}"><small>${tr('titleTokens')}</small></div>
        <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="sequential"><option value="1" ${state.planner.sequential?'selected':''}>${tr('sequential')}</option><option value="0" ${!state.planner.sequential?'selected':''}>${tr('anyOrder')}</option></select></div>
        <div class="field"><label>${tr('location')}</label><select id="hidden"><option value="0" ${!state.planner.hiddenLocation?'selected':''}>${tr('visible')}</option><option value="1" ${state.planner.hiddenLocation?'selected':''}>${tr('hidden')}</option></select></div></div>
        <div class="field"><label>${tr('portalsPerMission')}</label><input id="ppm" type="number" min="${MIN_PORTALS_PER_MISSION}" max="24" value="${need}"><small>${tr('minimumSix')}</small></div>
      </div>
    </details>

    <div class="missionlist-v2">${state.planner.missions.map((x,i)=>{
      const ok=x.portals.length>=need;
      return `<button class="missioncard-v2 ${ok?'ok':''}" data-mi="${i}">
        <span class="missioncard-num">${String(i+1).padStart(2,'0')}</span>
        <span class="missioncard-copy"><b>${escapeHtml(x.title||generatedMissionTitle(i))}</b><small>${x.portals.length}/${need} · ${formatDistance(missionDistance(x))}</small></span>
        <span class="missioncard-state">${ok?'✓':'!'}</span>
      </button>`;
    }).join('')}</div>`);

  $('.close',sh).onclick=closeSheet;

  $('#bannerDesc',sh).oninput=e=>{
    const value=e.target.value;
    state.planner.description=value;
    state.planner.missions.forEach(x=>{
      if(!x.descriptionCustom)x.description=value;
    });
    scheduleSave();

    const card=$('.requiredFieldCard',sh);
    const valid=!!value.trim();
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  $('#titleFormat',sh).oninput=e=>{state.planner.titleFormat=e.target.value||'$T $0N / $M';refreshGeneratedMissionTitles();scheduleSave()};
  $('#sequential',sh).onchange=e=>{state.planner.sequential=e.target.value==='1';scheduleSave()};
  $('#hidden',sh).onchange=e=>{state.planner.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('#ppm',sh).onchange=e=>{
    state.planner.portalsPerMission=clamp(parseInt(e.target.value)||MIN_PORTALS_PER_MISSION,MIN_PORTALS_PER_MISSION,24);
    scheduleSave();
    openMissionSettings();
  };
  $$('.missioncard-v2',sh).forEach(btn=>btn.onclick=()=>openMissionDetail(+btn.dataset.mi));
}

function openMissionDetail(idx){
  ensurePlannerMissions();state.planner.currentMission=idx;const m=plannerMission(idx);
  const seq=missionSequential(m),hidden=missionHidden(m);
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('missions')} ${idx+1}</h2><p>${m.portals.length}/${state.planner.portalsPerMission} · ${formatDistance(missionDistance(m))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="missionsetcard missiondetail-v2">
      <div class="field"><label>${tr('title')}</label><input id="missionTitle" value="${escapeAttr(m.title)}"></div>
      <div class="field"><label>${tr('description')}</label><textarea id="missionDesc" rows="3">${escapeHtml(m.description||'')}</textarea></div>
      <div class="grid2"><div class="field"><label>${tr('defaultType')}</label><select id="missionSeq"><option value="1" ${seq?'selected':''}>${tr('sequential')}</option><option value="0" ${!seq?'selected':''}>${tr('anyOrder')}</option></select></div>
      <div class="field"><label>${tr('location')}</label><select id="missionHidden" ${!seq?'disabled':''}><option value="0" ${!hidden?'selected':''}>${tr('visible')}</option><option value="1" ${hidden?'selected':''}>${tr('hidden')}</option></select></div></div>
      <div class="missiondetail-actions"><button class="secondary backmissions">‹ ${tr('missions')}</button><button class="primary openRoute">${icon('route')} ${tr('openRoute')}</button></div>
    </div>`);
  $('.close',sh).onclick=closeSheet;
  $('.backmissions',sh).onclick=openMissionSettings;
  $('#missionTitle',sh).oninput=e=>{m.title=e.target.value;m.titleCustom=true;scheduleSave()};
  $('#missionDesc',sh).oninput=e=>{m.description=e.target.value;m.descriptionCustom=true;scheduleSave()};
  $('#missionSeq',sh).onchange=e=>{m.sequential=e.target.value==='1';if(!m.sequential)m.hiddenLocation=false;scheduleSave();openMissionDetail(idx)};
  $('#missionHidden',sh).onchange=e=>{m.hiddenLocation=e.target.value==='1';scheduleSave()};
  $('.openRoute',sh).onclick=openRoutePlanner;
}
function missionPublishIssues(index=state.planner.currentMission){
  ensurePlannerMissions();
  const issues=[];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const m=state.planner.missions[clamp(index,0,state.planner.missions.length-1)];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));
  if(!m)return issues;

  if(!String(m.title||'').trim())issues.push(tr('emptyTitleIssue',{n:index+1}));
  if(!String(m.description||'').trim())issues.push(tr('emptyDescIssue',{n:index+1}));
  if((m.portals||[]).length<need){
    issues.push(tr('missionNeedsPortals',{n:index+1,count:(m.portals||[]).length,need}));
  }

  const missing=(m.portals||[]).filter(p=>!p.guid).length;
  if(missing)issues.push(tr('missingGuidIssue',{n:index+1,count:missing}));

  const badPass=(m.portals||[]).filter(p=>
    p.objective?.type==='PASSPHRASE' &&
    (!p.objective?.passphrase_params?.question?.trim() ||
     !p.objective?.passphrase_params?._single_passphrase?.trim())
  ).length;
  if(badPass)issues.push(tr('passIssue',{n:index+1,count:badPass}));

  return issues;
}

function validatePlanner(){
  ensurePlannerMissions();
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const issues=[];

  if(!state.planner.description.trim())issues.push(tr('bannerDescriptionRequired'));

  state.planner.missions.forEach((m,i)=>{
    const n=i+1;
    if(!m.title.trim())issues.push(tr('emptyTitleIssue',{n}));
    if(!m.description.trim())issues.push(tr('emptyDescIssue',{n}));
    if(m.portals.length<need)issues.push(tr('portalsIssue',{n,count:m.portals.length,need}));

    const missing=m.portals.filter(p=>!p.guid).length;
    if(missing)issues.push(tr('missingGuidIssue',{n,count:missing}));

    const badPass=m.portals.filter(p=>
      p.objective?.type==='PASSPHRASE' &&
      (!p.objective?.passphrase_params?.question?.trim() ||
       !p.objective?.passphrase_params?._single_passphrase?.trim())
    ).length;
    if(badPass)issues.push(tr('passIssue',{n,count:badPass}));
  });
  return issues;
}

function openBannerDescriptionRequired(onSaved){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('describeBeforePublish')}</h2><p>${tr('describeBeforePublishText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="requiredFieldCard missing">
      <div class="requiredFieldHead"><div><b>${tr('bannerDescription')}</b><span>${tr('required')}</span></div><strong>!</strong></div>
      <textarea id="requiredBannerDesc" rows="5" autofocus placeholder="${escapeAttr(tr('bannerDescriptionHint'))}">${escapeHtml(state.planner.description||'')}</textarea>
    </div>
    <div class="actions"><button class="primary saveDesc" disabled>${tr('saveAndContinue')}</button></div>`);

  $('.close',sh).onclick=closeSheet;
  const input=$('#requiredBannerDesc',sh);
  const save=$('.saveDesc',sh);

  const update=()=>{
    const valid=!!input.value.trim();
    save.disabled=!valid;
    const card=$('.requiredFieldCard',sh);
    card?.classList.toggle('ok',valid);
    card?.classList.toggle('missing',!valid);
    const badge=$('.requiredFieldHead strong',sh);
    if(badge)badge.textContent=valid?'✓':'!';
  };

  input.oninput=update;
  update();
  setTimeout(()=>input.focus(),80);

  save.onclick=()=>{
    const value=input.value.trim();
    if(!value)return;
    state.planner.description=value;
    state.planner.missions.forEach(m=>{
      if(!m.descriptionCustom)m.description=value;
    });
    scheduleSave();
    saveProject();
    closeSheet();
    if(typeof onSaved==='function')setTimeout(onSaved,80);
  };
}

function missionPublisherData(m,i,imageDataUrl=''){
  return {
    number:i+1,
    title:m.title||generatedMissionTitle(i),
    description:m.description||'',
    sequential:missionSequential(m),
    hiddenLocation:missionHidden(m),
    imageDataUrl,
    portals:(m.portals||[]).map(p=>({
      guid:p.guid||'',title:p.title||tr('portalDefault'),
      latitude:Number(p.location?.latitude)||0,longitude:Number(p.location?.longitude)||0,
      imageUrl:p.imageUrl||'',description:p.description||'',
      objective:{
        type:p.objective?.type||'HACK_PORTAL',
        question:p.objective?.passphrase_params?.question||'',
        answer:p.objective?.passphrase_params?._single_passphrase||''
      }
    }))
  };
}
async function buildPublisherSession(){
  ensurePlannerMissions();
  if(!state.bg.image)throw new Error(tr('noBackground'));
  const issues=validatePlanner();
  if(issues.length){const e=new Error(issues.join('\n'));e.rblBlockingIssues=issues;throw e}
  const total=state.planner.missions.length;
  const missions=[];
  for(let index=0;index<total;index++){
    toast(tr('publisherSessionCreating',{n:index+1,total}));
    const {row,col}=rowColForMission(index+1),c=document.createElement('canvas');
    c.width=c.height=512;drawTile(c,row,col,512);
    const imageDataUrl=c.toDataURL('image/jpeg',.90);
    missions.push(missionPublisherData(state.planner.missions[index],index,imageDataUrl));
    if(index%2===1)await tick();
  }
  return {
    format:'redacted-bannerlab-milo-session',version:3,appVersion:APP_VERSION,
    sessionId:`${state.projectId||'project'}-${Date.now()}`,
    projectId:state.projectId||'',name:state.name,language:projectLanguage(),
    portalsPerMission:Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission),
    currentIndex:0,missions
  };
}

async function savePublisherSessionFile(){
  const session=await buildPublisherSession();
  const currentName='MILO_CurrentBanner.json';
  const projectName=`MILO_${safeName(state.name)}.json`;
  const text=JSON.stringify(session);

  if(Capacitor.isNativePlatform()){
    const result=await PublisherFiles.saveSession({text,projectName});
    if(!result?.ok)throw new Error('MILO banner native write failed');
  }else{
    downloadBlob(new Blob([text],{type:'application/json'}),projectName);
  }

  toast(tr('publisherSessionReady'));
  return {session,currentName,projectName};
}

const PUBLISH_BROWSER_KEY='rblPublisherBrowser';
const CHROME_READY_KEY='rblPublisherChromeReady';
const FIREFOX_READY_KEY='rblPublisherFirefoxReady';
const CHROME_STEP_KEY='rblPublisherChromeStep';
const CHROME_CODE_KEY='rblPublisherChromeCodeCopied';
const PUBLISHER_SETUP_VERSION='0.11.0';
const CHROME_SETUP_VERSION_KEY='rblPublisherChromeSetupVersion';
const FIREFOX_SETUP_VERSION_KEY='rblPublisherFirefoxSetupVersion';

function publisherBrowser(){
  return localStorage.getItem(PUBLISH_BROWSER_KEY)||'chrome';
}
function setPublisherBrowser(browser){
  browser=browser==='firefox'?'firefox':'chrome';
  localStorage.setItem(PUBLISH_BROWSER_KEY,browser);
  toast(tr('browserSaved',{browser:browser==='firefox'?tr('firefoxMode'):tr('chromeMode')}));
}
function publisherReady(browser){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  return localStorage.getItem(readyKey)==='1'
    && localStorage.getItem(versionKey)===PUBLISHER_SETUP_VERSION;
}
function setPublisherReady(browser,value=true){
  const readyKey=browser==='firefox'?FIREFOX_READY_KEY:CHROME_READY_KEY;
  const versionKey=browser==='firefox'?FIREFOX_SETUP_VERSION_KEY:CHROME_SETUP_VERSION_KEY;
  localStorage.setItem(readyKey,value?'1':'0');
  if(value)localStorage.setItem(versionKey,PUBLISHER_SETUP_VERSION);
  else localStorage.removeItem(versionKey);
  if(browser==='chrome'&&value)localStorage.setItem(CHROME_STEP_KEY,'8');
}
function chromeSetupStep(){
  if(publisherReady('chrome'))return 8;
  if(localStorage.getItem(CHROME_SETUP_VERSION_KEY)!==PUBLISHER_SETUP_VERSION){
    localStorage.setItem(CHROME_STEP_KEY,'1');
    localStorage.removeItem(CHROME_CODE_KEY);
  }
  return clamp(parseInt(localStorage.getItem(CHROME_STEP_KEY))||1,1,7);
}
function setChromeSetupStep(step){
  step=clamp(parseInt(step)||1,1,8);
  localStorage.setItem(CHROME_STEP_KEY,String(step));
}
function resetChromeSetup(){
  setPublisherReady('chrome',false);
  localStorage.setItem(CHROME_STEP_KEY,'1');
  localStorage.removeItem(CHROME_CODE_KEY);
  toast(tr('chromeResetDone'));
}

async function prepareAndOpenPublisher(browser=publisherBrowser()){
  if(!Capacitor.isNativePlatform()){toast(tr('liveNativeOnly'));return}
  try{
    if(!publisherReady(browser)){
      if(browser==='firefox')openFirefoxSetupSheet();else openChromeSetupSheet();
      toast(browser==='firefox'?tr('firefoxNeedsSetup'):tr('chromeNeedsSetup'));
      return;
    }

    await saveProject();

    // Keep the stable JS file current without changing the bookmark.
    if(browser==='chrome'){
      await saveChromePublisherDirect().catch(e=>console.warn('[Publisher JS refresh]',e));
    }

    await savePublisherSessionFile();

    const packageName=browser==='firefox'?'org.mozilla.firefox':'com.android.chrome';
    const url='https://missions.ingress.com/';

    toast(tr('browserResume'));
    toast(browser==='chrome'?tr('chromeResumeHint'):tr('firefoxResumeHint'));

    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:url,
        packageName,
        // Browser.EXTRA_APPLICATION_ID:
        // Android/Chrome will associate this external-app id with a browser
        // tab and attempt to reuse that same tab on later launches.
        extra:{
          'com.android.browser.application_id':'com.bannerforge.mobile'
        },
        // Intent.FLAG_ACTIVITY_NEW_TASK
        flags:268435456
      });
    }catch(e){
      console.warn('[Publisher app-tab launch]',e);
      toast(tr('browserResumeFallback'));
      try{
        await IntentLauncher.openApplication({packageName});
      }catch(e2){
        await AppLauncher.openUrl({url});
      }
    }
  }catch(e){
    console.error('[Publisher session]',e);
    if(e?.rblBlockingIssues){openPublishSheet();return}
    toast(tr('browserFailed',{error:e?.message||e}));
  }
}
async function openChromePublisher(){return prepareAndOpenPublisher('chrome')}
async function openFirefoxPublisher(){return prepareAndOpenPublisher('firefox')}
async function openBrowserPublisher(){return prepareAndOpenPublisher(publisherBrowser())}

async function publisherFolderStatus(){
  if(!Capacitor.isNativePlatform())return {configured:true,label:'Navigateur'};
  try{return await PublisherFiles.getFolder()}catch(e){console.warn('[Publisher folder status]',e);return {configured:false,label:''}}
}

async function choosePublisherFolder(){
  if(!Capacitor.isNativePlatform())return {configured:true,label:'Navigateur'};
  try{
    const result=await PublisherFiles.chooseFolder();
    if(result?.configured&&!result?.cancelled){
      toast(`${tr('publisherFolderChosen')||'Dossier de travail'} : ${result.label||''}`.trim());
      return result;
    }
    return result||{configured:false,cancelled:true};
  }catch(e){
    console.error('[Publisher folder choose]',e);
    toast(`${tr('publisherFolderChooseFail')||'Impossible de sélectionner le dossier.'} ${e?.message||''}`.trim());
    return {configured:false,cancelled:true};
  }
}

async function saveChromePublisherDirect(){
  const name='MILO.user.js';
  try{
    if(Capacitor.isNativePlatform()){
      let folder=await publisherFolderStatus();
      if(!folder?.configured){
        folder=await choosePublisherFolder();
        if(!folder?.configured)return false;
      }
      const result=await PublisherFiles.savePublisher();
      if(!result?.ok)throw new Error('Publisher native write failed');
      toast(`${tr('chromeFileSaved')} ${result.folderLabel||folder.label||''}`.trim());
      return true;
    }

    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();
    downloadBlob(new Blob([text],{type:'text/javascript'}),name);
    return true;
  }catch(e){
    console.error('[Chrome Publisher direct write]',e);
    toast(`${tr('chromeFileWriteFail')} ${e?.message||''}`.trim());
    return false;
  }
}

async function shareBrowserPublisher(forChrome=false){
  const name='MILO.user.js';
  try{
    const response=await fetch('/'+name);
    if(!response.ok)throw new Error('Publisher asset '+response.status);
    const text=await response.text();

    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({
        path:`RedactedBannerLab/${name}`,
        data:text,
        directory:Directory.Cache,
        encoding:Encoding.UTF8
      });
      const uri=await Filesystem.getUri({
        path:`RedactedBannerLab/${name}`,
        directory:Directory.Cache
      });
      await Share.share({
        title:'MILO 0.5.3 · Redacted BannerLab',
        text:forChrome?tr('chromeFileShareText'):tr('browserShareText'),
        url:uri.uri,
        dialogTitle:forChrome?tr('chromeFileShareDialog'):tr('browserShareDialog')
      });
    }else{
      downloadBlob(new Blob([text],{type:'text/javascript'}),name);
    }
    return true;
  }catch(e){
    console.error('[Browser Publisher share]',e);
    toast(forChrome?tr('chromeFileShareFail'):tr('browserShareFailed'));
    return false;
  }
}

async function chromeBookmarkletText(){
  const r=await fetch('/MILO_Launch.txt');
  if(!r.ok)throw new Error('bookmarklet '+r.status);
  return r.text();
}

async function copyChromeBookmarklet(){
  const code=await chromeBookmarkletText();
  try{
    await navigator.clipboard.writeText(code);
    localStorage.setItem(CHROME_CODE_KEY,'1');
    toast(tr('miniCodeCopied'));
    return true;
  }catch(e){
    console.warn('[Chrome bookmarklet clipboard]',e);
    return false;
  }
}

async function openChromeSetupPage(test=false){
  const url=test
    ?`https://missions.ingress.com/#rblsetup=chrome&rblpick=1&rbltoken=${encodeURIComponent(newPublisherSetupToken('chrome'))}`
    :'https://missions.ingress.com/';
  try{
    await IntentLauncher.startActivityAsync({
      action:ActivityAction.VIEW,
      data:url,
      packageName:'com.android.chrome'
    });
    if(test)toast(tr('chromeTestWaiting'));
  }catch(e){
    toast(tr('chromeOpenFail'));
    await AppLauncher.openUrl({url});
  }
}


const MILO_GUIDE_STYLE=`<style>
.miloGuideSpeak{display:grid;grid-template-columns:48px 1fr;gap:10px;align-items:center;margin:8px 0 14px;padding:9px 10px;border:1px solid #28613f;border-radius:14px;background:linear-gradient(135deg,#0b2116,#07140e)}
.miloGuideSpeak img{width:48px;height:48px;max-width:48px;object-fit:cover;object-position:center 35%;border-radius:12px;border:1px solid #31ed83;box-shadow:0 0 16px #31ed8333}
.miloGuideSpeak b{display:block;color:#31ed83;font-size:9px;letter-spacing:.08em;margin-bottom:3px}
.miloGuideSpeak span{display:block;color:#b9d1c1;font-size:9px;line-height:1.45}
</style>`;

async function openChromeSetupSheet(step=chromeSetupStep()){
  step=publisherReady('chrome')?8:clamp(parseInt(step)||1,1,7);
  setChromeSetupStep(step);
  const code=await chromeBookmarkletText().catch(()=> '');
  const codeCopied=localStorage.getItem(CHROME_CODE_KEY)==='1';
  const publisherFolder=await publisherFolderStatus();
  const publisherFolderLabel=publisherFolder?.configured?(publisherFolder.label||tr('publisherFolderConfigured')):tr('publisherFolderNone');
  const shot=(src,caption,cls='')=>`<figure class="chromeGuideShot ${cls}"><button type="button" class="chromeGuideShotFrame chromeShotZoom"><img src="${src}" alt="${escapeHtml(caption)}"><span class="chromeGuideZoomHint">🔍</span></button><figcaption>${escapeHtml(caption)}</figcaption></figure>`;
  const milo=(text)=>`<div class="miloGuideSpeak"><img src="/assets/milo.jpg" alt="MILO"><div><b>MILO</b><span>${text}</span></div></div>`;

  let body='';
  if(step===1){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeGuideEyebrow">${tr('chromeGuideTestBadge')}</div>
      ${milo(escapeHtml(op('miloHello')))}
      <div class="chromeWizardIcon">📄</div>
      <h3>${tr('chromeFileTitle')}</h3>
      <p>${tr('chromeFileText')}</p>
      <div class="rule"><span class="dot ${publisherFolder?.configured?'':'warn'}"></span><span><b>${tr('publisherFolderLabel')}</b><br>${escapeHtml(publisherFolderLabel)}</span></div>
      <button class="secondary choosepubfolder">${publisherFolder?.configured?tr('publisherFolderChange'):tr('publisherFolderChoose')}</button>
      <button class="primary savepub">${tr('chromeSaveFile')}</button>
      <button class="secondary alreadysaved">${tr('alreadySaved')}</button>
    </div>`;
  }else if(step===2){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">📋</div>
      <h3>${tr('chromeGuide2Title')}</h3>
      <p>${tr('chromeGuide2Text')}</p>
      <div class="chromeCodeMeta"><b>${tr('chromeBookmarkName')}</b><span>${tr('codeLength',{n:code.length})}</span></div>
      <div class="chromeGuideCallout"><b>${escapeHtml(op('shortcutReady'))}</b><span>${escapeHtml(op('shortcutReadyText'))}</span></div>
      <button class="primary copybookmark">${codeCopied?'✓ ':''}${tr('copyMiniCode')}</button>
      <button class="secondary openchrome">${tr('chromeGuideOpenMat')}</button>
      ${shot('/tutorials/chrome/01-mission-authoring.jpg',op('matOpenedChrome'),'focus-mat')}
    </div>`;
  }else if(step===3){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">⭐</div>
      <h3>${tr('chromeGuide3Title')}</h3>
      <p>${tr('chromeGuide3Text')}</p>
      ${shot('/tutorials/chrome/02-chrome-menu-star.jpg',tr('chromeGuideSourceM3'),'focus-star')}
      <div class="chromeGuideCallout"><b>⋮ → ⭐</b><span>${tr('chromeGuideRealScreens')}</span></div>
      <button class="primary stepdone">${tr('chromeGuideDone')}</button>
    </div>`;
  }else if(step===4){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">🔖</div>
      <h3>${tr('chromeGuide4Title')}</h3>
      <p>${tr('chromeGuide4Text')}</p>
      ${shot('/tutorials/chrome/03-bookmarks-root.jpg',tr('chromeGuideSourceBookmarks'),'focus-bookmarks')}
      ${shot('/tutorials/chrome/04-bookmark-menu-edit.jpg',op('bookmarkEditMenu'),'focus-bookmarkmenu')}
      <div class="chromeGuideCallout"><b>${escapeHtml(op('mobileBookmarksPath'))}</b></div>
      <button class="primary stepdone">${tr('chromeGuideDone')}</button>
    </div>`;
  }else if(step===5){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">✏️</div>
      <h3>${tr('chromeGuide5Title')}</h3>
      <p>${tr('chromeGuide5Text')}</p>
      ${shot('/tutorials/chrome/05-edit-bookmark.jpg',tr('chromeGuideSourceEdit'),'focus-edit')}
      ${shot('/tutorials/chrome/05b-milo-bookmark.jpg',op('miloBookmarkSaved'),'focus-bookmarks')}
      <div class="chromeGuideFields"><span><small>${escapeHtml(op('fieldName'))}</small><b>MILO</b></span><span><small>${escapeHtml(op('fieldUrl'))}</small><b>javascript:…</b></span></div>
      <button class="primary copybookmark">${codeCopied?'✓ ':''}${tr('copyMiniCode')}</button>
      <button class="secondary stepdone">${tr('chromeGuideDone')}</button>
    </div>`;
  }else if(step===6){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">🚀</div>
      ${milo(escapeHtml(op('miloAddress')))}
      <h3>${tr('chromeGuide6Title')}</h3>
      <p>${tr('chromeGuide6Text')}</p>
      ${shot('/tutorials/chrome/06-address-bar-bookmark.jpg',tr('chromeGuideSourceRun'),'focus-run')}
      <div class="chromeGuideCallout important"><b>${escapeHtml(op('addressMilo'))}</b></div>
      <button class="secondary openchrome">${tr('chromeGuideOpenMat')}</button>
      <button class="primary stepdone">${tr('chromeGuideDone')}</button>
    </div>`;
  }else if(step===7){
    body=`<div class="chromeWizardCard chromeGuideCard">
      <div class="chromeWizardIcon">📂</div>
      <h3>${tr('chromeGuide7Title')}</h3>
      <p>${tr('chromeGuide7Text')}</p>
      <div class="chromeGuideFileStack">
        <div><span>1</span><div><b>${escapeHtml(op('miloProgram'))}</b><small>MILO.user.js · ${escapeHtml(publisherFolderLabel)}</small></div></div>
        <div><span>2</span><div><b>${escapeHtml(op('currentBanner'))}</b><small>MILO_CurrentBanner.json · ${escapeHtml(publisherFolderLabel)}</small></div></div>
      </div>
      ${shot('/tutorials/chrome/07-file-permission.jpg',op('chromePermissionCaption'),'focus-permission')}
      <div class="chromeGuideCallout important"><b>${escapeHtml(op('touchAllow'))}</b><span>${escapeHtml(op('touchAllowText'))}</span></div>
      <button class="primary testchrome">${tr('chromeTestButton')}</button>
      <p class="chromeWizardHelp">${tr('chromeTestWaiting')}</p>
    </div>`;
  }else{
    body=`<div class="chromeWizardCard success chromeGuideCard">
      <div class="chromeWizardIcon">✓</div>
      ${milo(escapeHtml(op('miloInstalled')))}
      <h3>${tr('chromeSetupSuccess')}</h3>
      <p>${tr('chromeSetupSuccessText')}</p>
      <button class="primary publishnow">${tr('publishNow')}</button>
    </div>`;
  }

  const progress=step<=7?Math.round((step/7)*100):100;
  const sh=openSheet(`${MILO_GUIDE_STYLE}<div class="sheethead"><div><h2>${tr('chromeWizardTitle')}</h2><p>${step<=7?tr('chromeGuideStep',{n:step}):tr('chromeSetupSuccess')} · ${tr('chromeWizardIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="chromeGuideProgress"><span>${step<=7?tr('chromeGuideStep',{n:step}):'✓'}</span><div><i style="width:${progress}%"></i></div></div>
    ${body}
    <div class="chromeWizardNav">
      ${step>1&&step<=7?`<button class="secondary wizardprev">← ${tr('wizardPrev')}</button>`:''}
      ${step===2?`<button class="secondary wizardnext">${tr('wizardNext')} →</button>`:''}
    </div>
    <button class="chromeRestart">${tr('wizardRestart')}</button>`);

  $('.close',sh).onclick=closeSheet;
  $$('.chromeShotZoom',sh).forEach(btn=>btn.addEventListener('click',()=>{
    const img=$('img',btn); if(!img)return;
    const viewer=document.createElement('div');
    viewer.className='chromeShotViewer';
    viewer.innerHTML=`<button type="button" class="chromeShotViewerClose">×</button><img src="${img.getAttribute('src')}" alt="${escapeHtml(img.getAttribute('alt')||'Chrome Android')}"><div>${escapeHtml(img.getAttribute('alt')||'')}</div>`;
    document.body.appendChild(viewer);
    const close=()=>viewer.remove();
    $('.chromeShotViewerClose',viewer).onclick=close;
    viewer.addEventListener('click',e=>{if(e.target===viewer)close()});
  }));
  $('.wizardprev',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step-1)});
  $('.wizardnext',sh)?.addEventListener('click',()=>{closeSheet();openChromeSetupSheet(step+1)});
  $('.stepdone',sh)?.addEventListener('click',()=>{setChromeSetupStep(step+1);closeSheet();openChromeSetupSheet(step+1)});

  $('.choosepubfolder',sh)?.addEventListener('click',async()=>{
    const result=await choosePublisherFolder();
    if(result?.configured){closeSheet();openChromeSetupSheet(1)}
  });

  $('.savepub',sh)?.addEventListener('click',async e=>{
    const btn=e.currentTarget;
    const oldText=btn.textContent;
    btn.disabled=true;
    btn.textContent=tr('publisherSaving')||'Enregistrement…';
    const ok=await saveChromePublisherDirect();
    if(ok){
      setChromeSetupStep(2);
      closeSheet();
      openChromeSetupSheet(2);
      return;
    }
    btn.disabled=false;
    btn.textContent=oldText;
  });
  $('.alreadysaved',sh)?.addEventListener('click',()=>{
    setChromeSetupStep(2);closeSheet();openChromeSetupSheet(2);
  });

  $('.copybookmark',sh)?.addEventListener('click',async()=>{
    if(await copyChromeBookmarklet()){
      closeSheet();openChromeSetupSheet(step);
    }else toast(tr('bookmarkletCopyFail'));
  });
  $('.openchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(false));
  $('.testchrome',sh)?.addEventListener('click',()=>openChromeSetupPage(true));
  $('.publishnow',sh)?.addEventListener('click',()=>{
    closeSheet();openChromePublisher(state.planner.currentMission);
  });

  $('.chromeRestart',sh).onclick=()=>{
    resetChromeSetup();
    closeSheet();
    openChromeSetupSheet(1);
  };
}

function openFirefoxSetupSheet(){
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('firefoxSetupTitle')}</h2><p>${tr('firefoxSetupIntro')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="actions"><button class="primary sharepublisher">${tr('sharePublisher')}</button></div>
    <div class="actions"><button class="secondary testfirefox">${tr('testFirefox')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.sharepublisher',sh).onclick=()=>shareBrowserPublisher(false);
  $('.testfirefox',sh).onclick=async()=>{
    try{
      await IntentLauncher.startActivityAsync({
        action:ActivityAction.VIEW,
        data:`https://missions.ingress.com/#rblsetup=firefox&rbltoken=${encodeURIComponent(newPublisherSetupToken('firefox'))}`,
        packageName:'org.mozilla.firefox'
      });
    }catch(e){
      toast(tr('publisherNoFirefox'));
    }
  };
}

function openPublishSheet(){
  ensurePlannerMissions();
  if(!state.planner.description.trim()){openBannerDescriptionRequired(openPublishSheet);return}

  const issues=validatePlanner();
  const current=state.planner.currentMission;
  const currentIssues=missionPublishIssues(current);
  const m=state.planner.missions[current];
  const need=Math.max(MIN_PORTALS_PER_MISSION,state.planner.portalsPerMission);
  const complete=state.planner.missions.filter(x=>x.portals.length>=need && String(x.description||'').trim()).length;
  const total=state.planner.missions.length;
  const mode=publisherBrowser();
  const chromeReady=publisherReady('chrome'),firefoxReady=publisherReady('firefox');
  const blocked=issues.length>0;

  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('publish')}</h2><p>${complete}/${total} · ${formatDistance(totalRouteDistance())}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div>
    <div class="publishMissionGate ${blocked?'blocked':'ready'}">
      <div class="publishMissionGateHead"><span class="missioncard-num">${String(current+1).padStart(2,'0')}</span><div><b>${escapeHtml(m?.title||generatedMissionTitle(current))}</b><small>${m?.portals?.length||0}/${need} · ${tr('bannerDescription')} ✓</small></div><strong>${blocked?'!':'✓'}</strong></div>
      ${blocked?`<div class="publishBlockingList">${issues.slice(0,12).map(x=>`<div>${icon('warning')}<span>${escapeHtml(x)}</span></div>`).join('')}</div><div class="actions"><button class="primary completemission">${icon('route')} ${tr('completeMission')}</button></div>`:`<div class="publishReadyText">${tr('publisherWholeHint')}<small>${tr('publisherCurrentFile')}</small></div>`}
    </div>
    ${blocked?`<div class="publishscore warn"><b>${tr('reviewCount',{n:issues.length})}</b><span>${tr('publisherAllRequired')}</span></div>`:''}
    <div class="field"><label>${tr('publisherBrowser')}</label><div class="publisherchoices">
      <button class="publisherchoice chrome ${mode==='chrome'?'selected':''}" data-mode="chrome"><span class="browsericon">🌐</span><span><b>${tr('chromeMode')}</b><small>${tr('chromeModeSub')}</small><em>${chromeReady?'✓ '+tr('chromeReady'):tr('noExtraApp')}</em></span></button>
      <button class="publisherchoice firefox ${mode==='firefox'?'selected':''}" data-mode="firefox"><span class="browsericon">🦊</span><span><b>${tr('firefoxMode')}</b><small>${tr('firefoxModeSub')}</small><em>${firefoxReady?'✓ '+tr('firefoxReady'):tr('recommendedAuto')}</em></span></button>
    </div></div>
    <div class="actions"><button class="primary livepublisher" ${blocked?'disabled':''}>🚀 ${tr('publisherWholeBanner')}</button></div>
    <div class="actions"><button class="secondary setupselected">${mode==='firefox'?tr('firefoxSetup'):tr('chromeSetup')}</button></div>
    <details class="missionCommon"><summary>${tr('backupTransfer')}</summary><div class="missionCommonBody"><div class="actions"><button class="secondary exportpack">${icon('download')} ${tr('exportPackBackup')}</button></div><div class="actions"><button class="secondary openmat">${icon('globe')} ${tr('openOfficialOnly')}</button></div></div></details>`);
  $('.close',sh).onclick=closeSheet;
  $('.completemission',sh)?.addEventListener('click',()=>{closeSheet();state.planner.currentMission=current;scheduleSave();openRoutePlanner()});
  $$('.publisherchoice',sh).forEach(btn=>btn.onclick=()=>{setPublisherBrowser(btn.dataset.mode);closeSheet();openPublishSheet()});
  $('.livepublisher',sh).onclick=()=>openBrowserPublisher();
  $('.setupselected',sh).onclick=()=>publisherBrowser()==='firefox'?openFirefoxSetupSheet():openChromeSetupSheet();
  $('.exportpack',sh).onclick=exportBannerLabPack;$('.openmat',sh).onclick=openMissionAuthoring;
}

async function exportBannerLabPack(){
  ensurePlannerMissions();
  const zip=new JSZip(),imgFolder=zip.folder('missions');
  const manifest={
    format:'redacted-bannerlab',version:1,appVersion:APP_VERSION,name:state.name,
    language:projectLanguage(),portalsPerMission:state.planner.portalsPerMission,
    missions:state.planner.missions.map((m,i)=>({
      number:i+1,title:m.title,description:m.description,sequential:missionSequential(m),hiddenLocation:missionHidden(m),
      image:`missions/${String(i+1).padStart(3,'0')}.jpg`,
      portals:(m.portals||[]).map(p=>({
        guid:p.guid,title:p.title,latitude:p.location.latitude,longitude:p.location.longitude,imageUrl:p.imageUrl||'',
        objective:{type:p.objective?.type||'HACK_PORTAL',question:p.objective?.passphrase_params?.question||'',answer:p.objective?.passphrase_params?._single_passphrase||''}
      }))
    }))
  };
  try{
    toast(tr('packCreating'));
    for(let n=1;n<=manifest.missions.length;n++){
      const {row,col}=rowColForMission(n),c=document.createElement('canvas');c.width=c.height=512;drawTile(c,row,col,512);
      imgFolder.file(`${String(n).padStart(3,'0')}.jpg`,await canvasBlob(c,'image/jpeg',.94));
      if(n%4===0)await tick();
    }
    zip.file('missions.json',JSON.stringify(manifest,null,2));
    const name=`${safeName(state.name)}_BannerLab.zip`;
    if(Capacitor.isNativePlatform()){
      const b64=await zip.generateAsync({type:'base64',compression:'STORE',streamFiles:true});
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:b64,directory:Directory.Cache});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:`${manifest.missions.length} ${tr('missions').toLowerCase()} · ${state.name}`,url:uri.uri,dialogTitle:name});
    }else{
      const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
      downloadBlob(blob,name);
    }
    toast(tr('packCreated'));
  }catch(e){console.error(e);toast(tr('exportImpossible',{error:e?.message||e}))}
}
async function openMissionAuthoring(){
  const url='https://missions.ingress.com/';
  try{if(Capacitor.isNativePlatform())await AppLauncher.openUrl({url});else window.open(url,'_blank','noopener')}catch(e){console.warn(e);window.open(url,'_blank','noopener')}
}

function backupAutoEnabled(){return localStorage.getItem(BACKUP_AUTO_KEY)==='1'}
function setBackupAutoEnabled(value){localStorage.setItem(BACKUP_AUTO_KEY,value?'1':'0');if(value)queueForegroundAutoBackup(250);else{clearTimeout(backupAutoTimer);backupAutoTimer=null}}
function markBackupChanged(){backupRevision++;queueForegroundAutoBackup()}
function queueForegroundAutoBackup(delay=1800){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||!backupAppActive)return;
  // Throttle volontairement au lieu de repousser le timer à chaque mouvement :
  // une longue session d'édition produit ainsi régulièrement un snapshot complet
  // pendant que le WebView est encore actif.
  if(backupAutoTimer)return;
  backupAutoTimer=setTimeout(async()=>{
    backupAutoTimer=null;
    if(!backupAutoEnabled())return;
    await autoBackupIfNeeded('foreground');
    // Si des modifications sont arrivées pendant la création du JSON, on repasse.
    if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(2200);
  },Math.max(0,delay));
}
function backupDateText(value){
  if(!value)return tr('backupNever');
  try{return tr('backupLast',{date:new Date(value).toLocaleString(appLocale(),{dateStyle:'short',timeStyle:'short'})})}catch{return tr('backupNever')}
}
async function blobToBackupMedia(blob){
  if(!blob)return null;
  const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';
  for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
  return {mime:blob.type||'application/octet-stream',name:blob.name||'',base64:btoa(binary)};
}
function backupMediaToBlob(media){
  if(!media?.base64)return null;
  const bin=atob(media.base64),bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
  try{return media.name?new File([bytes],media.name,{type:media.mime||'application/octet-stream'}):new Blob([bytes],{type:media.mime||'application/octet-stream'})}catch{return new Blob([bytes],{type:media.mime||'application/octet-stream'})}
}
function portableLocalSettings(){
  const keys=[BANNER_FAVORITES_KEY,BANNER_TODO_KEY,PLAY_HISTORY_KEY,BANNER_SEARCH_PREFS_KEY,PLAY_SESSION_KEY,'rbl-language'];
  const out={};for(const k of keys){const v=localStorage.getItem(k);if(v!==null)out[k]=v}return out;
}
async function buildFullBackup(){
  await saveProject({markBackup:false});
  const rows=await getAllProjects(),projects=[];
  for(const rec of rows){
    const background=await blobToBackupMedia(rec.blob);
    const layerBlobs=[];
    for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
    projects.push({id:rec.id,data:rec.data||{},background,layerBlobs});
    await tick();
  }
  return {format:'redacted-bannerlab-backup',schemaVersion:1,appVersion:APP_VERSION,createdAt:new Date().toISOString(),currentProjectId:localStorage.getItem('redactedBannerLabCurrentProjectId')||state.projectId||'',language:APP_LANG,settings:portableLocalSettings(),projects};
}
async function fullBackupJson(){return JSON.stringify(await buildFullBackup())}
function safeProjectFilename(name='Redacted_BannerLab'){
  const clean=String(name||'Redacted_BannerLab').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,72);
  return clean||'Redacted_BannerLab';
}
async function projectRecordById(id){
  if(id===state.projectId)await saveProject({markBackup:false});
  const db=await openDB(),tx=db.transaction('project','readonly');
  return await request(tx.objectStore('project').get(id));
}
async function buildPortableProject(id=state.projectId){
  const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
  const background=await blobToBackupMedia(rec.blob),layerBlobs=[];
  for(const x of (rec.layerBlobs||[]))layerBlobs.push({id:x.id,media:await blobToBackupMedia(x.blob)});
  return {
    format:'redacted-bannerlab-project',schemaVersion:1,appVersion:APP_VERSION,exportedAt:new Date().toISOString(),
    originalProjectId:String(rec.id||''),
    project:{data:rec.data,background,layerBlobs},
    capabilities:{images:true,customFonts:true,planner:true,routeFromPortalCoordinates:true}
  };
}
async function portableProjectJson(id=state.projectId){return JSON.stringify(await buildPortableProject(id),null,2)}
function validatePortableProject(x){return !!(x&&x.format==='redacted-bannerlab-project'&&Number(x.schemaVersion)>=1&&x.project?.data)}
async function deliverPortableProject(id,{share=false}={}){
  try{
    toast(tr('projectExporting'));
    const rec=await projectRecordById(id);if(!rec?.data)throw new Error(tr('projectImportInvalid'));
    const text=await portableProjectJson(id),name=`Redacted_BannerLab_${safeProjectFilename(rec.data.name)}.rbl.json`;
    if(Capacitor.isNativePlatform()){
      if(share){
        // Partager garde la feuille de partage Android.
        await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
        await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
        const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
        await Share.share({title:tr('projectShareTitle'),text:rec.data.name||tr('projectShareTitle'),url:uri.uri,dialogTitle:tr('shareProject')});
      }else{
        // Exporter ouvre le sélecteur Android ACTION_CREATE_DOCUMENT :
        // l'utilisateur choisit réellement le dossier et peut modifier le nom.
        const result=await BackupFolder.saveTextFileAs({fileName:name,text,mimeType:'application/json'});
        if(result?.cancelled)return;
        if(!result?.saved)throw new Error(tr('projectSaveFailed'));
      }
    }else{
      downloadBlob(new Blob([text],{type:'application/json'}),name);
    }
    toast(share?tr('projectShared'):tr('projectExported'));
  }catch(e){console.error('portable project',e);toast(tr('backupFailed',{error:e?.message||e}))}
}
async function restorePortableProject(payload){
  if(!validatePortableProject(payload)){toast(tr('projectImportInvalid'));return false}
  try{
    const src=payload.project,data=JSON.parse(JSON.stringify(src.data||{})),blob=backupMediaToBlob(src.background),layerBlobs=[];
    for(const x of (src.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    data.updatedAt=new Date().toISOString();
    const id=newProjectId(),db=await openDB(),tx=db.transaction('project','readwrite');
    tx.objectStore('project').put({id,data,blob,layerBlobs});await txDone(tx);
    markBackupChanged();await loadProject(id);resetHistory();closeSheet();toast(tr('projectImportSuccess'));return true;
  }catch(e){console.error('project import',e);toast(tr('projectImportInvalid'));return false}
}
function importPortableProject(){
  const input=document.createElement('input');input.type='file';input.accept='.json,.rbl.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());await restorePortableProject(payload)}catch(e){console.warn(e);toast(tr('projectImportInvalid'))}finally{input.remove()}};
  input.click();
}

async function backupFolderInfo(){
  if(!Capacitor.isNativePlatform())return {configured:false,label:''};
  try{return await BackupFolder.getFolder()}catch(e){console.warn('backup folder',e);return {configured:false,label:''}}
}
async function chooseBackupFolder(){
  if(!Capacitor.isNativePlatform()){toast(tr('backupNativeOnly'));return null}
  try{const r=await BackupFolder.chooseFolder();if(r?.configured){toast(tr('backupFolderChosen'));return r}}catch(e){console.warn(e);toast(tr('backupFolderError'))}return null;
}
function refreshBackupLastStatus(when=localStorage.getItem(BACKUP_LAST_KEY)){
  $$('.backupLastStatus').forEach(el=>{el.textContent=backupDateText(when)});
}
async function writeBackupToFolder({automatic=false,force=false}={}){
  if(backupInProgress)return false;
  if(automatic&&!force&&lastBackedRevision===backupRevision)return false;
  const folder=await backupFolderInfo();if(!folder?.configured){if(!automatic)toast(tr('backupNeedFolder'));return false}
  const targetRevision=backupRevision;
  backupInProgress=true;
  try{
    if(!automatic)toast(tr('backupWorking'));
    const text=await fullBackupJson();
    await BackupFolder.writeTextFile({fileName:BACKUP_FILE_NAME,text});
    const when=new Date().toISOString();localStorage.setItem(BACKUP_LAST_KEY,when);lastBackedRevision=Math.max(lastBackedRevision,targetRevision);refreshBackupLastStatus(when);
    // Pas de toast pour les sauvegardes automatiques de premier plan : elles peuvent
    // arriver régulièrement et ne doivent pas interrompre l'édition.
    if(!automatic)toast(tr('backupSaved'));
    return true;
  }catch(e){console.error('backup',e);if(!automatic)toast(tr('backupFailed',{error:e?.message||e}));return false}
  finally{backupInProgress=false;if(backupAppActive&&backupAutoEnabled()&&lastBackedRevision!==backupRevision)queueForegroundAutoBackup(1200)}
}
async function exportFullBackupJson(){
  if(backupInProgress)return;backupInProgress=true;
  try{
    toast(tr('backupWorking'));const text=await fullBackupJson();const name=`Redacted_BannerLab_Backup_${new Date().toISOString().slice(0,19).replaceAll(':','-')}.json`;
    if(Capacitor.isNativePlatform()){
      await Filesystem.mkdir({path:'RedactedBannerLab',directory:Directory.Cache,recursive:true}).catch(()=>{});
      await Filesystem.writeFile({path:`RedactedBannerLab/${name}`,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
      const uri=await Filesystem.getUri({path:`RedactedBannerLab/${name}`,directory:Directory.Cache});
      await Share.share({title:'Redacted BannerLab',text:tr('backupTitle'),url:uri.uri,dialogTitle:name});
    }else downloadBlob(new Blob([text],{type:'application/json'}),name);
    toast(tr('backupSaved'));
  }catch(e){console.error(e);toast(tr('backupFailed',{error:e?.message||e}))}finally{backupInProgress=false}
}
function validateBackupPayload(x){return !!(x&&x.format==='redacted-bannerlab-backup'&&Number(x.schemaVersion)>=1&&Array.isArray(x.projects))}
async function restoreFullBackup(payload,{replace=false}={}){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return false}
  const prepared=[];
  for(const rec of payload.projects){
    if(!rec?.id||!rec?.data)continue;
    const blob=backupMediaToBlob(rec.background),layerBlobs=[];
    for(const x of (rec.layerBlobs||[])){const b=backupMediaToBlob(x.media);if(b)layerBlobs.push({id:x.id,blob:b})}
    prepared.push({id:String(rec.id),data:rec.data,blob,layerBlobs});await tick();
  }
  if(!prepared.length){toast(tr('backupInvalid'));return false}
  const db=await openDB();const tx=db.transaction('project','readwrite'),store=tx.objectStore('project');if(replace)store.clear();for(const rec of prepared)store.put(rec);await txDone(tx);
  if(payload.settings&&typeof payload.settings==='object')for(const [k,v] of Object.entries(payload.settings))if(typeof v==='string'&&k!==BACKUP_AUTO_KEY&&k!==BACKUP_LAST_KEY)localStorage.setItem(k,v);
  if(SUPPORTED_LANGS.includes(payload.language))localStorage.setItem('rbl-language',payload.language);
  const target=prepared.some(x=>x.id===payload.currentProjectId)?payload.currentProjectId:prepared[0].id;localStorage.setItem('redactedBannerLabCurrentProjectId',target);
  localStorage.setItem('redactedBannerLabMigrationDone','1');markBackupChanged();toast(tr('backupImported'));setTimeout(()=>location.reload(),450);return true;
}
function confirmBackupImport(payload){
  if(!validateBackupPayload(payload)){toast(tr('backupInvalid'));return}
  const date=(()=>{try{return new Date(payload.createdAt).toLocaleString(appLocale())}catch{return payload.createdAt||'—'}})();
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('backupImportTitle')}</h2><p>${tr('backupImportText',{n:payload.projects.length,date})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('backupReplaceWarn')}</span></div><div class="actions"><button class="secondary mergeBackup">${tr('backupMerge')}</button><button class="danger replaceBackup">${tr('backupReplace')}</button></div>`);
  $('.close',sh).onclick=()=>openInfoSheet();$('.mergeBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:false});$('.replaceBackup',sh).onclick=()=>restoreFullBackup(payload,{replace:true});
}
function importFullBackupJson(){
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.style.display='none';document.body.appendChild(input);
  input.onchange=async()=>{try{const file=input.files?.[0];if(!file)return;const payload=JSON.parse(await file.text());confirmBackupImport(payload)}catch(e){console.warn(e);toast(tr('backupInvalid'))}finally{input.remove()}};input.click();
}
async function autoBackupIfNeeded(reason='background'){
  if(!Capacitor.isNativePlatform()||!backupAutoEnabled()||backupInProgress||lastBackedRevision===backupRevision)return false;
  try{
    // Sauvegarde d'abord le projet courant dans IndexedDB, puis construit le JSON.
    await saveProject({markBackup:false});
    return await writeBackupToFolder({automatic:true});
  }catch(e){console.warn('auto backup '+reason,e);return false}
}
function autoBackupOnBackground(reason='background'){
  backupAppActive=false;
  clearTimeout(backupAutoTimer);backupAutoTimer=null;
  // On lance immédiatement le flush. En parallèle, les snapshots réguliers faits
  // au premier plan évitent de dépendre de ce court créneau avant suspension Android.
  void autoBackupIfNeeded(reason);
}
function autoBackupOnForeground(){backupAppActive=true;if(lastBackedRevision!==backupRevision)queueForegroundAutoBackup(500)}


function updatePref(key,defaultValue=true){const v=localStorage.getItem(key);return v===null?defaultValue:v==='1'}
function setUpdatePref(key,value){localStorage.setItem(key,value?'1':'0')}
function extractSemver(raw=''){const m=String(raw).match(/(\d+(?:\.\d+){2,})/);return m?m[1].split('.').map(Number):null}
function compareSemver(a,b){const x=extractSemver(a),y=extractSemver(b);if(!x||!y)return 0;const n=Math.max(x.length,y.length);for(let i=0;i<n;i++){const xv=x[i]||0,yv=y[i]||0;if(xv>yv)return 1;if(xv<yv)return-1}return 0}
async function loadUpdateConfig(){
  if(updateConfigCache)return updateConfigCache;
  try{const r=await fetch('/update-config.json',{cache:'no-store'});const j=await r.json();updateConfigCache=j||{};return updateConfigCache}catch(e){console.warn('[RBL update config]',e);return {}}
}
function chooseReleaseApk(release){
  const assets=Array.isArray(release?.assets)?release.assets:[];
  return assets.find(a=>/redacted.*bannerlab.*\.apk$/i.test(String(a?.name||'')))||assets.find(a=>/\.apk$/i.test(String(a?.name||'')))||null;
}
function chooseReleaseMeta(release){
  const assets=Array.isArray(release?.assets)?release.assets:[];
  return assets.find(a=>String(a?.name||'').toLowerCase()==='redacted-bannerlab-update.json')||null;
}
async function fetchReleaseMeta(release){
  const metaAsset=chooseReleaseMeta(release);
  if(!metaAsset?.browser_download_url)return {};
  try{
    const url=String(metaAsset.browser_download_url);
    const res=Capacitor.isNativePlatform()?await CapacitorHttp.get({url,headers:{Accept:'application/json'}}):await fetch(url,{cache:'no-store'}).then(async r=>({status:r.status,data:await r.text()}));
    if(Number(res?.status||0)!==200)return {};
    if(res?.data&&typeof res.data==='object')return res.data;
    if(typeof res?.data==='string')return JSON.parse(res.data);
  }catch(e){console.warn('[RBL update metadata]',e)}
  return {};
}
async function fetchLatestRblRelease(){
  const cfg=await loadUpdateConfig(),repo=String(cfg?.repo||'').trim();
  if(!repo||!repo.includes('/'))throw new Error(tr('updateRepoMissing'));
  const url=`https://api.github.com/repos/${repo}/releases/latest`;
  const res=Capacitor.isNativePlatform()?await CapacitorHttp.get({url,headers:{Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2026-03-10'}}):await fetch(url,{headers:{Accept:'application/vnd.github+json'}}).then(async r=>({status:r.status,data:await r.json()}));
  if(Number(res?.status||0)!==200)throw new Error(`GitHub HTTP ${res?.status||'?'}`);
  const release=res.data||{},asset=chooseReleaseApk(release);
  if(!asset)throw new Error(tr('updateNoApk'));
  const meta=await fetchReleaseMeta(release);
  const fallbackVersion=(extractSemver(release.tag_name)||extractSemver(release.name))?.join('.')||String(release.tag_name||release.name||'');
  const version=String(meta?.versionName||fallbackVersion);
  const versionCode=Number(meta?.versionCode||0);
  return {repo,version,versionCode,tag:String(release.tag_name||version),name:String(release.name||release.tag_name||version),body:String(release.body||''),publishedAt:release.published_at||'',htmlUrl:release.html_url||'',asset:{name:asset.name||'',url:asset.browser_download_url||'',size:Number(asset.size)||0,digest:String(asset.digest||'')}};
}
async function ensureUpdateProgressListener(){
  if(updateProgressListenerReady||!Capacitor.isNativePlatform())return;updateProgressListenerReady=true;
  try{await UpdateManager.addListener('updateProgress',p=>{const bar=document.querySelector('.rblUpdateProgressBar i'),label=document.querySelector('.rblUpdateProgressLabel');const pct=Number(p?.percent);if(bar&&pct>=0)bar.style.width=`${Math.max(0,Math.min(100,pct))}%`;if(label)label.textContent=pct>=0?`${tr('updateDownloading')} · ${pct}%`:tr('updateDownloading')})}catch(e){console.warn('[RBL update listener]',e)}
}
function updateReleaseIgnored(rel){return !!rel&&localStorage.getItem(UPDATE_IGNORE_KEY)===String(rel.tag||rel.version||'')}
function saveStagedMeta(rel,verified){localStorage.setItem(UPDATE_STAGED_META_KEY,JSON.stringify({tag:rel.tag,version:rel.version,name:rel.name,body:rel.body,sha256:verified?.sha256||'',versionCode:verified?.versionCode||0,at:Date.now()}))}
async function updateNativeStatus(){if(!Capacitor.isNativePlatform())return null;try{return await UpdateManager.getStatus()}catch(e){console.warn('[RBL update status]',e);return null}}
function updateNotesHtml(rel){return rel?.body?`<details class="rblUpdateNotes"><summary>${escapeHtml(tr('updateReleaseNotes'))}</summary><p>${escapeHtml(rel.body).replaceAll('\n','<br>')}</p></details>`:''}
function showUpdatePermissionSheet(rel){
  pendingUpdateRelease=rel;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('updatePermission')}</h2><p>${escapeHtml(rel?.name||rel?.tag||'')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="igorUpdateHero"><img src="/igor.webp" alt="IGOR"><div><b>${tr('updateIgorTitle')}</b><p>${tr('updatePermissionText')}</p></div></div>${updateNotesHtml(rel)}<div class="actions"><button class="secondary later">${tr('cancel')}</button><button class="primary allow">${tr('updateOpenPermission')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.later',sh).onclick=closeSheet;
  $('.allow',sh).onclick=async()=>{
    if(updateInstallRequestInFlight)return;
    updateInstallRequestInFlight=true;
    try{
      const permission=await UpdateManager.openInstallPermission();
      closeSheet();
      if(permission?.canRequestPackageInstalls){
        await showUpdateAvailableSheet(rel,{downloaded:true});
        return;
      }
      toast(tr('updatePermission'));
    }catch(e){
      toast(`${tr('updateError')} · ${e?.message||e}`);
    }finally{
      updateInstallRequestInFlight=false;
    }
  };
}
function updateVerifiedChecklist(rel,st){
  if(!st?.staged)return '';
  const version=escapeHtml(st.stagedVersionName||rel?.version||rel?.tag||'?');
  const code=Number(st.stagedVersionCode||0);
  return `<div class="rulelist rblUpdateVerified">
    <div class="rule"><span class="dot"></span><span><b>APK</b> · ${version}${code?` · ${code}`:''}</span></div>
    <div class="rule"><span class="dot"></span><span>✓ SHA-256 · ✓ package · ✓ signature · ✓ versionCode</span></div>
  </div>`;
}
async function showUpdateAvailableSheet(rel,{downloaded=null}={}){
  pendingUpdateRelease=rel;
  const st=await updateNativeStatus();
  const stagedForThisRelease=!!(st?.staged && (Number(rel?.versionCode||0)>0?Number(st.stagedVersionCode||0)===Number(rel.versionCode):(!rel?.version||String(st.stagedVersionName||'')===String(rel.version||''))));
  const ready=downloaded===null?stagedForThisRelease:!!downloaded;
  const latestLabel=`${escapeHtml(rel.version||rel.tag||'?')}${Number(rel?.versionCode||0)>0?` · ${Number(rel.versionCode)}`:''}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('updateAvailable')}</h2><p>${escapeHtml(rel?.name||rel?.tag||rel?.version||'')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="igorUpdateHero"><img src="/igor.webp" alt="IGOR"><div><b>${tr('updateIgorTitle')}</b><p>${tr('updateIgorText')}</p></div></div><div class="rblUpdateVersion"><span>${tr('updateCurrent')}<b>${APP_VERSION} · ${DISPLAY_BUILD_CODE}</b></span><span>→</span><span>${tr('updateLatest')}<b>${latestLabel}</b></span></div><div class="rblUpdateProgress"><span class="rblUpdateProgressLabel">${ready?tr('updateReady'):tr('updateAvailable')}</span><div class="rblUpdateProgressBar"><i style="width:${ready?'100':'0'}%"></i></div></div>${ready?updateVerifiedChecklist(rel,st):''}${updateNotesHtml(rel)}<div class="actions updateSheetActions"><button class="ghost ignore">${tr('updateIgnore')}</button><button class="primary go">${ready?tr('updateInstall'):tr('updateDownload')}</button></div>`);
  $('.close',sh).onclick=closeSheet;
  $('.ignore',sh).onclick=()=>{localStorage.setItem(UPDATE_IGNORE_KEY,String(rel.tag||rel.version||''));closeSheet();toast(tr('updateIgnored'))};
  $('.go',sh).onclick=()=>ready?installStagedRblUpdate(rel):downloadRblUpdate(rel);
  return sh;
}
async function installStagedRblUpdate(rel){
  if(!Capacitor.isNativePlatform()||updateInstallRequestInFlight)return;
  updateInstallRequestInFlight=true;
  try{
    pendingUpdateRelease=rel||pendingUpdateRelease;
    const st=await updateNativeStatus();
    if(!st?.staged){
      toast(`${tr('updateError')} · APK absent`);
      if(rel)await showUpdateAvailableSheet(rel,{downloaded:false});
      return;
    }
    if(!st?.canRequestPackageInstalls){
      showUpdatePermissionSheet(rel||pendingUpdateRelease);
      return;
    }
    const label=document.querySelector('.rblUpdateProgressLabel');
    if(label)label.textContent=tr('updateInstalling');
    const r=await UpdateManager.installStagedUpdate();
    if(r?.needsPermission){
      showUpdatePermissionSheet(rel||pendingUpdateRelease);
      return;
    }
    if(label)label.textContent=tr('updatePendingAndroid');
  }catch(e){
    console.warn('[RBL update install]',e);
    toast(`${tr('updateError')} · ${e?.message||e}`);
  }finally{
    updateInstallRequestInFlight=false;
  }
}
async function downloadRblUpdate(rel){
  if(updateInProgress||!Capacitor.isNativePlatform())return;
  updateInProgress=true;
  try{
    if(!rel?.asset?.digest||!/^sha256:/i.test(rel.asset.digest))throw new Error(tr('updateDigestMissing'));
    await ensureUpdateProgressListener();
    const sh=document.querySelector('.sheet');
    const label=sh?.querySelector('.rblUpdateProgressLabel'),bar=sh?.querySelector('.rblUpdateProgressBar i'),go=sh?.querySelector('.go');
    if(go)go.disabled=true;
    if(label)label.textContent=tr('updateDownloading');
    const verified=await UpdateManager.downloadUpdate({url:rel.asset.url,sha256:rel.asset.digest});
    saveStagedMeta(rel,verified);
    if(label)label.textContent=tr('updateReady');
    if(bar)bar.style.width='100%';
    closeSheet();
    await showUpdateAvailableSheet(rel,{downloaded:true});
  }catch(e){
    console.warn('[RBL update download]',e);
    toast(`${tr('updateError')} · ${e?.message||e}`);
  }finally{
    updateInProgress=false;
  }
}
async function downloadAndMaybeInstallRblUpdate(rel,{forceInstall=false}={}){
  return downloadRblUpdate(rel);
}

async function showRitaUpdateAnnouncement(rel,{downloaded=false}={}){
  pendingUpdateRelease=rel;
  const latestLabel=`${escapeHtml(rel.version||rel.tag||'?')}${Number(rel?.versionCode||0)>0?` · ${Number(rel.versionCode)}`:''}`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('updateAvailable')}</h2><p>${latestLabel}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="igorUpdateHero"><img src="/rita.webp" alt="RITA"><div><b>RITA · ${tr('updateAvailable')}</b><p>${tr('ritaUpdateAnnouncement')}</p></div></div>${updateNotesHtml(rel)}<div class="actions"><button class="secondary later">${tr('cancel')}</button><button class="primary details">${downloaded?tr('updateInstall'):tr('updateDownload')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.later',sh).onclick=closeSheet;
  $('.details',sh).onclick=async()=>{closeSheet();await showUpdateAvailableSheet(rel,{downloaded});};
  return sh;
}

async function checkForRblUpdate({manual=false,automatic=false,uiRoot=null}={}){
  if(TEST_BUILD){if(manual)toast(testText('updatesOff'));return null}
  if(!Capacitor.isNativePlatform()){if(manual)toast(tr('updateRepoMissing'));return null}
  const statusEl=uiRoot?.querySelector?.('.updateStatusText');if(statusEl)statusEl.textContent=tr('updateChecking');
  try{
    const rel=await fetchLatestRblRelease();localStorage.setItem(UPDATE_LAST_CHECK_KEY,String(Date.now()));
    const currentCode=Number(BUILD_CODE||0),remoteCode=Number(rel?.versionCode||0);
    const newer=remoteCode>0&&currentCode>0?remoteCode>currentCode:compareSemver(rel.version,APP_VERSION)>0;
    const relLabel=`${rel.version||rel.tag||'—'}${remoteCode>0?` · ${remoteCode}`:''}`;
    if(statusEl)statusEl.textContent=newer?`${tr('updateAvailable')} · ${relLabel}`:tr('updateUpToDate');
    const latest=uiRoot?.querySelector?.('.updateLatestValue');if(latest)latest.textContent=relLabel;
    if(!newer){if(manual)toast(tr('updateUpToDate'));return rel}
    if(updateReleaseIgnored(rel)&&!manual)return rel;
    pendingUpdateRelease=rel;
    const native=await updateNativeStatus();
    const stagedForRelease=!!(native?.staged && (remoteCode>0?Number(native.stagedVersionCode||0)===remoteCode:String(native.stagedVersionName||'')===String(rel.version||'')));
    if(manual)await showUpdateAvailableSheet(rel,{downloaded:stagedForRelease});
    else if(automatic&&updatePref(UPDATE_DOWNLOAD_KEY,false)&&!stagedForRelease)await downloadRblUpdate(rel);
    else await showRitaUpdateAnnouncement(rel,{downloaded:stagedForRelease});
    return rel;
  }catch(e){console.warn('[RBL update check]',e);if(statusEl)statusEl.textContent=`${tr('updateError')} · ${e?.message||e}`;if(manual)toast(`${tr('updateError')} · ${e?.message||e}`);return null}
}
function updateSettingsHtml(){if(TEST_BUILD)return `<div class="updateSection"><div class="updateCard"><div class="updateHead"><div><strong>${tr('testEditionTitle')}</strong><p>${testText('updatesOff')}</p></div></div><div class="updateVersions"><span>${tr('testVersion')}<b>${APP_VERSION} · ${DISPLAY_BUILD_CODE}</b></span><span>${tr('testPackage')}<b>${tr('testPackageSeparate')}</b></span></div></div></div>`;return `<div class="updateSection"><div class="updateCard"><div class="updateHead"><img src="/igor.webp" alt="IGOR"><div><strong>${tr('updateIgorTitle')}</strong><p>${tr('updateIgorText')}</p></div></div><div class="updateVersions"><span>${tr('updateCurrent')}<b>${APP_VERSION} · ${DISPLAY_BUILD_CODE}</b></span><span>${tr('updateLatest')}<b class="updateLatestValue">—</b></span></div><label class="switchline"><input type="checkbox" class="updateAutoCheck" ${updatePref(UPDATE_CHECK_KEY,true)?'checked':''}> ${tr('updateAutoCheck')}</label><label class="switchline"><input type="checkbox" class="updateAutoDownload" ${updatePref(UPDATE_DOWNLOAD_KEY,false)?'checked':''}> ${tr('updateAutoDownload')}</label><div class="updateStatusText">${tr('updateChecking')}</div><button class="primary updateCheckNow">🧪 ${tr('updateCheckNow')}</button></div></div>`}
function bindUpdateSettings(sh){
  if(TEST_BUILD)return;
  $('.updateAutoCheck',sh).onchange=e=>setUpdatePref(UPDATE_CHECK_KEY,e.target.checked);$('.updateAutoDownload',sh).onchange=e=>setUpdatePref(UPDATE_DOWNLOAD_KEY,e.target.checked);$('.updateCheckNow',sh).onclick=()=>checkForRblUpdate({manual:true,uiRoot:sh});void checkForRblUpdate({manual:false,uiRoot:sh});
}
let updateLaunchCheckDone=false;
async function maybeAutoCheckRblUpdate(){
  if(TEST_BUILD||updateLaunchCheckDone)return;
  if(!Capacitor.isNativePlatform()||!updatePref(UPDATE_CHECK_KEY,true))return;
  updateLaunchCheckDone=true;
  await checkForRblUpdate({automatic:true});
}
function stagedUpdateMetaAsRelease(){
  try{
    const m=JSON.parse(localStorage.getItem(UPDATE_STAGED_META_KEY)||'null');
    if(!m?.version&&!m?.tag)return null;
    return {tag:String(m.tag||m.version||''),version:String(m.version||m.tag||''),name:String(m.name||m.tag||m.version||''),body:String(m.body||'')};
  }catch(e){return null}
}
async function resumePendingUpdateAfterSettings(){
  // Aucun démarrage d’installation au resume : l’APK reste prêt jusqu’au clic Installer.
}


function openInfoSheet(){
  const t=elevatorCopy();
  const sh=openLabFloorPage('attic',`<header class="floorTopbar"><div><small>${escapeHtml(t.atticTag)}</small><h1>${tr('settingsInfo')}</h1><p>Redacted BannerLab · ${tr('versionLabel')} ${APP_VERSION} · build ${DISPLAY_BUILD_CODE}</p></div>${elevatorButtonHtml('atticLiftTop')}</header>
    <div class="field"><label>${tr('language')}</label><select id="appLanguage">${SUPPORTED_LANGS.map(code=>`<option value="${code}" ${APP_LANG===code?'selected':''}>${LANG_META[code].flag} ${LANG_META[code].name}</option>`).join('')}</select></div>
    <div class="rulelist">
      <div class="rule"><span class="dot"></span><span><b>Prime</b> · ${tr('infoPrime')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>Mission Planner</b> · ${tr('infoPlanner')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>🧪 IGOR 0.6.39</b> · ${tr('infoCompanion')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>🧪 MILO 0.5.3</b> · ${tr('infoMilo')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>🤖 RITA</b> · ${tr('infoRita')}</span></div>
      <div class="rule"><span class="dot"></span><span><b>🧮 LEON</b> · ${tr('infoLeon')}</span></div>
      <div class="rule warning"><span class="dot"></span><span>${tr('disclaimer')}</span></div>
    </div>

    <div class="tutorialHubSection">
      <div class="tutorialHubCard"><div class="tutorialHubHead"><img src="/redacted-logo-512.png" alt="Redacted"><div><strong>🎓 ${tr('tutorialHubTitle')}</strong><p>${tr('tutorialHubText')}</p></div></div><button class="primary tutorialHubOpen">${tr('tutorialOpen')}</button></div>
    </div>

    ${halloweenWindowOpen()?`<div class="halloweenSettingsSection"><div class="halloweenSettingsCard"><div><strong>🎃 ${tr('halloweenTitle')}</strong><p>${tr('halloweenText')}</p></div><label class="switchline"><input type="checkbox" class="halloweenToggle" ${halloweenEnabled()?'checked':''}> ${tr('halloweenToggle')}</label></div></div>`:''}

    <div class="redactedOverlaySection">
      <div class="redactedOverlayCard">
        <div class="redactedOverlayHead"><img src="/redacted-dino-cutout.png" alt="Redacted"><div><strong>${tr('redactedOverlayTitle')}</strong><p>${tr('redactedOverlayText')}</p></div></div>
        <label class="switchline"><input type="checkbox" class="redactedOverlayToggle" ${redactedOverlayEnabled()?'checked':''} ${Capacitor.isNativePlatform()?'':'disabled'}> ${tr('redactedOverlayToggle')}</label>
        <small class="redactedOverlayStatus">${Capacitor.isNativePlatform()?(redactedOverlayEnabled()?tr('redactedOverlayOn'):tr('redactedOverlayOff')):tr('redactedOverlayUnavailable')}</small>
        <div class="field primeHudFactionField"><label>${tr('primeHudFaction')}</label><select class="primeHudFaction" ${Capacitor.isNativePlatform()?'':'disabled'}><option value="ENL" ${redactedOverlayFaction()==='ENL'?'selected':''}>🟢 ENL · Enlightened</option><option value="RES" ${redactedOverlayFaction()==='RES'?'selected':''}>🔵 RES · Resistance</option></select><small>${tr('primeHudFactionHint')}</small></div>
        <div class="primeHudActions"><button class="secondary primeHudUsage" ${Capacitor.isNativePlatform()?'':'disabled'}>${tr('primeHudUsage')}</button></div>
      </div>
    </div>
    ${updateSettingsHtml()}

    <div class="backupSection">
      <div class="backupCard">
        <div class="backupHead"><span>💾</span><div><strong>${tr('backupTitle')}</strong><p>${tr('backupText')}</p></div></div>
        <div class="backupFolderLine"><div><b>${tr('backupFolder')}</b><small class="backupFolderStatus">${tr('backupFolderNone')}</small></div><button class="secondary chooseBackupFolder">${tr('backupFolderChoose')}</button></div>
        <label class="switchline backupAutoLine"><input type="checkbox" class="backupAutoToggle" ${backupAutoEnabled()?'checked':''} ${Capacitor.isNativePlatform()?'':'disabled'}> ${tr('backupAuto')}</label>
        <small class="backupHint">${tr('backupAutoHint')}</small>
        <div class="backupActions"><button class="primary backupNow" ${Capacitor.isNativePlatform()?'':'disabled'}>💾 ${tr('backupNow')}</button><button class="secondary backupExport">${icon('download')} ${tr('backupExport')}</button><button class="secondary backupImport">${icon('upload')} ${tr('backupImport')}</button></div>
        <small class="backupPortable">${tr('backupPortable')}</small><small class="backupLastStatus">${backupDateText(localStorage.getItem(BACKUP_LAST_KEY))}</small>
      </div>
    </div>

    <div class="creatorCommunity">
      <div class="communityCard">
        <div class="communityIcon">✈</div><div class="communityCopy"><strong>${tr('communityTitle')}</strong><p>${tr('communityText')}</p></div>
      </div>
      <div class="reportCard">
        <div><strong>🐛 ${tr('reportProblem')}</strong><p>${tr('reportProblemText')}</p></div>
        <div class="reportActions"><button class="secondary copyDiagnostic">${tr('copyDiagnostic')}</button><button class="primary reportTelegram">${tr('telegramOpen')}</button></div>
      </div>
    </div>

    <div class="sourcePrivacySection">
      <div class="sourcePrivacyCard">
        <div class="sourcePrivacyHead"><span class="sourcePrivacyIcon">⌘</span><div><strong>${tr('sourcePrivacyTitle')}</strong><p>${tr('sourcePrivacyText')}</p></div></div>
        <div class="privacyPoints">
          <p>✓ ${tr('sourcePrivacyNoTracking')}</p>
          <p>✓ ${tr('sourcePrivacyLocal')}</p>
          <p>↗ ${tr('sourcePrivacyNetwork')}</p>
          <p>🔐 ${tr('sourcePrivacySecurity')}</p>
        </div>
        <small>${tr('sourcePrivacySecrets')}</small>
        <button class="secondary infoGithub">↗ ${tr('sourcePrivacyGithub')}</button>
      </div>
    </div>

    <div class="creditSection">
      <div class="creditHeading">♥ ${tr('creditsTitle')}</div>
      <div class="creditCard bannergressCredit">
        <strong>${tr('bannergressThanks')}</strong>
        <p>${tr('bannergressThanksText')}</p>
        <p>${tr('bannergressNoLogin')}</p>
        <small>${tr('independentProject')}</small>
        <button class="secondary infoBannergress">↗ ${tr('visitBannergress')}</button>
      </div>
      <div class="creditCard">
        <strong>${tr('mapCredits')}</strong>
        <p>${tr('mapCreditsText')}</p>
      </div>
      <div class="creditFoot">${tr('rblCreditsFoot')}</div>
    </div>

    <div class="actions"><button class="secondary atticElevatorReturn">⇅ ${escapeHtml(t.backLift)}</button></div>

    <footer class="rblInfoFooter">
      <strong>${tr('footerCopyright')}</strong>
      <p>${tr('footerCommunity')}</p>
    </footer>`);
  $('.atticLiftTop',sh).onclick=returnToLabElevator;
  $('#appLanguage',sh).onchange=e=>setAppLanguage(e.target.value);
  const halloweenToggle=$('.halloweenToggle',sh);if(halloweenToggle)halloweenToggle.onchange=e=>{localStorage.setItem(HALLOWEEN_KEY,e.target.checked?'1':'0');applyHalloweenTheme()};
  $('.atticElevatorReturn',sh)?.addEventListener('click',returnToLabElevator);
  $('.tutorialHubOpen',sh).onclick=openTutorialHubSheet;
  const redactedToggle=$('.redactedOverlayToggle',sh),redactedStatus=$('.redactedOverlayStatus',sh);
  if(redactedToggle)redactedToggle.onchange=async e=>{
    if(!e.target.checked){await disableRedactedOverlay();if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayOff');toast(tr('redactedOverlayOff'));return}
    if(!Capacitor.isNativePlatform()){e.target.checked=false;if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayUnavailable');return}
    try{
      const p=await MissionOverlay.hasPermission();
      if(!p?.granted){e.target.checked=false;if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayNeedsPermission');openRedactedOverlayPermissionSheet();return}
      const ok=await enableRedactedOverlayNow();
      if(!ok){e.target.checked=false;if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayNeedsPermission');return}
      if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayOn');toast(tr('redactedOverlayOn'));
    }catch(err){e.target.checked=false;if(redactedStatus)redactedStatus.textContent=tr('redactedOverlayNeedsPermission');toast(tr('overlayFailed',{error:err?.message||err}))}
  };

  const primeHudFaction=$('.primeHudFaction',sh);
  if(primeHudFaction)primeHudFaction.onchange=async e=>{
    const faction=setRedactedOverlayFactionLocal(e.target.value);
    if(!Capacitor.isNativePlatform())return;
    try{
      const p=await MissionOverlay.hasPermission();
      if(p?.granted&&redactedOverlayEnabled())await MissionOverlay.setRedactedFaction({faction});
    }catch(err){console.warn('[Prime HUD faction]',err)}
  };

  $('.primeHudUsage',sh)?.addEventListener('click',async()=>{
    if(!Capacitor.isNativePlatform())return;
    try{const r=await MissionOverlay.requestUsageAccess();toast(r?.granted?tr('redactedOverlayReady'):tr('primeHudUsageNeeded'))}catch(err){toast(tr('overlayFailed',{error:err?.message||err}))}
  });
  bindUpdateSettings(sh);
  const refreshBackupFolder=async()=>{
    const info=await backupFolderInfo(),status=$('.backupFolderStatus',sh),btn=$('.chooseBackupFolder',sh),now=$('.backupNow',sh);
    if(status)status.textContent=info?.configured?(info.label||tr('backupFolderReady')):tr('backupFolderNone');
    if(btn){btn.textContent=info?.configured?tr('backupFolderChange'):tr('backupFolderChoose');btn.disabled=!Capacitor.isNativePlatform()}
    if(now)now.disabled=!Capacitor.isNativePlatform()||!info?.configured;
  };
  refreshBackupFolder();
  $('.chooseBackupFolder',sh).onclick=async()=>{const r=await chooseBackupFolder();if(r){markBackupChanged();await refreshBackupFolder()}};
  $('.backupAutoToggle',sh).onchange=async e=>{if(e.target.checked){const info=await backupFolderInfo();if(!info?.configured){const r=await chooseBackupFolder();if(!r){e.target.checked=false;return}await refreshBackupFolder()}}setBackupAutoEnabled(e.target.checked)};
  $('.backupNow',sh).onclick=async()=>{await writeBackupToFolder({force:true});$('.backupLastStatus',sh).textContent=backupDateText(localStorage.getItem(BACKUP_LAST_KEY))};
  $('.backupExport',sh).onclick=exportFullBackupJson;
  $('.backupImport',sh).onclick=importFullBackupJson;
  $('.infoBannergress',sh).onclick=()=>{
    const url='https://bannergress.com/';
    if(Capacitor.isNativePlatform())AppLauncher.openUrl({url}).catch(()=>{});
    else window.open(url,'_blank','noopener');
  };
  $('.infoGithub',sh).onclick=()=>{
    const url='https://github.com/zw4nn/Redacted-Banner-Lab';
    if(Capacitor.isNativePlatform())AppLauncher.openUrl({url}).catch(()=>{});
    else window.open(url,'_blank','noopener');
  };
  $('.reportTelegram',sh).onclick=launchRitaSupport;
  $('.copyDiagnostic',sh).onclick=async()=>{
    const diagnostic=rblDiagnostic();
    if(await copyText(diagnostic))toast(tr('diagnosticCopied'));else toast(tr('diagnosticCopyFailed'));
  };
}

/* =========================================================
   v1.0.7 — tutoriels guidés contextuels
========================================================= */
let tutorialSession=null;
let tutorialOverlay=null;
let tutorialResizeHandler=null;

// TEST-27 : le tutoriel suit désormais réellement l'architecture du Lab par étages.
// Les anciennes étapes contextuelles restent utilisées dans les tutoriels spécialisés,
// mais elles ouvrent toujours le bon étage avant de poser le spotlight.
Object.assign(I18N.fr,{
  tutLabIntroTitle:'Bienvenue au Lab',
  tutLabIntroText:'Le Lab est organisé par étages. L’ascenseur est le point de départ : chaque service vit dans sa propre zone, donc le tutoriel va vraiment les visiter au lieu de parler à travers un écran resté derrière.',
  tutGroundFloorTitle:'RDC · Atelier fresques',
  tutGroundFloorText:'Ici vivent les projets, les images, les calques, le texte, l’aperçu et l’export. C’est l’atelier où tu fabriques visuellement la fresque.',
  tutIgorFloorTitle:'2e · Salle d’IGOR',
  tutIgorFloorText:'IGOR regroupe les opérations terrain : missions, clés, inventaire C.O.R.E., captures uniques et paramètres de la passerelle IITC.',
  tutLeonFloorTitle:'1er · LEON',
  tutLeonFloorText:'LEON est le comptable des AP du Lab. Donne-lui ton AP et ton objectif : il cherche un plan exact avec les actions que tu autorises.',
  tutRitaFloorTitle:'3e · RITA',
  tutRitaFloorText:'RITA gère les communications et le support du Lab. C’est ici que tu peux préparer un diagnostic et contacter le bot Telegram.',
  tutAtticFloorTitle:'Combles · Réglages et sauvegardes',
  tutAtticFloorText:'Langue, mises à jour, sauvegardes, tutoriels, informations et diagnostic sont rangés ici. Oui, même un laboratoire finit par avoir un grenier administratif.',
  tutBasementFloorTitle:'Sous-sol · Zone interdite',
  tutBasementFloorText:'Le sous-sol cache les zones clandestines du Lab : Arcade du Lab et Glyph Lab. Redacted nie évidemment toute responsabilité.',
  tutFloorEnterText:'Le tutoriel ouvre maintenant cet étage pour te montrer ce qui s’y trouve.',
  tutInventoryControlsTitle:'Ajouter ou retirer du matériel',
  tutInventoryControlsText:'Touche la carte d’un objet pour ajouter +1. Utilise le bouton − pour retirer immédiatement 1. Un appui long ouvre toujours le réglage précis avec −10, −1, +1 et +10.'
});
Object.assign(I18N.en,{
  tutLabIntroTitle:'Welcome to the Lab',
  tutLabIntroText:'The Lab is organized by floors. The elevator is the starting point: every service has its own area, so the tutorial now actually visits them instead of explaining controls through another screen.',
  tutGroundFloorTitle:'Ground floor · Banner workshop',
  tutGroundFloorText:'Projects, images, layers, text, preview and export live here. This is where the banner itself is built.',
  tutIgorFloorTitle:'2nd floor · IGOR room',
  tutIgorFloorText:'IGOR groups field operations: missions, keys, C.O.R.E. inventory, unique captures and the IITC gateway settings.',
  tutLeonFloorTitle:'1st floor · LEON',
  tutLeonFloorText:'LEON is the Lab AP accountant. Give him your AP and target and he searches for an exact plan using the actions you allow.',
  tutRitaFloorTitle:'3rd floor · RITA',
  tutRitaFloorText:'RITA handles Lab communications and support. This is where you can prepare diagnostics and contact the Telegram bot.',
  tutAtticFloorTitle:'Attic · Settings and backups',
  tutAtticFloorText:'Language, updates, backups, tutorials, information and diagnostics live here. Even a laboratory eventually acquires administrative storage.',
  tutBasementFloorTitle:'Basement · Restricted area',
  tutBasementFloorText:'The basement hides the Lab’s clandestine areas: the Lab Arcade and Glyph Lab. Redacted obviously denies all responsibility.',
  tutFloorEnterText:'The tutorial now opens this floor to show what is inside.',
  tutInventoryControlsTitle:'Add or remove gear',
  tutInventoryControlsText:'Tap an item card to add +1. Use the − button to remove 1 immediately. A long press still opens precise editing with −10, −1, +1 and +10.'
});

function tutorialCatalog(){
  const redacted='/redacted-logo-512.png',igor='/igor.webp',leon='/leon.webp',rita='/rita.webp';
  const elevator=elevatorCopy();
  return {
    quick:{icon:'🚀',title:tr('tutorialQuick'),desc:tr('tutorialQuickDesc'),restoreMode:'keep',markAutoDone:true,steps:[
      {prepare:'elevator',target:'.labElevatorHost',speaker:redacted,title:tr('tutLabIntroTitle'),text:tr('tutLabIntroText')},
      {prepare:'elevator',target:'.labElevatorFloor.basement',speaker:redacted,title:tr('tutBasementFloorTitle'),text:tr('tutBasementFloorText')},
      {prepare:'elevator',target:'.labElevatorFloor.ground',speaker:redacted,title:tr('tutGroundFloorTitle'),text:tr('tutGroundFloorText')},
      {prepare:'elevator',target:'.labElevatorFloor.leon',speaker:leon,title:leonTimerText(APP_LANG,'floorTitle'),text:leonTimerText(APP_LANG,'tutFloor')},
      {prepare:'elevator',target:'.labElevatorFloor.igor',speaker:igor,title:tr('tutIgorFloorTitle'),text:tr('tutIgorFloorText')},
      {prepare:'elevator',target:'.labElevatorFloor.rita',speaker:rita,title:tr('tutRitaFloorTitle'),text:tr('tutRitaFloorText')},
      {prepare:'elevator',target:'.labElevatorFloor.attic',speaker:redacted,title:tr('tutAtticFloorTitle'),text:tr('tutAtticFloorText')}
    ]},
    banner:{icon:'🖼',title:tr('tutorialBanner'),desc:tr('tutorialBannerDesc'),steps:[
      {prepare:'elevator',target:'.labElevatorFloor.ground',speaker:redacted,title:tr('tutGroundFloorTitle'),text:tr('tutGroundFloorText')},
      {prepare:'ground',target:'#rowsSelect',speaker:redacted,title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'image',target:'.addBackground',speaker:redacted,title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',speaker:redacted,title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addImageLayer',speaker:redacted,title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.imageLayerStack',speaker:redacted,title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'ground',target:'.tool[data-tool="text"]',speaker:redacted,title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'ground',target:'.tool[data-tool="preview"]',speaker:redacted,title:tr('tutPreviewTitle'),text:tr('tutPreviewText')},
      {prepare:'ground',target:'.tool[data-tool="export"]',speaker:redacted,title:tr('tutExportTitle'),text:tr('tutExportText')}
    ]},
    layers:{icon:'🎨',title:tr('tutorialLayers'),desc:tr('tutorialLayersDesc'),steps:[
      {prepare:'elevator',target:'.labElevatorFloor.ground',speaker:redacted,title:tr('tutGroundFloorTitle'),text:tr('tutGroundFloorText')},
      {prepare:'image',target:'.addBackground',speaker:redacted,title:tr('tutBackgroundTitle'),text:tr('tutBackgroundText')},
      {prepare:'image',target:'.addImageLayer',speaker:redacted,title:tr('tutExtraLayerTitle'),text:tr('tutExtraLayerText')},
      {prepare:'image',target:'.addImageLayer',speaker:redacted,title:tr('missionLayerTutorialTitle'),text:tr('missionLayerTutorialText')},
      {prepare:'image',target:'.imageLayerStack',speaker:redacted,title:tr('tutLayersTitle'),text:tr('tutLayersText')},
      {prepare:'image',target:'.layerGroupBar',speaker:redacted,title:tr('groupSelection'),text:tr('groupHint')},
      {prepare:'text',target:'#txt',speaker:redacted,title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'text',target:'.textTypographyCard',speaker:redacted,title:tr('textTypography'),text:tr('tutTextText')},
      {prepare:'ground',target:'#openStudioEditorBtn',speaker:redacted,title:tr('tutStudioTitle'),text:tr('tutStudioText')}
    ]},
    iitc:{icon:'🗺',title:tr('tutorialIitc'),desc:tr('tutorialIitcDesc'),steps:[
      {prepare:'elevator',target:'.labElevatorFloor.igor',speaker:igor,title:tr('tutIgorFloorTitle'),text:tr('tutIgorFloorText')},
      {prepare:'igor',target:'.igorMission',speaker:igor,title:tr('tutRouteTitle'),text:tr('tutRouteText')},
      {prepare:'keys',target:'.rblKeySync',speaker:igor,title:'Key Sync',text:tr('tutIgorFloorText')},
      {prepare:'inventory',target:'.rblInvTileControls',speaker:igor,title:tr('tutInventoryControlsTitle'),text:tr('tutInventoryControlsText')},
      {prepare:'igor-settings',target:'.igorSettingsHero',speaker:igor,title:tr('tutInstallCompanionTitle'),text:tr('tutInstallCompanionText')}
    ]},
    publish:{icon:'📤',title:tr('tutorialPublish'),desc:tr('tutorialPublishDesc'),steps:[
      {prepare:'elevator',target:'.labElevatorFloor.ground',speaker:redacted,title:tr('tutGroundFloorTitle'),text:tr('tutGroundFloorText')},
      {prepare:'missions',target:'.requiredFieldCard',speaker:redacted,title:tr('tutMissionDescTitle'),text:tr('tutMissionDescText')},
      {prepare:'missions',target:'.missionlist-v2',speaker:redacted,title:tr('tutMissionsTitle'),text:tr('tutMissionsText')},
      {prepare:'publish',target:'[data-flow="publish"]',speaker:redacted,title:tr('tutPublishTitle'),text:tr('tutPublishText')}
    ]},
    backup:{icon:'💾',title:tr('tutorialBackup'),desc:tr('tutorialBackupDesc'),steps:[
      {prepare:'elevator',target:'.labElevatorFloor.attic',speaker:redacted,title:tr('tutAtticFloorTitle'),text:tr('tutAtticFloorText')},
      {prepare:'info',target:'.backupCard',speaker:redacted,title:tr('tutBackupTitle'),text:tr('tutBackupText')},
      {prepare:'projects',target:'.portableProjectIntro',speaker:redacted,title:tr('tutPortableTitle'),text:tr('tutPortableText')},
      {prepare:'info',target:'.reportCard',speaker:rita,title:tr('tutSupportTitle'),text:tr('tutSupportText')}
    ]},
    'floor-basement':{restoreMode:'keep',steps:[
      {prepare:'basement',target:'.labMenuHero',speaker:redacted,title:tr('tutBasementFloorTitle'),text:tr('tutBasementFloorText')},
      {prepare:'basement',target:'.labGlyphBasementCard',speaker:redacted,title:elevator.glyph,text:elevator.glyphSub},
      {prepare:'basement',target:'.labGameGrid',speaker:redacted,title:elevator.arcade,text:elevator.arcadeSub}
    ]},
    'floor-ground':{restoreMode:'keep',steps:[
      {prepare:'ground',target:'#projectsBtn',speaker:redacted,title:tr('tutProjectTitle'),text:tr('tutProjectText')},
      {prepare:'ground',target:'#projectName',speaker:redacted,title:tr('tutNameTitle'),text:tr('tutNameText')},
      {prepare:'ground',target:'#rowsSelect',speaker:redacted,title:tr('tutRowsTitle'),text:tr('tutRowsText')},
      {prepare:'ground',target:'.tool[data-tool="image"]',speaker:redacted,title:tr('tutImageTitle'),text:tr('tutImageText')},
      {prepare:'ground',target:'.tool[data-tool="text"]',speaker:redacted,title:tr('tutTextTitle'),text:tr('tutTextText')},
      {prepare:'ground',target:'.tool[data-tool="preview"]',speaker:redacted,title:tr('tutPreviewTitle'),text:tr('tutPreviewText')},
      {prepare:'ground',target:'.tool[data-tool="export"]',speaker:redacted,title:tr('tutExportTitle'),text:tr('tutExportText')}
    ]},
    'floor-leon-v2':{restoreMode:'keep',steps:[
      {prepare:'leon-floor',target:'.leonFloorHero',speaker:leon,title:leonTimerText(APP_LANG,'floorTitle'),text:leonTimerText(APP_LANG,'tutFloor')},
      {prepare:'leon-floor',target:'.leonDoorCalc',speaker:leon,title:leonTimerText(APP_LANG,'calcDoor'),text:leonTimerText(APP_LANG,'tutCalcDoor')},
      {prepare:'leon-floor',target:'.leonDoorTimers',speaker:leon,title:leonTimerText(APP_LANG,'timersDoor'),text:leonTimerText(APP_LANG,'tutTimerDoor')},
      {prepare:'leon-timers',target:'.leonTimersHeader',speaker:leon,title:leonTimerText(APP_LANG,'roomTitle'),text:leonTimerText(APP_LANG,'tutTimerRoom')},
      {prepare:'leon-timers',target:'.leonTimerCard.drone',speaker:leon,title:leonTimerText(APP_LANG,'droneTitle'),text:leonTimerText(APP_LANG,'tutDrone')},
      {prepare:'leon-timers',target:'.leonTimerAdd',speaker:leon,title:leonTimerText(APP_LANG,'addTimer'),text:leonTimerText(APP_LANG,'tutAdd')},
      {prepare:'leon-timers',target:'.leonTimerMeta',speaker:leon,title:leonTimerText(APP_LANG,'visibility'),text:leonTimerText(APP_LANG,'tutVisibility')},
      {prepare:'leon',target:'.leonSourceCard',speaker:leon,title:tr('leonStatsTitle'),text:tr('leonStatsTut')},
      {prepare:'leon',target:'.leonTargetCard',speaker:leon,title:tr('leonTargetTitle'),text:tr('leonTargetTut')},
      {prepare:'leon',target:'.leonActions',speaker:leon,title:tr('leonActionsTitle'),text:tr('leonActionsTut')},
      {prepare:'leon',target:'.leonCalculate',speaker:leon,title:tr('leonCalcTitle'),text:tr('leonCalcTut')},
      {prepare:'leon-floor',target:'.leonFloorHero',speaker:leon,title:leonTimerText(APP_LANG,'floorTitle'),text:leonTimerText(APP_LANG,'floorHero')}
    ]},
    'floor-igor':{restoreMode:'keep',steps:[
      {prepare:'igor',target:'.igorFloorHero',speaker:igor,title:tr('tutIgorFloorTitle'),text:tr('tutIgorFloorText')},
      {prepare:'igor',target:'.igorMission',speaker:igor,title:elevator.mission,text:elevator.missionSub},
      {prepare:'igor',target:'.igorKeys',speaker:igor,title:elevator.keys,text:elevator.keysSub},
      {prepare:'igor',target:'.igorInventory',speaker:igor,title:elevator.inventory,text:elevator.inventorySub},
      {prepare:'igor',target:'.igorUniques',speaker:igor,title:elevator.uniques,text:elevator.uniquesSub},
      {prepare:'igor',target:'.igorSettings',speaker:igor,title:elevator.igorSettings,text:elevator.igorSettingsSub}
    ]},
    'floor-rita':{restoreMode:'keep',steps:[
      {prepare:'rita',target:'.ritaFloorHero',speaker:rita,title:tr('tutRitaFloorTitle'),text:tr('tutRitaFloorText')},
      {prepare:'rita',target:'.ritaTelegram',speaker:rita,title:'Telegram',text:tr('ritaTelegramTut')},
      {prepare:'rita',target:'.ritaDiagnostic',speaker:rita,title:tr('copyDiagnostic'),text:tr('reportProblemText')}
    ]},
    'floor-attic':{restoreMode:'keep',steps:[
      {prepare:'info',target:'#appLanguage',speaker:redacted,title:tr('language'),text:tr('tutAtticFloorText')},
      {prepare:'info',target:'.tutorialHubCard',speaker:redacted,title:tr('tutorialHubTitle'),text:tr('tutorialHubText')},
      {prepare:'info',target:'.backupCard',speaker:redacted,title:tr('tutBackupTitle'),text:tr('tutBackupText')},
      {prepare:'info',target:'.reportCard',speaker:rita,title:tr('reportProblem'),text:tr('reportProblemText')},
      {prepare:'info',target:'.sourcePrivacyCard',speaker:redacted,title:tr('sourcePrivacyTitle'),text:tr('sourcePrivacyText')}
    ]}
  };
}

function openTutorialHubSheet(){
  const catalog=tutorialCatalog();
  const cards=Object.entries(catalog).filter(([id])=>!String(id).startsWith('floor-')).map(([id,t])=>{
    const seen=localStorage.getItem(TUTORIAL_SEEN_PREFIX+id)==='1';
    return `<button class="tutorialChoice" data-tutorial-id="${escapeAttr(id)}"><span class="tutorialChoiceIcon">${t.icon}</span><span><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.desc)}</small></span>${seen?`<em>✓ ${tr('tutorialSeen')}</em>`:'<i>›</i>'}</button>`;
  }).join('');
  const sh=openSheet(`<div class="sheethead"><div><h2>🎓 ${tr('tutorialHubTitle')}</h2><p>${tr('tutorialHubText')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="tutorialChoiceList">${cards}</div>`);
  $('.close',sh).onclick=openInfoSheet;
  $$('.tutorialChoice',sh).forEach(btn=>btn.onclick=()=>startTutorial(btn.dataset.tutorialId,{manual:true}));
}

function showFirstTutorialPrompt(){
  sessionStorage.setItem(TUTORIAL_PROMPT_SESSION_KEY,'1');
  const sh=openSheet(`<div class="tutorialWelcome"><img src="/redacted-logo-512.png" alt="Redacted"><div><h2>${tr('tutorialWelcomeTitle')}</h2><p>${tr('tutorialWelcomeText')}</p></div></div><div class="tutorialWelcomeActions"><button class="primary tutorialStart">${tr('tutorialStart')}</button><button class="secondary tutorialLater">${tr('tutorialLater')}</button><button class="ghost tutorialNever">${tr('tutorialNever')}</button></div>`);
  $('.tutorialStart',sh).onclick=()=>startTutorial('quick',{manual:false,markAutoDone:true,restoreMode:'keep'});
  $('.tutorialLater',sh).onclick=closeSheet;
  $('.tutorialNever',sh).onclick=()=>{localStorage.setItem(TUTORIAL_AUTO_KEY,'never');closeSheet()};
}

function maybeShowFirstTutorial(){
  if(localStorage.getItem(TUTORIAL_AUTO_KEY))return;
  if(sessionStorage.getItem(TUTORIAL_PROMPT_SESSION_KEY)==='1')return;
  setTimeout(showFirstTutorialPrompt,450);
}

function maybeStartFloorTutorial(floor){
  const base=`floor-${String(floor||'').toLowerCase()}`;const id=String(floor||'').toLowerCase()==='leon'?'floor-leon-v2':base;
  if(!floor||tutorialSession||localStorage.getItem(TUTORIAL_AUTO_KEY)==='never'||localStorage.getItem(TUTORIAL_SEEN_PREFIX+id)==='1')return;
  setTimeout(()=>{
    if(tutorialSession||localStorage.getItem(TUTORIAL_SEEN_PREFIX+id)==='1')return;
    startTutorial(id,{manual:false,markAutoDone:false,restoreMode:'keep'});
  },260);
}

async function prepareTutorialStep(step){
  const action=step?.prepare||'ground';
  const clean=()=>{closeSheet();closeLabFloor();closeLabElevator();closeLeon(false);closeLeonTimers(false);document.body.classList.remove('groundFloorActive')};
  const ground=()=>{clean();activateGroundFloor({fromTutorial:true})};
  if(action==='elevator'){clean();openLabElevator()}
  else if(action==='ground'||action==='home'){ground()}
  else if(action==='image'){ground();openImageLayersSheet()}
  else if(action==='text'){ground();openTextSheet()}
  else if(action==='route'){ground();setFlowStep('route')}
  else if(action==='missions'){ground();setFlowStep('missions')}
  else if(action==='publish'){ground();setFlowStep('publish')}
  else if(action==='igor'){clean();openIgorFloor()}
  else if(action==='keys'){clean();openRblKeysFloor()}
  else if(action==='inventory'){clean();openRblInventoryFloor()}
  else if(action==='igor-settings'){clean();await openIgorSettings()}
  else if(action==='basement'){clean();openBasementRestrictedAccess({fromTutorial:true});await new Promise(r=>setTimeout(r,4200))}
  else if(action==='rita'){clean();openRitaFloor()}
  else if(action==='leon-floor'){clean();openLeonFloor()}
  else if(action==='leon-timers'){
    if(!document.querySelector('.leonTimersBack')){clean();setLabFloor('leon');await openLeonTimers(APP_LANG)}
    else setLabFloor('leon');
  }
  else if(action==='leon'){
    if(!document.querySelector('.leonBack')){clean();setLabFloor('leon');openLeon(APP_LANG)}
    else setLabFloor('leon');
  }
  else if(action==='info'){clean();openInfoSheet()}
  else if(action==='projects'){ground();openProjectsSheet()}
  await new Promise(r=>setTimeout(r,130));
}

function startTutorial(id,{manual=false,markAutoDone=false,restoreMode=null}={}){
  const t=tutorialCatalog()[id];if(!t)return;
  closeTutorial({restore:false});
  closeSheet();
  tutorialSession={id,index:0,manual,markAutoDone:!!(markAutoDone||t.markAutoDone),restoreMode:restoreMode??t.restoreMode??'elevator',title:t.title||'Tutoriel',steps:t.steps};
  void renderTutorialStep();
}

async function renderTutorialStep(){
  if(!tutorialSession)return;
  const step=tutorialSession.steps[tutorialSession.index];if(!step)return;
  await prepareTutorialStep(step);
  if(!tutorialSession)return;
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  tutorialOverlay?.remove();
  const overlay=document.createElement('div');overlay.className='guidedTutorialOverlay';
  const tutorialSpeaker=step.speaker||(tutorialSession.id==='iitc'?'/igor.webp':'/redacted-logo-512.png');
  overlay.innerHTML=`<div class="guidedTutorialSpotlight"></div><section class="guidedTutorialBubble"><button class="guidedTutorialClose" aria-label="${escapeAttr(tr('tutorialClose'))}">×</button><div class="guidedTutorialRedacted"><img src="${tutorialSpeaker}" alt=""><div><small>${escapeHtml(tutorialSession.title)}</small><strong>${escapeHtml(step.title)}</strong></div></div><p>${escapeHtml(step.text)}</p><div class="guidedTutorialProgress"><span>${tutorialSession.index+1} / ${tutorialSession.steps.length}</span><div><i style="width:${Math.round((tutorialSession.index+1)/tutorialSession.steps.length*100)}%"></i></div></div><div class="guidedTutorialActions"><button class="secondary guidedTutorialPrev" ${tutorialSession.index===0?'disabled':''}>‹ ${tr('tutorialPrevious')}</button><button class="primary guidedTutorialNext">${tutorialSession.index===tutorialSession.steps.length-1?tr('tutorialUnderstood'):tr('tutorialNext')+' ›'}</button></div><button class="guidedTutorialNever" type="button">${tr('tutorialNever')}</button></section>`;
  document.body.appendChild(overlay);tutorialOverlay=overlay;
  $('.guidedTutorialClose',overlay).onclick=()=>closeTutorial();
  $('.guidedTutorialNever',overlay).onclick=()=>{localStorage.setItem(TUTORIAL_AUTO_KEY,'never');closeTutorial();toast(tr('tutorialNever'));};
  $('.guidedTutorialPrev',overlay).onclick=()=>{if(tutorialSession&&tutorialSession.index>0){tutorialSession.index--;void renderTutorialStep()}};
  $('.guidedTutorialNext',overlay).onclick=()=>{if(!tutorialSession)return;if(tutorialSession.index>=tutorialSession.steps.length-1){finishTutorial();return}tutorialSession.index++;void renderTutorialStep()};
  placeTutorialOverlay(step.target);
  tutorialResizeHandler=()=>placeTutorialOverlay(step.target);
  window.addEventListener('resize',tutorialResizeHandler,{passive:true});
}

function placeTutorialOverlay(selector){
  if(!tutorialOverlay)return;
  const spot=$('.guidedTutorialSpotlight',tutorialOverlay),bubble=$('.guidedTutorialBubble',tutorialOverlay);
  let target=null;try{target=selector?$(selector):null}catch{}
  if(target){try{target.scrollIntoView({behavior:'auto',block:'center',inline:'center'})}catch{target.scrollIntoView()}}
  setTimeout(()=>{
    if(!tutorialOverlay)return;
    const vw=window.innerWidth,vh=window.innerHeight,margin=10;
    if(!target||!document.body.contains(target)){
      spot.hidden=true;bubble.classList.add('centered');bubble.style.left='12px';bubble.style.right='12px';bubble.style.top='50%';bubble.style.bottom='auto';return;
    }
    spot.hidden=false;bubble.classList.remove('centered');bubble.style.right='auto';bubble.style.bottom='auto';
    const r=target.getBoundingClientRect(),pad=7;
    spot.style.left=`${Math.max(margin,r.left-pad)}px`;spot.style.top=`${Math.max(margin,r.top-pad)}px`;spot.style.width=`${Math.min(vw-margin, r.right+pad)-Math.max(margin,r.left-pad)}px`;spot.style.height=`${Math.min(vh-margin,r.bottom+pad)-Math.max(margin,r.top-pad)}px`;
    const br=bubble.getBoundingClientRect(),bw=Math.min(br.width,vw-24),bh=br.height;
    let left=Math.max(12,Math.min(vw-bw-12,r.left+(r.width-bw)/2));
    let top=r.bottom+16;
    if(top+bh>vh-12)top=r.top-bh-16;
    if(top<12){top=Math.max(12,(vh-bh)/2);left=r.right+bw+20<vw?r.right+12:Math.max(12,r.left-bw-12)}
    bubble.style.left=`${Math.round(left)}px`;bubble.style.top=`${Math.round(Math.max(12,Math.min(vh-bh-12,top)))}px`;
  },110);
}

function closeTutorial({restore=true}={}){
  if(tutorialResizeHandler){window.removeEventListener('resize',tutorialResizeHandler);tutorialResizeHandler=null}
  const session=tutorialSession;
  tutorialOverlay?.remove();tutorialOverlay=null;
  if(restore&&session){
    const mode=session.restoreMode||'elevator';
    if(mode==='elevator'){closeLeon(false);document.body.classList.remove('groundFloorActive');closeSheet();closeLabFloor();closeLabElevator();openLabElevator()}
  }
  tutorialSession=null;
}

function finishTutorial(){
  if(!tutorialSession)return;
  const id=tutorialSession.id,markAutoDone=!!tutorialSession.markAutoDone;
  localStorage.setItem(TUTORIAL_SEEN_PREFIX+id,'1');
  if(markAutoDone)localStorage.setItem(TUTORIAL_AUTO_KEY,'done');
  closeTutorial();toast(tr('tutorialDone'));
}


function freshEditor(name=tr('defaultProject')){
  state.projectLanguage=APP_LANG;state.name=name;state.rows=3;state.showGrid=true;state.showCircles=true;state.circleOpacity=0.44;state.showNumbers=true;state.editMode='fresco';state.selectedMissionKey=null;state.missionOverrides={};state.bg={image:null,blob:null,x:WORLD_W/2,y:STEP*1.5,scale:1,rotation:0,opacity:1,visible:true,name:tr('backgroundLayer')};state.imageLayers=[];state.texts=[];state.customFonts=[];state.active='background';layerGroupSelection.clear();state.planner={description:'',titleFormat:'$T $0N / $M',sequential:true,hiddenLocation:false,portalsPerMission:6,autoAdvance:true,reuseLastPortal:true,iitcTutorialSeen:false,currentMission:0,missions:[]};ensurePlannerMissions();
}
function refreshProjectUi(){
  const pn=$('#projectName');if(pn)pn.value=state.name;$('#rowsSelect').value=String(state.rows);const mc=$('#missionCount');if(mc)mc.textContent=state.rows*6;const wh=$('#worldH');if(wh)wh.textContent=worldH();syncChips();const op=$('#circleOpacity');if(op)op.value=String(Math.round((state.circleOpacity??0.44)*100));const opVal=$('#circleOpacityVal');if(opVal)opVal.textContent=`${Math.round((state.circleOpacity??0.44)*100)}%`;$$('[data-editmode]').forEach(b=>b.classList.toggle('on',b.dataset.editmode===state.editMode));updateMissionUi();resizeCanvas();
}
function newProjectId(){return `p_${Date.now().toString(36)}_${uid()}`}
async function createNewProject(name=tr('defaultNewProject')){
  setFlowStep('fresco',{open:false});
  await saveProject();state.projectId=newProjectId();freshEditor(name);await loadDefaultBackground();localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();await saveProject();closeSheet();toast(tr('newProjectCreated'));
}
async function openProjectsSheet(){
  await saveProject();
  const projects=await getAllProjects();
  const locale=appLocale();
  const cards=projects.map(rec=>{
    const d=rec.data||{},current=rec.id===state.projectId,updated=d.updatedAt?new Date(d.updatedAt).toLocaleString(locale,{dateStyle:'short',timeStyle:'short'}):'';
    return `<div class="projectcard ${current?'current':''}" data-project="${escapeAttr(rec.id)}"><div class="projectcardmain"><strong>${escapeHtml(d.name||tr('unnamed'))}</strong><span>${(d.rows||3)*6} ${tr('missions').toLowerCase()}${updated?' · '+escapeHtml(updated):''}</span></div>${current?`<span class="currentbadge">${tr('opened')}</span>`:''}<div class="projectactions"><button class="secondary openproject" ${current?'disabled':''}>${tr('open')}</button><button class="secondary exportproject">${icon('download')} ${tr('exportProject')}</button><button class="secondary shareproject">${icon('upload')} ${tr('shareProject')}</button><button class="secondary renameproject">${icon('edit')} ${tr('rename')}</button><button class="secondary duplicateproject">${icon('copy')} ${tr('copy')}</button><button class="danger deleteproject">${icon('trash')}</button></div></div>`;
  }).join('')||`<div class="small">${tr('noSavedProject')}</div>`;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('myProjects')}</h2><p>${tr('projectsSaved',{n:projects.length})}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="portableProjectIntro"><b>📦 ${tr('portableProject')}</b><span>${tr('portableProjectDesc')}</span></div><div class="projectlist">${cards}</div><div class="actions projectMainActions"><button class="secondary" id="importProject">${icon('upload')} ${tr('importProject')}</button><button class="primary" id="createProject">${icon('plus')} ${tr('newProject')}</button></div><p class="small">${tr('projectImportHint')}</p>`);
  $('.close',sh).onclick=closeSheet;$('#createProject',sh).onclick=()=>createNewProject();$('#importProject',sh).onclick=importPortableProject;
  $$('.projectcard',sh).forEach(card=>{
    const id=card.dataset.project;
    $('.openproject',card).onclick=()=>switchProject(id);
    $('.exportproject',card).onclick=()=>deliverPortableProject(id,{share:false});
    $('.shareproject',card).onclick=()=>deliverPortableProject(id,{share:true});
    $('.renameproject',card).onclick=()=>renameProject(id);
    $('.duplicateproject',card).onclick=()=>duplicateProject(id);
    $('.deleteproject',card).onclick=()=>confirmDeleteProject(id);
  });
}

async function switchProject(id){setFlowStep('fresco',{open:false});await saveProject();await loadProject(id);resetHistory();closeSheet();toast(tr('projectOpened',{name:state.name}))}
async function renameProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('renameProject')}</h2><p>${tr('renameHint')}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="field"><label>${tr('projectName')}</label><input id="renameInput" maxlength="60" value="${escapeAttr(rec.data?.name||tr('defaultProject'))}"></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="primary save">${tr('save')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;
  $('.save',sh).onclick=async()=>{const name=$('#renameInput',sh).value.trim()||tr('defaultProject');const db=await openDB();let tx=db.transaction('project','readonly');const fresh=await request(tx.objectStore('project').get(id));if(!fresh)return;fresh.data.name=name;fresh.data.updatedAt=new Date().toISOString();markBackupChanged();tx=db.transaction('project','readwrite');tx.objectStore('project').put(fresh);await txDone(tx);if(id===state.projectId){state.name=name;const pn=$('#projectName');if(pn)pn.value=name}closeSheet();toast(tr('projectRenamed'))};
}

async function confirmDeleteProject(id){
  const projects=await getAllProjects(),rec=projects.find(p=>p.id===id);if(!rec)return;
  const sh=openSheet(`<div class="sheethead"><div><h2>${tr('deleteProject')}</h2><p>${escapeHtml(rec.data?.name||tr('unnamed'))}</p></div><div class="grow"></div><button class="iconbtn close">${icon('close')}</button></div><div class="rule warning"><span class="dot"></span><span>${tr('deleteWarning')}</span></div><div class="actions"><button class="secondary cancel">${tr('cancel')}</button><button class="danger confirmdelete">${icon('trash')} ${tr('delete')}</button></div>`);
  $('.close',sh).onclick=closeSheet;$('.cancel',sh).onclick=closeSheet;$('.confirmdelete',sh).onclick=()=>deleteProject(id);
}

async function duplicateProject(id){
  const db=await openDB(),tx=db.transaction('project','readonly'),rec=await request(tx.objectStore('project').get(id));if(!rec)return;
  const newId=newProjectId(),data=JSON.parse(JSON.stringify(rec.data||{}));data.name=`${data.name||tr('fresco')} ${tr('copySuffix')}`;if(data.planner&&typeof data.planner==='object')data.planner.iitcSessionId=newIitcSessionId();data.updatedAt=new Date().toISOString();
  const tx2=db.transaction('project','readwrite');tx2.objectStore('project').put({id:newId,data,blob:rec.blob,layerBlobs:rec.layerBlobs||[]});await txDone(tx2);markBackupChanged();await loadProject(newId);closeSheet();toast(tr('copyCreated'));
}
async function deleteProject(id){
  const projects=await getAllProjects();if(projects.length<=1){await createNewProject();const db=await openDB();const tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);return}
  const db=await openDB(),tx=db.transaction('project','readwrite');tx.objectStore('project').delete(id);await txDone(tx);markBackupChanged();
  if(id===state.projectId){const remain=(await getAllProjects()).filter(p=>p.id!==id);await loadProject(remain[0]?.id)}
  closeSheet();toast(tr('projectDeleted'));
}
function escapeHtml(s=''){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;')}
function serializeState(){ensurePlannerMissions();return {version:APP_VERSION,projectLanguage:projectLanguage(),name:state.name,rows:state.rows,showGrid:state.showGrid,showCircles:state.showCircles,circleOpacity:clamp(state.circleOpacity??0.44,0,1),showNumbers:state.showNumbers,editMode:state.editMode,selectedMissionKey:state.selectedMissionKey,missionOverrides:state.missionOverrides,bg:{x:state.bg.x,y:state.bg.y,scale:state.bg.scale,rotation:state.bg.rotation,opacity:state.bg.opacity??1,visible:state.bg.visible!==false,name:state.bg.name||tr('backgroundLayer')},imageLayers:state.imageLayers.map(l=>({id:l.id,name:l.name||'',x:l.x,y:l.y,scale:l.scale,rotation:l.rotation||0,opacity:l.opacity??1,visible:l.visible!==false,groupId:l.groupId||null,groupNumber:l.groupNumber||null,scope:l.scope==='mission'?'mission':'global',missionNumber:l.scope==='mission'?(parseInt(l.missionNumber)||1):null,fitMode:l.fitMode==='contain'?'contain':'cover'})),texts:state.texts,customFonts:state.customFonts,active:state.active,planner:state.planner,updatedAt:new Date().toISOString()}}
function scheduleSave(){markBackupChanged();clearTimeout(saveTimer);saveTimer=setTimeout(saveProject,350)}
async function saveProject({markBackup=true}={}){try{const db=await openDB();const tx=db.transaction('project','readwrite');const layerBlobs=state.imageLayers.filter(l=>l.blob).map(l=>({id:l.id,blob:l.blob}));tx.objectStore('project').put({id:state.projectId||'current',data:serializeState(),blob:state.bg.blob,layerBlobs});await txDone(tx);localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId||'current');if(markBackup)markBackupChanged()}catch(e){console.warn('save',e)}}
async function loadProject(id=null){
  try{
    const db=await openDB();let target=id||localStorage.getItem('redactedBannerLabCurrentProjectId')||'current';let tx=db.transaction('project','readonly');let rec=await request(tx.objectStore('project').get(target));
    if(!rec){const all=await getAllProjects();rec=all[0];target=rec?.id}
    if(!rec){state.projectId='current';freshEditor();await loadDefaultBackground();refreshProjectUi();resetHistory();await saveProject();return}
    freshEditor();state.projectId=target;state.projectLanguage=SUPPORTED_LANGS.includes(rec.data.projectLanguage)?rec.data.projectLanguage:(SUPPORTED_LANGS.includes(rec.data.language)?rec.data.language:APP_LANG);
    Object.assign(state,{name:rec.data.name||state.name,rows:rec.data.rows||3,showGrid:rec.data.showGrid!==false,showCircles:rec.data.showCircles!==false,circleOpacity:Number.isFinite(+rec.data.circleOpacity)?clamp(+rec.data.circleOpacity,0,1):0.44,showNumbers:rec.data.showNumbers!==false,editMode:rec.data.editMode==='mission'?'mission':'fresco',selectedMissionKey:rec.data.selectedMissionKey||null,missionOverrides:rec.data.missionOverrides||{},texts:rec.data.texts||[],customFonts:rec.data.customFonts||[]});await registerProjectFonts();normalizeAllTextStyles();
    if(rec.data.planner&&typeof rec.data.planner==='object')state.planner=normalizePlanner(rec.data.planner);else state.planner=normalizePlanner({description:'',missions:[]});ensurePlannerMissions();
    Object.assign(state.bg,rec.data.bg||{});state.bg.visible=rec.data.bg?.visible!==false;state.bg.opacity=Number.isFinite(+rec.data.bg?.opacity)?+rec.data.bg.opacity:1;state.bg.name=rec.data.bg?.name||tr('backgroundLayer');if(rec.blob){state.bg.blob=rec.blob;state.bg.image=await blobToImage(rec.blob)}
    const media=new Map((rec.layerBlobs||[]).map(x=>[x.id,x.blob]));state.imageLayers=(rec.data.imageLayers||[]).map(l=>normalizeImageLayerScope({...l,image:null,blob:media.get(l.id)||null,visible:l.visible!==false,opacity:Number.isFinite(+l.opacity)?+l.opacity:1,groupId:l.groupId||null}));
    await Promise.all(state.imageLayers.map(async l=>{if(l.blob)try{l.image=await blobToImage(l.blob)}catch(e){console.warn('layer image',l.id,e)}}));normalizeLayerGroups();
    const requestedActive=rec.data.active||'background';state.active=requestedActive.startsWith('image:')&&state.imageLayers.some(l=>'image:'+l.id===requestedActive)||requestedActive.startsWith('text:')&&state.texts.some(t=>'text:'+t.id===requestedActive)||requestedActive==='background'?requestedActive:'background';
    localStorage.setItem('redactedBannerLabCurrentProjectId',state.projectId);refreshProjectUi();resetHistory();
  }catch(e){console.warn('load',e)}
}
async function getAllProjects(){try{const db=await openDB();const tx=db.transaction('project','readonly'),all=await request(tx.objectStore('project').getAll());return (all||[]).sort((a,b)=>String(b.data?.updatedAt||'').localeCompare(String(a.data?.updatedAt||'')))}catch(e){console.warn('projects',e);return[]}}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('redacted-bannerlab',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function migrateLegacyStorage(){
  if(localStorage.getItem('redactedBannerLabMigrationDone')==='1')return;
  // Identifiants de stockage utilisés par les versions antérieures, encodés pour ne plus
  // conserver l'ancien nom dans l'interface ou les ressources de l'application.
  const legacyDb=atob('YmFubmVyZm9yZ2U=');
  const legacyKey=atob('YmFubmVyZm9yZ2VDdXJyZW50UHJvamVjdElk');
  try{
    const oldId=localStorage.getItem(legacyKey);
    const oldDb=await new Promise((resolve,reject)=>{let created=false;const r=indexedDB.open(legacyDb,1);r.onupgradeneeded=()=>{created=true;if(!r.result.objectStoreNames.contains('project'))r.result.createObjectStore('project',{keyPath:'id'})};r.onsuccess=()=>resolve({db:r.result,created});r.onerror=()=>reject(r.error)});
    if(!oldDb.created&&oldDb.db.objectStoreNames.contains('project')){
      const tx=oldDb.db.transaction('project','readonly');
      const rows=await request(tx.objectStore('project').getAll());
      if(rows?.length){
        const db=await openDB();const ntx=db.transaction('project','readwrite');const store=ntx.objectStore('project');
        rows.forEach(row=>store.put(row));await txDone(ntx);
      }
    }
    oldDb.db.close();
    if(oldId)localStorage.setItem('redactedBannerLabCurrentProjectId',oldId);
  }catch(e){console.warn('migration',e)}
  localStorage.setItem('redactedBannerLabMigrationDone','1');
}
function request(r){return new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}

function syncChips(){$$('[data-toggle]').forEach(btn=>{const k=btn.dataset.toggle;btn.classList.toggle('on',k==='circles'?state.showCircles:k==='grid'?state.showGrid:state.showNumbers)})}
function toast(msg){clearTimeout(toastTimer);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);toastTimer=setTimeout(()=>t.remove(),2600)}

function handleAndroidBackButton({canGoBack=false}={}){
  // L'ascenseur est désormais la racine absolue de RBL.
  if(document.querySelector('.labElevatorRoot')){App.minimizeApp().catch(()=>App.exitApp().catch(()=>{}));return true}
  if(document.querySelector('.labArcadeRoot'))return handleLabArcadeBack()
  if(document.querySelector('.leonBack')){closeLeon();return true}
  if(document.querySelector('.leonTimersBack')){closeLeonTimers();return true}
  const shotClose=document.querySelector('.chromeShotViewer .chromeShotViewerClose');
  if(shotClose){shotClose.click();return true}
  if(tutorialOverlay){closeTutorial();return true}
  if(currentSheet){closeSheet();return true}
  if(labFloorRoot){if(String(labCurrentFloor).startsWith('igor-'))openIgorFloor();else returnToLabElevator();return true}
  const previewClose=document.querySelector('.previewFullBack .previewFullClose');
  if(previewClose){previewClose.click();return true}
  if(studioEditorRoot){
    const openDrawer=document.querySelector('.studioEditorBack .studioDrawer.open');
    if(openDrawer){openDrawer.classList.remove('open');return true}
    closeStudioEditor();return true
  }
  if(missionEditorBack){closeMissionEditor();return true}
  if(labCurrentFloor==='ground'){returnToLabElevator();return true}
  if(canGoBack && window.history.length>1){window.history.back();return true}
  // À la racine, comportement Android attendu : on remet RBL en arrière-plan.
  App.minimizeApp().catch(()=>App.exitApp().catch(()=>{}));
  return true;
}

let iitcSyncInboxBusy=false;
async function consumeIitcSyncInbox(){
  if(!Capacitor.isNativePlatform()||iitcSyncInboxBusy)return false;
  iitcSyncInboxBusy=true;
  try{
    const batch=await IitcSyncInbox.consume();
    const urls=Array.isArray(batch?.urls)?batch.urls:[];
    for(const url of urls)await handleBridgeUrl(url);
    return urls.length>0;
  }catch(e){console.warn('[RBL IITC native inbox]',e);return false}
  finally{iitcSyncInboxBusy=false}
}

if(Capacitor.isNativePlatform()){
  App.addListener('backButton',handleAndroidBackButton).catch?.(()=>{});
  App.addListener('appUrlOpen',event=>{if(event?.url)handleBridgeUrl(event.url);setTimeout(consumeIitcSyncInbox,60)}).catch?.(()=>{});
  App.addListener('appStateChange',({isActive})=>{if(isActive){autoBackupOnForeground();resumePendingPlayOverlay();ensureRedactedOverlayRunning();setTimeout(consumeIitcSyncInbox,80)}else autoBackupOnBackground('appStateChange')}).catch?.(()=>{});
  // `pause` est plus direct sur plusieurs versions Android que le seul
  // appStateChange. Les gardes backupInProgress/révision rendent les doublons sûrs.
  App.addListener('pause',()=>autoBackupOnBackground('pause')).catch?.(()=>{});
  App.addListener('resume',()=>{autoBackupOnForeground();ensureRedactedOverlayRunning();setTimeout(consumeIitcSyncInbox,50);setTimeout(()=>{if(labCurrentFloor!=='ground'&&!document.querySelector('.labElevatorRoot,.labFloorRoot,.labArcadeRoot,.leonBack,.leonTimersBack,.sheetback'))openLabElevator()},120)}).catch?.(()=>{});
  App.getLaunchUrl().then(async r=>{if(r?.url)await handleBridgeUrl(r.url);setTimeout(consumeIitcSyncInbox,80)}).catch(()=>{setTimeout(consumeIitcSyncInbox,120)});
}
document.addEventListener('visibilitychange',()=>{
  if(document.hidden)autoBackupOnBackground('visibilitychange');
  else{
    autoBackupOnForeground();
  }
});
window.addEventListener('pagehide',()=>autoBackupOnBackground('pagehide'));
window.addEventListener('rbl:floor-exit',e=>{const floor=e?.detail?.floor;if((floor==='leon'||floor==='leon-timers')&&!document.querySelector('.labElevatorRoot'))openLeonFloor();else if(floor==='basement'&&!document.querySelector('.labElevatorRoot'))openLabElevator()});
window.addEventListener('rbl:elevator-request',()=>returnToLabElevator());
window.addEventListener('resize',render);
window.addEventListener('keydown',e=>{
  const k=(e.key||'').toLowerCase(),ctrl=e.ctrlKey||e.metaKey;if(!ctrl)return;
  const target=e.target,tag=(target?.tagName||'').toUpperCase();
  const editing=['INPUT','TEXTAREA','SELECT'].includes(tag)||target?.isContentEditable;
  if(editing)return; // laisse l'annulation native fonctionner dans les champs texte
  if(k==='z'&&!e.shiftKey){e.preventDefault();undoAction();return}
  if(k==='y'||(k==='z'&&e.shiftKey)){e.preventDefault();redoAction();return}
});
if(Capacitor.isNativePlatform()){
  // Les anciennes APK ont pu enregistrer un Service Worker avant que nous le désactivions
  // sur Android. On le supprime sans toucher a IndexedDB/localStorage (donc sans perdre les projets).
  window.addEventListener('load',async()=>{
    try{
      if('serviceWorker' in navigator){
        const regs=await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map(r=>r.unregister()));
      }
      if('caches' in window){
        const keys=await caches.keys();
        await Promise.all(keys.filter(k=>k.startsWith('redacted-bannerlab-')).map(k=>caches.delete(k)));
      }
    }catch(e){console.warn('[RBL native cache cleanup]',e)}
  });
}else if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
}
openLabElevator({startup:true});resizeCanvas();migrateLegacyStorage().then(()=>loadProject()).then(()=>{maybeShowFirstTutorial();setTimeout(maybeAutoCheckRblUpdate,3200)});
