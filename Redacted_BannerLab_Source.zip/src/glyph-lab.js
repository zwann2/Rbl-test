import './glyph-lab.css';

/*
 * Glyph geometry / dictionary values adapted from gm9/ingress-glyph-tools
 * Copyright (c) 2014 gm9, MIT License.
 * Original project: https://github.com/gm9/ingress-glyph-tools
 * Redacted BannerLab UI/game logic below is original integration code.
 */

const RT3 = Math.sqrt(3);
const NODE_POS = [
  [0,-1],[RT3/2,-1/2],[RT3/2,1/2],[0,1],[-RT3/2,1/2],[-RT3/2,-1/2],
  [RT3/4,-1/4],[RT3/4,1/4],[-RT3/4,1/4],[-RT3/4,-1/4],[0,0]
];

const RAW_GLYPHS = [
  ['89',['1']],['696a787a',['3']],['1634486a8a',['Abandon']],['587a8a',['Adapt']],['0949',['Advance']],
  ['1216276a7a',['After']],['49676a898a',['Again','Repeat']],['010512233445',['All']],['67697a',['Answer']],
  ['06092649',['Attack','War']],['05061617',['Avoid']],['0a277a',['Barrier','Obstacle']],['4548598a9a',['Before']],
  ['083738',['Begin']],['3738676989',['Being','Human']],['696a9a',['Body','Shell']],['16596a9a',['Breathe','Live']],
  ['1734487a8a',['Capture']],['373a8a',['Change','Modify']],['01051638456a8a',['Chaos','Disorder']],['0a3a',['Clear']],
  ['01050a1223343a45',['Clear All']],['698a9a',['Complex']],['2649677889',['Conflict']],['27597889',['Consequence']],
  ['011223386a899a',['Contemplate']],['497889',['Courage']],['16486a8a',['Create','Creation']],
  ['1216274548597a9a',['Creativity','Idea','Thought']],['093a9a',['Danger']],['06386a8a',['Data','Signal']],
  ['17373858',['Defend']],['38676a789a',['Destiny']],['1223',['Destination']],['27597a9a',['Destroy','Destruction']],
  ['488a9a',['Deteriorate','Erode']],['386a8a',['Easy']],['27487a8a',['Die','Death']],['16677a8a',['Difficult']],
  ['122334',['Discover']],['0545',['Distance','Outside']],['010a17373a',['End','Close']],['01091223696a9a',['Enlightened','Enlightenment']],
  ['676989',['Equal']],['01166989',['Escape']],['0a899a',['Evolution','Progress','Success']],['0a676a',['Failure']],
  ['176769',['Fear']],['1517373858',['Field']],['061216',['Follow']],['48',['Forget']],['162767',['Future']],['58',['Gain']],
  ['1659677889',['Civilization','Structure']],['4989',['Grow']],['0609276a7a9a',['Harm']],['060937386a7a8a9a',['Harmony','Peace']],
  ['387a8a',['Have']],['59788a9a',['Help']],['16176978',['Hide']],['363969',['I','Me']],['27',['Ignore']],
  ['6a898a9a',['Imperfect']],['166a7a',['Improve']],['3a898a9a',['Impure']],['16486a899a',['Intelligence']],
  ['0a3a4548598a9a',['Interrupt']],['163445596a9a',['Journey']],['3a676a7a898a9a',['Key']],['36396a9a',['Knowledge']],
  ['7889',['L']],['05384548',['Lead']],['0105162748596789',['Legacy']],['6a9a',['Less']],['0116496a9a',['Liberate']],
  ['676a7a899a',['Lie']],['15',['Link']],['16496a898a',['Live Again','Reincarnate']],['17',['Lose']],
  ['17497a9a',['Message','Notification']],['383a899a',['Mind']],['7a8a',['More']],['0609596989',['Mystery']],
  ['677a899a',['N']],['06090a3a6a9a',["N'Zeer"]],['2748676989',['Nature']],['1516242748596a7a8a9a',['Nemesis']],
  ['2767',['New']],['6769',['Not','Inside']],['343a488a',['Nourish']],['5989',['Old']],['373878',['Open','Accept']],
  ['010512233437384578',['Open All']],['0609242649696a9a',['Osiris']],['1216274548596978',['Portal']],['485989',['Past']],
  ['0a488a',['Path']],['0a232734487a8a',['Balance','Perfection']],['060927486a7a8a9a',['Perspective']],
  ['0a12277a',['Potential']],['3738676a78899a',['Presence']],['677889',['Present','Now']],['0a676a7a',['Pure']],
  ['060959',['Pursue']],['066989',['Question']],['27697a9a',['React']],['1216586a8a',['Rebel']],['050a599a',['Recharge','Repair']],
  ['090a383a69',['Resistance','Struggle']],['2327597a9a',['Restraint']],['0626',['Retreat']],['264969',['Safety']],
  ['177a8a',['Save']],['09',['See']],['696a7889',['Search']],['2334',['Self','Individual']],['2759676a898a',['Separate']],
  ['060927486789',['Shapers','Collective']],['27344878',['Share']],['060937386789',['Shield']],['78',['Simple']],
  ['373a676a',['Soul']],['274878',['Stability','Stay']],['0a16273a48596a7a8a9a',['Star']],['67697889',['Strong']],
  ['16276a7a898a9a',['Technology']],['0878',['Them']],['48696a8a9a',['Together']],['676a7a898a9a',['Truth']],
  ['010517233445696a7889',['Unbounded']],['177a',['Use']],['06093639',['Victory']],['373848',['Want']],['3669',['We','Us']],
  ['596769',['Weak']],['17587a8a',['Worth']],['67697a898a',['XM']],['070878',['You','Your','Other']]
];

const GLYPHS = RAW_GLYPHS.map(([code,names])=>({code,names,key:names[0].toLowerCase().replaceAll(' ','_')}));
const BY_WORD = new Map();
for(const g of GLYPHS) for(const name of g.names) BY_WORD.set(name.toLowerCase(), g);
const word = s => BY_WORD.get(String(s).toLowerCase());

const COMMON_SINGLE = ['portal','link','field','capture','hack','xm','human','shapers','truth','future','past','more','less','create','destroy','attack','defend','recharge','key','mind','soul','journey','resistance','enlightenment']
  .map(word).filter(Boolean);
const PAIRS = [
  ['less','more'],['attack','defend'],['create','destroy'],['future','past'],['gain','lose'],['advance','retreat'],
  ['pure','impure'],['courage','fear'],['new','old'],['capture','liberate'],['civilization','nature'],['improve','deteriorate']
].map(a=>a.map(word).filter(Boolean)).filter(a=>a.length===2);
const SEQ3 = [
  ['advance','human','enlightenment'],['advance','human','resistance'],['attack','capture','link'],['attack','shapers','portal'],
  ['capture','shapers','portal'],['change','human','future'],['civilization','attack','chaos'],['complex','journey','future'],
  ['contemplate','journey','distance'],['create','new','future'],['discover','pure','truth'],['escape','shapers','harm'],
  ['follow','pure','journey'],['journey','harmony','path'],['mind','equal','truth'],['open','human','weak'],
  ['past','equal','future'],['potential','truth','harmony'],['question','human','truth'],['search','xm','portal']
];
const SEQ4 = [
  ['attack','not','worth','consequence'],['clear','mind','open','mind'],['discover','balance','safety','all'],['help','gain','create','pursue'],
  ['human','past','present','future'],['less','mind','more','soul'],['less','soul','more','mind'],['more','data','gain','portal'],
  ['portal','change','truth','data'],['question','truth','gain','future'],['shapers','mind','complex','harmony'],['together','discover','harmony','equal'],
  ['truth','idea','discover','xm'],['defend','message','answer','idea'],['nourish','portal','avoid','weak'],['recharge','soul','less','human']
];
const SEQ5 = [
  ['want','truth','pursue','difficult','path'],['strong','together','attack','together','chaos'],['strong','together','attack','together','destiny'],
  ['react','rebel','question','shapers','lie'],['mind','body','soul','pure','human'],['shapers','lead','human','complex','journey'],
  ['portal','attack','danger','pursue','safety'],['create','separate','path','end','journey'],['help','human','civilization','pursue','destiny'],
  ['human','not','together','civilization','deteriorate'],['search','destiny','create','pure','future'],['stability','strong','together','defend','resistance']
];

const UI = {
  fr:{title:'GLYPH LAB',sub:'Annexe expérimentale du sous-sol',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Dictionnaire',free:'Dessin libre',
    intro:'Deux façons de s’entraîner : Arcade pour jouer contre le chrono, Simple pour travailler à ton rythme.',
    speed:'Vitesse démo',slow:'Lente',normal:'Scanner',fast:'Rapide',start:'Commencer',restart:'Recommencer',nextSeq:'Séquence suivante',replay:'Revoir',watch:'OBSERVE',yourTurn:'À TOI',
    glyph:'Glyph',correct:'Correct',wrong:'Raté · nouvelle séquence.',complete:'Séquence validée',search:'Chercher un glyph…',draw:'Trace un glyph sur la matrice.',
    unknown:'Glyph non identifié',clear:'Effacer',source:'Outil non officiel · entraînement local · données de glyphs communautaires',
    noTimer:'SANS CHRONO',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Tracer en plein écran',closePad:'Fermer',release:'Relâche pour valider',drawAgain:'Trace le glyph suivant',nodes:'nœuds',demoHere:'Observe le glyph ici',
    arcadeIntro:'30 secondes au départ. La difficulté augmente par paliers, avec plusieurs séries à chaque longueur.',vibration:'Vibrations',vibrationOn:'activées',vibrationOff:'désactivées',
    simpleIntro:'Choisis une longueur de 1 à 5 glyphs. Aucun chrono. Quand tu valides, passe à la séquence suivante quand tu veux.',
    length:'Longueur',time:'TEMPS',score:'GLYPHS',record:'RECORD',round:'SÉRIE',bonus:'Bonus temps',penalty:'Erreur : -3 s',timeUp:'Temps écoulé',ready:'Prêt ?',autoNext:'Séquence suivante…',getReady:'Prépare-toi'},
  en:{title:'GLYPH LAB',sub:'Experimental basement annex',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Dictionary',free:'Free draw',
    intro:'Two ways to train: Arcade against the clock, Simple at your own pace.',
    speed:'Demo speed',slow:'Slow',normal:'Scanner',fast:'Fast',start:'Start',restart:'Restart',nextSeq:'Next sequence',replay:'Replay',watch:'WATCH',yourTurn:'YOUR TURN',
    glyph:'Glyph',correct:'Correct',wrong:'Missed · new sequence.',complete:'Sequence complete',search:'Search a glyph…',draw:'Trace a glyph on the matrix.',
    unknown:'Unknown glyph',clear:'Clear',source:'Unofficial tool · local training · community glyph data',
    noTimer:'NO TIMER',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Draw fullscreen',closePad:'Close',release:'Release to validate',drawAgain:'Draw the next glyph',nodes:'nodes',demoHere:'Watch the glyph here',
    arcadeIntro:'Start with 30 seconds. Difficulty rises in stages, with several rounds at each sequence length.',vibration:'Vibration',vibrationOn:'on',vibrationOff:'off',
    simpleIntro:'Choose a sequence length from 1 to 5 glyphs. No timer. After success, move on whenever you want.',
    length:'Length',time:'TIME',score:'GLYPHS',record:'RECORD',round:'ROUND',bonus:'Time bonus',penalty:'Mistake: -3 s',timeUp:'Time up',ready:'Ready?',autoNext:'Next sequence…',getReady:'Get ready'}
 };
Object.assign(UI,{
es:{title:'GLYPH LAB',sub:'Anexo experimental del sótano',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simple',dictionary:'Diccionario',free:'Dibujo libre',intro:'Dos formas de entrenar: Arcade contra el reloj o Simple a tu ritmo.',speed:'Velocidad de demo',slow:'Lenta',normal:'Scanner',fast:'Rápida',start:'Empezar',restart:'Reiniciar',nextSeq:'Secuencia siguiente',replay:'Repetir',watch:'OBSERVA',yourTurn:'TU TURNO',glyph:'Glyph',correct:'Correcto',wrong:'Fallado · nueva secuencia.',complete:'Secuencia validada',search:'Buscar un glyph…',draw:'Traza un glyph en la matriz.',unknown:'Glyph no identificado',clear:'Borrar',source:'Herramienta no oficial · entrenamiento local · datos comunitarios de glyphs',noTimer:'SIN CRONO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Dibujar a pantalla completa',closePad:'Cerrar',release:'Suelta para validar',drawAgain:'Traza el siguiente glyph',nodes:'nodos',demoHere:'Observa aquí el glyph',arcadeIntro:'Empiezas con 30 segundos. Cada secuencia completada añade tiempo. Las secuencias crecen progresivamente de 1 a 5 glyphs.',simpleIntro:'Elige una longitud de 1 a 5 glyphs. Sin cronómetro. Tras acertar, pasa a la siguiente cuando quieras.',length:'Longitud',time:'TIEMPO',score:'GLYPHS',record:'RÉCORD',round:'SERIE',bonus:'Bonus de tiempo',penalty:'Error: -3 s',timeUp:'Tiempo agotado',ready:'¿Listo?',autoNext:'Secuencia siguiente…',getReady:'Prepárate'},
pt:{title:'GLYPH LAB',sub:'Anexo experimental da cave',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simples',dictionary:'Dicionário',free:'Desenho livre',intro:'Duas formas de treinar: Arcade contra o relógio ou Simples ao teu ritmo.',speed:'Velocidade da demo',slow:'Lenta',normal:'Scanner',fast:'Rápida',start:'Começar',restart:'Recomeçar',nextSeq:'Sequência seguinte',replay:'Rever',watch:'OBSERVA',yourTurn:'A TUA VEZ',glyph:'Glyph',correct:'Correto',wrong:'Falhou · nova sequência.',complete:'Sequência validada',search:'Procurar um glyph…',draw:'Traça um glyph na matriz.',unknown:'Glyph não identificado',clear:'Limpar',source:'Ferramenta não oficial · treino local · dados comunitários de glyphs',noTimer:'SEM CRONÓMETRO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Desenhar em ecrã inteiro',closePad:'Fechar',release:'Solta para validar',drawAgain:'Traça o glyph seguinte',nodes:'nós',demoHere:'Observa o glyph aqui',arcadeIntro:'Começas com 30 segundos. Cada sequência concluída acrescenta tempo. As sequências crescem progressivamente de 1 a 5 glyphs.',simpleIntro:'Escolhe uma sequência de 1 a 5 glyphs. Sem cronómetro. Depois de acertares, avança quando quiseres.',length:'Comprimento',time:'TEMPO',score:'GLYPHS',record:'RECORDE',round:'SÉRIE',bonus:'Bónus de tempo',penalty:'Erro: -3 s',timeUp:'Tempo esgotado',ready:'Pronto?',autoNext:'Sequência seguinte…',getReady:'Prepara-te'},
de:{title:'GLYPH LAB',sub:'Experimenteller Kelleranbau',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Einfach',dictionary:'Wörterbuch',free:'Freies Zeichnen',intro:'Zwei Trainingsarten: Arcade gegen die Uhr oder Einfach in deinem Tempo.',speed:'Demo-Geschwindigkeit',slow:'Langsam',normal:'Scanner',fast:'Schnell',start:'Starten',restart:'Neu starten',nextSeq:'Nächste Sequenz',replay:'Nochmal ansehen',watch:'BEOBACHTEN',yourTurn:'DU BIST DRAN',glyph:'Glyph',correct:'Richtig',wrong:'Daneben · neue Sequenz.',complete:'Sequenz geschafft',search:'Glyph suchen…',draw:'Zeichne einen Glyph auf der Matrix.',unknown:'Glyph nicht erkannt',clear:'Löschen',source:'Inoffizielles Werkzeug · lokales Training · Community-Glyphdaten',noTimer:'OHNE TIMER',arcadeBadge:'ARCADE',phrase:'Phrase',openPad:'Vollbild zeichnen',closePad:'Schließen',release:'Loslassen zum Bestätigen',drawAgain:'Zeichne den nächsten Glyph',nodes:'Knoten',demoHere:'Glyph hier beobachten',arcadeIntro:'Du startest mit 30 Sekunden. Jede geschaffte Sequenz gibt zusätzliche Zeit. Die Sequenzen wachsen schrittweise von 1 auf 5 Glyphs.',simpleIntro:'Wähle eine Länge von 1 bis 5 Glyphs. Kein Timer. Nach einem Erfolg gehst du weiter, wann du willst.',length:'Länge',time:'ZEIT',score:'GLYPHS',record:'REKORD',round:'RUNDE',bonus:'Zeitbonus',penalty:'Fehler: -3 s',timeUp:'Zeit abgelaufen',ready:'Bereit?',autoNext:'Nächste Sequenz…',getReady:'Mach dich bereit'},
it:{title:'GLYPH LAB',sub:'Annesso sperimentale del seminterrato',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Semplice',dictionary:'Dizionario',free:'Disegno libero',intro:'Due modi per allenarti: Arcade contro il tempo o Semplice al tuo ritmo.',speed:'Velocità demo',slow:'Lenta',normal:'Scanner',fast:'Rapida',start:'Inizia',restart:'Ricomincia',nextSeq:'Sequenza successiva',replay:'Rivedi',watch:'OSSERVA',yourTurn:'TOCCA A TE',glyph:'Glyph',correct:'Corretto',wrong:'Errore · nuova sequenza.',complete:'Sequenza completata',search:'Cerca un glyph…',draw:'Traccia un glyph sulla matrice.',unknown:'Glyph non identificato',clear:'Cancella',source:'Strumento non ufficiale · allenamento locale · dati glyph della community',noTimer:'SENZA CRONOMETRO',arcadeBadge:'ARCADE',phrase:'Frase',openPad:'Disegna a schermo intero',closePad:'Chiudi',release:'Rilascia per convalidare',drawAgain:'Traccia il glyph successivo',nodes:'nodi',demoHere:'Osserva qui il glyph',arcadeIntro:'Parti con 30 secondi. Ogni sequenza completata aggiunge tempo. Le sequenze crescono gradualmente da 1 a 5 glyph.',simpleIntro:'Scegli una lunghezza da 1 a 5 glyph. Nessun cronometro. Dopo un successo, passa alla successiva quando vuoi.',length:'Lunghezza',time:'TEMPO',score:'GLYPHS',record:'RECORD',round:'SERIE',bonus:'Bonus tempo',penalty:'Errore: -3 s',timeUp:'Tempo scaduto',ready:'Pronto?',autoNext:'Sequenza successiva…',getReady:'Preparati'},
nl:{title:'GLYPH LAB',sub:'Experimentele kelderbijlage',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Eenvoudig',dictionary:'Woordenboek',free:'Vrij tekenen',intro:'Twee manieren om te trainen: Arcade tegen de klok of Eenvoudig op je eigen tempo.',speed:'Demosnelheid',slow:'Langzaam',normal:'Scanner',fast:'Snel',start:'Starten',restart:'Opnieuw',nextSeq:'Volgende reeks',replay:'Opnieuw bekijken',watch:'KIJK',yourTurn:'JOUW BEURT',glyph:'Glyph',correct:'Goed',wrong:'Gemist · nieuwe reeks.',complete:'Reeks voltooid',search:'Glyph zoeken…',draw:'Teken een glyph op de matrix.',unknown:'Glyph niet herkend',clear:'Wissen',source:'Onofficiële tool · lokale training · community-glyphgegevens',noTimer:'ZONDER TIMER',arcadeBadge:'ARCADE',phrase:'Zin',openPad:'Volledig scherm tekenen',closePad:'Sluiten',release:'Loslaten om te bevestigen',drawAgain:'Teken de volgende glyph',nodes:'knooppunten',demoHere:'Bekijk de glyph hier',arcadeIntro:'Je start met 30 seconden. Elke voltooide reeks geeft extra tijd. Reeksen groeien geleidelijk van 1 naar 5 glyphs.',simpleIntro:'Kies een lengte van 1 tot 5 glyphs. Geen timer. Na een succes ga je verder wanneer je wilt.',length:'Lengte',time:'TIJD',score:'GLYPHS',record:'RECORD',round:'REEKS',bonus:'Tijdbonus',penalty:'Fout: -3 s',timeUp:'Tijd voorbij',ready:'Klaar?',autoNext:'Volgende reeks…',getReady:'Maak je klaar'}
});
Object.assign(UI,{
pl:{title:'GLYPH LAB',sub:'Eksperymentalny aneks w piwnicy',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Prosty',dictionary:'Słownik',free:'Rysowanie dowolne',intro:'Dwa sposoby treningu: Arcade na czas albo Prosty we własnym tempie.',speed:'Prędkość demonstracji',slow:'Wolna',normal:'Scanner',fast:'Szybka',start:'Start',restart:'Od nowa',nextSeq:'Następna sekwencja',replay:'Powtórz',watch:'OBSERWUJ',yourTurn:'TWOJA KOLEJ',glyph:'Glyph',correct:'Dobrze',wrong:'Błąd · nowa sekwencja.',complete:'Sekwencja ukończona',search:'Szukaj glyphu…',draw:'Narysuj glyph na matrycy.',unknown:'Nieznany glyph',clear:'Wyczyść',source:'Niezależne narzędzie · trening lokalny · społecznościowe dane glyphów',noTimer:'BEZ CZASU',arcadeBadge:'ARCADE',phrase:'Fraza',openPad:'Rysuj na pełnym ekranie',closePad:'Zamknij',release:'Puść, aby zatwierdzić',drawAgain:'Narysuj następny glyph',nodes:'punkty',demoHere:'Obserwuj glyph tutaj',arcadeIntro:'Na start masz 30 sekund. Trudność rośnie etapami, z kilkoma seriami dla każdej długości.',vibration:'Wibracje',vibrationOn:'włączone',vibrationOff:'wyłączone',simpleIntro:'Wybierz długość od 1 do 5 glyphów. Bez czasu. Po sukcesie przejdź dalej, kiedy chcesz.',length:'Długość',time:'CZAS',score:'GLYPHY',record:'REKORD',round:'SERIA',bonus:'Bonus czasu',penalty:'Błąd: -3 s',timeUp:'Koniec czasu',ready:'Gotowy?',autoNext:'Następna sekwencja…',getReady:'Przygotuj się'},
cs:{title:'GLYPH LAB',sub:'Experimentální sklepní přístavba',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Jednoduchý',dictionary:'Slovník',free:'Volné kreslení',intro:'Dva způsoby tréninku: Arcade na čas nebo Jednoduchý vlastním tempem.',speed:'Rychlost ukázky',slow:'Pomalá',normal:'Scanner',fast:'Rychlá',start:'Start',restart:'Znovu',nextSeq:'Další sekvence',replay:'Přehrát znovu',watch:'SLEDUJ',yourTurn:'JDEŠ TY',glyph:'Glyph',correct:'Správně',wrong:'Chyba · nová sekvence.',complete:'Sekvence dokončena',search:'Hledat glyph…',draw:'Nakresli glyph na matici.',unknown:'Neznámý glyph',clear:'Smazat',source:'Neoficiální nástroj · místní trénink · komunitní data glyphů',noTimer:'BEZ ČASU',arcadeBadge:'ARCADE',phrase:'Fráze',openPad:'Kreslit na celou obrazovku',closePad:'Zavřít',release:'Uvolni pro potvrzení',drawAgain:'Nakresli další glyph',nodes:'body',demoHere:'Sleduj glyph zde',arcadeIntro:'Začínáš s 30 sekundami. Obtížnost roste po stupních a každá délka má několik kol.',vibration:'Vibrace',vibrationOn:'zapnuté',vibrationOff:'vypnuté',simpleIntro:'Vyber délku 1 až 5 glyphů. Bez časomíry. Po úspěchu pokračuj, kdy chceš.',length:'Délka',time:'ČAS',score:'GLYPHY',record:'REKORD',round:'KOLO',bonus:'Časový bonus',penalty:'Chyba: -3 s',timeUp:'Čas vypršel',ready:'Připraven?',autoNext:'Další sekvence…',getReady:'Připrav se'},
ro:{title:'GLYPH LAB',sub:'Anexă experimentală la subsol',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Simplu',dictionary:'Dicționar',free:'Desen liber',intro:'Două moduri de antrenament: Arcade contra cronometru sau Simplu în ritmul tău.',speed:'Viteza demonstrației',slow:'Lentă',normal:'Scanner',fast:'Rapidă',start:'Începe',restart:'Reîncepe',nextSeq:'Secvența următoare',replay:'Revede',watch:'PRIVEȘTE',yourTurn:'RÂNDUL TĂU',glyph:'Glyph',correct:'Corect',wrong:'Ratat · secvență nouă.',complete:'Secvență completă',search:'Caută un glyph…',draw:'Trasează un glyph pe matrice.',unknown:'Glyph necunoscut',clear:'Șterge',source:'Instrument neoficial · antrenament local · date glyph ale comunității',noTimer:'FĂRĂ CRONOMETRU',arcadeBadge:'ARCADE',phrase:'Frază',openPad:'Desenează pe tot ecranul',closePad:'Închide',release:'Eliberează pentru validare',drawAgain:'Trasează glyph-ul următor',nodes:'noduri',demoHere:'Privește glyph-ul aici',arcadeIntro:'Începi cu 30 de secunde. Dificultatea crește treptat, cu mai multe serii pentru fiecare lungime.',vibration:'Vibrații',vibrationOn:'activate',vibrationOff:'dezactivate',simpleIntro:'Alege o lungime de la 1 la 5 glyph-uri. Fără cronometru. După reușită, continuă când vrei.',length:'Lungime',time:'TIMP',score:'GLYPH-URI',record:'RECORD',round:'SERIE',bonus:'Bonus de timp',penalty:'Eroare: -3 s',timeUp:'Timp expirat',ready:'Pregătit?',autoNext:'Secvența următoare…',getReady:'Pregătește-te'},
tr:{title:'GLYPH LAB',sub:'Deneysel bodrum bölümü',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Basit',dictionary:'Sözlük',free:'Serbest çizim',intro:'İki eğitim yolu: zamana karşı Arcade veya kendi hızında Basit.',speed:'Demo hızı',slow:'Yavaş',normal:'Scanner',fast:'Hızlı',start:'Başla',restart:'Yeniden başla',nextSeq:'Sonraki dizi',replay:'Tekrar izle',watch:'İZLE',yourTurn:'SIRA SENDE',glyph:'Glyph',correct:'Doğru',wrong:'Kaçırdın · yeni dizi.',complete:'Dizi tamamlandı',search:'Glyph ara…',draw:'Matriste bir glyph çiz.',unknown:'Bilinmeyen glyph',clear:'Temizle',source:'Resmî olmayan araç · yerel eğitim · topluluk glyph verileri',noTimer:'SÜRE YOK',arcadeBadge:'ARCADE',phrase:'İfade',openPad:'Tam ekranda çiz',closePad:'Kapat',release:'Onaylamak için bırak',drawAgain:'Sonraki glyphi çiz',nodes:'düğüm',demoHere:'Glyphi burada izle',arcadeIntro:'30 saniyeyle başlarsın. Zorluk aşamalar hâlinde artar ve her uzunlukta birkaç tur vardır.',vibration:'Titreşim',vibrationOn:'açık',vibrationOff:'kapalı',simpleIntro:'1 ile 5 glyph arasında uzunluk seç. Süre yok. Başarınca istediğin zaman sonraki diziye geç.',length:'Uzunluk',time:'SÜRE',score:'GLYPH',record:'REKOR',round:'TUR',bonus:'Süre bonusu',penalty:'Hata: -3 sn',timeUp:'Süre doldu',ready:'Hazır?',autoNext:'Sonraki dizi…',getReady:'Hazırlan'},
ru:{title:'GLYPH LAB',sub:'Экспериментальный модуль в подвале',back:'‹ Аркада',arcade:'Аркада',simpleMode:'Простой',dictionary:'Словарь',free:'Свободный рисунок',intro:'Два режима тренировки: Аркада на время или Простой в своём темпе.',speed:'Скорость демонстрации',slow:'Медленно',normal:'Scanner',fast:'Быстро',start:'Начать',restart:'Сначала',nextSeq:'Следующая последовательность',replay:'Повторить',watch:'СМОТРИ',yourTurn:'ТВОЙ ХОД',glyph:'Глиф',correct:'Верно',wrong:'Ошибка · новая последовательность.',complete:'Последовательность завершена',search:'Найти глиф…',draw:'Нарисуй глиф на матрице.',unknown:'Неизвестный глиф',clear:'Очистить',source:'Неофициальный инструмент · локальная тренировка · данные сообщества',noTimer:'БЕЗ ТАЙМЕРА',arcadeBadge:'АРКАДА',phrase:'Фраза',openPad:'Рисовать на весь экран',closePad:'Закрыть',release:'Отпусти для подтверждения',drawAgain:'Нарисуй следующий глиф',nodes:'точек',demoHere:'Смотри глиф здесь',arcadeIntro:'Старт с 30 секундами. Сложность растёт по этапам, по несколько раундов на каждую длину.',vibration:'Вибрация',vibrationOn:'вкл.',vibrationOff:'выкл.',simpleIntro:'Выбери длину от 1 до 5 глифов. Без таймера. После успеха переходи дальше, когда захочешь.',length:'Длина',time:'ВРЕМЯ',score:'ГЛИФЫ',record:'РЕКОРД',round:'РАУНД',bonus:'Бонус времени',penalty:'Ошибка: -3 с',timeUp:'Время вышло',ready:'Готов?',autoNext:'Следующая последовательность…',getReady:'Приготовься'},
uk:{title:'GLYPH LAB',sub:'Експериментальний модуль у підвалі',back:'‹ Аркада',arcade:'Аркада',simpleMode:'Простий',dictionary:'Словник',free:'Вільне малювання',intro:'Два режими тренування: Аркада на час або Простий у власному темпі.',speed:'Швидкість демонстрації',slow:'Повільно',normal:'Scanner',fast:'Швидко',start:'Почати',restart:'Спочатку',nextSeq:'Наступна послідовність',replay:'Повторити',watch:'ДИВИСЬ',yourTurn:'ТВІЙ ХІД',glyph:'Гліф',correct:'Правильно',wrong:'Помилка · нова послідовність.',complete:'Послідовність завершена',search:'Знайти гліф…',draw:'Намалюй гліф на матриці.',unknown:'Невідомий гліф',clear:'Очистити',source:'Неофіційний інструмент · локальне тренування · дані спільноти',noTimer:'БЕЗ ТАЙМЕРА',arcadeBadge:'АРКАДА',phrase:'Фраза',openPad:'Малювати на весь екран',closePad:'Закрити',release:'Відпусти для підтвердження',drawAgain:'Намалюй наступний гліф',nodes:'точок',demoHere:'Дивись гліф тут',arcadeIntro:'Старт із 30 секундами. Складність зростає поетапно, з кількома раундами для кожної довжини.',vibration:'Вібрація',vibrationOn:'увімк.',vibrationOff:'вимк.',simpleIntro:'Обери довжину від 1 до 5 гліфів. Без таймера. Після успіху переходь далі, коли захочеш.',length:'Довжина',time:'ЧАС',score:'ГЛІФИ',record:'РЕКОРД',round:'РАУНД',bonus:'Бонус часу',penalty:'Помилка: -3 с',timeUp:'Час вийшов',ready:'Готовий?',autoNext:'Наступна послідовність…',getReady:'Приготуйся'},
ja:{title:'GLYPH LAB',sub:'地下実験区画',back:'‹ アーケード',arcade:'アーケード',simpleMode:'シンプル',dictionary:'辞書',free:'自由描画',intro:'2つの練習方法：時間制のアーケード、または自分のペースで行うシンプル。',speed:'デモ速度',slow:'遅い',normal:'Scanner',fast:'速い',start:'開始',restart:'やり直す',nextSeq:'次のシーケンス',replay:'もう一度見る',watch:'観察',yourTurn:'あなたの番',glyph:'グリフ',correct:'正解',wrong:'ミス · 新しいシーケンス。',complete:'シーケンス完了',search:'グリフを検索…',draw:'マトリクスにグリフを描いてください。',unknown:'不明なグリフ',clear:'消去',source:'非公式ツール · ローカル練習 · コミュニティのグリフデータ',noTimer:'時間制限なし',arcadeBadge:'アーケード',phrase:'フレーズ',openPad:'全画面で描く',closePad:'閉じる',release:'離すと確定',drawAgain:'次のグリフを描く',nodes:'ノード',demoHere:'ここでグリフを観察',arcadeIntro:'30秒から開始。難易度は段階的に上がり、各長さで複数ラウンドがあります。',vibration:'振動',vibrationOn:'オン',vibrationOff:'オフ',simpleIntro:'1〜5個のグリフを選択。タイマーなし。成功後は好きなタイミングで次へ進めます。',length:'長さ',time:'時間',score:'グリフ',record:'記録',round:'ラウンド',bonus:'時間ボーナス',penalty:'ミス：-3秒',timeUp:'時間切れ',ready:'準備OK？',autoNext:'次のシーケンス…',getReady:'準備してください'},
ko:{title:'GLYPH LAB',sub:'지하 실험 구역',back:'‹ 아케이드',arcade:'아케이드',simpleMode:'심플',dictionary:'사전',free:'자유 그리기',intro:'두 가지 훈련 방식: 시간 제한 아케이드 또는 자신의 속도로 하는 심플.',speed:'데모 속도',slow:'느림',normal:'Scanner',fast:'빠름',start:'시작',restart:'다시 시작',nextSeq:'다음 시퀀스',replay:'다시 보기',watch:'관찰',yourTurn:'당신 차례',glyph:'글리프',correct:'정답',wrong:'실패 · 새 시퀀스.',complete:'시퀀스 완료',search:'글리프 검색…',draw:'매트릭스에 글리프를 그리세요.',unknown:'알 수 없는 글리프',clear:'지우기',source:'비공식 도구 · 로컬 훈련 · 커뮤니티 글리프 데이터',noTimer:'시간 제한 없음',arcadeBadge:'아케이드',phrase:'문구',openPad:'전체 화면으로 그리기',closePad:'닫기',release:'손을 떼면 확인',drawAgain:'다음 글리프를 그리세요',nodes:'노드',demoHere:'여기서 글리프를 관찰',arcadeIntro:'30초로 시작합니다. 난이도는 단계별로 올라가며 각 길이마다 여러 라운드가 있습니다.',vibration:'진동',vibrationOn:'켜짐',vibrationOff:'꺼짐',simpleIntro:'1~5개의 글리프 길이를 선택하세요. 타이머 없음. 성공 후 원하는 때 다음으로 이동합니다.',length:'길이',time:'시간',score:'글리프',record:'기록',round:'라운드',bonus:'시간 보너스',penalty:'실수: -3초',timeUp:'시간 종료',ready:'준비됐나요?',autoNext:'다음 시퀀스…',getReady:'준비하세요'},
'zh-cn':{title:'GLYPH LAB',sub:'地下实验区',back:'‹ 街机厅',arcade:'街机',simpleMode:'简单',dictionary:'词典',free:'自由绘制',intro:'两种训练方式：计时街机模式，或按自己的节奏进行简单模式。',speed:'演示速度',slow:'慢',normal:'Scanner',fast:'快',start:'开始',restart:'重新开始',nextSeq:'下一个序列',replay:'重看',watch:'观察',yourTurn:'轮到你',glyph:'Glyph',correct:'正确',wrong:'失败 · 新序列。',complete:'序列完成',search:'搜索 glyph…',draw:'在矩阵上绘制 glyph。',unknown:'未知 glyph',clear:'清除',source:'非官方工具 · 本地训练 · 社区 glyph 数据',noTimer:'无计时',arcadeBadge:'街机',phrase:'短语',openPad:'全屏绘制',closePad:'关闭',release:'松开以确认',drawAgain:'绘制下一个 glyph',nodes:'节点',demoHere:'在这里观察 glyph',arcadeIntro:'从30秒开始。难度分阶段提高，每种长度包含多个回合。',vibration:'振动',vibrationOn:'开启',vibrationOff:'关闭',simpleIntro:'选择1到5个 glyph 的长度。无计时。成功后可随时进入下一个序列。',length:'长度',time:'时间',score:'GLYPH',record:'记录',round:'回合',bonus:'时间奖励',penalty:'错误：-3秒',timeUp:'时间到',ready:'准备好？',autoNext:'下一个序列…',getReady:'准备'},
'zh-tw':{title:'GLYPH LAB',sub:'地下實驗區',back:'‹ 街機廳',arcade:'街機',simpleMode:'簡單',dictionary:'詞典',free:'自由繪製',intro:'兩種訓練方式：計時街機模式，或按自己的節奏進行簡單模式。',speed:'示範速度',slow:'慢',normal:'Scanner',fast:'快',start:'開始',restart:'重新開始',nextSeq:'下一個序列',replay:'重看',watch:'觀察',yourTurn:'輪到你',glyph:'Glyph',correct:'正確',wrong:'失敗 · 新序列。',complete:'序列完成',search:'搜尋 glyph…',draw:'在矩陣上繪製 glyph。',unknown:'未知 glyph',clear:'清除',source:'非官方工具 · 本地訓練 · 社群 glyph 資料',noTimer:'無計時',arcadeBadge:'街機',phrase:'短語',openPad:'全螢幕繪製',closePad:'關閉',release:'放開以確認',drawAgain:'繪製下一個 glyph',nodes:'節點',demoHere:'在這裡觀察 glyph',arcadeIntro:'從30秒開始。難度分階段提高，每種長度包含多個回合。',vibration:'震動',vibrationOn:'開啟',vibrationOff:'關閉',simpleIntro:'選擇1到5個 glyph 的長度。無計時。成功後可隨時進入下一個序列。',length:'長度',time:'時間',score:'GLYPH',record:'紀錄',round:'回合',bonus:'時間獎勵',penalty:'錯誤：-3秒',timeUp:'時間到',ready:'準備好？',autoNext:'下一個序列…',getReady:'準備'},
yue:{title:'GLYPH LAB',sub:'地庫實驗區',back:'‹ 街機廳',arcade:'街機',simpleMode:'簡單',dictionary:'詞典',free:'自由繪製',intro:'兩種訓練方式：計時街機，或者按自己節奏用簡單模式。',speed:'示範速度',slow:'慢',normal:'Scanner',fast:'快',start:'開始',restart:'重新開始',nextSeq:'下一個序列',replay:'再睇',watch:'觀察',yourTurn:'到你',glyph:'Glyph',correct:'正確',wrong:'失敗 · 新序列。',complete:'序列完成',search:'搜尋 glyph…',draw:'喺矩陣上畫 glyph。',unknown:'未知 glyph',clear:'清除',source:'非官方工具 · 本地訓練 · 社群 glyph 資料',noTimer:'無計時',arcadeBadge:'街機',phrase:'短語',openPad:'全螢幕繪製',closePad:'關閉',release:'放手確認',drawAgain:'畫下一個 glyph',nodes:'節點',demoHere:'喺呢度觀察 glyph',arcadeIntro:'由30秒開始。難度逐級提高，每種長度有幾個回合。',vibration:'震動',vibrationOn:'開',vibrationOff:'關',simpleIntro:'揀1至5個 glyph。冇計時。成功之後想幾時去下一個序列都得。',length:'長度',time:'時間',score:'GLYPH',record:'紀錄',round:'回合',bonus:'時間獎勵',penalty:'錯誤：-3秒',timeUp:'時間到',ready:'準備好？',autoNext:'下一個序列…',getReady:'準備'},
ar:{title:'GLYPH LAB',sub:'ملحق تجريبي في القبو',back:'‹ الأركيد',arcade:'أركيد',simpleMode:'بسيط',dictionary:'القاموس',free:'رسم حر',intro:'طريقتان للتدريب: أركيد ضد الوقت أو وضع بسيط وفق سرعتك.',speed:'سرعة العرض',slow:'بطيئة',normal:'Scanner',fast:'سريعة',start:'ابدأ',restart:'إعادة',nextSeq:'التسلسل التالي',replay:'إعادة العرض',watch:'راقب',yourTurn:'دورك',glyph:'Glyph',correct:'صحيح',wrong:'خطأ · تسلسل جديد.',complete:'اكتمل التسلسل',search:'ابحث عن glyph…',draw:'ارسم glyph على المصفوفة.',unknown:'Glyph غير معروف',clear:'مسح',source:'أداة غير رسمية · تدريب محلي · بيانات glyph من المجتمع',noTimer:'بدون مؤقت',arcadeBadge:'أركيد',phrase:'عبارة',openPad:'الرسم بملء الشاشة',closePad:'إغلاق',release:'اترك للتأكيد',drawAgain:'ارسم glyph التالي',nodes:'نقاط',demoHere:'راقب glyph هنا',arcadeIntro:'تبدأ بـ30 ثانية. ترتفع الصعوبة تدريجياً مع عدة جولات لكل طول.',vibration:'الاهتزاز',vibrationOn:'مفعّل',vibrationOff:'معطّل',simpleIntro:'اختر طولاً من 1 إلى 5 glyphs. بلا مؤقت. بعد النجاح انتقل متى شئت.',length:'الطول',time:'الوقت',score:'GLYPHS',record:'الرقم القياسي',round:'الجولة',bonus:'وقت إضافي',penalty:'خطأ: -3 ث',timeUp:'انتهى الوقت',ready:'جاهز؟',autoNext:'التسلسل التالي…',getReady:'استعد'},
id:{title:'GLYPH LAB',sub:'Lampiran eksperimen bawah tanah',back:'‹ Arcade',arcade:'Arcade',simpleMode:'Sederhana',dictionary:'Kamus',free:'Gambar bebas',intro:'Dua cara latihan: Arcade melawan waktu atau Sederhana dengan ritmemu sendiri.',speed:'Kecepatan demo',slow:'Lambat',normal:'Scanner',fast:'Cepat',start:'Mulai',restart:'Mulai ulang',nextSeq:'Urutan berikutnya',replay:'Lihat lagi',watch:'AMATI',yourTurn:'GILIRANMU',glyph:'Glyph',correct:'Benar',wrong:'Gagal · urutan baru.',complete:'Urutan selesai',search:'Cari glyph…',draw:'Gambar glyph pada matriks.',unknown:'Glyph tidak dikenal',clear:'Hapus',source:'Alat tidak resmi · latihan lokal · data glyph komunitas',noTimer:'TANPA TIMER',arcadeBadge:'ARCADE',phrase:'Frasa',openPad:'Gambar layar penuh',closePad:'Tutup',release:'Lepaskan untuk mengonfirmasi',drawAgain:'Gambar glyph berikutnya',nodes:'titik',demoHere:'Amati glyph di sini',arcadeIntro:'Mulai dengan 30 detik. Kesulitan meningkat bertahap dengan beberapa ronde untuk tiap panjang.',vibration:'Getaran',vibrationOn:'aktif',vibrationOff:'nonaktif',simpleIntro:'Pilih panjang 1 sampai 5 glyph. Tanpa timer. Setelah berhasil, lanjut kapan pun kamu mau.',length:'Panjang',time:'WAKTU',score:'GLYPH',record:'REKOR',round:'RONDE',bonus:'Bonus waktu',penalty:'Salah: -3 dtk',timeUp:'Waktu habis',ready:'Siap?',autoNext:'Urutan berikutnya…',getReady:'Bersiap'}
});
const tr = lang => { const k=String(lang||'').toLowerCase().replace('_','-'); return UI[k] || UI[k.split('-')[0]] || UI.en; };
const esc = s => String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const pick = a => a[Math.floor(Math.random()*a.length)];
const sleep = ms => new Promise(r=>setTimeout(r,ms));

function idx(ch){ return parseInt(ch,11); }
function nodeXY(i,size=240){
  const [x,y]=NODE_POS[i]; const r=size*.39,c=size/2;
  return [c+r*x,c+r*y];
}
function edges(code){
  const out=[]; for(let i=0;i+1<code.length;i+=2) out.push([idx(code[i]),idx(code[i+1])]); return out;
}
function glyphSvg(g, size=210, cls=''){
  if(!g) return '';
  const ls=edges(g.code).map(([a,b])=>{const [x1,y1]=nodeXY(a,size),[x2,y2]=nodeXY(b,size);return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`;}).join('');
  const ns=NODE_POS.map((_,i)=>{const [x,y]=nodeXY(i,size);return `<circle cx="${x}" cy="${y}" r="${Math.max(3,size*.018)}"/>`;}).join('');
  return `<svg class="glyphLabGlyph ${esc(cls)}" viewBox="0 0 ${size} ${size}" aria-label="${esc(g.names[0])}"><g class="glyphLabLines">${ls}</g><g class="glyphLabNodes">${ns}</g></svg>`;
}
function canonicalFromPath(path){
  const seen=new Set();
  for(let i=1;i<path.length;i++){
    let a=path[i-1],b=path[i]; if(a===b)continue; if(a>b)[a,b]=[b,a];
    seen.add(`${a.toString(11)}${b.toString(11)}`);
  }
  return [...seen].sort((x,y)=>{const ax=idx(x[0]),bx=idx(x[1]),ay=idx(y[0]),by=idx(y[1]);return ax-ay||bx-by;}).join('');
}
function glyphByCode(code){ return GLYPHS.find(g=>g.code===code) || null; }
function sequenceForLength(len){
  len=Math.max(1,Math.min(5,Number(len)||1));
  if(len===1) return [pick(COMMON_SINGLE.length?COMMON_SINGLE:GLYPHS)];
  if(len===2) return pick(PAIRS);
  const bank=len===3?SEQ3:len===4?SEQ4:SEQ5;
  const seq=pick(bank).map(word).filter(Boolean);
  if(seq.length===len)return seq;
  return Array.from({length:len},()=>pick(COMMON_SINGLE.length?COMMON_SINGLE:GLYPHS));
}

export function glyphLabMarkup(lang='fr'){
  const t=tr(lang);
  return `<section class="glyphLabScreen labGameScreen">
    <div class="glyphLabTop">
      <button class="labBack" data-arc-menu>${esc(t.back)}</button>
      <div><small>${esc(t.sub)}</small><h2>${esc(t.title)}</h2></div>
      <span class="glyphLabNoTimer arcade" data-glyph-mode-badge>${esc(t.arcadeBadge)}</span>
    </div>
    <p class="glyphLabIntro">${esc(t.intro)}</p>
    <div class="glyphLabTabs" role="tablist">
      <button class="active" data-glyph-tab="arcade">◉ ${esc(t.arcade)}</button>
      <button data-glyph-tab="simple">⌁ ${esc(t.simpleMode)}</button>
      <button data-glyph-tab="dictionary">◫ ${esc(t.dictionary)}</button>
      <button data-glyph-tab="free">✎ ${esc(t.free)}</button>
    </div>
    <div class="glyphLabPane" data-glyph-pane></div>
    <footer class="glyphLabSource">${esc(t.source)}</footer>
  </section>`;
}

function makePad(host,{onStroke,onNode,t}){
  host.innerHTML=`<button class="glyphPadLaunch" type="button" data-pad-open>✎ <span>${esc(t.openPad)}</span></button>`;
  const launch=host.querySelector('[data-pad-open]');
  const overlay=document.createElement('div');
  overlay.className='glyphPadOverlay';
  overlay.innerHTML=`
    <div class="glyphPadFullscreenTop">
      <button type="button" class="glyphPadClose" data-pad-close>×</button>
      <div><small>GLYPH LAB</small><strong data-pad-hint>${esc(t.release)}</strong></div>
      <span class="glyphPadFullscreenBadge" data-pad-badge>${esc(t.noTimer)}</span>
    </div>
    <div class="glyphPadStage">
      <div class="glyphPadWrap fullscreen">
        <svg class="glyphPad" viewBox="0 0 300 300" data-pad aria-label="Glyph input">
          <g class="glyphPadDemoGlow" data-demo-glow></g>
          <g class="glyphPadDemoInk" data-demo-ink></g>
          <g class="glyphPadTrace">
            <path class="glyphPadGlow" data-trace-glow fill="none"></path>
            <path class="glyphPadInk" data-trace-ink fill="none"></path>
            <circle class="glyphPadHead" data-trace-head cx="0" cy="0" r="7" hidden></circle>
          </g>
          <g class="glyphPadNodes">${NODE_POS.map((_,i)=>{const [x,y]=nodeXY(i,300);return `<circle data-node="${i}" cx="${x}" cy="${y}" r="7"/>`;}).join('')}</g>
        </svg>
        <div class="glyphPadFooter">
          <span data-pad-count>0 / 11 ${esc(t.nodes)}</span>
          <button type="button" class="glyphPadClear" data-pad-clear>${esc(t.clear)}</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const svg=overlay.querySelector('[data-pad]');
  const ink=overlay.querySelector('[data-trace-ink]');
  const glow=overlay.querySelector('[data-trace-glow]');
  const head=overlay.querySelector('[data-trace-head]');
  const demoGlow=overlay.querySelector('[data-demo-glow]');
  const demoInk=overlay.querySelector('[data-demo-ink]');
  const hint=overlay.querySelector('[data-pad-hint]');
  const count=overlay.querySelector('[data-pad-count]');
  const badge=overlay.querySelector('[data-pad-badge]');
  let path=[],rawSamples=[],drawing=false,disabled=false,raf=0,lastPointerId=null,currentPoint=null,demoMode=false;
  const MAX_NODES=NODE_POS.length;
  const MAX_TRANSITIONS=48;

  const pointFromEvent=ev=>{
    try{
      const pt=svg.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;
      const ctm=svg.getScreenCTM();
      if(ctm){const q=pt.matrixTransform(ctm.inverse());return {x:q.x,y:q.y};}
    }catch(_){}
    const r=svg.getBoundingClientRect(),scale=Math.min(r.width/300,r.height/300)||1;
    const ox=r.left+(r.width-300*scale)/2,oy=r.top+(r.height-300*scale)/2;
    return {x:(ev.clientX-ox)/scale,y:(ev.clientY-oy)/scale};
  };
  const distToSegment=(p,a,b)=>{
    const vx=b.x-a.x,vy=b.y-a.y,wx=p.x-a.x,wy=p.y-a.y;
    const vv=vx*vx+vy*vy;
    const q=vv?Math.max(0,Math.min(1,(wx*vx+wy*vy)/vv)):0;
    const x=a.x+q*vx,y=a.y+q*vy;
    return {d:Math.hypot(p.x-x,p.y-y),q};
  };
  const NODE_HIT_RADIUS=23;
  const captureAlong=(a,b)=>{
    if(path.length>=MAX_TRANSITIONS)return [];
    const hits=[];
    NODE_POS.forEach((_,i)=>{
      const [x,y]=nodeXY(i,300),h=distToSegment({x,y},a,b);
      if(h.d<=NODE_HIT_RADIUS)hits.push([h.q,i,h.d]);
    });
    hits.sort((x,y)=>x[0]-y[0]||x[2]-y[2]);
    const added=[];
    for(const [,i] of hits){if(path.length>=MAX_TRANSITIONS)break;if(path[path.length-1]!==i){path.push(i);added.push(i);}}
    return added;
  };
  const traceD=()=>{
    // Prime-like behaviour: the visible trace is NOT the finger trajectory.
    // It exists only between nodes that were actually crossed/validated.
    if(!path.length)return '';
    const pts=path.map(i=>{const [x,y]=nodeXY(i,300);return {x,y};});
    let d=`M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
    for(let i=1;i<pts.length;i++)d+=` L ${pts[i].x.toFixed(1)} ${pts[i].y.toFixed(1)}`;
    return d;
  };
  const render=()=>{
    raf=0;const d=traceD();ink.setAttribute('d',d);glow.setAttribute('d',d);
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.toggle('used',path.includes(Number(n.dataset.node))));
    if(drawing&&path.length){
      const [hx,hy]=nodeXY(path[path.length-1],300);
      head.hidden=false;head.setAttribute('cx',hx.toFixed(1));head.setAttribute('cy',hy.toFixed(1));
    }else head.hidden=true;
    count.textContent=`${new Set(path).size} / ${MAX_NODES} ${t.nodes}`;
  };
  const queueRender=()=>{if(!raf)raf=requestAnimationFrame(render)};
  let lastRaw=null;
  const addPoint=p=>{
    if(demoMode||disabled)return;
    // The raw pointer path is used only as an invisible detector so fast swipes
    // cannot jump over nodes. Nothing is drawn until a node is crossed.
    const added=lastRaw?captureAlong(lastRaw,p):captureAlong(p,p);
    lastRaw=p;currentPoint=p;
    if(added.length){
      added.forEach(i=>{
        onNode?.(i);
        const node=svg.querySelector(`[data-node="${i}"]`);
        if(node){node.classList.remove('just-hit');void node.getBBox();node.classList.add('just-hit');setTimeout(()=>node.classList.remove('just-hit'),240);}
      });
    }
    queueRender();
  };
  const clearTrace=()=>{
    path=[];rawSamples=[];lastRaw=null;currentPoint=null;head.hidden=true;ink.setAttribute('d','');glow.setAttribute('d','');
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('used'));
    count.textContent=`0 / ${MAX_NODES} ${t.nodes}`;
  };
  const clearDemo=()=>{
    demoGlow.innerHTML='';demoInk.innerHTML='';
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('demo-used'));
    overlay.classList.remove('demoing');demoMode=false;
  };
  const openOverlay=()=>{
    overlay.classList.add('open');document.documentElement.classList.add('glyphInputOpen');document.body?.classList.add('glyphInputOpen');
  };
  const close=()=>{
    drawing=false;lastPointerId=null;currentPoint=null;overlay.classList.remove('open');document.documentElement.classList.remove('glyphInputOpen');document.body?.classList.remove('glyphInputOpen');
  };
  const open=()=>{
    if(disabled)return;clearDemo();clearTrace();openOverlay();requestAnimationFrame(()=>svg.focus?.());
  };
  const setHint=text=>{hint.textContent=String(text||t.release)};
  const setBadge=(text,state='')=>{badge.textContent=String(text||t.noTimer);badge.classList.remove('ok','bad','urgent','countdown');if(state)badge.classList.add(state);};
  const setDisabled=v=>{disabled=!!v;launch.disabled=disabled;svg.classList.toggle('disabled',disabled);};
  const showDemo=(g,label='')=>{
    disabled=true;launch.disabled=true;demoMode=true;drawing=false;clearTrace();overlay.classList.add('demoing');openOverlay();
    const used=new Set();
    const lines=edges(g.code).map(([a,b],i)=>{
      used.add(a);used.add(b);const [x1,y1]=nodeXY(a,300),[x2,y2]=nodeXY(b,300);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" pathLength="1" style="--glyph-delay:${(i*.07).toFixed(2)}s"/>`;
    }).join('');
    demoGlow.innerHTML=lines;demoInk.innerHTML=lines;
    svg.querySelectorAll('[data-node]').forEach(n=>n.classList.toggle('demo-used',used.has(Number(n.dataset.node))));
    count.textContent=label||t.demoHere;setHint(label||t.demoHere);
  };
  const showGap=(label='')=>{
    demoGlow.innerHTML='';demoInk.innerHTML='';svg.querySelectorAll('[data-node]').forEach(n=>n.classList.remove('demo-used'));
    count.textContent=label||t.watch;setHint(label||t.watch);openOverlay();
  };
  const beginInput=(label='')=>{
    clearDemo();disabled=false;launch.disabled=false;svg.classList.remove('disabled');clearTrace();setHint(label||t.release);openOverlay();
  };

  launch.onclick=open;
  overlay.querySelector('[data-pad-close]').onclick=close;
  overlay.querySelector('[data-pad-clear]').onclick=()=>{if(!demoMode)clearTrace();};
  overlay.addEventListener('pointerdown',ev=>{if(ev.target===overlay)ev.preventDefault();});
  svg.addEventListener('contextmenu',ev=>ev.preventDefault());
  svg.addEventListener('pointerdown',ev=>{
    if(disabled||demoMode)return;ev.preventDefault();drawing=true;lastPointerId=ev.pointerId;clearTrace();svg.setPointerCapture?.(ev.pointerId);addPoint(pointFromEvent(ev));
  });
  svg.addEventListener('pointermove',ev=>{
    if(!drawing||ev.pointerId!==lastPointerId||demoMode)return;ev.preventDefault();
    const events=typeof ev.getCoalescedEvents==='function'?ev.getCoalescedEvents():[ev];
    for(const e of events)addPoint(pointFromEvent(e));
  });
  const end=ev=>{
    if(!drawing||ev.pointerId!==lastPointerId||demoMode)return;ev.preventDefault();addPoint(pointFromEvent(ev));drawing=false;lastPointerId=null;currentPoint=null;queueRender();
    const code=canonicalFromPath(path);if(code)onStroke?.({code,path:[...path],match:glyphByCode(code)});else setHint(t.unknown);
  };
  svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
  return {clear:clearTrace,open,close,setHint,setBadge,disable:setDisabled,showDemo,showGap,beginInput,destroy(){close();if(raf)cancelAnimationFrame(raf);overlay.remove();}};
}

export function mountGlyphLab(body,{lang='fr',tone=()=>{},buzz=()=>{}}={}){
  const t=tr(lang); const pane=body.querySelector('[data-glyph-pane]');
  const modeBadge=body.querySelector('[data-glyph-mode-badge]');
  let active='arcade',destroyed=false,demoToken=0,timerId=null,lastTick=0;
  const BEST_KEY='rbl-glyph-arcade-best-v1';
  const HAPTIC_KEY='rbl-glyph-haptics-v1';
  const state={simpleLen:3,speed:'normal',sequence:[],index:0,pad:null,haptics:localStorage.getItem(HAPTIC_KEY)!=='0',
    arcade:{running:false,paused:true,time:30,score:0,round:0,best:Number(localStorage.getItem(BEST_KEY)||0),lastResult:''}};
  const speedMs=()=>state.speed==='slow'?900:state.speed==='fast'?360:590;
  const arcadeLength=round=>round<3?1:round<6?2:round<9?3:round<12?4:5;
  const arcadeSpeedMs=()=>Math.max(430,900-Math.floor(state.arcade.round/3)*85-(state.arcade.round%3)*20);
  const gameBuzz=ms=>{if(state.haptics)buzz(ms)};
  const stopTimer=()=>{if(timerId){clearInterval(timerId);timerId=null;}lastTick=0;};
  const fmtTime=n=>Math.max(0,n).toFixed(n<10?1:0);
  const syncArcadeHud=()=>{
    const a=state.arcade;
    pane.querySelectorAll('[data-arc-time]').forEach(x=>x.textContent=fmtTime(a.time));
    pane.querySelectorAll('[data-arc-score]').forEach(x=>x.textContent=String(a.score));
    pane.querySelectorAll('[data-arc-round]').forEach(x=>x.textContent=String(a.round+1));
    pane.querySelectorAll('[data-arc-best]').forEach(x=>x.textContent=String(a.best));
    if(state.pad&&active==='arcade'){const r=a.lastResult?` · ${a.lastResult}`:'';state.pad.setBadge(`⏱ ${fmtTime(a.time)} s · ◆ ${a.score}${r}`,a.lastResult==='✓'?'ok':a.lastResult==='✕'?'bad':a.time<=10?'urgent':'');}
  };
  const gameOver=()=>{
    const a=state.arcade;if(!a.running)return;a.running=false;a.paused=true;a.time=0;stopTimer();syncArcadeHud();
    state.pad?.close();
    const status=pane.querySelector('[data-status]');if(status){status.className='glyphStatus bad';status.textContent=`${t.timeUp} · ${a.score} glyph${a.score>1?'s':''}`;}
    const start=pane.querySelector('[data-arc-start]');if(start){start.textContent=t.restart;start.disabled=false;}
  };
  const startTimer=()=>{
    stopTimer();lastTick=performance.now();timerId=setInterval(()=>{
      const now=performance.now(),dt=(now-lastTick)/1000;lastTick=now;
      const a=state.arcade;if(!a.running||a.paused){syncArcadeHud();return;}
      a.time=Math.max(0,a.time-dt);syncArcadeHud();if(a.time<=0)gameOver();
    },80);
  };
  const setTopBadge=mode=>{
    if(!modeBadge)return;
    const arcade=mode==='arcade';modeBadge.textContent=arcade?t.arcadeBadge:t.noTimer;modeBadge.classList.toggle('arcade',arcade);
  };

  const wirePad=(mode,{status,phrase,demo,onSequenceDone,onSequenceFail})=>{
    state.pad=makePad(pane.querySelector('[data-pad-host]'),{t,onNode:()=>gameBuzz(6),onStroke:({code})=>{
      if(!state.sequence.length||state.index>=state.sequence.length)return;
      const target=state.sequence[state.index];
      if(code===target.code){
        gameBuzz(18);tone(720,0.045,0.02,'sine',920);if(mode==='arcade'){state.arcade.lastResult='✓';syncArcadeHud();}status.className='glyphStatus ok';status.textContent=`✓ ${t.correct} · ${target.names[0]}`;state.index+=1;state.pad.clear();
        if(state.index>=state.sequence.length){
          phrase.innerHTML=`<b>${esc(t.phrase)}</b> · ${state.sequence.map(g=>esc(g.names[0].toUpperCase())).join(' · ')}`;
          status.textContent=`✓ ${t.complete}`;demo.innerHTML=`<strong>${esc(t.complete)}</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
          state.pad.setHint(`✓ ${t.complete}`);gameBuzz(26);tone(520,0.08,0.024,'triangle',880);onSequenceDone?.();
        }else{
          state.pad.setHint(`${t.yourTurn} · ${t.glyph} ${state.index+1}/${state.sequence.length}`);
          setTimeout(()=>{if(!destroyed&&state.pad){status.className='glyphStatus';status.textContent=`${t.yourTurn} · ${t.glyph} ${state.index+1}/${state.sequence.length}`;}},180);
        }
      }else{
        gameBuzz(40);tone(170,0.07,0.02,'square',110);if(mode==='arcade'){state.arcade.lastResult='✕';syncArcadeHud();}status.className='glyphStatus bad';
        if(mode==='arcade'){
          state.arcade.paused=true;state.arcade.time=Math.max(0,state.arcade.time-3);status.textContent=`✕ ${t.wrong} · -3 s`;syncArcadeHud();state.pad.setHint(`✕ ${t.wrong}`);state.pad.disable(true);state.pad.clear();if(state.arcade.time<=0){gameOver();return;}onSequenceFail?.();return;
        }else status.textContent=t.wrong;
        state.pad.setHint(t.wrong);state.pad.clear();
      }
    }});
    state.pad.disable(true);state.pad.setBadge(mode==='arcade'?`⏱ ${fmtTime(state.arcade.time)} s`:t.noTimer);
  };

  const playDemo=async({mode,ms})=>{
    const token=++demoToken;state.index=0;state.pad.disable(true);
    if(mode==='arcade')state.arcade.paused=true;
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    status.className='glyphStatus';status.textContent=t.watch;phrase.textContent='';
    for(let i=0;i<state.sequence.length;i++){
      if(destroyed||token!==demoToken)return;
      const g=state.sequence[i],label=`${t.watch} · ${t.glyph} ${i+1}/${state.sequence.length}`;
      demo.innerHTML=`<strong>${esc(t.watch)}</strong><span>${esc(t.glyph)} ${i+1}/${state.sequence.length} · ${esc(t.demoHere)}</span>`;
      state.pad.showDemo(g,label);tone(340+i*36,0.035,0.012,'sine');await sleep(ms());
      if(destroyed||token!==demoToken)return;state.pad.showGap(`${t.watch} · ${i+1}/${state.sequence.length}`);await sleep(Math.max(110,ms()*.24));
    }
    if(destroyed||token!==demoToken)return;
    if(mode==='arcade'){
      for(const n of [3,2,1]){
        if(destroyed||token!==demoToken)return;
        const label=`${t.getReady} · ${n}`;
        demo.innerHTML=`<strong class="glyphCountdown">${n}</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
        status.className='glyphStatus countdown';status.textContent=label;state.pad.setHint(label);state.pad.setBadge(`PRÊT · ${n}`,'countdown');
        gameBuzz(n===1?16:7);tone(260+n*70,0.035,0.012,'sine');await sleep(210);
      }
      if(destroyed||token!==demoToken)return;
      demo.innerHTML=`<strong class="glyphCountdown go">GO</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
      status.textContent='GO';state.pad.setHint('GO');state.pad.setBadge('GO','countdown');gameBuzz(22);tone(760,0.055,0.018,'sine');
      await sleep(110);
    }
    demo.innerHTML=`<strong>${esc(t.yourTurn)}</strong><span>${state.sequence.length} glyph${state.sequence.length>1?'s':''}</span>`;
    status.className='glyphStatus';status.textContent=`${t.yourTurn} · ${t.glyph} 1/${state.sequence.length}`;
    state.pad.beginInput(`${t.yourTurn} · ${t.glyph} 1/${state.sequence.length}`);
    if(mode==='arcade'){state.arcade.lastResult='';state.arcade.paused=false;lastTick=performance.now();syncArcadeHud();}
  };

  const renderArcade=()=>{
    setTopBadge('arcade');stopTimer();
    const a=state.arcade;a.running=false;a.paused=true;
    pane.innerHTML=`<div class="glyphModeIntro arcade"><strong>◉ ${esc(t.arcade)}</strong><p>${esc(t.arcadeIntro)}</p><button type="button" class="glyphHapticToggle ${state.haptics?'on':''}" data-glyph-haptics>📳 ${esc(t.vibration||'Vibrations')} · ${esc(state.haptics?(t.vibrationOn||'activées'):(t.vibrationOff||'désactivées'))}</button></div>
      <div class="glyphArcadeHud"><div><small>${esc(t.time)}</small><b data-arc-time>30</b><span>s</span></div><div><small>${esc(t.score)}</small><b data-arc-score>${a.score}</b></div><div><small>${esc(t.round)}</small><b data-arc-round>1</b></div><div><small>${esc(t.record)}</small><b data-arc-best>${a.best}</b></div></div>
      <div class="glyphExercise"><div class="glyphDemo" data-demo><strong>${esc(t.ready)}</strong><span>1 → 5 glyphs</span></div><div class="glyphPhrase" data-phrase></div><div class="glyphStatus" data-status></div><div class="glyphPadHost" data-pad-host></div><div class="glyphActions single"><button class="labArcadePrimary" data-arc-start>${esc(t.start)}</button></div></div>`;
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    const nextRound=()=>{
      if(!a.running)return;
      const len=arcadeLength(a.round);state.sequence=sequenceForLength(len);state.index=0;
      status.className='glyphStatus';status.textContent=`${t.round} ${a.round+1} · ${len} glyph${len>1?'s':''}`;
      playDemo({mode:'arcade',ms:arcadeSpeedMs});
    };
    wirePad('arcade',{status,phrase,demo,onSequenceDone:()=>{
      a.paused=true;a.score+=state.sequence.length;a.round+=1;
      const bonus=2+state.sequence.length;a.time=Math.min(60,a.time+bonus);
      if(a.score>a.best){a.best=a.score;localStorage.setItem(BEST_KEY,String(a.best));}
      syncArcadeHud();status.className='glyphStatus ok';status.textContent=`✓ ${t.complete} · +${bonus} s`;state.pad.setHint(`+${bonus} s`);
      setTimeout(()=>{if(a.running&&!destroyed)nextRound();},650);
    },onSequenceFail:()=>{
      demo.innerHTML=`<strong class="glyphFailMark">✕</strong><span>${esc(t.wrong)}</span>`;status.className='glyphStatus bad';status.textContent=`✕ ${t.wrong} · -3 s`;
      setTimeout(()=>{if(a.running&&!destroyed)nextRound();},700);
    }});
    pane.querySelector('[data-glyph-haptics]').onclick=e=>{state.haptics=!state.haptics;localStorage.setItem(HAPTIC_KEY,state.haptics?'1':'0');e.currentTarget.classList.toggle('on',state.haptics);e.currentTarget.textContent=`📳 ${t.vibration||'Vibrations'} · ${state.haptics?(t.vibrationOn||'activées'):(t.vibrationOff||'désactivées')}`;if(state.haptics)gameBuzz(16);};
    pane.querySelector('[data-arc-start]').onclick=e=>{
      demoToken++;a.running=true;a.paused=true;a.time=30;a.score=0;a.round=0;a.lastResult='';state.sequence=[];state.index=0;e.currentTarget.disabled=true;e.currentTarget.textContent='ARCADE EN COURS';syncArcadeHud();startTimer();nextRound();
    };
    syncArcadeHud();
  };

  const renderSimple=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;state.arcade.paused=true;
    pane.innerHTML=`<div class="glyphModeIntro"><strong>⌁ ${esc(t.simpleMode)}</strong><p>${esc(t.simpleIntro)}</p></div>
      <div class="glyphLabControls"><div class="glyphCtl"><label>${esc(t.length)}</label><div class="glyphLengths">${[1,2,3,4,5].map(n=>`<button class="${n===state.simpleLen?'active':''}" data-length="${n}">${n}</button>`).join('')}</div></div>
      <div class="glyphCtl"><label>${esc(t.speed)}</label><div class="glyphSpeeds"><button data-speed="slow" class="${state.speed==='slow'?'active':''}">${esc(t.slow)}</button><button data-speed="normal" class="${state.speed==='normal'?'active':''}">${esc(t.normal)}</button><button data-speed="fast" class="${state.speed==='fast'?'active':''}">${esc(t.fast)}</button></div></div></div>
      <div class="glyphExercise"><div class="glyphDemo" data-demo><span>${esc(t.ready)}</span></div><div class="glyphPhrase" data-phrase></div><div class="glyphStatus" data-status></div><div class="glyphPadHost" data-pad-host></div><div class="glyphActions"><button class="labArcadePrimary" data-next-seq>${esc(t.start)}</button><button class="labArcadeSecondary" data-replay disabled>${esc(t.replay)}</button></div></div>`;
    pane.querySelectorAll('[data-length]').forEach(b=>b.onclick=()=>{state.simpleLen=Number(b.dataset.length)||3;render();});
    pane.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>{state.speed=b.dataset.speed;render();});
    const status=pane.querySelector('[data-status]'),phrase=pane.querySelector('[data-phrase]'),demo=pane.querySelector('[data-demo]');
    const nextBtn=pane.querySelector('[data-next-seq]'),replay=pane.querySelector('[data-replay]');
    wirePad('simple',{status,phrase,demo,onSequenceDone:()=>{
      setTimeout(()=>state.pad?.close(),420);nextBtn.disabled=false;nextBtn.textContent=t.nextSeq;replay.disabled=false;
    }});
    const launch=()=>{state.sequence=sequenceForLength(state.simpleLen);nextBtn.disabled=true;replay.disabled=false;playDemo({mode:'simple',ms:speedMs});};
    nextBtn.onclick=launch;replay.onclick=()=>{if(state.sequence.length)playDemo({mode:'simple',ms:speedMs});};
  };

  const renderDictionary=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;
    pane.innerHTML=`<div class="glyphDictHead"><input type="search" data-glyph-search placeholder="${esc(t.search)}" autocomplete="off"><span>${GLYPHS.length} glyphs</span></div><div class="glyphDictionary" data-glyph-list></div>`;
    const list=pane.querySelector('[data-glyph-list]'),input=pane.querySelector('[data-glyph-search]');
    const fill=()=>{const q=input.value.trim().toLowerCase();const rows=GLYPHS.filter(g=>!q||g.names.some(n=>n.toLowerCase().includes(q))).sort((a,b)=>a.names[0].localeCompare(b.names[0])).map(g=>`<article class="glyphDictCard">${glyphSvg(g,120)}<div><strong>${esc(g.names[0])}</strong>${g.names.length>1?`<small>${g.names.slice(1).map(esc).join(' · ')}</small>`:''}</div></article>`).join('');list.innerHTML=rows||'<p class="glyphEmpty">∅</p>';};
    input.oninput=fill;fill();
  };

  const renderFree=()=>{
    setTopBadge('simple');stopTimer();state.arcade.running=false;
    pane.innerHTML=`<div class="glyphFree"><p>${esc(t.draw)}</p><div class="glyphFreeResult" data-free-result>?</div><div class="glyphPadHost" data-pad-host></div></div>`;
    const result=pane.querySelector('[data-free-result]');
    state.pad=makePad(pane.querySelector('[data-pad-host]'),{t,onStroke:({match})=>{if(match){result.className='glyphFreeResult known';result.innerHTML=`${glyphSvg(match,105)}<div><strong>${esc(match.names[0])}</strong>${match.names.length>1?`<small>${match.names.slice(1).map(esc).join(' · ')}</small>`:''}</div>`;state.pad?.setHint(`✓ ${match.names[0]}`);tone(660,0.05,0.018,'sine',840);}else{result.className='glyphFreeResult unknown';result.textContent=t.unknown;state.pad?.setHint(t.unknown);tone(160,0.06,0.018,'square',120);}}});
    state.pad.setBadge(t.noTimer);
  };

  const render=()=>{demoToken++;stopTimer();state.pad?.destroy?.();state.pad=null;if(active==='dictionary')renderDictionary();else if(active==='free')renderFree();else if(active==='simple')renderSimple();else renderArcade();};
  body.querySelectorAll('[data-glyph-tab]').forEach(b=>b.onclick=()=>{active=b.dataset.glyphTab;body.querySelectorAll('[data-glyph-tab]').forEach(x=>x.classList.toggle('active',x===b));render();});
  render();
  return ()=>{destroyed=true;demoToken++;stopTimer();state.pad?.destroy?.();state.pad=null;};
}

