import { Capacitor, CapacitorHttp } from '@capacitor/core';
const NEWS='https://ingress.com/news';
const C={
 en:{title:'INTELLIGENCE FEED',sub:'Official Ingress transmissions',refresh:'Refresh',news:'High priority',events:'Latest news',source:'Original source',translate:'Translate page',empty:'No transmission.',offline:'Offline · cached feed',priority:'HIGH PRIORITY'},
 fr:{title:'FLUX DE RENSEIGNEMENT',sub:'Transmissions officielles Ingress',refresh:'Actualiser',news:'Haute priorité',events:'Dernières actualités',source:'Source originale',translate:'Traduire la page',empty:'Aucune transmission.',offline:'Hors ligne · flux en cache',priority:'HAUTE PRIORITÉ'},
 it:{title:'FLUSSO INTELLIGENCE',sub:'Trasmissioni ufficiali Ingress',refresh:'Aggiorna',news:'Alta priorità',events:'Ultime notizie',source:'Fonte originale',translate:'Traduci la pagina',empty:'Nessuna trasmissione.',offline:'Offline · feed in cache',priority:'ALTA PRIORITÀ'},
 es:{title:'FLUJO DE INTELIGENCIA',sub:'Transmisiones oficiales de Ingress',refresh:'Actualizar',news:'Alta prioridad',events:'Últimas noticias',source:'Fuente original',translate:'Traducir página',empty:'Sin transmisiones.',offline:'Sin conexión · feed en caché',priority:'ALTA PRIORIDAD'},
 pt:{title:'FLUXO DE INTELIGÊNCIA',sub:'Transmissões oficiais do Ingress',refresh:'Atualizar',news:'Alta prioridade',events:'Últimas notícias',source:'Fonte original',translate:'Traduzir página',empty:'Sem transmissões.',offline:'Offline · feed em cache',priority:'ALTA PRIORIDADE'},
 de:{title:'INTELLIGENCE FEED',sub:'Offizielle Ingress-Übertragungen',refresh:'Aktualisieren',news:'Hohe Priorität',events:'Neueste Meldungen',source:'Originalquelle',translate:'Seite übersetzen',empty:'Keine Übertragung.',offline:'Offline · Feed im Cache',priority:'HOHE PRIORITÄT'},
 nl:{title:'INTELLIGENCE FEED',sub:'Officiële Ingress-transmissies',refresh:'Vernieuwen',news:'Hoge prioriteit',events:'Laatste nieuws',source:'Originele bron',translate:'Pagina vertalen',empty:'Geen transmissie.',offline:'Offline · feed in cache',priority:'HOGE PRIORITEIT'}
};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function get(url){if(Capacitor.isNativePlatform()){const r=await CapacitorHttp.get({url});return String(r.data||'');}const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw Error(String(r.status));return await r.text()}
function absolute(href){try{return new URL(href,NEWS).href}catch{return NEWS}}
function translateUrl(url,lang){const tl=({zh:'zh-CN','zh-hant':'zh-TW',yue:'zh-TW'}[lang]||lang||'en');return `https://translate.google.com/translate?sl=auto&tl=${encodeURIComponent(tl)}&u=${encodeURIComponent(url)}`}
function parseIndex(html){
 const doc=new DOMParser().parseFromString(html,'text/html');
 const links=[...doc.querySelectorAll('a[href*="/news/"]')].map(a=>({title:(a.textContent||'').replace(/\s+/g,' ').trim(),url:absolute(a.getAttribute('href'))})).filter(x=>x.title.length>2&&!/^news$/i.test(x.title));
 const uniq=[];for(const x of links)if(!uniq.some(y=>y.url===x.url))uniq.push(x);
 // ingress.com/news currently exposes the four HIGH PRIORITY cards before All News.
 return {priority:uniq.slice(0,4),all:uniq.slice(4,14).filter(x=>!uniq.slice(0,4).some(p=>p.url===x.url))};
}
function articleSummary(html){
 const doc=new DOMParser().parseFromString(html,'text/html');
 const main=doc.querySelector('main')||doc.body;
 const paras=[...main.querySelectorAll('p,li')].map(x=>(x.textContent||'').replace(/\s+/g,' ').trim()).filter(x=>x.length>35&&!/health and security|ongoing updates|world around you/i.test(x));
 return paras.slice(0,2).join(' ').slice(0,360);
}
async function enrich(items){return Promise.all(items.map(async x=>{try{return {...x,summary:articleSummary(await get(x.url))}}catch{return {...x,summary:''}}}))}
function card(x,t,lang,priority=false){return `<article class="ritaFeedCard ${priority?'priority':''}"><small>${priority?'⚠ '+esc(t.priority):'NIA // INGRESS'}</small><b>${esc(x.title)}</b>${x.summary?`<p>${esc(x.summary)}</p>`:''}<div class="ritaFeedActions"><a href="${esc(translateUrl(x.url,lang))}" target="_blank">🌐 ${esc(t.translate)}</a><a href="${esc(x.url)}" target="_blank">↗ ${esc(t.source)}</a></div></article>`}
export async function renderRitaFeed(host,lang='en'){
 const t=C[lang]||C.en;host.innerHTML=`<section class="ritaFeed"><div class="ritaFeedHead"><div><small>RITA // LIVE</small><h2>${esc(t.title)}</h2><p>${esc(t.sub)}</p></div><button class="ritaFeedRefresh">↻ ${esc(t.refresh)}</button></div><div class="ritaFeedStatus">RX…</div><div class="ritaFeedCols"><div><h3>${esc(t.news)}</h3><div class="ritaNewsList"></div></div><div><h3>${esc(t.events)}</h3><div class="ritaEventList"></div></div></div></section>`;
 const status=host.querySelector('.ritaFeedStatus'),news=host.querySelector('.ritaNewsList'),events=host.querySelector('.ritaEventList');
 const paint=data=>{news.innerHTML=data.priority.length?data.priority.map(x=>card(x,t,lang,true)).join(''):`<div class="ritaFeedEmpty">${esc(t.empty)}</div>`;events.innerHTML=data.all.length?data.all.map(x=>card(x,t,lang,false)).join(''):`<div class="ritaFeedEmpty">${esc(t.empty)}</div>`};
 const load=async()=>{status.textContent='RX…';try{const idx=parseIndex(await get(NEWS));const data={priority:await enrich(idx.priority),all:await enrich(idx.all)};paint(data);localStorage.setItem('rbl.rita.news.v2',JSON.stringify({at:Date.now(),...data}));status.textContent=`● ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;}catch(e){const old=JSON.parse(localStorage.getItem('rbl.rita.news.v2')||'null');status.textContent=t.offline;if(old)paint(old)}};
 host.querySelector('.ritaFeedRefresh').onclick=load;await load();
}
