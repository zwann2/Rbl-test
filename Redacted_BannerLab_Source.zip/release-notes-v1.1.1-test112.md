# Redacted BannerLab v1.1.1-test.112

- REDACTED RUN : zone de jeu agrandie, saut déclenché dès pointerdown, toute l’arène et 150 px sous celle-ci acceptent le saut.
- RITA Intelligence Feed : cartes événement localisées, dates lisibles, boutons distincts « Traduire la page » et « Source originale ».
- Traduction de secours : ouverture de la source via Google Translate dans la langue RBL ; aucune clé API embarquée.
- Traductions locales révisées pour les événements actuellement connus (FR/IT/ES/PT/DE/NL), anglais conservé comme source/fallback.
- Android TEST : versionCode 2100011112.
