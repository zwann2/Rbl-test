# Redacted BannerLab v1.1.1-test.105

- Inventaire : remplacement des pictogrammes maison par les assets Ingress communautaires `le-jeu/ingress-items`, épinglés sur le commit `62618d18af81cc4f31e8fed0b6294781a68768f4`.
- Mods : variantes Common / Rare / Very Rare distinctes, avec leurs couleurs d'origine.
- Objets à niveau : silhouette source authentique, couleur de niveau appliquée uniquement à l'objet et au petit repère de niveau ; suppression de l'effet « stabilo » sur toute la carte.
- Clés manuelles : l'ajout d'un lien ne déclenche plus une résolution Intel immédiate. Le bouton de synchronisation traite les portails en attente en lot.
