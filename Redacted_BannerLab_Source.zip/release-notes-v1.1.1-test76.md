# Redacted BannerLab 1.1.1 TEST-76 CLEAN

- Glyph Lab : le tracé visible n'est plus la trajectoire libre du doigt.
- Le trait apparaît uniquement lorsqu'un nœud est effectivement traversé.
- Les nœuds validés sont reliés par des segments nets, comme dans Prime.
- Ajout d'un flux lumineux animé dans les segments déjà validés pour simuler le passage d'énergie.
- La tête lumineuse reste sur le dernier nœud reconnu, elle ne tremble plus sous le doigt.
- Détection invisible conservée entre les événements tactiles pour ne pas rater les nœuds lors d'un geste rapide.
- Démonstration des glyphes avec flux d'énergie animé.
- Compte à rebours Glyph Lab : 3 / 2 / 1 / GO plus court ; contrôle rendu presque immédiatement après GO.
- Compte à rebours des jeux Arcade : 3 / 2 / 1 / GO accéléré et lancement immédiat.
- Restauration du véritable easter egg Redacted après 7 clics : dialogues, compteur fiable, réactions contextuelles et raretés.
- IGOR : métadonnées visibles harmonisées en 0.6.36.
- Android versionCode : 2100011076.
