# Redacted BannerLab v1.1.1-test.110

- Arcade : REDACTED RUN devient un endless runner à saut unique, avec accélération progressive et obstacles de la faction adverse.
- RITA : ajout d’un Intelligence Feed dans son étage, alimenté par les pages officielles Ingress News et Events, avec cache hors-ligne.
- Traductions : toute nouvelle interface du feed est localisée dans les langues prioritaires et retombe en anglais pour les autres langues prises en charge ; le contenu officiel externe reste identifié comme contenu source afin de ne pas inventer une traduction officielle.
- Android versionCode : 2100011110.
