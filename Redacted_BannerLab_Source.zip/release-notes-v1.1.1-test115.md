# Redacted BannerLab v1.1.1-test.115

- Papy Redacted : popup Scanner compact avec visuels dédiés ENL / RES.
- Habillage automatiquement adapté à la faction.
- Anecdote suivante au toucher dans le panneau ; fermeture au toucher à l’extérieur.
- Base prévue pour faire tourner plusieurs scènes de Papy Redacted par groupes d’anecdotes.
- Android TEST : versionCode 2100011115.
