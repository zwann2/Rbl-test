# Redacted BannerLab v1.1.1-test.115

- Papy Redacted : popup Scanner compact avec visuels dédiés ENL / RES.
- Habillage automatiquement adapté à la faction.
- Anecdote suivante au toucher dans le panneau ; fermeture au toucher à l’extérieur.
- Base prévue pour faire tourner plusieurs scènes de Papy Redacted par groupes d’anecdotes.
- Android TEST : versionCode 2100011117.
- Papy Redacted : 12 scènes ENL + 12 scènes RES nettoyées, sans texte ni logos générés ; les vrais éléments HUD/faction sont superposés par le code.
- Une scène est conservée pendant 20 anecdotes avant rotation vers la suivante.

- Papy Redacted : une scène ENL/RES est désormais choisie à chaque anecdote parmi les 12 visuels de la faction, sans répéter immédiatement la même image.
- Android versionCode : 2100011117.
